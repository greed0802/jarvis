# Excluded Runtime Data Manifest

| path | action |
| --- | --- |
| jarvis_v5/data/conversations/alpha35_10_2_write_preview.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/conversations/alpha35_10_2_feedback_preview.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/conversations/alpha35_10_2_real_preview.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/active_tasks/task_9b59800a8ab349e698b7e6418b320a33.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/active_tasks/task_0da05cbda4cf42a3b5f2617786eea7fc.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/active_tasks/task_1ac37d433d334bbf81f5570b0c66c652.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/events/alpha35_10_2_write_preview.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/events/alpha35_10_2_feedback_preview.json | excluded_from_release_staging_not_deleted_from_source |
| jarvis_v5/data/events/alpha35_10_2_real_preview.json | excluded_from_release_staging_not_deleted_from_source |

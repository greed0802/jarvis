# Manifest Current Release — alpha46.3R81

Package: Dhanrick_Jarvis_v5_0_0_alpha_46_3R81_Route_Class_Policy_Static_Evaluator_Assertion_Coverage_Boundary.zip
Version: v5.0.0-alpha.46.3R81
Base: v5.0.0-alpha.46.3R80
Previous clean checkpoint: v5.0.0-alpha.46.3R79R1
Rejected candidate: v5.0.0-alpha.46.3R77
Rollback: v5.0.0-alpha.46.3R73
Status: built_pending_review

Boundary: assertion coverage evidence only.

Changed files are limited to metadata, documentation, SourceOfTruth metadata cells, smoke test/evidence pack, manifest, and evidence outputs.

# Roadmap After Alpha 37.12

## Recommended sequence
- alpha37.13 — JSON/docs-only Fixture Evidence Package
- alpha37.14 — Fixture Evidence Coverage Review
- alpha37.15 — Optional implementation readiness plan, still no runtime
- alpha37.16 — Optional implementation dry run, only if separately approved

## Rule
Do not jump to runtime implementation. Continue metadata-first, contract-first, permission-first, approval-before-execution, and preview-before-export discipline.

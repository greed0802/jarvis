# Metadata Bridge Protected Route and Runtime Boundaries

Protected files and systems:
- app.py
- route modules
- permission-gate modules
- owner-wrapper modules
- registry_loader.py
- Builder runtime
- Formatter runtime
- QA runtime
- O&A runtime
- Document Reader runtime
- Output Center runtime
- Job runtime
- safe path resolver
- preview policy
- static/UI

Any future edit to these requires separate explicit PLAN, DRY RUN, FIRE, and REVIEW.
No protected route/runtime boundary is changed in alpha38.7.

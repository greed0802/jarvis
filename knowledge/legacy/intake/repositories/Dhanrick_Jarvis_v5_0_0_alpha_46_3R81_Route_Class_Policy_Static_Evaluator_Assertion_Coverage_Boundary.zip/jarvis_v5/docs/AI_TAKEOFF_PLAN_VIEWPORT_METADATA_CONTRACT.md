# AI Takeoff Plan Viewport Metadata Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines the future plan viewport metadata contract without implementing a viewport. A viewport metadata contract does not authorize rendering, reading, or inspecting drawing content.

## Allowed metadata example

```json
{
  "viewport_id": "viewport_meta_001",
  "selected_plan_id": "plan_meta_001",
  "safe_display_name": "A-105 Level 05 Floor Plan",
  "discipline": "architectural",
  "drawing_type": "floor_plan",
  "revision_label": "Rev C",
  "viewport_status": "metadata_only_placeholder",
  "drawing_content_loaded": false,
  "image_rendered": false,
  "pdf_rendered": false,
  "ocr_available": false,
  "measurement_enabled": false,
  "takeoff_engine_enabled": false
}
```

## Allowed viewport labels

- No drawing loaded
- Metadata-only placeholder
- Permission required before drawing read
- Takeoff engine disabled
- OCR disabled
- Measurement disabled

## Blocked viewport content

PDF/image bitmap, rendered drawing page, thumbnail derived from drawing content, drawing geometry, OCR text, vector entities, coordinates, scale-derived data, measurement overlays, takeoff marks, and quantity result overlays are blocked.

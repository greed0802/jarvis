# Auth Functional Verification Contract — alpha46.3R13

**Version:** v5.0.0-alpha.46.3R13  
**Base:** v5.0.0-alpha.46.3R12  
**Mode:** Contract-only functional verification permission boundary  
**Runtime behavior changed:** false  
**Functional tests executed in R13:** false

## Purpose

R12 implemented the minimal API-key boundary for protected routes using the R11 route matrix. R12 was intentionally verified by static evidence only. R13 does not execute runtime tests. R13 defines the exact permission boundary for a future controlled functional verification phase.

This contract follows the current architecture rule: **contracts before execution, permission before runtime access, approval before execution**.

## R13 Non-Execution Commitments

R13 must not perform any of the following:

- runtime import
- `jarvis_v5.app` import
- FastAPI TestClient execution
- API route calls
- workbook read
- workbook content read
- workbook execution
- Builder execution
- Formatter execution
- QA Checker execution
- Output Center export
- Job Center execution
- tool execution
- OCR
- drawing/PDF/image read
- document read
- external network access

## Future Functional Verification Permission Boundary

A later explicitly approved target may perform controlled auth-boundary functional checks only if the user authorizes runtime import, `app.py` import, FastAPI TestClient, and selected API route calls.

The later verification must be limited to proving auth boundary behavior. It must not prove workbook, Builder, Formatter, QA, Output Center, Job Center, tool, OCR, drawing, document, or business execution behavior.

## Allowed Future Temporary Environment Setup

Only this environment variable may be set during a future functional auth verification test:

```text
JARVIS_API_KEY=accepted-test-key
```

Rules:

- set only inside the test scope
- do not persist to project files
- do not write to `.env`
- do not print or echo the key
- restore previous environment state after test

## Future Request Header Samples

A future verification may use only these auth header forms:

```text
no key
X-Jarvis-API-Key: invalid
X-Jarvis-API-Key: accepted-test-key
Authorization: Bearer accepted-test-key
```

## Future Route Sample Matrix

### Public route sample

```text
GET /api/version
```

Expected later: without key, response is not `401 auth_required`.

### Protected missing-key samples

```text
GET /api/events/test-conversation
GET /api/state/test-conversation
GET /api/plan/test-conversation
```

Expected later: safe `401` envelope with:

```json
{
  "ok": false,
  "error": "auth_required",
  "auth_required": true,
  "authenticated": false,
  "execution_enabled": false,
  "workbook_read": false,
  "workbook_content_read": false,
  "tool_execution_performed": false,
  "engine_called": false,
  "excel_created": false
}
```

### Protected invalid-key sample

```text
GET /api/events/test-conversation
X-Jarvis-API-Key: invalid
```

Expected later: same safe `401 auth_required` envelope.

### Protected valid-key samples

```text
GET /api/events/test-conversation
X-Jarvis-API-Key: accepted-test-key

GET /api/events/test-conversation
Authorization: Bearer accepted-test-key
```

Expected later: not blocked by the auth boundary. The test must not require business-success status, because a protected handler may validly return route-specific validation, state, or not-found output after auth passes.

### Dev/debug guard samples

```text
GET /api/debug/pending-clarification/test-conversation
POST /api/dev/validate-test-pack
```

Expected later: not intercepted by the R12 auth boundary. These routes remain governed by the existing R7 `DEBUG_MODE` guard behavior.

### Unknown route sample

```text
GET /api/not-a-real-route
```

Expected later: normal FastAPI `404`, not `401 auth_required`.

## Forbidden Future Assertions

Future functional checks must not assert any workbook, Builder, Formatter, QA, Output Center, Job Center, tool, OCR, drawing/PDF/image, document, or business success behavior.

Future valid-key checks may assert only that the auth boundary did not return `401 auth_required`.

## Forbidden R13 File Changes

R13 must not change:

- `jarvis_v5/app.py`
- route decorators
- route handlers
- Builder modules
- Formatter modules
- QA Checker modules
- Output Center modules
- Job Center modules
- safe path resolver runtime
- workbook policy runtime
- preview policy
- active-task guards
- `requirements.txt`
- registries
- CORS
- rate limiting
- upload/text validation implementation
- saved_path schema implementation
- EventLedger storage
- MainRouter routing
- AttachmentMeta
- AttachmentStore

## Inherited R10 Evidence Note

A known inherited R10 smoke-test reference to the Source of Truth tracker remains non-blocking. R13 must report it separately and add zero new Python Source of Truth tracker references.

## Stop Conditions

Stop before any future functional verification if any of the following becomes necessary:

- changing `app.py`
- changing route decorators, paths, methods, or handlers
- changing `requirements.txt`
- changing registries
- running workbook or tool execution
- reading uploaded workbook/document/drawing content
- executing Output Center or Job Center
- relying on business-success status for a valid-key protected route
- exposing an API key, header value, environment value, path, traceback, saved path, workbook content, or tool result

## R13 Expected Evidence

R13 expected evidence:

- docs/static-test/manifest additions only
- Source of Truth tracker updated last
- `app.py` hash unchanged from R12
- route count unchanged at 43
- R12 middleware count unchanged at 1
- no runtime import
- no `app.py` import
- no TestClient execution
- no API route calls
- no workbook/tool/output/job execution

## Explicit Forbidden Change Keywords

For static verification clarity, R13 forbids dependency changes, registry changes, and route changes.

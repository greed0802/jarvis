# Manifest-only Metadata Blocked Fields

Version: v5.0.0-alpha.37.10

The following remain blocked in alpha37.10:

- sheet_count
- workbook_properties_from_file
- workbook_container_metadata
- worksheet_dimensions
- workbook_content
- cell_values
- formulas
- cached_formula_values
- styles
- named_ranges
- tables
- merged_cells
- comments
- VBA/macros
- external links
- defined names
- pivot tables
- charts
- images
- embedded objects
- hidden sheets
- sheet visibility
- data validation
- conditional formatting
- Builder execution
- Formatter execution
- QA execution
- O&A execution
- Document Reader execution
- Job runtime
- Output runtime
- tool execution
- production/user workbook access

## Sheet count rule

Sheet count remains blocked/future gated because it may require workbook-container inspection. It is not approved for alpha37.10 dry-run implementation or runtime behavior.

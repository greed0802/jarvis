# Namespace Migration Regression Test Plan

Before any actual `jarvis_v5` to `jarvis_app` rename, run and pass:

- import smoke test
- pytest discovery test
- smoke runner pack path test
- start script path test
- protected hash path remap test
- changed files report path remap test
- external regression path expectation test
- root artifact scan
- old-version residue scan
- hyphen path scan
- package hygiene scan
- retained alpha pack replay
- external regression sample replay

## Required rename safety checks

- all runtime imports updated
- all tests updated
- all smoke packs path references handled
- protected hash manifests remapped or regenerated
- root historical reports archived, not deleted
- one canonical current handoff retained

## Alpha36.6 status

Test plan only. No rename performed.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

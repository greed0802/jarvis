# Isolated Metadata Adapter Protected Files Policy

Protected files must remain untouched:
- jarvis_v5/app.py
- jarvis_v5/config.py
- jarvis_v5/registry/registry_loader.py
- permission-gate modules
- owner-wrapper modules
- route modules
- Builder runtime modules
- Formatter runtime modules
- QA runtime modules
- O&A runtime modules
- Document Reader runtime modules
- Output Center runtime modules
- Job runtime modules
- safe path resolver
- preview policy
- static/UI
- inherited workbook fixture files

Any protected file edit requires separate explicit approval. Any unexpected protected hash change blocks acceptance.

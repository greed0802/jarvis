# Jarvis Local Evidence Runner Script Contract — alpha39.9

Target: v5.0.0-alpha.39.9-batch  
Base: v5.0.0-alpha.39.8-batch  
Status: metadata contract only. No actual runner script is implemented in alpha39.9.

## Purpose

This document defines the first future `tools/jarvis_evidence_runner.py` contract as a static, deterministic, local-only evidence utility. It is intended to reduce full ZIP review overhead while preserving Jarvis protected boundaries.

## Script Boundary

The future local evidence runner must be:

- static
- local-only
- deterministic
- read-only over packages/source trees
- package/file based
- no runtime import
- no endpoint calls
- no workbook, drawing, OCR, or takeoff behavior

## Allowed Future Behavior

The future script may:

- read file names
- read safe text files for static scans
- read ZIP central directory metadata
- verify ZIP integrity
- calculate SHA256 hashes
- compare base-vs-target file lists
- compare protected file hashes
- scan text for forbidden enablement patterns
- count static route decorators in source text
- write JSON and Markdown evidence reports

## Forbidden Future Behavior

The future script must not:

- import jarvis_v5.app
- import app.py
- instantiate FastAPI app
- use FastAPI TestClient
- No FastAPI TestClient may be used by the future runner unless a later scoped runtime-test phase explicitly allows it.
- call endpoints
- open workbook files
- No workbook open or workbook container inspection may be performed.
- inspect workbook containers
- read PDF/image/drawing files
- perform OCR
- call takeoff engine
- execute Builder
- execute Formatter
- execute QA Checker
- execute O&A
- write quantities
- modify source files
- modify release packages

## Alpha39.9 Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "local_script_implemented": false,
  "local_script_execution_allowed": false,
  "local_script_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "workbook_opened": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "route_added": false,
  "endpoint_added": false,
  "protected_systems_touched": false
}
```

## Stop Conditions

Stop immediately if any future implementation proposal requires runtime import, endpoint calls, workbook/drawing/PDF/image access, OCR, takeoff execution, source mutation, route additions, or UI implementation without explicit scoped approval.

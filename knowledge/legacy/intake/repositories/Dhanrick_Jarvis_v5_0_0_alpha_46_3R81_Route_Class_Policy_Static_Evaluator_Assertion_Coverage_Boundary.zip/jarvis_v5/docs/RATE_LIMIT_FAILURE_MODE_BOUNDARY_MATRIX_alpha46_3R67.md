# Rate Limit Failure Mode Boundary Matrix

**Version:** `v5.0.0-alpha.46.3R67`  
**Base:** `v5.0.0-alpha.46.3R66`  
**Mode:** Evidence-only boundary matrix  
**Rollback:** `v5.0.0-alpha.46.3R66`

## Purpose

This checkpoint defines the failure-mode boundary matrix required before any future rate-limit failure behavior can be selected or implemented.

R67 is a contract checkpoint only. It does not select fail-open, fail-closed, backend outage behavior, timeout behavior, retry behavior, partial read/write behavior, clock-skew behavior, state-corruption behavior, limiter fallback behavior, or any rate-limit runtime behavior.

## Boundary lock

```text
failure_mode_boundary_matrix_exists=true
failure_mode_boundary_matrix_only=true
failure_candidate_classes_defined=true
fail_open_boundary_defined=true
fail_closed_boundary_defined=true
backend_outage_boundary_defined=true
timeout_boundary_defined=true
retry_boundary_defined=true
partial_read_failure_boundary_defined=true
partial_write_failure_boundary_defined=true
partial_read_write_boundary_defined=true
clock_skew_boundary_defined=true
state_corruption_boundary_defined=true
limiter_fallback_boundary_defined=true
fallback_boundary_defined=true
failure_error_response_boundary_defined=true
observability_boundary_defined=true
fail_open_selected=false
fail_closed_selected=false
failure_behavior_selected=false
failure_behavior_implemented=false
rate_limit_implementation=false
```

## Candidate failure classes

| Failure class | R67 status | Future decision required |
|---|---:|---|
| Backend unavailable | Candidate only | Decide safe route-class behavior during backend outage. |
| Backend timeout | Candidate only | Decide whether timeout equals outage or has a separate response. |
| Partial read failure | Candidate only | Decide behavior when quota state cannot be read. |
| Partial write failure | Candidate only | Decide behavior when request is allowed but counter update fails. |
| Retry exhaustion | Candidate only | Decide whether retries are allowed and when they stop. |
| Clock skew | Candidate only | Decide clock source, skew tolerance, and window authority. |
| State corruption | Candidate only | Decide behavior for malformed counters or quota windows. |
| Identity-key unavailable | Candidate only | Decide safe behavior when no approved identity key exists. |
| Configuration missing | Candidate only | Decide behavior when approved backend configuration is absent. |
| Dependency import failure | Candidate only | Decide behavior if a future dependency cannot import. |
| Middleware ordering conflict | Candidate only | Decide safe behavior if future middleware ordering is unsafe. |
| Unknown failure | Candidate only | Decide default behavior for unclassified failure. |

No failure behavior is selected in this checkpoint.

## Fail-open candidate boundary

```text
fail_open_candidate=true
fail_open_boundary_defined=true
fail_open_selected=false
fail_open_implemented=false
```

Future approval must determine which route classes may ever fail open, whether authenticated/public/upload/tool/output/job routes differ, whether fail-open requires elevated observability, whether fail-open is temporary only, and what abuse blast-radius controls are required.

## Fail-closed candidate boundary

```text
fail_closed_candidate=true
fail_closed_boundary_defined=true
fail_closed_selected=false
fail_closed_implemented=false
```

Future approval must determine which route classes may fail closed, whether health/status routes are excluded, whether valid users could be blocked, whether the normal error envelope applies, and whether retry-after headers are required.

## Backend outage boundary

```text
backend_outage_boundary_defined=true
backend_outage_behavior_selected=false
backend_outage_behavior_implemented=false
```

Future outage review fields:

```text
backend_type
outage_scope
affected_route_class
affected_identity_class
observed_error_category
safe_default_candidate
user_response_candidate
operator_alert_candidate
rollback_path
manual_override_allowed
```

No backend outage behavior is selected in R67.

## Timeout boundary

```text
timeout_boundary_defined=true
timeout_duration_selected=false
timeout_behavior_selected=false
timeout_behavior_implemented=false
```

Future timeout review must define timeout threshold, route-class-specific timeout, backend-specific timeout, whether timeout equals outage, response candidate, and redacted logging category.

## Retry boundary

```text
retry_boundary_defined=true
retry_count_selected=false
retry_backoff_selected=false
retry_behavior_implemented=false
```

Future retry review must define whether retries are allowed, maximum retry count, backoff policy, jitter policy, timeout cap, load impact, and outage amplification risk.

## Partial read failure boundary

```text
partial_read_failure_boundary_defined=true
partial_read_behavior_selected=false
partial_read_behavior_implemented=false
```

Future review must decide whether quota-read failure equals outage, whether unknown quota blocks or allows the request, and whether route class changes the decision.

## Partial write failure boundary

```text
partial_write_failure_boundary_defined=true
partial_write_behavior_selected=false
partial_write_behavior_implemented=false
```

Future review must decide whether counter-write failure triggers degraded mode, whether already-allowed requests are rolled back, whether it requires alerting, and whether it can create quota bypass.

## Clock skew boundary

```text
clock_skew_boundary_defined=true
clock_source_selected=false
clock_skew_behavior_implemented=false
```

Future review must define server time source, backend time source, window reset authority, multi-worker consistency, maximum tolerated skew, detection evidence, and rollback behavior.

## State corruption boundary

```text
state_corruption_boundary_defined=true
state_corruption_behavior_selected=false
state_corruption_behavior_implemented=false
```

Future review must define malformed counter behavior, negative counter behavior, expired key behavior, unexpected window format behavior, identity-key collision handling, manual reset behavior, and operator audit behavior.

## Limiter fallback boundary

```text
limiter_fallback_boundary_defined=true
limiter_fallback_selected=false
limiter_fallback_implemented=false
fallback_route_behavior_changed=false
```

Candidate fallback states remain unselected:

```text
fallback_to_no_rate_limit
fallback_to_static_denial
fallback_to_route_class_policy
fallback_to_anonymous_bucket
fallback_to_manual_review
fallback_to_maintenance_mode
fallback_to_existing_error_envelope
```

## Error response and observability boundary

```text
failure_error_response_boundary_defined=true
failure_error_envelope_selected=false
failure_error_envelope_implemented=false
observability_boundary_defined=true
observability_logging_implemented=false
```

Future response fields remain unresolved:

```text
status_code_candidate
error_code_candidate
user_message_candidate
retry_after_header_candidate
correlation_id_candidate
route_class
failure_category
redaction_level
```

Raw logging remains blocked:

```text
raw_api_key_logged=false
raw_token_logged=false
raw_ip_logged=false
raw_identity_key_logged=false
raw_backend_secret_logged=false
request_payload_logged=false
workbook_content_logged=false
document_content_logged=false
ocr_content_logged=false
```

## Policy decisions still unresolved

```text
fail_open_selection_unresolved=true
fail_closed_selection_unresolved=true
route_class_specific_failure_behavior_unresolved=true
backend_outage_behavior_unresolved=true
timeout_threshold_unresolved=true
retry_count_unresolved=true
retry_backoff_unresolved=true
partial_read_behavior_unresolved=true
partial_write_behavior_unresolved=true
clock_source_unresolved=true
clock_skew_tolerance_unresolved=true
state_corruption_behavior_unresolved=true
limiter_fallback_behavior_unresolved=true
error_envelope_shape_unresolved=true
retry_after_header_behavior_unresolved=true
observability_logging_unresolved=true
alerting_behavior_unresolved=true
manual_override_behavior_unresolved=true
dependency_selection_unresolved=true
backend_selection_unresolved=true
identity_key_implementation_unresolved=true
route_limit_values_unresolved=true
route_exemptions_unresolved=true
middleware_ordering_unresolved=true
cors_interaction_unresolved=true
```

## Middleware-count gate

```text
middleware_count_gate_defined=true
middleware_count=1
middleware_delta=0
future_middleware_count_approval_required=true
```

Failure-mode planning does not imply middleware approval. Future rate-limit middleware requires separate PLAN plus FIRE and middleware-count approval.

## Nonimplementation lock

```text
api_key_extraction_implementation=false
backend_client_implementation=false
backend_outage_behavior_implementation=false
burst_window_policy_implementation=false
cache_backend_selection=false
clock_skew_behavior_implementation=false
cors_implementation=false
default_limit_policy_implementation=false
dependency_installation=false
dependency_selection=false
environment_variable_implementation=false
error_envelope_implementation=false
fail_closed_selection=false
fail_open_fail_closed_implementation=false
fail_open_selection=false
failure_behavior_implementation=false
forwarded_header_trust_implementation=false
identity_key_implementation=false
in_memory_limiter_selection=false
ip_extraction_implementation=false
limiter_fallback_implementation=false
limiter_library_selection=false
middleware_addition=false
middleware_configuration_change=false
observability_logging_implementation=false
partial_read_write_behavior_implementation=false
per_route_limit_policy_implementation=false
rate_limit_implementation=false
redis_selection=false
request_schema_modification=false
request_validation_implementation=false
requirements_txt_modification=false
retry_behavior_implementation=false
route_behavior_modification=false
route_exemption_activation=false
route_grouping_implementation=false
route_limit_value_selection=false
state_corruption_behavior_implementation=false
storage_backend_selection=false
timeout_behavior_implementation=false
user_session_identity_implementation=false
```

## Future gates

```text
future_failure_mode_selection_requires_separate_plan_plus_fire=true
future_fail_open_fail_closed_selection_requires_separate_plan_plus_fire=true
future_backend_outage_behavior_requires_separate_plan_plus_fire=true
future_timeout_retry_behavior_requires_separate_plan_plus_fire=true
future_limiter_fallback_behavior_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
future_middleware_count_approval_required=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

## Protected logic not touched

```text
builder_formula_export_engine_touched=false
workbook_policy_runtime_touched=false
preview_policy_touched=false
active_task_writing_report_guards_touched=false
safe_path_resolver_touched=false
output_center_runtime_touched=false
job_center_runtime_touched=false
ai_takeoff_execution_touched=false
document_reader_touched=false
ocr_touched=false
tool_execution_touched=false
app_py_modified=false
router_main_router_modified=false
requirements_txt_modified=false
route_behavior_modified=false
middleware_configuration_changed=false
auth_runtime_modified=false
global_exception_envelope_modified=false
```

## Review requirement

R67 must be reviewed before acceptance. Until REVIEW passes, `v5.0.0-alpha.46.3R66` remains the accepted rollback checkpoint.

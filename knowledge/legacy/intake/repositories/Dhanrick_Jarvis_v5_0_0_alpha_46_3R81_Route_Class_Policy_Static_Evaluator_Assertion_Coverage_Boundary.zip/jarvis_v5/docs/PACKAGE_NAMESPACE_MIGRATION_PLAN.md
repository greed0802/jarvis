# Package Namespace Migration Plan

Current namespace: `jarvis_v5`.
Proposed future namespace: `jarvis_app`.

Alpha36.6 action: inventory and plan only.

```text
current_namespace=jarvis_v5
future_namespace_candidate=jarvis_app
migration_mode=staged
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
```

## Options

### Option A — Keep `jarvis_v5` internal

Keep the code namespace stable and use `Jarvis App` / `Jarvis AI Workbench` only as product/display names.

Risk: lowest.

### Option B — Full rename to `jarvis_app`

Rename folder and update imports, tests, smoke runner, reports, start scripts, hash manifests, and external expectations.

Risk: high until migration tests exist.

### Option C — Temporary compatibility alias

Create a temporary `jarvis_v5` alias forwarding to `jarvis_app` after migration only if external compatibility requires it.

Risk: medium; may hide incomplete migration.

### Option D — Defer rename until after workbook governance

Return to Unified Workbook Permission Gate first and revisit namespace after runtime governance is stable.

## Recommendation

Do not rename in alpha36.6. First complete artifact cleanup and migration readiness tests.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

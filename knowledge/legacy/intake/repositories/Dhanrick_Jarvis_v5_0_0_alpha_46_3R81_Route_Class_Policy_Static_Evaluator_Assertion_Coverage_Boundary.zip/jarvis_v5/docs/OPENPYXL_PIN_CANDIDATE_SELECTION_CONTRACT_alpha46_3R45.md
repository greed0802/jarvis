# v5.0.0-alpha.46.3R45 — openpyxl Pin Candidate Selection Contract

**Mode:** FIRE evidence artifact  
**Base:** `v5.0.0-alpha.46.3R44`  
**Target:** `v5.0.0-alpha.46.3R45`  
**Scope:** candidate selection contract only; no implementation.

## Verdict

This R45 checkpoint defines the contract for selecting a future exact `openpyxl` pin candidate while explicitly not selecting, inventing, applying, or installing that candidate.

R45 does not modify `requirements.txt`, does not add an `openpyxl` pin, does not install dependencies, does not import `openpyxl`, and does not enable workbook behavior.

## Current accepted checkpoint

`v5.0.0-alpha.46.3R44` — openpyxl Pin Implementation Readiness Dry Run.

R44 locked:

- no exact approved `openpyxl` pin candidate was supplied
- `approved_openpyxl_pin_candidate_present=false`
- `approved_openpyxl_pin_candidate_line=null`
- `requirements_txt_change_allowed=false`
- no `requirements.txt` change
- no dependency installation
- no `openpyxl` pin/import/runtime use
- no workbook runtime enablement

## R45 candidate selection contract purpose

R45 answers this question:

> What exact evidence and approval are required before Jarvis may select an `openpyxl` version candidate for a future `requirements.txt` pin?

R45 is a contract checkpoint only. It must not choose a version unless the user explicitly supplies and approves one in a separate phase.

## Candidate status

No exact approved `openpyxl` pin candidate was supplied for R45.

```json
{
  "approved_openpyxl_pin_candidate_present": false,
  "approved_openpyxl_pin_candidate_line": null,
  "candidate_selection_executed": false
}
```

R45 must not invent, fetch, infer, select, or apply a version.

## Candidate-line format

A future candidate line, if explicitly approved, must use exact-version pinning only:

```text
openpyxl==<APPROVED_VERSION>
```

Allowed future candidate shape:

- package name: `openpyxl`
- operator: `==`
- version: explicit approved version only
- one line only
- no extras unless separately approved

Forbidden candidate shapes:

- `openpyxl`
- `openpyxl>=...`
- `openpyxl~=...`
- `openpyxl<...`
- `openpyxl>...`
- wildcard pins
- extras-based candidate lines
- dependency group replacement
- lockfile-only declaration

## Approval evidence required before future candidate selection

Before any future phase can select or apply an `openpyxl` pin candidate, the package must document:

1. explicit user approval of the candidate line
2. the exact candidate line shown before FIRE
3. no automatic web/package-index lookup unless separately approved
4. no dependency installation during candidate selection
5. no `openpyxl` import during candidate selection
6. no workbook open/read/write/container inspection
7. no `requirements.txt` edit until a separate FIRE
8. rollback point identified
9. static diff scope limited to the approved line
10. future REVIEW verifies `requirements.txt` diff exactly

## R45 locked contract facts

```json
{
  "openpyxl_pin_candidate_selection_contract_only": true,
  "selected_after_r44_readiness_dry_run": true,
  "approved_openpyxl_pin_candidate_present": false,
  "approved_openpyxl_pin_candidate_line": null,
  "candidate_selection_executed": false,
  "requirements_txt_changed": false,
  "requirements_txt_change_allowed": false,
  "dependency_installed": false,
  "dependency_changed": false,
  "openpyxl_pin_added": false,
  "openpyxl_present": false,
  "openpyxl_pinned": false,
  "openpyxl_imported": false,
  "openpyxl_runtime_used": false,
  "workbook_runtime_enabled": false,
  "workbook_open_read_write": false,
  "workbook_container_inspected": false,
  "builder_execution_enabled": false,
  "output_center_export_executed": false,
  "job_center_execution": false,
  "route_count": 43,
  "route_delta": 0,
  "middleware_count": 1,
  "future_actual_pin_requires_separate_fire": true,
  "future_candidate_requires_explicit_user_approval": true
}
```

## Dependency non-install policy

R45 preserves:

- no `pip install`
- no dependency resolver execution
- no package lock generation
- no environment mutation
- no import-based dependency probe
- no runtime dependency check
- no CI or deployment dependency change

Future dependency installation requires a separate approval phase.

## Workbook non-enablement guarantees

Candidate selection does not grant permission to:

- read workbook files
- write workbook files
- inspect workbook containers
- evaluate formulas
- execute Builder
- export through Output Center
- run Job Center behavior

R45 preserves:

```json
{
  "workbook_runtime_enabled": false,
  "workbook_open_read_write": false,
  "workbook_container_inspected": false,
  "formula_evaluation_enabled": false,
  "builder_execution_enabled": false,
  "output_center_export_executed": false,
  "job_center_execution": false
}
```

## Route and middleware invariants

- route count remains 43
- route delta remains 0
- middleware count remains 1
- no route added, removed, or modified
- no middleware added, removed, or reordered

## Protected systems not touched

- `requirements.txt`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- schema modules
- Builder formula/export engine
- workbook permission runtime
- workbook policy runtime
- preview/export policy
- Output Center runtime
- Job Center runtime
- auth runtime boundary
- exception envelope boundary
- CORS boundary
- rate-limit boundary
- dependency/openpyxl boundary
- sidecar generator source
- UI/runtime modules

## Stop condition summary

R45 must stop if:

- `requirements.txt` changes
- an `openpyxl` pin is added
- an `openpyxl` candidate version is invented
- dependency installation occurs
- `openpyxl` import/runtime use occurs
- workbook open/read/write/container inspection occurs
- Builder, Output Center, or Job Center execution occurs
- route or middleware counts change
- protected source files change
- sidecars disagree
- package hygiene fails

## Future implementation boundary

A future actual pin remains blocked until separate explicit approval and a separate FIRE.


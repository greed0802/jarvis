# alpha46.3R62 — Rate Limit Route Scope Classification Matrix

Mode: FIRE  
Base: `v5.0.0-alpha.46.3R61R1`  
Target: `v5.0.0-alpha.46.3R62` — Rate Limit Route Scope Classification Matrix  
Rollback: `v5.0.0-alpha.46.3R61R1`

## Purpose

R62 creates an evidence-only route-scope classification matrix required before any future rate-limit implementation.

R62 does not implement rate limiting, select a dependency, install dependencies, select a storage backend, select Redis/cache/in-memory limiter behavior, implement limiter identity key, implement default/per-route/burst-window/fail behavior, implement error envelope, implement observability/logging, add middleware, modify middleware configuration, modify `app.py`, modify `router/main_router.py`, modify route behavior, modify request schema or validation, implement CORS, or modify `requirements.txt`.

R62 classifies route families conceptually only. It does not enumerate live routes by runtime import, app import, TestClient, API calls, or route execution.

## Accepted base context

```text
base_checkpoint=v5.0.0-alpha.46.3R61R1
target_checkpoint=v5.0.0-alpha.46.3R62
R61R1_status=accepted_rate_limit_policy_decision_matrix_reissue
R61R1_route_count=43
R61R1_middleware_count=1
R61R1_rate_limit_implementation=false
R61R1_dependency_selection=false
R61R1_storage_backend_selection=false
R61R1_middleware_addition=false
R61R1_app_router_modification=false
```

## R62 route-scope matrix status

```text
route_scope_classification_matrix_exists=true
route_scope_classification_matrix_only=true
route_classes_defined=true
runtime_enforcement=false
rate_limit_policy_assigned=false
limit_values_selected=false
active_route_exemption_implemented=false
dependency_selected=false
storage_backend_selected=false
middleware_added=false
route_behavior_modified=false
```

## Route classes to classify later

| Route class | R62 classification status | Runtime enforcement | Limit values | Exemption status | Future decision required |
| --- | --- | --- | --- | --- | --- |
| Public / health / status routes | boundary_defined | false | not_selected | undecided | Decide exempt, lightly limited, or globally limited. |
| Auth-protected API routes | boundary_defined | false | not_selected | undecided | Decide identity key and default/per-route policy. |
| Debug / dev / diagnostics routes | boundary_defined | false | not_selected | undecided | Preserve guards; decide whether separately limited or exempt. |
| Upload / attachment routes | boundary_defined | false | not_selected | undecided | Decide upload frequency and payload-risk policy later. |
| AI chat / tool-intent routes | boundary_defined | false | not_selected | undecided | Preserve no tool execution; decide request bucket later. |
| Workbook-disabled routes | boundary_defined | false | not_selected | undecided | Preserve no workbook read/write enablement. |
| Document-disabled / OCR-disabled routes | boundary_defined | false | not_selected | undecided | Preserve no document/OCR enablement. |
| Output Center routes | boundary_defined | false | not_selected | undecided | Preserve no export execution. |
| Job Center routes | boundary_defined | false | not_selected | undecided | Preserve no job execution. |
| Event / ledger / projection routes | boundary_defined | false | not_selected | undecided | Decide read/projection throttling later. |
| Unknown / unclassified fallback routes | boundary_defined | false | not_selected | undecided | Decide default classification rule before implementation. |

## Public route boundary

```text
public_route_boundary_defined=true
public_route_runtime_enforcement=false
public_route_limit_values_selected=false
public_route_exemption_approved=false
health_status_exemption_approved=false
```

Future public-route policy must decide whether health/status/public metadata routes are exempt, lightly limited, or globally limited. R62 does not make that decision.

## Protected route boundary

```text
protected_route_boundary_defined=true
protected_route_runtime_enforcement=false
protected_route_identity_key_implemented=false
protected_route_limit_values_selected=false
auth_failure_behavior_changed=false
```

Future protected-route policy must decide API-key identity, user/session identity, IP/proxy identity, or composite identity. R62 does not implement any identity-key logic.

## Debug / dev route boundary

```text
debug_dev_route_boundary_defined=true
debug_dev_guards_preserved=true
debug_dev_route_behavior_modified=false
debug_dev_rate_limit_exemption_approved=false
future_policy_must_not_weaken_debug_dev_protection=true
```

## Upload / attachment route boundary

```text
upload_attachment_boundary_defined=true
upload_attachment_runtime_enforcement=false
upload_payload_enablement=false
attachment_payload_enablement=false
payload_size_runtime_enforcement=false
upload_route_limit_values_selected=false
```

## AI / tool route boundary

```text
ai_tool_route_boundary_defined=true
tool_execution_enabled=false
ai_takeoff_execution=false
tool_execution_payload_enablement=false
ai_tool_route_runtime_enforcement=false
```

## Workbook / document / OCR-disabled boundary

```text
workbook_disabled_boundary_defined=true
workbook_runtime_enabled=false
workbook_open_read_write=false
workbook_container_inspection=false
document_reader_enabled=false
ocr_enabled=false
future_limiter_must_not_enable_workbook_document_ocr_payloads=true
```

## Exemption boundary

R62 does not approve active exemptions. Future exemption approval requires:

```text
route_class
reason_for_exemption
risk_level
auth_requirement
abuse_risk
observability_requirement
fallback_if_abused
approval_owner
test_evidence_required
```

Current exemption state:

```text
exemption_boundary_defined=true
active_route_exemption_implemented=false
route_exemption_values_selected=false
health_status_exemption_approved=false
dev_route_exemption_approved=false
upload_route_exemption_approved=false
unknown_route_exemption_approved=false
```

## Policy decisions still unresolved

```text
rate_limit_dependency=unresolved
storage_backend=unresolved
identity_key_strategy=unresolved
default_limit_values=unresolved
per_route_override_values=unresolved
burst_window_algorithm=unresolved
fail_open_fail_closed_behavior=unresolved
429_error_envelope_shape=unresolved
retry_after_header_policy=unresolved
observability_logging_policy=unresolved
middleware_ordering=unresolved
cors_interaction=unresolved
route_exemptions=unresolved
test_route_exemptions=unresolved
deployment_multi_worker_behavior=unresolved
```

## Middleware-count gate

```text
current_middleware_count=1
middleware_delta=0
r62_middleware_addition=false
r62_middleware_configuration_change=false
future_middleware_count_approval_required=true
future_rate_limit_middleware_requires_separate_PLAN_plus_FIRE=true
future_cors_implementation_requires_separate_PLAN_plus_FIRE=true
future_cors_implementation_requires_middleware_count_approval=true
```

## Current invariants

```text
route_count=43
route_delta=0
middleware_count=1
middleware_delta=0
active_runtime_rate_limit_token_total=0
```

## Still not approved

```text
rate_limit_implementation=false
rate_limit_dependency_selection=false
rate_limit_dependency_installation=false
rate_limit_storage_backend_selection=false
redis_cache_in_memory_limiter_selection=false
limiter_identity_key_implementation=false
default_limit_policy_implementation=false
per_route_limit_policy_implementation=false
burst_window_policy_implementation=false
fail_open_fail_closed_implementation=false
error_envelope_implementation=false
observability_logging_implementation=false
middleware_addition=false
middleware_configuration_change=false
app_py_modification=false
router_main_router_modification=false
route_behavior_modification=false
request_schema_modification=false
request_validation_implementation=false
chatrequest_schema_implementation=false
cors_implementation=false
requirements_txt_change=false
active_route_exemption_implementation=false
route_limit_value_selection=false
workbook_runtime_enabled=false
workbook_open_read_write=false
workbook_container_inspection=false
builder_execution=false
output_center_export_execution=false
job_center_execution=false
ai_takeoff_execution=false
```

## Authority

```text
source_of_truth_and_accepted_checkpoints_authoritative=true
claude_reference_plan_role=reference_only
```

# Jarvis Stop-On-Failed-Batch Policy

Version label: v5.0.0-alpha.39.4-accelerated-playbook  
Base checkpoint: v5.0.0-alpha.39.3-testmap  
Scope type: docs/reports/metadata only

## Hard rule

If any batch fails:

```text
1. Stop immediately.
2. Do not continue to later batches.
3. Diagnose only the failed batch.
4. Fix only the failed batch if FIRE allows.
5. Retest the failed batch.
6. Rerun Batch 0.
7. Continue only after clean baseline.
```

## Batch 0 failure

If Batch 0 fails, no changes may be made until the base failure is understood.

Examples:

```text
compileall fails
current smoke test fails
package integrity fails
execution flag unexpectedly true
protected hash mismatch
missing required fixture
unexpected route/endpoint change
```

## Later batch failure

If Batch 1/2/3/4 fails:

```text
Do not patch unrelated files.
Do not continue to the next batch.
Do not broaden scope.
Do not change protected runtime to make tests pass.
```

## Forbidden shortcuts

```text
skip failed gate
combine failed fix with new feature
silently rewrite tests to pass
modify protected systems outside scope
enable workbook read for convenience
change route behavior to satisfy stale old test
run old alpha22/alpha30 packs raw without mapping approval
proceed because failure seems minor
```

## Recovery path

```text
DIAGNOSE failed batch
CONFIDENCE gate
FIRE failed-batch fix only, if approved
run failed-batch tests
rerun Batch 0
continue only if clean
```

## Acceptance rule

A phase checkpoint is accepted only after REVIEW confirms:

```text
all scoped files present
no unauthorized files changed
required tests/scans passed
safety flags remain false
protected systems untouched
risks documented
rollback path clear
```

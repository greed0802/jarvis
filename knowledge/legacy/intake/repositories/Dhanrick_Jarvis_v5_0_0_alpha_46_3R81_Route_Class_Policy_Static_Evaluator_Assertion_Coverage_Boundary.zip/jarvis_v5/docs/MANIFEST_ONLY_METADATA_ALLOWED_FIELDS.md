# Manifest-only Metadata Allowed Fields

Version: v5.0.0-alpha.37.10

The following fields may be planned for synthetic manifest-only contract validation:

- attachment_id_present
- contract_id_present
- original_filename_display
- sanitized_filename_display
- declared_extension
- declared_mime_type
- declared_file_size_bytes
- manifest_created_at
- manifest_modified_at
- source_kind=attachment_manifest
- accepted_sheet_name_reference_present
- accepted_sheet_name_probe_result_id_present

## Restrictions

- Filename fields are display-safe only.
- Do not expose saved_path.
- Do not expose absolute path.
- Do not expose private attachment path.
- Do not expose raw workbook_ref.
- Do not expose production workbook path.
- Do not expose workbook internals.
- Do not expose sheet names in blocked responses.
- Accepted sheet-name probe information is reference-presence only; alpha37.10 must not rerun or expand sheet-name probing.

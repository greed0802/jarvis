# Metadata Bridge Blocked Fields — Implementation Readiness

Version: v5.0.0-alpha.38.1

## Blocked workbook-container fields

- `sheet_count` unless separately fixture-proven and permission-approved in a later phase.
- `sheet_names` from workbook read.
- Workbook properties from the workbook container.
- Worksheet dimensions.
- Hidden sheet state.
- External links.

## Blocked workbook-content/internal fields

- cell values.
- formulas.
- cached formula values.
- styles.
- Named ranges.
- Tables.
- Merged cells.
- Comments.
- VBA/macros.

## Blocked operational fields

- Production/user workbook paths.
- Raw workbook references.
- Private attachment paths.
- Runtime internals.
- Tracebacks.

## Fail-closed policy

Unknown field = block. Ambiguous field = block. Source kind other than `attachment_manifest` = block. Missing approval = block. Missing permission contract = block.

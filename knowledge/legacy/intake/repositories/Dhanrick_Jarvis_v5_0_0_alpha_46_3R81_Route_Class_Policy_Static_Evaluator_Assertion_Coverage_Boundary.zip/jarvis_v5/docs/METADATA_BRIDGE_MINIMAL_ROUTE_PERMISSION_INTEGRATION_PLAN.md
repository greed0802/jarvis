# Metadata Bridge Minimal Route/Permission Integration Plan

Version: v5.0.0-alpha.38.9
Base: v5.0.0-alpha.38.8

alpha38.9 does not integrate the adapter.
alpha38.9 does not add an endpoint.
alpha38.9 does not edit app.py.
alpha38.9 does not edit route modules.
alpha38.9 does not change permission-gate contracts.
alpha38.9 does not change owner-wrapper logic.
alpha38.9 does not enable workbook access.

Minimal integration may be appropriate later only if it is route-thin, permission-first, adapter-only, audit-safe, and no-workbook-access.

Future integration is blocked if it requires workbook path, workbook open, workbook-container inspection, permission-gate contract change, owner-wrapper edit, Builder/runtime call, raw workbook_ref exposure, or private path exposure.

The isolated adapter may only be called after schema validation, source_kind validation, contract_type validation, and explicit approval/permission precheck.


Safety flags remain false:
- execution_enabled=false
- workbook_opened=false
- workbook_container_inspected=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false
- production_workbook_access=false
- synthetic_workbook_created=false
- fixture_deleted=false
- route_integration_added=false
- endpoint_added=false
- permission_gate_changed=false
- owner_wrapper_changed=false

Protected systems untouched: Builder formula/export engine, Builder runtime, existing workbook policy runtime, safe path resolver, preview policy, registry loader, routes, Formatter runtime, QA runtime, O&A runtime, Document Reader runtime, Output Center runtime, Job runtime, static/UI, app.py, permission-gate contract, owner wrapper logic, and inherited workbook fixture files.

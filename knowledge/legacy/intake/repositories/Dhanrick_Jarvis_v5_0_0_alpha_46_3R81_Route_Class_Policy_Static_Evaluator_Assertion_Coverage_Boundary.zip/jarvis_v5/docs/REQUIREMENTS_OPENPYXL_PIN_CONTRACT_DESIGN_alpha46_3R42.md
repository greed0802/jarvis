# v5.0.0-alpha.46.3R42 — requirements.txt openpyxl Pin Contract Design

**Mode:** FIRE evidence artifact  
**Base:** `v5.0.0-alpha.46.3R41`  
**Target:** `v5.0.0-alpha.46.3R42`  
**Scope:** contract design only; no implementation.

## Verdict

This R42 checkpoint defines the future contract for adding an explicit `openpyxl` pin to `requirements.txt`.
It does not add the pin, does not modify `requirements.txt`, does not install dependencies, does not import `openpyxl`, and does not enable workbook behavior.

## Current accepted checkpoint

`v5.0.0-alpha.46.3R41` — Dependency Pinning / openpyxl Static Compliance Lock.

R41 locked:

- `openpyxl_present=false`
- `openpyxl_pinned=false`
- `openpyxl_requirement_line=null`
- `requirements_txt_changed=false`
- `dependency_installed=false`
- `dependency_changed=false`
- `openpyxl_imported=false`
- `openpyxl_runtime_used=false`
- `workbook_runtime_enabled=false`
- `workbook_open_read_write=false`
- `workbook_container_inspected=false`

## R42 contract-design purpose

R42 answers this question:

> What exact contract must be satisfied before Jarvis may add `openpyxl` to `requirements.txt`, and how do we prove that adding the pin will not enable workbook runtime behavior?

## Future openpyxl pin rule

A future implementation phase may propose this shape only after separate approval:

```text
openpyxl==<approved_version>
```

The future pin must use an exact version. The contract forbids unpinned, wildcard, range, or compatible-release forms unless explicitly re-approved in a later plan:

```text
openpyxl
openpyxl>=...
openpyxl~="..."
openpyxl*
```

## Requirements.txt change constraints

A future `requirements.txt` modification must be limited to one approved openpyxl line only:

1. Add exactly one approved `openpyxl==<approved_version>` line if no line exists.
2. Or update exactly one approved `openpyxl` line if it later exists.
3. No unrelated dependency additions.
4. No unrelated dependency upgrades.
5. No dependency removals.
6. No formatting churn outside the approved line unless explicitly approved.
7. No package lockfile generation unless separately approved.
8. No dependency installation unless separately approved.

## Dependency installation restrictions

R42 does not allow:

- `pip install`
- dependency resolver execution
- environment mutation
- import-based dependency probing
- runtime dependency checks
- CI dependency install changes
- Docker/deployment dependency changes

Future dependency installation, if ever allowed, must provide separate evidence and rollback.

## Workbook non-enablement guarantees

Adding an `openpyxl` pin in a future phase must not imply permission to perform workbook operations.

The following remain blocked unless separately approved by permission contracts:

- workbook reads
- workbook writes
- workbook-container inspection
- formula evaluation
- Builder execution
- Output Center export
- Job Center execution
- workbook runtime enablement

## R42 locked facts

```json
{
  "openpyxl_pin_contract_design_only": true,
  "selected_after_r41_static_compliance": true,
  "requirements_txt_changed": false,
  "dependency_installed": false,
  "dependency_changed": false,
  "openpyxl_present": false,
  "openpyxl_pinned": false,
  "openpyxl_requirement_line": null,
  "openpyxl_imported": false,
  "openpyxl_runtime_used": false,
  "workbook_runtime_enabled": false,
  "workbook_open_read_write": false,
  "workbook_container_inspected": false,
  "builder_execution_enabled": false,
  "output_center_export_executed": false,
  "job_center_execution": false,
  "route_count": 43,
  "route_delta": 0,
  "middleware_count": 1,
  "future_openpyxl_pin_requires_exact_version": true,
  "future_openpyxl_pin_requires_separate_fire": true,
  "future_requirements_txt_change_requires_separate_plan_dry_run_fire_review": true
}
```

## Protected systems not touched

- `requirements.txt`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- schema modules
- Builder formula/export engine
- workbook permission runtime
- workbook policy runtime
- preview/export policy
- Output Center runtime
- Job Center runtime
- auth runtime boundary
- exception envelope boundary
- CORS boundary
- rate-limit boundary
- dependency/openpyxl boundary
- sidecar generator source
- UI/runtime modules

## Stop condition summary

R42 must stop if it modifies `requirements.txt`, adds an openpyxl pin, installs a dependency, imports `openpyxl`, opens or inspects a workbook, changes source behavior, changes routes/middleware, or enables runtime behavior.

## Next phase

Review R42. If accepted, a later static compliance lock or separately approved implementation phase may follow. The actual `requirements.txt` openpyxl pin is not part of R42.

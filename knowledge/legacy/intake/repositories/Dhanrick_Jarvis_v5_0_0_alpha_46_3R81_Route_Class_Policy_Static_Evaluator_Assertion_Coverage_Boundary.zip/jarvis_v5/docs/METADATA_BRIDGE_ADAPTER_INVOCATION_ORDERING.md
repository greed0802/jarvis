# Metadata Bridge Adapter Invocation Ordering

The adapter can only be called after request schema is valid, source_kind is valid, contract_type is valid, approval exists, permission precheck passed, and requested fields are allowlisted or safely blocked.

Adapter receives only attachment_manifest dict, permission_context dict, and requested_fields list[str].

Adapter must never receive workbook path, private attachment path, raw workbook_ref, file handle, workbook object, cell data, formula data, or style data.


## Safety boundary
- no source patch occurs
- no route integration occurs
- no endpoint is added
- no runtime implementation occurs
- no workbook open occurs
- no workbook-container inspection occurs
- no permission-gate contract change occurs
- no owner-wrapper change occurs
- safety flags remain false
- protected systems untouched

# Rate Limit Error Envelope Boundary Matrix

**Version:** `v5.0.0-alpha.46.3R68`  
**Base:** `v5.0.0-alpha.46.3R67`  
**Mode:** Evidence-only boundary matrix  
**Rollback:** `v5.0.0-alpha.46.3R67`

## Purpose

This checkpoint defines the error-envelope boundary matrix required before any future rate-limit response behavior can be selected or implemented.

R68 is a contract checkpoint only. It does not implement a 429 response, Retry-After header, rate-limit headers, failure response body, error code, global exception envelope interaction, observability category, logging, middleware behavior, route behavior, or any rate-limit runtime behavior.

## Boundary lock

```text
error_envelope_boundary_matrix_exists=true
error_envelope_boundary_matrix_only=true
error_response_candidate_classes_defined=true
rate_limit_429_boundary_defined=true
retry_after_header_boundary_defined=true
failure_response_body_boundary_defined=true
rate_limit_error_code_boundary_defined=true
global_exception_envelope_interaction_boundary_defined=true
observability_category_boundary_defined=true
redaction_boundary_defined=true
error_response_selected=false
error_envelope_selected=false
error_envelope_implemented=false
rate_limit_429_status_selected=false
rate_limit_429_response_implemented=false
retry_after_header_selected=false
retry_after_header_implemented=false
rate_limit_headers_implemented=false
global_exception_handler_modified=false
global_exception_envelope_modified=false
rate_limit_implementation=false
route_behavior_modified=false
middleware_added=false
```

## Candidate response classes

| Candidate class | R68 status | Future decision required |
|---|---:|---|
| 429 Too Many Requests response | Candidate only | Decide exact status/body/header contract. |
| Retry-After header | Candidate only | Decide seconds, HTTP-date, route-specific, or absent. |
| Rate-limit error code | Candidate only | Decide stable machine-readable code. |
| Human-readable message | Candidate only | Decide safe generic wording without policy leakage. |
| Failure-mode response | Candidate only | Decide difference between limit exceeded and limiter failure. |
| Global exception envelope interaction | Candidate only | Decide reuse/bypass behavior without modifying app handler. |
| Observability category | Candidate only | Decide redacted category names. |
| Unknown limiter error response | Candidate only | Decide fallback response for unclassified limiter errors. |

```text
error_response_candidate_classes_defined=true
error_response_selected=false
error_response_implemented=false
runtime_behavior_changed=false
route_behavior_changed=false
middleware_added=false
```

## 429 response boundary

```text
rate_limit_429_boundary_defined=true
rate_limit_429_status_selected=false
rate_limit_429_response_implemented=false
```

Future approval must decide whether 429 is used for all limit-exceeded cases, whether route classes differ, whether public/auth/upload/tool/output/job routes share one envelope, whether valid-key failures differ from anonymous failures, whether a correlation id is included, whether quota/window information is exposed, whether Retry-After is included, and whether the existing global exception envelope shape is reused.

No 429 response is selected or implemented in R68.

## Retry-After and header boundary

```text
retry_after_header_boundary_defined=true
retry_after_header_selected=false
retry_after_header_implemented=false
rate_limit_headers_implemented=false
```

Future candidate headers remain unselected:

```text
Retry-After
X-RateLimit-Limit
X-RateLimit-Remaining
X-RateLimit-Reset
X-Request-ID
```

Future approval must decide whether Retry-After is included, whether it uses seconds or HTTP-date, whether quota headers are included, whether quota headers expose too much policy detail, whether headers differ by route class, and whether headers are suppressed for security-sensitive routes.

## Failure response body boundary

```text
failure_response_body_boundary_defined=true
failure_response_body_selected=false
failure_response_body_implemented=false
```

Candidate body fields remain unselected:

```text
success
error
error_code
message
details
retry_after
route_class
correlation_id
timestamp
```

Future approval must decide exact envelope shape, field names, optionality, whether details are allowed, whether retry_after appears in body, whether route_class appears in body, whether timestamp appears in body, whether the body matches the existing global envelope, and whether the contract is stable for API clients.

## Rate-limit error-code boundary

```text
rate_limit_error_code_boundary_defined=true
rate_limit_error_code_selected=false
rate_limit_error_code_implemented=false
```

Candidate codes remain unselected:

```text
RATE_LIMIT_EXCEEDED
RATE_LIMIT_UNAVAILABLE
RATE_LIMIT_IDENTITY_UNAVAILABLE
RATE_LIMIT_BACKEND_TIMEOUT
RATE_LIMIT_BACKEND_UNAVAILABLE
RATE_LIMIT_POLICY_UNRESOLVED
```

Future approval must decide which code applies to true quota exceedance, backend outage, timeout, identity failure, and unresolved policy. Failure-mode codes must remain separate from selected response implementation until a later approved checkpoint.

## Global exception envelope interaction boundary

```text
global_exception_envelope_interaction_boundary_defined=true
global_exception_handler_modified=false
global_exception_envelope_modified=false
app_py_modified=false
route_behavior_modified=false
```

Future approval must decide whether rate-limit denial is a normal response or exception, whether limiter errors pass through the global exception handler, whether the global envelope shape must be reused, whether implementation belongs in middleware or a route guard, whether 429 bypasses any generic server-error envelope, and whether traceback/internal details remain blocked.

R68 does not modify app.py, exception handlers, route handlers, middleware, or response logic.

## Observability and redaction boundary

```text
observability_category_boundary_defined=true
redaction_boundary_defined=true
observability_logging_implemented=false
raw_identity_logging_allowed=false
```

Allowed future observability candidates, if separately approved:

```text
failure_category
route_class
response_category
redacted_identity_class
status_code_candidate
retry_after_present_boolean
limiter_decision_category
correlation_id_if_already_available
```

Raw observability values remain blocked:

```text
raw_api_key_logged=false
raw_token_logged=false
raw_ip_logged=false
raw_identity_key_logged=false
raw_backend_secret_logged=false
raw_request_payload_logged=false
raw_workbook_content_logged=false
raw_document_content_logged=false
raw_ocr_content_logged=false
```

## Policy decisions still unresolved

```text
rate_limit_429_response_shape_unresolved=true
retry_after_header_behavior_unresolved=true
rate_limit_error_code_selection_unresolved=true
failure_response_body_selection_unresolved=true
quota_header_exposure_unresolved=true
global_exception_envelope_interaction_unresolved=true
observability_category_selection_unresolved=true
redaction_format_unresolved=true
correlation_id_behavior_unresolved=true
route_class_specific_response_behavior_unresolved=true
fail_open_selection_unresolved=true
fail_closed_selection_unresolved=true
backend_outage_behavior_unresolved=true
timeout_behavior_unresolved=true
retry_behavior_unresolved=true
limiter_fallback_behavior_unresolved=true
dependency_selection_unresolved=true
backend_selection_unresolved=true
identity_key_implementation_unresolved=true
route_limit_values_unresolved=true
route_exemptions_unresolved=true
middleware_ordering_unresolved=true
cors_interaction_unresolved=true
```

## Middleware-count gate

```text
middleware_count_gate_defined=true
middleware_count=1
middleware_delta=0
future_middleware_count_approval_required=true
```

Error-envelope planning does not imply middleware approval. Future rate-limit middleware requires separate PLAN plus FIRE and middleware-count approval.

## Nonimplementation lock

```text
api_key_extraction_implementation=false
backend_client_implementation=false
backend_outage_behavior_implementation=false
burst_window_policy_implementation=false
cache_backend_selection=false
cors_implementation=false
default_limit_policy_implementation=false
dependency_installation=false
dependency_selection=false
environment_variable_implementation=false
error_envelope_implementation=false
fail_closed_selection=false
fail_open_selection=false
failure_behavior_implementation=false
forwarded_header_trust_implementation=false
global_exception_handler_modification=false
global_exception_envelope_modification=false
identity_key_implementation=false
in_memory_limiter_selection=false
ip_extraction_implementation=false
limiter_fallback_implementation=false
limiter_library_selection=false
middleware_addition=false
middleware_configuration_change=false
observability_logging_implementation=false
partial_read_write_behavior_implementation=false
per_route_limit_policy_implementation=false
rate_limit_429_response_implementation=false
rate_limit_headers_implementation=false
rate_limit_implementation=false
redis_selection=false
request_schema_modification=false
request_validation_implementation=false
requirements_txt_modification=false
retry_after_header_implementation=false
retry_behavior_implementation=false
route_behavior_modification=false
route_exemption_activation=false
route_grouping_implementation=false
route_limit_value_selection=false
storage_backend_selection=false
timeout_behavior_implementation=false
user_session_identity_implementation=false
```

## Future gates

```text
future_error_envelope_implementation_requires_separate_plan_plus_fire=true
future_429_response_implementation_requires_separate_plan_plus_fire=true
future_retry_after_header_behavior_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
future_middleware_count_approval_required=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

## Protected logic not touched

```text
builder_formula_export_engine_touched=false
workbook_policy_runtime_touched=false
preview_policy_touched=false
active_task_writing_report_guards_touched=false
safe_path_resolver_touched=false
output_center_runtime_touched=false
job_center_runtime_touched=false
ai_takeoff_execution_touched=false
document_reader_touched=false
ocr_touched=false
tool_execution_touched=false
app_py_modified=false
router_main_router_modified=false
requirements_txt_modified=false
route_behavior_modified=false
middleware_configuration_changed=false
auth_runtime_modified=false
global_exception_envelope_modified=false
```

## Review requirement

R68 must be reviewed before acceptance. Until REVIEW passes, `v5.0.0-alpha.46.3R67` remains the accepted rollback checkpoint.

# alpha46.3R9 — /api/events Safe Projection Implementation

Base: v5.0.0-alpha.46.3R8  
Target: v5.0.0-alpha.46.3R9  
Mode: FIRE / minimal implementation patch

## Purpose

Implement the accepted alpha46.3R8 `/api/events` projection/redaction contract with a minimal allowlisted response projection.

## Scope

R9 changes only the `/api/events/{conversation_id}` response projection in `jarvis_v5/app.py`. It does not change route count, route path, EventLedger storage, MainRouter routing, workbook policy runtime, Builder, Formatter, QA Checker, Output Center, Job Center, registries, requirements, CORS, rate limiting, or API-key middleware.

## Implementation contract

The endpoint keeps the same method/path/handler:

```text
GET /api/events/{conversation_id}
api_events
```

The route now returns projection metadata:

```text
conversation_id
projection=safe_events_v1
projection_version=alpha46.3R9
count
events
```

Each projected event is allowlisted to:

```text
event_id
client_event_id
conversation_id
intent
route
created_at
safe_status
safe_flags
```

`safe_status` contains only:

```text
blocked
duplicate
```

`safe_flags` contains only safe boolean summaries:

```text
blocked
duplicate
has_attachment
contract_only
execution_enabled
workbook_read
workbook_content_read
tool_execution_performed
engine_called
excel_created
```

## Explicitly forbidden returned data

The projection must not return raw event `request` or raw event `response`. It must not return prompts, request bodies, headers, authorization values, API keys, secrets, config or environment values, tracebacks, exceptions, internal paths, saved paths, workbook paths, attachment metadata, workbook content, snapshots, adapters, reducer results, raw route outputs, raw state objects, raw task objects, raw workbook metadata, or raw tool results.

## Storage boundary

`EventLedger.append()` and `EventLedger.list_events()` remain unchanged. They may continue storing raw event records internally. R9 projects safely at the `/api/events` response boundary only.

## Verification boundary

Verification is static-only: source text and AST inspection. No `jarvis_v5.app` import, no Jarvis runtime import, no FastAPI TestClient, no route call, no workbook execution, no tool execution, no Output Center export, and no Job Center execution.

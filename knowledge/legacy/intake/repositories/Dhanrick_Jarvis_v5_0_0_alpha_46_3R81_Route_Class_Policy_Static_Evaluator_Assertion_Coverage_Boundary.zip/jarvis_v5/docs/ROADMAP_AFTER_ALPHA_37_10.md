# Roadmap After alpha37.10

Accepted base: v5.0.0-alpha.37.10

## Current target
v5.0.0-alpha.37.11 — Manifest-only Metadata Contract Fixture Evidence Plan

## Next possible phases
- alpha37.12 — Manifest-only Metadata Fixture Evidence Package, JSON/docs only
- alpha37.13 — Manifest-only Metadata Contract Review, no runtime
- Later optional implementation plan only after separate approval

## Boundaries retained
No workbook open, workbook-container inspection, workbook content read, formula read, cell value read, style read, route change, permission-gate contract change, owner wrapper change, Builder runtime change, or production workbook access.

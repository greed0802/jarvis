# Jarvis Phase Batch FIRE Template

Version label: v5.0.0-alpha.39.4-accelerated-playbook  
Base checkpoint: v5.0.0-alpha.39.3-testmap  
Scope type: docs/reports/metadata only

Use this template for future controlled FIRE commands.

```text
FIRE <target>

Mode:
FIRE

Current accepted checkpoint:
<base checkpoint>

Target:
<target version> —
<scope title>

Allowed scope:
<exact allowed changes>

Excluded scope:
No unrelated patch.
No broad refactor.
No deletion unless explicitly scoped.
No workbook open unless explicitly scoped.
No workbook-container inspection unless explicitly scoped.
No OCR unless explicitly scoped.
No runtime execution unless explicitly scoped.
No route/endpoint change unless explicitly scoped.
No protected system change unless explicitly scoped.

Batch structure:
Batch 0 — Baseline lock
Batch 1 — Docs/contracts
Batch 2 — Tests/evidence
Batch 3 — Runtime family only, if explicitly approved
Batch 4 — Reports/handoff/package
Batch 5 — Review gate

Protected systems:
- Builder formula/export engine
- Workbook policy runtime
- Preview policy
- Active-task writing/report guards
- Safe path resolver
- Output Center runtime
- UI/runtime modules
- Route layer
- Endpoint layer
- Workbook/openpyxl paths
- Drawing/PDF/image/OCR paths
- Takeoff engine paths

Required tests/scans:
- python -m compileall -q jarvis_v5
- current relevant smoke tests
- execution flag scan
- no new route/endpoint scan
- no new workbook read/open behavior scan
- protected file/hash scan when relevant
- package hygiene scan if packaging

Required evidence flags:
runtime_behavior_changed=<true/false>
source_behavior_changed=<true/false>
workbook_opened=false
old_tests_executed=<true/false>
jarvis_runtime_imported=<true/false>
fastapi_testclient_used=<true/false>
route_added=false
endpoint_added=false
memory_imported=false
protected_systems_touched=false

Stop conditions:
- Any need to touch a protected system outside approved scope
- Any need to execute old tests outside approved scope
- Any need to import Jarvis runtime outside approved scope
- Any need to open workbook contents outside approved scope
- Any need to change runtime behavior outside approved scope

Expected output:
- package/report/handoff if scoped
- tests/scans results
- risks and rollback notes
- next REVIEW command
```

## FIRE output checklist

After FIRE, report:

```text
Version label
Base version
Files added
Files changed
Files removed
Functions changed, if any
Tests/scans run
Results
Safety flags
Protected systems untouched
Risks
Rollback
Next command script
```

# Manifest-only Metadata Audit Result Rules

Version: v5.0.0-alpha.37.10

## Safe audit/result fields

- decision
- allowed
- reason
- requested_scope
- source_kind
- contract_type
- contract_version
- approval_granted
- metadata_fields_requested
- metadata_fields_allowed
- metadata_fields_blocked
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- safe_ui_summary
- fail_closed
- safety_flags

## Forbidden audit/result fields

- absolute paths
- saved_path
- private attachment path
- raw workbook_ref
- raw exception traces
- sheet names in blocked responses
- cell values
- formulas
- cached values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- Builder internals
- Job/Output internals
- runtime internals

## Safe UI summary

Safe UI summary may include only display filename, declared extension/type, declared file size, manifest timestamp if provided, and accepted sheet-name reference presence.

# alpha46.3R21 — Attachment Upload Hardening Evidence Boundary Inventory

## 1. Version / Base / Target

- Version: `v5.0.0-alpha.46.3R21`
- Base: `v5.0.0-alpha.46.3R20`
- Target: `Attachment Upload Hardening Evidence Boundary Inventory`
- Rollback: `v5.0.0-alpha.46.3R20`

## 2. Scope Statement

R21 is evidence inventory only and static source inspection only.

R21 does not implement attachment upload hardening. R21 does not modify upload behavior, attachment store behavior, upload route behavior, workbook behavior, route behavior, dependencies, registries, middleware, or runtime source behavior.

R21 does not execute attachment upload, file upload routes, API routes, FastAPI TestClient, Jarvis runtime import, app.py import, workbook open/read/write/execution, workbook-container inspection, file execution through Jarvis runtime, OCR, Output Center export, Job Center execution, or tool execution.

## 3. Accepted R20 Summary

R20 is the accepted checkpoint for this phase. R20 selected `attachment_upload_hardening_evidence_boundary` as the next stability phase and explicitly recorded `attachment_upload_hardening_not_implemented_in_r20 = true`.

R20 preserved route count 43, middleware count 1, workbook-related route count 5, and sheet-name probe approval route count 1. R20 changed no runtime behavior and did not change attachment store behavior.

## 4. Static Inventory Findings

Static source inspection identifies the attachment upload boundary without executing it:

- `jarvis_v5/app.py` defines `POST /api/attach`.
- `api_attach` accepts FastAPI upload metadata through `UploadFile = File(...)`.
- `api_attach` calls `kernel.attachments.save_upload(file)`.
- `jarvis_v5/core/attachment_store.py` defines `AttachmentStore.save_upload`.
- `AttachmentStore.save_upload` persists uploaded bytes to the attachments directory as existing behavior.
- `AttachmentStore.save_upload` returns metadata that includes `saved_path`.
- `jarvis_v5/schemas/message_schema.py` defines `AttachmentMeta.saved_path`.
- `jarvis_v5/router/main_router.py` defines `public_workbook_ref` and states that `saved_path` stays in internal state/debug endpoints only.
- `public_workbook_ref` omits `saved_path` from the public workbook reference projection.
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py` declares forbidden raw path keys including `saved_path`.
- `safe_workbook_path_resolver.py` remains metadata-only and declares `path_resolved=false`, `filesystem_checked=false`, `workbook_opened=false`, and `workbook_read=false`.
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` calls `evaluate_workbook_permission_gate` before `_safe_attachment_file`.
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` calls `_safe_attachment_file` before `load_workbook`.

## 5. Inventory Questions

R21 records these evidence questions for a future hardening phase:

1. Does `/api/attach` expose `saved_path` directly in public responses?
2. Does `AttachmentMeta` allow `saved_path` through request or route flow beyond internal metadata?
3. Is `saved_path` retained only in internal state, debug, or event paths?
4. Does `public_workbook_ref` consistently strip `saved_path` from public workbook projections?
5. Does event ledger or debug state store raw `saved_path` through request serialization?
6. Are conversation IDs sanitized before any storage path use?
7. Are attachment IDs generated internally rather than user-supplied?
8. Does upload filename handling use basename-only behavior to strip directory components?
9. Can any user-supplied path segment affect the attachments directory?
10. Can upload bridge directly into workbook read without explicit permission?
11. Does permission gate occur before workbook file resolution?
12. Does safe path resolver remain metadata-only?
13. Does any normal route expose local directory, parent, absolute path, raw path, or resolved path values?
14. Is attachment upload hardening still unimplemented after R21?
15. What exact future hardening contract is needed before implementation?

These are inventory questions, not patch claims.

## 6. Explicit Non-Implementation Boundary

R21 does not patch:

- attachment upload behavior
- `attachment_store.py`
- `app.py`
- upload routes
- file path resolver behavior
- public response schema
- attachment metadata schema
- file deletion or cleanup behavior
- file access enablement
- workbook access enablement
- OCR, document reader, or RAG
- dependency versions
- sidecar generator source

## 7. Future Phase Entry Conditions

Any future attachment upload hardening patch requires a separate PLAN / DRY RUN / FIRE cycle. Static inventory must be accepted first. No hidden route, upload, file, workbook, or source behavior changes are permitted under R21.

## 8. Protected Systems Not Touched

Protected systems not touched by R21:

- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`
- `requirements.txt`
- registries
- route handlers
- middleware behavior
- auth runtime boundary
- workbook permission runtime
- workbook policy runtime
- Builder formula/export engine
- Formatter workbook behavior
- QA Checker workbook behavior
- Description / BOQ Writer workbook behavior
- preview/export policy
- active-task writing/report guards
- Output Center runtime
- Job Center runtime
- UI/runtime modules
- sidecar generator source

## 9. Quarantined Backlog Rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for future ideas, but it cannot expand R21 scope, add R21 files, change the R21 target, promote connectors, promote OCR/document reader, promote personal assistant features, promote structural engineering engine, or override checkpoint evidence.

## 10. Closure Verdict

R21 inventories the attachment upload hardening evidence boundary only. It does not implement hardening, execute uploads, call routes, open files, read workbooks, or change runtime/source behavior.

# v5.0.0-alpha.46.3R46R1 — openpyxl Pin Candidate Selection Static Compliance Lock Reissue

## Status

R46R1 is a reissue from clean `v5.0.0-alpha.46.3R45` after the failed `v5.0.0-alpha.46.3R46` sidecar tracker mismatch.

This checkpoint is evidence-only and no-source-change. It locks the openpyxl pin candidate selection static compliance boundary after R45.

## Reissue correction

- The failed R46 package body was clean, but the standalone Source of Truth tracker sidecar did not match the tracker inside the final package.
- R46R1 requires the final standalone tracker sidecar to be copied from the exact tracker bytes inside the final package.
- Package tracker, standalone tracker, manifest tracker SHA, and FIRE outputs tracker must match byte-for-byte.

## Locked facts

```text
openpyxl_pin_candidate_selection_static_compliance_lock_reissue_only=true
selected_after_r45_candidate_selection_contract=true
failed_r46_reason=standalone_tracker_sidecar_mismatch
approved_openpyxl_pin_candidate_present=false
approved_openpyxl_pin_candidate_line=null
candidate_selection_executed=false
candidate_version_supplied=false
candidate_version_selected=false
candidate_version_invented=false
candidate_version_approved=false
candidate_version_applied=false
requirements_txt_changed=false
requirements_txt_change_allowed=false
dependency_installed=false
dependency_changed=false
openpyxl_pin_added=false
openpyxl_present=false
openpyxl_pinned=false
openpyxl_imported=false
openpyxl_runtime_used=false
workbook_runtime_enabled=false
workbook_open_read_write=false
workbook_container_inspected=false
builder_execution_enabled=false
output_center_export_executed=false
job_center_execution=false
route_count=43
route_delta=0
middleware_count=1
future_candidate_requires_explicit_user_approval=true
future_actual_pin_requires_separate_fire=true
```

## Scope exclusions

No implementation, no requirements.txt modification, no dependency installation, no openpyxl pin/import/runtime use, no candidate version selection/invention/approval/application, no runtime import, no app.py import, no TestClient, no API route calls, no workbook open/read/write, no workbook-container inspection, no Builder execution, no Output Center export, no Job Center execution, no OCR/document/tool execution, and no sidecar generator source patch.

## Rollback

`v5.0.0-alpha.46.3R45`

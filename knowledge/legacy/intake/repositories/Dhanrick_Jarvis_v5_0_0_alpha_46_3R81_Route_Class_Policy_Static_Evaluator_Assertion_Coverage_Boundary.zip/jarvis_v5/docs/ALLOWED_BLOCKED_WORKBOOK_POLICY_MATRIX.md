# Allowed / Blocked Workbook Policy Matrix

## Allowed now
- Approved sheet-name-only probe through accepted owner wrapper.
- Metadata-only route/policy inventory.
- Audit/result metadata with `contains_workbook_data=false`.

## Still blocked
- workbook_content_read
- formula_read
- cell_value_read
- style_read
- Builder engine call
- Excel output creation
- Formatter/QA/O&A/Document Reader/Job/Output runtime execution

## Enforcement note
Future metadata expansion must remain permission-gated and must not imply workbook content access.

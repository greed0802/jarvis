# Old Test Pack Version Target Normalization

Target checkpoint: `v5.0.0-alpha.39.3-testmap`  
Base checkpoint: `v5.0.0-alpha.39.2-batch`  
Mode: FIRE metadata-only  
Scope: docs/reports/metadata inventory only. No runtime execution.


## Historical targets

```text
alpha22: v5.0.0-alpha.22.2D-engineering-language-target
alpha30: v5.0.0-alpha.30
```

## Current mapping target

```text
v5.0.0-alpha.39.2-batch
```

The target checkpoint label for this inventory is:

```text
v5.0.0-alpha.39.3-testmap
```

## Normalization rule

Do not destructively replace old version strings inside original packs. A future mapped test pack should carry both fields:

```json
{
  "historical_target_version": "<old suite version>",
  "current_mapped_target_version": "v5.0.0-alpha.39.2-batch",
  "mapping_checkpoint": "v5.0.0-alpha.39.3-testmap",
  "execution_status": "not_executed"
}
```

## Failure-handling rule

If an old test cannot be mapped without changing current protected runtime behavior, it must be quarantined as `stale_or_quarantine` or `excluded_until_contract_review`.

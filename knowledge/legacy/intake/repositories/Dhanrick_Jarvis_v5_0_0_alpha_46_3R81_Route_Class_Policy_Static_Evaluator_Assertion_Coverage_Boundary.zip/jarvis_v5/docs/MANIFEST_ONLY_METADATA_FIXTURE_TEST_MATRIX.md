# Manifest-only Metadata Fixture Test Matrix

| Category | Minimum coverage | Required proof |
|---|---:|---|
| allow_manifest_metadata | 8 | source_kind=attachment_manifest and manifest-only fields |
| block_workbook_container_metadata | 4 | sheet_count and container metadata blocked |
| block_workbook_internal_data | 8 | content/formula/cell/style/named ranges/tables/merged/comments/VBA blocked |
| fail_closed_unknown | 1 | unknown field blocks |
| fail_closed_missing_approval | 2 | missing/false approval blocks |
| fail_closed_wrong_source | 1 | source_kind other than attachment_manifest blocks |
| fail_closed_path_like_input | 3 | production path/raw workbook ref/private attachment path block |
| audit_redaction | 5 | forbidden fields suppressed |
| safety_flags_false | 1 | all safety flags false |
| protected_source_untouched | 1 | protected source unchanged |
| package_hygiene | 1 | no cache artifacts or workbook fixture files |

## Workbook-file guard
No synthetic workbook files are planned or created:
- no .xlsx
- no .xlsm
- no .xls

# Jarvis Local Evidence Runner Static Scan Design — alpha39.9

Target: v5.0.0-alpha.39.9-batch  
Status: static scan design only. No runner script is implemented.

## Protected Hash Compare Design

Flow:

1. Load protected file list.
2. Hash each protected file in base.
3. Hash each protected file in target.
4. Compare hashes.
5. Classify each protected file as unchanged, changed, missing_in_base, missing_in_target, or new_protected_file.
6. Fail if protected files changed outside allowed scope.
7. Write JSON and Markdown reports.

Protected groups:

- Core runtime: app.py, config.py, registry_loader.py
- Builder: Builder engine files, legacy bridge, preview execution policy, safe workbook path resolver
- Workbook: workbook permission runtime and workbook read policy/runtime files
- UI: UI runtime modules
- Output: Output Center runtime modules
- Routes: route files and endpoint files

Expected output:

```json
{
  "protected_files_total": 0,
  "unchanged": 0,
  "changed": 0,
  "missing": 0,
  "all_unchanged": true,
  "unexpected_changes": []
}
```

## Safety Flag Scan Design

Raw patterns to scan:

```text
WORKBOOK_READ_ENABLED = True
BUILDER_ENGINE_EXECUTION_ENABLED = True
LEGACY_BUILDER_CALLABLE = True
EXCEL_OUTPUT_ENABLED = True
drawing_read=true
ocr_called=true
takeoff_engine_called=true
workbook_read=true
workbook_opened=true
quantity_writeback=true
approval_token_issued=true
runtime_execution=true
ui_implemented=true
local_script_execution_allowed=true
```

Context classes:

```text
actual_enabled_flag
blocked_example
test_assertion
report_false_flag
inherited_base_reference
new_target_reference
unknown_context
```

Rules:

- actual_enabled_flag = fail
- unknown_context = manual_review_required
- blocked_example = report only
- test_assertion = report only
- report_false_flag = pass

Expected output:

```json
{
  "actual_enabled_flags": [],
  "blocked_examples": [],
  "test_assertions": [],
  "manual_review_required": [],
  "all_clear": true
}
```

## Route / Endpoint Scan Design

Static route scan only. Do not import app.py.

Patterns:

```text
@app.get(
@app.post(
@app.put(
@app.delete(
@router.get(
@router.post(
@router.put(
@router.delete(
```

Expected output:

```json
{
  "base_route_count": 43,
  "target_route_count": 43,
  "route_delta": 0,
  "new_route_lines": [],
  "removed_route_lines": [],
  "changed_route_files": []
}
```

If scope says no route or endpoint addition, route_delta must be 0.

## Package Hygiene Design

Checks:

- ZIP integrity passes
- no .pytest_cache/
- no __pycache__/
- no *.pyc
- no temp files unless explicitly marked TEMP
- no nested full-release ZIP unless explicitly allowed
- no local secrets
- no environment files
- no runtime cache

Blocked patterns:

```text
.pytest_cache/
__pycache__/
*.pyc
.env
*.secret
*.key
.DS_Store
Thumbs.db
```

Expected output:

```json
{
  "zip_integrity": "PASS",
  "entry_count": 0,
  "pytest_cache_count": 0,
  "pycache_count": 0,
  "pyc_count": 0,
  "blocked_secret_files": [],
  "all_clear": true
}
```

## SHA256 Manifest Design

The future runner should produce SHA256 for:

- base ZIP
- target ZIP
- patch ZIP, if present
- evidence ZIP, if present
- changed file list
- protected file list

Every accepted package must have a SHA256. Every evidence report must record package SHA256.

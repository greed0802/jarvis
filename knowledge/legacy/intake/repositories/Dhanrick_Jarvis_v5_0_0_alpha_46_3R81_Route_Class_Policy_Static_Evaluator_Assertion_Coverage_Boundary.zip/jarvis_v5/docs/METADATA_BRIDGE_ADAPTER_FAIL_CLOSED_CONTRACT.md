# Metadata Bridge Adapter Fail Closed Contract

Version: v5.0.0-alpha.38.4

## Future fail-closed cases

```text
unknown field requested
blocked field requested
missing approval
approval=false
missing source_kind
wrong source_kind
missing contract_type
wrong contract_type
path-like input present
raw workbook_ref present
workbook object present
file handle present
production/user workbook path present
scope expansion attempted
workbook access attempted
```

## Expected fail-closed output

```text
decision=block
allowed=false
fail_closed=true
reason_code=safe_block_reason
workbook_opened=false
workbook_container_inspected=false
contains_workbook_data=false
safe_ui_summary contains no forbidden fields
```

## Required redaction

Blocked responses must not expose saved paths, private attachment paths, raw workbook references, sheet names from workbook read, cell values, formulas, styles, tracebacks, or runtime internals.

# AI Takeoff Workbench Reuse Policy

## Safe reuse

- Public feature categories.
- Publicly described workflow ideas.
- General QS terminology.
- User-owned workflow requirements.
- Open-source libraries only after license, security, and dependency review.
- Public APIs only with authorization and separate integration plan.

## Blocked reuse

- Proprietary code.
- Proprietary templates/databases.
- Paid manuals copied into Jarvis.
- Screenshots/assets copied as implementation materials.
- Reverse-engineered commercial file formats.
- Commercial APIs without authorization.
- Exact UI cloning.

## Policy

Use competitors as precedent, not source. Use open-source as candidates, not automatic dependencies. Jarvis architecture remains metadata-first and permission-before-access.

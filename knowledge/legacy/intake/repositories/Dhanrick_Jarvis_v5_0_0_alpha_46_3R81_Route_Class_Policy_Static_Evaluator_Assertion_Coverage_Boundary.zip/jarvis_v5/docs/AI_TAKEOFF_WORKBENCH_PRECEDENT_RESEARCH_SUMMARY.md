# AI Takeoff Workbench Precedent Research Summary

## Purpose

Document public precedent patterns from takeoff tools as architecture inspiration only.

## Commercial takeoff patterns observed from public product materials

- Plan viewport / drawing viewer.
- Scale/calibration workflow.
- Measurement and markup tools.
- Item/template/assembly workflow.
- Quantity table and estimate/BOQ output.
- Revision/change tracking.
- Reporting and export.
- BIM/IFC concepts in some tools.
- AI/automation marketed in some tools for count, scale, bookmarks, or takeoff assistance.

## Jarvis interpretation

Jarvis should use these only as feature precedents. It should not copy proprietary code, data, templates, manuals, screenshots, assets, or protected workflows.

## Safe Jarvis pipeline

Selected plan metadata -> selected item metadata -> user-approved context -> safe assistant suggestion -> preview -> user confirmation -> evidence record -> future BOQ/QTO output.

## Current status

Documentation only. No implementation. No drawing read. No OCR. No takeoff engine.

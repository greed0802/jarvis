# Metadata Bridge Owner Wrapper Non-Involvement Policy

Owner wrapper remains out of scope for minimal metadata route integration.

Rules:
- no owner wrapper edit in alpha38.9
- no owner wrapper edit in future minimal route FIRE unless separately approved
- if future integration requires owner-wrapper behavior, stop and create a separate PLAN

Reason: the metadata adapter accepts manifest dictionaries only and should not require owner-wrapper workbook access behavior.

Owner-wrapper involvement would increase risk because it sits near workbook ownership, attachment access, and operational workbook pathways.

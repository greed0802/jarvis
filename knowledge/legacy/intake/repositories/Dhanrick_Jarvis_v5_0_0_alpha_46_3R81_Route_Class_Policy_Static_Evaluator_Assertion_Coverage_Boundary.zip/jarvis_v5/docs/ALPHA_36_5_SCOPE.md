# Alpha36.5 Scope — Workbook Runtime Governance Alignment Matrix

Version: v5.0.0-alpha.36.5  
Base: v5.0.0-alpha.36.4  
Scope type: docs/tests/evidence only.

Alpha36.5 exists to close the Governance Alignment Gap discovered during alpha36.4 and external regression testing: contracts are modern, existing workbook-related runtime owners still exist, and some tests assume an idealized future state.

## Objective

Create a decision-ready governance matrix for existing workbook runtime owners. The specific decision target is the existing sheet-name probe owner and the related workbook approval routes.

Decision options:

- PRESERVE
- WRAP
- REPLACE
- DISABLE

Recommended planning posture: WRAP existing sheet-name ownership behind a future unified workbook permission gate. This is a planning recommendation only, not an implementation.

## Explicit exclusions

- No new runtime implementation.
- No route behavior change.
- No endpoint added.
- No workbook opened.
- No workbook content/formula/cell/style read.
- No new openpyxl or pandas runtime import.
- No safe path resolver call.
- No Builder, Formatter, QA, O&A, Document Reader, Output Center, or Job runtime changes.

## Safety flags


metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
implementation_created=false
runtime_imported=false
runtime_called=false
workbook_opened=false
safe_path_resolver_called=false
path_resolved=false
audit_event_written=false
runtime_data_written=false
no runtime behavior changed
future-only


# Future Metadata Bridge Policy

Before any metadata bridge expansion:

1. Route inventory must remain clean.
2. Permission-gate call path must be explicit.
3. No app.py direct permission-gate integration without a separate plan/dry run/FIRE.
4. Sheet-name-only access remains the maximum currently evidenced workbook access.
5. Content, formulas, cell values, styles, Builder execution, and Excel output remain blocked.
6. User-facing audit data must never reveal raw paths, saved_path, raw workbook_ref, sheet names in blocked responses, cells, formulas, or styles.

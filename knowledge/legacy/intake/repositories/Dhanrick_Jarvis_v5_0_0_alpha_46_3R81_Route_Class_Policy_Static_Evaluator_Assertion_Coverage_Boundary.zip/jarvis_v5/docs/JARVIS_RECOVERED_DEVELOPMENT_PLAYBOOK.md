# Jarvis Recovered Development Playbook

Version label: v5.0.0-alpha.39.4-accelerated-playbook  
Base checkpoint: v5.0.0-alpha.39.3-testmap  
Scope type: docs/reports/metadata only  
Runtime behavior changed: false

## Purpose

This playbook records the recovered old ChatGPT Jarvis development rules so future work can move faster without weakening protected boundaries.

The acceleration principle is:

```text
PLAN by phase.
DRY RUN by phase.
FIRE by batch.
REVIEW by checkpoint.
```

## Core principles

```text
Stability > Features
Evidence > Assumptions
Minimal Patch > Refactor
Protected Boundaries > Fast Progress
Metadata before execution
Contracts before runtime
Permission before workbook access
Approval before execution
Preview before export
```

## Default modes

```text
DIAGNOSE  - investigate only
PLAN      - propose controlled scope only
DRY RUN   - inspect and simulate without changes
CONFIDENCE - state evidence, risks, files, tests, uncertainties before FIRE
FIRE      - perform approved scoped changes only
REVIEW    - verify evidence package and accept/reject
HANDOFF   - create next-chat continuation state
```

## Required issue structure

Every Jarvis issue should keep this structure:

```text
1. Expected behavior
2. Actual behavior
3. Files/functions involved
4. Root cause
5. Minimal patch plan
6. Regression tests
7. Confidence %
8. Supporting evidence
9. Remaining uncertainty
10. Protected logic not touched
```

## Confirmed / Likely / Hypothesis discipline

```text
Confirmed  = directly evidenced by file, test, report, or controlled scan.
Likely     = supported by evidence but not directly proven.
Hypothesis = plausible explanation requiring more diagnosis.
```

Hypotheses must never be presented as facts.

## FIRE discipline

```text
No patch.
No build.
No package.
No source modification.
No workbook access.
No runtime execution.
```

Unless the user explicitly says FIRE and the scope allows it.

## Recovered lessons from old Jarvis work

The old v4/v5 history showed that fast broad patches caused instability around:

```text
active task state
pending clarification
setup / review / approve / preview recovery
attachment replies
route ownership
slot reducer ownership
conversation recovery
UI scroll/composer behavior
```

The Builder formula/export engine was comparatively stronger than the surrounding conversation and workflow state. Therefore, future patches must isolate workflow/state changes from Builder/export logic.

## Do not repeat old failures

```text
Do not mix UI + router + Builder + workbook policy + preview/export + state recovery in one patch.
Do not run stale old test packs raw against a newer checkpoint.
Do not enable workbook reads before permission contracts.
Do not patch runtime just to satisfy old response shapes.
Do not treat old version-specific assertions as current truth.
Do not bypass Batch 0.
Do not continue after failed batch.
```

## Protected systems

These are protected by default:

```text
Builder formula/export engine
CostX formula generation
Formula Integrity Guard
Workbook policy runtime
Preview policy runtime
Safe path resolver runtime
Active-task writing/report guards
Output Center runtime
UI/runtime modules
Route layer
Endpoint layer
Workbook/openpyxl paths
Drawing/PDF/image/OCR paths
Takeoff engine
Quantity writeback
```

## Old evidence that can accelerate current work

Safe to reuse as planning/test intelligence:

```text
old governance rules
batch sequence rules
stop conditions
protected-boundary lists
old rollback/stable checkpoint lessons
alpha26 static audit finding about route ordering
alpha36.5 workbook runtime governance matrix
alpha22 engineering-language test categories
alpha30 red-team weakness categories
old active-task failure classes
old workbook-read safety doctrine
old package hygiene checklist
old handoff/report pattern
```

## Old evidence that must not be reused blindly

```text
old exact version assertions
old route counts
old endpoint names
old response shapes
old UI assumptions
old active_task wrapper shape
old known_routes list
old alpha22/alpha30 raw tests
old v4 workaround patches
old source code not independently reviewed
```

## Default acceleration decision

Use old data to reduce repeated discovery, but keep current alpha39+ contracts as the source of truth.

# Backend Protected Systems for Alpha38

Protected systems:
- Builder formula/export engine
- Builder runtime
- existing workbook policy runtime
- safe path resolver
- Preview policy
- Registry loader
- Routes
- Formatter runtime
- QA runtime
- O&A runtime
- Document Reader runtime
- Output Center runtime
- Job runtime
- Static/UI
- permission gate contract
- owner wrapper logic
- Inherited workbook fixture files

Any change to these systems requires a separate explicit PLAN, DRY RUN, FIRE, and REVIEW with approval. Alpha38.0 touches none of them.

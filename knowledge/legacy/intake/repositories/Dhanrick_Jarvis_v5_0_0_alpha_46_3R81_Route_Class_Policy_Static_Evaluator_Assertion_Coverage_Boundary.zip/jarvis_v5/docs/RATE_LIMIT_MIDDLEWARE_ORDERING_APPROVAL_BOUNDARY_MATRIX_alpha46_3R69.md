# v5.0.0-alpha.46.3R69 — Rate Limit Middleware Ordering Approval Boundary Matrix

## Mode
FIRE — evidence-only planning package.

## Base
`v5.0.0-alpha.46.3R68`

## Target
`v5.0.0-alpha.46.3R69 — Rate Limit Middleware Ordering Approval Boundary Matrix`

## Purpose
This document defines the approval boundary before any future rate-limit middleware, middleware ordering, middleware count change, CORS interaction, global exception envelope interaction, auth guard ordering, request lifecycle position, or route-guard versus middleware implementation pattern can be selected or implemented.

## Boundary Lock

```text
middleware_ordering_approval_boundary_matrix_exists=true
middleware_ordering_approval_boundary_matrix_only=true
middleware_ordering_candidate_classes_defined=true
middleware_count_approval_boundary_defined=true
cors_interaction_boundary_defined=true
global_exception_envelope_interaction_boundary_defined=true
auth_guard_ordering_boundary_defined=true
request_lifecycle_position_boundary_defined=true
route_guard_vs_middleware_boundary_defined=true
middleware_ordering_selected=false
middleware_selected=false
route_guard_selected=false
implementation_pattern_selected=false
middleware_added=false
middleware_configuration_changed=false
middleware_count_changed=false
rate_limit_implementation=false
route_behavior_modified=false
```

## Middleware Ordering Candidate Classes

Candidate classes are defined for future analysis only. None is selected in R69.

| Candidate | Status | Future question |
|---|---:|---|
| ASGI/FastAPI middleware | candidate only | Is global request interception safe for all route classes? |
| Route guard/dependency | candidate only | Is route-level control safer than global middleware? |
| Before auth guard | candidate only | Can anonymous/IP identities be limited before auth safely? |
| After auth guard | candidate only | Can API-key/user identities be limited after auth safely? |
| Before CORS | candidate only | Would preflight behavior or response headers break? |
| After CORS | candidate only | Can rate-limit headers be exposed safely? |
| Before global exception envelope | candidate only | Would limiter errors bypass existing envelope controls? |
| Upload/body-read boundary | candidate only | Can large requests be limited before expensive body processing? |
| Debug/dev route boundary | candidate only | Are debug/dev routes excluded or separately controlled later? |
| No middleware / route-only option | candidate only | Should implementation avoid middleware entirely? |

## Middleware Count Approval Boundary

```text
middleware_count_approval_boundary_defined=true
middleware_count_change_requested=false
middleware_count_change_approved=false
middleware_added=false
middleware_configuration_changed=false
middleware_count_changed=false
```

Required future approval fields:

```text
current_middleware_count
proposed_middleware_count
middleware_name
middleware_position_candidate
reason_for_middleware
routes_affected
auth_interaction
cors_interaction
global_exception_interaction
error_envelope_interaction
request_body_read_interaction
rollback_path
regression_tests_required
approval_checkpoint
review_checkpoint
```

## CORS Interaction Boundary

```text
cors_interaction_boundary_defined=true
cors_behavior_selected=false
cors_behavior_implemented=false
cors_implementation=false
middleware_added=false
```

Future CORS questions remain unresolved:

```text
whether OPTIONS preflight is rate-limited
whether rate-limit headers must be exposed through CORS
whether 429 responses include CORS headers
whether CORS order changes are required
whether CORS implementation requires separate middleware-count approval
```

## Global Exception Envelope Interaction Boundary

```text
global_exception_envelope_interaction_boundary_defined=true
global_exception_handler_modified=false
global_exception_envelope_modified=false
app_py_modified=false
error_envelope_implementation=false
rate_limit_429_response_implementation=false
retry_after_header_implementation=false
```

## Auth Guard Ordering Boundary

```text
auth_guard_ordering_boundary_defined=true
auth_ordering_selected=false
auth_behavior_modified=false
api_key_extraction_implementation=false
identity_key_implementation=false
route_behavior_modified=false
```

Future candidates:

```text
rate_limit_before_auth
rate_limit_after_auth
separate_public_and_authenticated_paths
anonymous_bucket_before_auth_and_api_key_bucket_after_auth
route_guard_only_after_auth
```

## Request Lifecycle Position Boundary

```text
request_lifecycle_position_boundary_defined=true
request_lifecycle_position_selected=false
request_body_read_behavior_implemented=false
middleware_added=false
```

Future lifecycle positions remain candidates only:

```text
before_request_body_read
after_request_body_read
before_route_handler
after_auth_guard
after_response_generation
on_exception_path
```

## Route Guard versus Middleware Boundary

```text
route_guard_vs_middleware_boundary_defined=true
route_guard_selected=false
middleware_selected=false
implementation_pattern_selected=false
```

Comparison fields for a future decision:

```text
coverage_scope
route_class_control
middleware_count_impact
auth_context_availability
identity_key_availability
error_envelope_control
CORS_header_control
testability
rollback_complexity
blast_radius
```

## Nonimplementation Lock

```text
middleware_addition=false
middleware_configuration_change=false
middleware_count_change=false
middleware_ordering_selection=false
app_py_modification=false
router_main_router_modification=false
route_behavior_modification=false
rate_limit_implementation=false
error_envelope_implementation=false
rate_limit_429_response_implementation=false
retry_after_header_implementation=false
global_exception_handler_modification=false
fail_open_selection=false
fail_closed_selection=false
backend_outage_behavior_implementation=false
timeout_behavior_implementation=false
retry_behavior_implementation=false
dependency_selection=false
dependency_installation=false
requirements_txt_modification=false
redis_selection=false
cache_backend_selection=false
in_memory_limiter_selection=false
limiter_library_selection=false
backend_client_implementation=false
environment_variable_implementation=false
storage_backend_selection=false
identity_key_implementation=false
api_key_extraction_implementation=false
ip_extraction_implementation=false
forwarded_header_trust_implementation=false
user_session_identity_implementation=false
route_grouping_implementation=false
route_exemption_activation=false
route_limit_value_selection=false
default_limit_policy_implementation=false
per_route_limit_policy_implementation=false
burst_window_policy_implementation=false
request_schema_modification=false
request_validation_implementation=false
cors_implementation=false
```

## Future Gates

```text
future_middleware_addition_requires_separate_plan_plus_fire=true
future_middleware_count_change_requires_separate_plan_plus_fire=true
future_middleware_ordering_selection_requires_separate_plan_plus_fire=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
future_global_exception_envelope_interaction_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
```

## Protected Logic Not Touched

```text
Builder formula/export engine
workbook policy runtime
preview policy
active-task writing/report guards
safe path resolver
Output Center runtime
Job Center runtime
AI Takeoff execution
document reader
OCR
tool execution
app.py
router/main_router.py
requirements.txt
route behavior
middleware configuration
middleware count
auth runtime
global exception envelope
request schemas
request validation
CORS
```

## Rollback

`v5.0.0-alpha.46.3R68`

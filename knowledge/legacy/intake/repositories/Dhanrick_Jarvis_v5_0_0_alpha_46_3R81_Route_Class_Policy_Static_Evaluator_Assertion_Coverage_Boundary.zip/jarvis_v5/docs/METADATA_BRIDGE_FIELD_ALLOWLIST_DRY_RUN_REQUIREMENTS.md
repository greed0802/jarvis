# Metadata Bridge Field Allowlist Dry Run Requirements

## Allowed manifest-only fields
- attachment_id_present
- contract_id_present
- declared_extension
- declared_mime_type
- declared_file_size_bytes
- manifest_created_at
- manifest_modified_at
- sanitized_filename_display
- accepted_sheet_name_probe_result_id_present

## Allowed-field rule
Every allowed field must be available from attachment manifest or accepted metadata evidence. No allowed field may require workbook open or workbook-container inspection.

## Blocked dry-run fields
- sheet_count
- sheet_names from workbook read
- workbook properties
- worksheet dimensions
- cell values
- formulas
- cached formula values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- external links
- hidden sheets
- runtime internals

## Unknown/ambiguous behavior
Unknown field = block. Ambiguous field = block. Missing approval = block. Wrong source_kind = block.

# Metadata Bridge Safe Response Audit Policy

Future safe response may include:
- decision
- allowed
- reason_code
- requested_fields
- allowed_fields
- blocked_fields
- safe_ui_summary
- safety_flags
- audit_id if safe

Future safe response must not include:
- private attachment path
- absolute path
- saved path
- raw workbook_ref
- cell values
- formulas
- cached values
- styles
- sheet names from workbook read
- tracebacks
- runtime internals

Audit/result must record:
- permission_precheck_performed=true
- approval_checked=true
- adapter_invoked=true only after approval
- workbook_opened=false
- workbook_container_inspected=false
- production_workbook_access=false
- contains_workbook_data=false

Safe response and audit policy must preserve no-workbook-access and redaction boundaries.

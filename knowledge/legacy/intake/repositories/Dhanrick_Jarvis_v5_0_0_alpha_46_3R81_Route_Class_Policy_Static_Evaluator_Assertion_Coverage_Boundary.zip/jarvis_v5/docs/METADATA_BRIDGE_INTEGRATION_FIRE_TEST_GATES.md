# Metadata Bridge Integration FIRE Test Gates

Before future integration FIRE, tests must prove route absent before integration, route added only when explicitly approved, request schema validates manifest-only payloads, request schema rejects workbook paths, permission precheck occurs before adapter call, adapter not called when permission fails, missing approval fails closed, wrong source_kind fails closed, wrong contract_type fails closed, unknown field fails closed, blocked workbook field fails closed, safe UI summary excludes forbidden data, audit excludes forbidden data, no workbook open occurs, no workbook-container inspection occurs, no openpyxl/load_workbook in integration path, no protected runtime call occurs, and protected hashes checked.


## Safety boundary
- no source patch occurs
- no route integration occurs
- no endpoint is added
- no runtime implementation occurs
- no workbook open occurs
- no workbook-container inspection occurs
- no permission-gate contract change occurs
- no owner-wrapper change occurs
- safety flags remain false
- protected systems untouched

# AI Takeoff Workbench Safe Early Actions

Safe early actions must use user-provided or declared metadata only.

## Allowed examples

- Explain selected item metadata.
- Summarize selected quantity metadata.
- Suggest QS QA checks.
- Draft BOQ wording from selected context.
- Identify missing plan/item/level/unit context.
- Prepare checklist for takeoff review.
- Flag mismatched unit vs measurement type.
- Suggest what permission would be needed before deeper access.

## Not allowed in early scope

Any action requiring drawing read, OCR, automatic measurement, workbook writeback, route integration, or runtime execution.

# Isolated Metadata Adapter No Workbook Access Tests

Future source FIRE tests must prove:
- no openpyxl import exists
- no load_workbook string exists
- no zipfile workbook inspection exists
- no pathlib/open call on workbook path exists
- no workbook object accepted as input
- no file handle accepted as input
- no sheet count read
- no sheet name read from workbook
- no cell/formula/style read
- no workbook fixture dependency
- no app.py change
- no route registration
- protected hashes unchanged

Static scans must check for forbidden imports and calls. Unit tests must use manifest-only dictionaries.

# alpha46.3R24 — Attachment Upload Response Boundary Static Compliance Lock

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R24`
- Base: `v5.0.0-alpha.46.3R23`
- Target: `Attachment Upload Response Boundary Static Compliance Lock`
- Rollback: `v5.0.0-alpha.46.3R23`

## Scope Statement

R24 is a static compliance lock only. It is not an implementation phase and it performs no source behavior change.

R24 makes no `app.py` patch, no `attachment_store.py` patch, no `message_schema.py` patch, no `main_router.py` patch, no route behavior change, no metadata schema implementation, no `saved_path` redaction implementation, no upload response implementation, and no sidecar generator source patch.

R24 performs no runtime import, no `app.py` import, no FastAPI TestClient execution, no API route calls, no attachment upload execution, no file upload route execution, no workbook open/read/write/execution, no workbook-container inspection, no file execution through Jarvis runtime, no drawing/PDF/image read, no OCR, no tool execution, no Output Center export, and no Job Center execution.

## Accepted R23 Checkpoint Summary

R23 was accepted as `PASS / ACCEPTABLE` and locked the minimal implementation plan. R23 documented the `/api/attach` response boundary, `kernel.attachments.save_upload(file)` handoff, `AttachmentMeta` wrapping, `router.route(req)` response flow, in-repo `saved_path` consumers, and future implementation gates. R23 recommended `api_attach_response_boundary_projection` only as a future option, identified `jarvis_v5/app.py` as the likely future primary candidate file, and recommended no `AttachmentStore` patch in the minimal path.

## Prior R24 Implementation-Patch Dry-Run Finding

The prior R24 implementation-patch dry run found no confirmed public `saved_path` exposure in the `/api/attach` `ChatResponse` path.

Static trace indicated:

```text
@app.post("/api/attach", response_model=ChatResponse)
def api_attach(..., file: UploadFile = File(...)) -> ChatResponse:
    saved = kernel.attachments.save_upload(file)
    req = ChatRequest(..., attachments=[AttachmentMeta(**saved)])
    return router.route(req)
```

Dry-run conclusion: Do not patch protected `jarvis_v5/app.py` without confirmed exposure. R24 is therefore retargeted to a no-source-change static compliance lock.

## /api/attach Static Response Boundary

Static compliance evidence to lock:

- `/api/attach` route exists.
- `/api/attach` `response_model` remains `ChatResponse`.
- `/api/attach` calls `kernel.attachments.save_upload(file)`.
- Saved metadata is wrapped as `AttachmentMeta(**saved)`.
- `AttachmentMeta` keeps `saved_path` as internal metadata.
- `/api/attach` returns `router.route(req)` and does not directly return the `saved` dictionary.
- `ChatResponse` has no direct `attachments` field.
- Attachment reducer output uses `public_workbook_ref(attachment)`.
- `public_workbook_ref` returns path-free public metadata.
- `public_workbook_ref` omits `saved_path` and raw path keys.

## Public Workbook Reference Allow-List

The path-free public projection in `public_workbook_ref` allows:

- `workbook_id`
- `attachment_id`
- `filename`
- `content_type`
- `size_bytes`
- `source`
- `bound_to_task_id`
- `created_at`

Forbidden public raw path keys remain:

- `saved_path`
- `path`
- `file_path`
- `absolute_path`
- `resolved_path`
- `raw_path`
- `local_path`
- `stored_path`
- `attachment_path`
- `directory`
- `parent`
- `full_path`
- `storage_root`

## Internal Metadata Boundary

`AttachmentStore.save_upload` remains unchanged. It owns persistence and can retain `saved_path` internally. `AttachmentMeta.saved_path` remains an internal metadata field. This checkpoint does not remove internal `saved_path` because permission-gated workbook lookup may still need internal storage metadata.

## Event Projection Boundary

Static compliance evidence confirms the `/api/events/{conversation_id}` route uses safe event projection:

- `api_events` obtains events from the event ledger;
- `api_events` calls `_project_events_safe(events)`;
- `_project_events_safe` maps each entry through `_project_event_safe(event)`;
- `_project_event_safe` returns an allow-listed summary and does not expose raw request metadata.

This means `_finalize` may keep request metadata internally while public event reads use safe projection.

## Permission and Workbook Boundary

R24 preserves the existing workbook safety boundary:

- permission gate remains before `_safe_attachment_file`;
- `_safe_attachment_file` remains before `load_workbook`;
- no workbook open/read/write/execution occurs in R24;
- no upload-to-workbook-read bridge is introduced.

## No-Source-Change Lock

R24 intentionally leaves these files unchanged:

- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`
- `requirements.txt`

## Future Functional Verification Gate

Functional upload verification requires explicit separate approval. Any later phase that uses FastAPI TestClient, calls `/api/attach`, executes upload mechanics, or inspects a live upload response must be separately planned and approved. Even then, workbook open/read/write/execution, OCR, document reader behavior, Output Center export, Job Center execution, and upload-to-workbook-read bridging remain excluded unless separately approved.

## Quarantined Backlog Rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for ideas only, but it cannot expand R24 scope, add R24 files, change the R24 target, promote OCR/document reader, promote file execution, promote workbook access, promote functional upload tests, or override checkpoint evidence.

## Protected Systems Not Touched

Protected runtime/source systems are not touched in R24. Builder formula/export engine, workbook policy runtime, preview policy, active-task writing/report guards, safe path resolver, Output Center runtime, Job Center runtime, UI/runtime modules, route handlers, middleware behavior, auth runtime behavior, workbook permission runtime, registries, and sidecar generator source remain unchanged.

## Closure Verdict

R24 locks the current static evidence that the `/api/attach` public response boundary is path-free under the inspected `ChatResponse` flow. R24 is a no-source-change static compliance lock and does not implement hardening.

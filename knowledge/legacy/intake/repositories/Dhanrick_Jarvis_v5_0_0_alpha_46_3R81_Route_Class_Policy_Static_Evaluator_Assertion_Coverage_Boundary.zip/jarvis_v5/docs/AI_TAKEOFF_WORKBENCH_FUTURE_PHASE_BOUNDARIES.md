# AI Takeoff Workbench Future Phase Boundaries

## Recommended sequence

1. alpha39.1 — Concept scope plan.
2. alpha39.2 — Selected Plan/Item Metadata Model Plan.
3. alpha39.3 — Takeoff Workbench Interaction Contract Plan.
4. alpha39.4 — Safe UI Mock Boundary Plan.
5. alpha39.5 — Backend Context Contract Dry Run.
6. Later only if approved — minimal source adapter for selected-context metadata.
7. Much later — UI/drawing/OCR/takeoff engine research, plan, dry run, confidence, fire, review.

## Rule

Do not start with UI implementation, drawing read, OCR, or takeoff engine.

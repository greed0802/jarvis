# v5.0.0-alpha.46.3R74 — Rate Limit Route Guard Attachment Candidate Matrix

## Mode
FIRE — evidence-only planning package.

## Base
`v5.0.0-alpha.46.3R73`

## Target
`v5.0.0-alpha.46.3R74 — Rate Limit Route Guard Attachment Candidate Matrix`

## Purpose
This document records the route-guard attachment candidate matrix required after accepted R73 and before any future route-guard-only implementation design may choose an attachment point. This checkpoint is design-only and does not implement route guards, rate limits, route dependencies, route decorators, router-level guards, middleware, identity keys, storage backends, failure behavior, error envelopes, headers, CORS, or runtime behavior.

## Attachment Candidate Matrix Lock

```text
route_guard_attachment_candidate_matrix_exists=true
route_guard_attachment_candidate_matrix_only=true
accepted_r73_route_guard_design_boundary_reviewed=true
attachment_candidates_defined=true
route_dependency_candidate_defined=true
router_level_guard_candidate_defined=true
explicit_wrapper_candidate_defined=true
route_class_policy_lookup_candidate_defined=true
no_guard_yet_candidate_defined=true
candidate_comparison_criteria_defined=true
candidate_scores_are_advisory_only=true
attachment_candidate_selected=false
route_dependency_guard_selected=false
router_level_guard_selected=false
explicit_route_wrapper_selected=false
route_class_policy_lookup_selected=false
no_guard_yet_selected_as_runtime_pattern=false
design_only=true
implementation_ready=false
implementation_approval_granted=false
protected_runtime_approval_granted=false
final_runtime_implementation_pattern_selected=false
route_guard_implementation=false
rate_limit_implementation=false
```

## Accepted R73 Boundary Reviewed

```text
accepted_r73_route_guard_design_boundary_reviewed=true
r73_route_guard_only_design_boundary_exists=true
r73_design_only=true
r73_route_guard_implementation=false
r73_rate_limit_implementation=false
```

R74 does not convert the R73 route-guard-only design boundary into runtime behavior. It defines candidates only.

## Candidate Comparison Matrix

| Candidate | Status | Benefit | Risk | Decision |
|---|---:|---|---|---|
| Route dependency guard | Candidate only | Explicit per-route attachment | Could require route dependency edits | Not selected |
| Router-level guard | Candidate only | Broader grouped control | Higher blast radius in router | Not selected |
| Explicit route wrapper | Candidate only | Localized wrapping model | Could alter handler behavior | Not selected |
| Route-class policy lookup | Candidate only | Metadata-first and classification-driven | Requires policy contract before execution | Not selected |
| No guard yet | Candidate only | Safest nonimplementation fallback | No implementation progress | Not selected as runtime pattern |

## Route Dependency Guard Candidate Boundary

```text
route_dependency_candidate_defined=true
route_dependency_guard_selected=false
route_dependency_modification=false
route_decorator_modification=false
route_guard_implementation=false
route_behavior_modification=false
```

Future questions only:

```text
which routes would receive a dependency
whether public/auth/debug/upload/output/job routes need different dependency handling
whether dependency injection exposes auth context safely
whether dependency-level denial can preserve error-envelope requirements
how rollback would remove dependency attachment cleanly
```

No route dependency attachment is allowed in R74.

## Router-Level Guard Candidate Boundary

```text
router_level_guard_candidate_defined=true
router_level_guard_selected=false
router_main_router_modification=false
router_level_guard_implementation=false
route_behavior_modification=false
```

Future questions only:

```text
whether router-level guard affects all 43 routes
whether route classes can be excluded safely
whether debug/dev or health routes need separate handling
whether router-level placement bypasses route-specific auth context
whether rollback blast radius is too broad
```

No router-level guard is allowed in R74.

## Explicit Route Wrapper Candidate Boundary

```text
explicit_wrapper_candidate_defined=true
explicit_route_wrapper_selected=false
route_wrapper_implementation=false
route_handler_modification=false
route_behavior_modification=false
```

Future questions only:

```text
whether wrappers preserve handler signatures
whether wrappers affect response shape
whether wrappers change exception propagation
whether wrappers appear in route/decorator scans
whether wrappers complicate testing and rollback
```

No wrapper behavior is allowed in R74.

## Route-Class Policy Lookup Candidate Boundary

```text
route_class_policy_lookup_candidate_defined=true
route_class_policy_lookup_selected=false
route_policy_lookup_implementation=false
route_class_policy_assigned=false
route_limit_value_selection=false
route_exemption_activation=false
```

Future questions only:

```text
whether route classes can be mapped without runtime behavior
whether policy lookup can be generated from static route metadata
whether unknown route classes remain blocked or unresolved
whether route policy metadata can be reviewed before execution
whether lookup remains separate from limit values and identity keys
```

This candidate aligns with metadata-first design but is not selected in R74.

## No-Guard-Yet Candidate Boundary

```text
no_guard_yet_candidate_defined=true
no_guard_yet_selected_as_runtime_pattern=false
route_guard_implementation=false
rate_limit_implementation=false
```

This remains a safety fallback only.

## Comparison Criteria

```text
candidate_comparison_criteria_defined=true
blast_radius=true
route_count_impact=true
middleware_count_impact=true
app_py_impact=true
router_main_router_impact=true
route_dependency_impact=true
route_decorator_impact=true
auth_context_availability=true
identity_key_readiness_dependency=true
error_envelope_dependency=true
cors_dependency=true
rollback_complexity=true
testability=true
protected_runtime_approval_required=true
candidate_scores_are_advisory_only=true
candidate_selected=false
implementation_approval_granted=false
```

## Current Accepted Base

```text
current_accepted_checkpoint=v5.0.0-alpha.46.3R73
rollback=v5.0.0-alpha.46.3R73
route_count=43
route_delta=0
middleware_count=1
middleware_delta=0
```

## Nonimplementation Lock

```text
route_guard_implementation=false
rate_limit_implementation=false
route_dependency_modification=false
route_decorator_modification=false
router_level_guard_implementation=false
route_wrapper_implementation=false
route_policy_lookup_implementation=false
route_class_policy_assigned=false
dependency_selection=false
dependency_installation=false
requirements_txt_modification=false
storage_backend_selection=false
redis_selection=false
cache_backend_selection=false
in_memory_limiter_selection=false
limiter_library_selection=false
backend_client_implementation=false
environment_variable_implementation=false
identity_key_implementation=false
api_key_extraction_implementation=false
ip_extraction_implementation=false
forwarded_header_trust_implementation=false
user_session_identity_implementation=false
fail_open_selection=false
fail_closed_selection=false
backend_outage_behavior_implementation=false
timeout_behavior_implementation=false
retry_behavior_implementation=false
error_envelope_implementation=false
rate_limit_429_response_implementation=false
retry_after_header_implementation=false
middleware_addition=false
middleware_configuration_change=false
middleware_count_change=false
middleware_ordering_selection=false
app_py_modification=false
router_main_router_modification=false
route_behavior_modification=false
route_exemption_activation=false
route_limit_value_selection=false
request_schema_modification=false
request_validation_implementation=false
cors_implementation=false
```

## Future Gates

```text
future_attachment_candidate_selection_requires_separate_plan_plus_fire=true
future_route_guard_only_implementation_requires_separate_plan_plus_fire=true
future_implementation_proposal_requires_separate_plan_plus_fire=true
future_dependency_selection_requires_separate_plan_plus_fire=true
future_storage_backend_selection_requires_separate_plan_plus_fire=true
future_identity_key_implementation_requires_separate_plan_plus_fire=true
future_failure_mode_selection_requires_separate_plan_plus_fire=true
future_error_envelope_implementation_requires_separate_plan_plus_fire=true
future_middleware_addition_requires_separate_plan_plus_fire_and_middleware_count_approval=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

## Protected Systems Not Touched

```text
requirements.txt
jarvis_v5/app.py
jarvis_v5/router/main_router.py
middleware registration
auth guards
global exception envelope
route behavior
route dependencies
route decorators
router-level guard behavior
request schemas
request validation
CORS
Builder formula/export engine
workbook policy runtime
preview policy
active-task writing/report guards
safe path resolver
Output Center runtime
Job Center runtime
AI Takeoff execution
document reader
OCR
tool execution
```

# Naming Policy — Snake Case and Artifacts

## Code/package paths

- Python packages: snake_case only
- Python modules: snake_case only
- Test pack files: snake_case only
- Avoid hyphens in internal paths

## Docs/reports

- Internal docs may use `UPPER_SNAKE.md` or `snake_case.md`
- Reports should use underscores and current version markers
- ZIP packages should use underscores, no spaces

## User output files

Use short readable pattern:

`Tool_SourceOrTrade_HHMM.ext`

Examples:

- `Builder_WallTypes_1417.xlsx`
- `Formatter_WallTypes_1420.xlsx`
- `QA_BasementBOQ_1015.xlsx`
- `TEMP_FormatHandoff_WallTypes_1418.xlsx`

## Clarification

Hyphens are not currently confirmed as an internal package-path issue in alpha36.5. This policy is future prevention.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

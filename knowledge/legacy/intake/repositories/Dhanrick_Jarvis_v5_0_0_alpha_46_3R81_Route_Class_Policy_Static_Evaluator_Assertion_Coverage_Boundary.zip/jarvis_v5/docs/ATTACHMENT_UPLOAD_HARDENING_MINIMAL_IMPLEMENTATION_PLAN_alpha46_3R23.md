# alpha46.3R23 — Attachment Upload Hardening Minimal Implementation Plan

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R23`
- Base: `v5.0.0-alpha.46.3R22`
- Target: `Attachment Upload Hardening Minimal Implementation Plan`
- Rollback: `v5.0.0-alpha.46.3R22`

## Scope Statement

R23 is implementation planning only. It is not an implementation phase.

R23 makes no runtime behavior change, no source behavior change, no attachment upload behavior change, no `app.py` patch, no `attachment_store.py` patch, no `message_schema.py` patch, no `main_router.py` patch, no route behavior change, no metadata schema implementation, no saved_path redaction implementation, and no sidecar generator source patch.

R23 performs no runtime import, no `app.py` import, no FastAPI TestClient execution, no API route calls, no attachment upload execution, no file upload route execution, no workbook open/read/write/execution, no workbook-container inspection, no file execution through Jarvis runtime, no drawing/PDF/image read, no OCR, no tool execution, no Output Center export, and no Job Center execution.

## Accepted R22 Contract Summary

R22 was accepted as `PASS / ACCEPTABLE` and locked these contract rules:

- public/private attachment metadata boundary;
- `saved_path` internal-only contract;
- upload response allow-list contract;
- forbidden public raw path keys;
- upload does not authorize workbook read;
- permission-before-workbook-access requirement;
- future implementation requires separate PLAN / DRY RUN / FIRE.

## Static Response Boundary Scan

Static source inspection confirms the `/api/attach` response boundary currently follows this source flow:

```text
@app.post("/api/attach", response_model=ChatResponse)
def api_attach(..., file: UploadFile = File(...)) -> ChatResponse:
    saved = kernel.attachments.save_upload(file)
    req = ChatRequest(..., attachments=[AttachmentMeta(**saved)])
    return router.route(req)
```

Static interpretation:

- `/api/attach` calls `kernel.attachments.save_upload(file)`.
- Saved metadata enters `AttachmentMeta` via `AttachmentMeta(**saved)`.
- `/api/attach` returns `router.route(req)`.
- `/api/attach` does not directly return the `saved` dictionary.
- The future response-shape trace must examine the `router.route(req)` / `ChatResponse` output path before any implementation patch.

## saved_path Consumer Scan

Static in-repo source scan identifies `saved_path` consumers or guards in these runtime/source areas:

- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/metadata_bridge/manifest_metadata_adapter.py`
- `jarvis_v5/router/active_task_language_gate.py`
- `jarvis_v5/router/clarification_gate.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/router/no_active_task_language_gate.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/tools/builder/contract_fixture_replay.py`
- `jarvis_v5/tools/builder/preview_execution_policy.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_metadata_probe_approval.py`
- `jarvis_v5/tools/builder/workbook_read_preflight_contract.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`


Planning interpretation:

- `AttachmentStore.save_upload` creates internal metadata that includes `saved_path`.
- `AttachmentMeta.saved_path` remains the internal schema field.
- `public_workbook_ref` omits `saved_path` from public workbook reference output.
- `safe_workbook_path_resolver` treats `saved_path` as forbidden raw path metadata.
- Workbook sheet-name probe approval uses `saved_path` only behind permission-gated safe attachment lookup.

## Minimal Implementation Options

### Option A — api_attach_response_boundary_projection

Plan a minimal path-free public projection at the `/api/attach` public response boundary or its immediate public response projection path.

This option preserves `AttachmentStore.save_upload`, keeps `saved_path` internal, and avoids changing storage behavior.

Assessment: recommended future implementation option.

### Option B — public helper/schema projection

Plan a reusable public attachment reference helper or schema, likely in `message_schema.py`, only if a later DRY RUN proves it is safer than local response-boundary projection.

Assessment: cleaner but broader, not the minimal default.

### Option C — AttachmentStore return-shape change

Change `AttachmentStore.save_upload` to remove `saved_path` from its return shape.

Assessment: not recommended for the minimal path because it risks breaking internal permission-gated lookup behavior.

### Option D — router/event redaction first

Redact event/router metadata before changing upload response behavior.

Assessment: defer unless future static evidence proves an event payload is a public exposure path.

## Recommended Future Implementation Scope

Recommended future implementation option: `api_attach_response_boundary_projection`.

Likely future primary candidate file: `jarvis_v5/app.py`.

Possible secondary file only if needed: `jarvis_v5/schemas/message_schema.py`.

Recommended minimal path:

- implement a path-free public projection at `/api/attach` or the immediate public response path;
- keep `AttachmentStore.save_upload` unchanged;
- keep `AttachmentMeta.saved_path` available internally;
- keep permission-gated workbook lookup unchanged;
- preserve route count, middleware count, dependencies, registries, Builder, workbook, Output Center, and Job Center behavior.

## Public / Private Metadata Projection Plan

Future public allow-list should include only path-free fields such as:

- `attachment_id`;
- `filename` or `display_name`;
- `content_type`;
- `size_bytes`;
- `created_at` or `uploaded_at`, if already available;
- `source`, if already public-safe;
- `bound_to_task_id`, if already public-safe.

Forbidden public fields:

- `saved_path`;
- `path`;
- `file_path`;
- `absolute_path`;
- `resolved_path`;
- `raw_path`;
- `local_path`;
- `stored_path`;
- `attachment_path`;
- `directory`;
- `parent`;
- `full_path`;
- `storage_root`.

Projection rule: do not return `AttachmentMeta.model_dump()` directly to clients if it contains `saved_path`; use an explicit path-free projection.

## saved_path Redaction Plan

Future implementation should preserve internal behavior while redacting public exposure:

- `saved_path` remains available internally for permission-gated workbook lookup;
- `saved_path` is not accepted from user input;
- `saved_path` is not returned in public `/api/attach` responses;
- `saved_path` is not returned in public workbook references;
- `saved_path` does not authorize workbook read;
- permission gate remains before safe attachment file lookup.

Future negative assertions should prove these keys are absent from public upload responses:

- `saved_path`
- `absolute_path`
- `file_path`
- `local_path`
- `stored_path`
- `resolved_path`
- `raw_path`
- `directory`
- `parent`
- `full_path`

## Upload Response Compatibility Risks

Primary risk: if any client or UI path expects `saved_path` in `/api/attach`-related output, redaction may be a response-shape change.

Current dry-run finding: no direct `/api/attach` frontend consumer was confirmed in the static scan; most `/api/attach` references are docs, tests, packs, or test executor metadata.

Future mitigation:

1. keep stable public fields;
2. remove only forbidden raw path fields;
3. keep `attachment_id`, filename/display name, content type, and size fields stable where already present;
4. document `saved_path` removal as security hardening;
5. run a tighter static response-shape trace before any `app.py` patch.

## Future Functional Test Approval Gate

R23 does not authorize functional tests.

Future sequence:

- R23: implementation plan only.
- R24: minimal static implementation patch, if separately approved.
- R25: controlled functional verification, if separately approved.

Functional upload testing requires explicit separate approval for:

- FastAPI TestClient;
- `/api/attach` route execution;
- attachment upload execution;
- any temporary upload fixture;
- any route call.

Even in future functional verification, no workbook open/read/write, no upload-to-workbook-read bridge, no OCR, and no file content inspection beyond approved upload fixture mechanics are allowed unless separately approved.

## Excluded Scope

R23 excludes:

- attachment upload behavior patch;
- `app.py` source patch;
- `attachment_store.py` source patch;
- `message_schema.py` patch;
- `main_router.py` patch;
- public response behavior change;
- metadata schema implementation;
- `saved_path` redaction implementation;
- upload route patch;
- route change;
- middleware change;
- dependency change;
- registry change;
- runtime import;
- FastAPI TestClient;
- API route call;
- attachment upload execution;
- file upload route execution;
- workbook open/read/write/execution;
- workbook-container inspection;
- file execution through Jarvis runtime;
- source behavior change.

## Protected Systems Not Touched

R23 does not modify:

- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`
- `requirements.txt`
- registries
- route handlers
- middleware behavior
- auth runtime boundary
- workbook permission runtime
- workbook policy runtime
- Builder formula/export engine
- Formatter workbook behavior
- QA Checker workbook behavior
- Description / BOQ Writer workbook behavior
- preview/export policy
- active-task writing/report guards
- Output Center runtime
- Job Center runtime
- schemas
- UI/runtime modules
- sidecar generator source

## Quarantined Backlog Rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for future ideas, but it cannot expand R23 scope, add R23 files, change the R23 target, promote OCR/document reader, promote file execution, promote workbook access, promote personal assistant features, or override checkpoint evidence.

## Closure Verdict

R23 plans the minimal future implementation path only. It recommends a future `api_attach_response_boundary_projection` path, likely in `jarvis_v5/app.py`, but it does not implement hardening.

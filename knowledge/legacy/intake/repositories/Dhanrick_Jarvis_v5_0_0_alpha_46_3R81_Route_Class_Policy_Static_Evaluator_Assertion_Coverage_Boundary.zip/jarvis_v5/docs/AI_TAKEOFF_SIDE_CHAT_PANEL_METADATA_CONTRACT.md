# AI Takeoff Side Chat Panel Metadata Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines safe side-chat panel metadata. The side chat receives metadata only and cannot claim visual access.

## Allowed metadata example

```json
{
  "panel_id": "side_chat_panel_meta_001",
  "conversation_scope": "ai_takeoff_workbench_metadata_only",
  "selected_plan_safe_display_name": "A-105 Level 05 Floor Plan",
  "selected_takeoff_item_label": "External Wall Type A",
  "permissions": {
    "drawing_read": false,
    "ocr": false,
    "takeoff_engine": false,
    "workbook_read": false,
    "quantity_writeback": false
  },
  "approval_token_issued": false
}
```

## Allowed side-chat actions

explain selected metadata, ask clarifying questions, draft measurement intent, explain blocked action reason, suggest next approval step, and prepare QA checklist.

## Blocked side-chat actions

reading plan content, OCR, measuring, running takeoff engine, opening workbook, writing quantities, issuing approval token, and claiming visual access are blocked.

# Jarvis Patch-Only Package Strategy

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch

## Purpose

Patch-only packages reduce review size by including only files that changed between checkpoints.

## Required Contents

- added files
- changed files
- deleted-file manifest
- changed-files manifest
- base version
- target version
- SHA256 manifest
- rollback instructions

## Required Exclusions

- `.pytest_cache/`
- `__pycache__/`
- `*.pyc`
- local secrets
- runtime data
- unrelated packages
- old full-release ZIPs
- large fixtures unless explicitly approved

## Review Rule

Patch-only packages should become the default review artifact once full packages exceed comfortable review size.

## Deleted-File Tombstones

If a file is removed in a future approved scope, the patch package must include a deletion manifest rather than silently omitting the file.



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

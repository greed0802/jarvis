# AI Takeoff Workbench Side Chat Panel Concept

## Purpose

A future Jarvis chat panel may respond using selected metadata context. It should show or declare what context it is using and ask for permission before reading drawings, workbooks, or production files.

## Safe early chat behavior

- Explain selected item metadata.
- Summarize selected quantity metadata.
- Suggest QS QA checks.
- Draft BOQ wording from provided metadata.
- Ask clarification questions.
- Identify missing context.
- Prepare a takeoff checklist.
- Compare declared unit vs selected measurement type.
- Warn about possible scope/level mismatch.

## Blocked early chat behavior

- Read drawing contents.
- Infer dimensions from image.
- Perform automatic takeoff.
- Generate quantities.
- Write quantities.
- Modify workbook.
- Modify takeoff data.
- Export workbook.
- Run Builder/Formatter/QA/O&A runtime.

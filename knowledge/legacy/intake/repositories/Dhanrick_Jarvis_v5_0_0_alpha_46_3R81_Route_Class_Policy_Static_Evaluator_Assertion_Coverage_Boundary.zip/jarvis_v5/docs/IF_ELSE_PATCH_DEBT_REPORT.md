# If/Else Patch Debt Report

Version: v5.0.0-alpha.36.7


- audit_only=true
- refactor_performed=false
- runtime_behavior_changed=false
- duplicates_removed=false
- owners_changed=false
- workbook_runtime_changed=false
- route_behavior_changed=false
- registry_loader_changed=false
- builder_runtime_changed=false
- execution_enabled=false
- workbook_read=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- sheet_name_probe_allowed=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false


alpha36.7 inventories complex branch families only.

Observed concentration categories:

| file_path | branch_type | reason | risk | classification | future_action |
|---|---|---|---|---|
| jarvis_v5/router/main_router.py | intent and fallback routing | route safety and compatibility | medium | policy_state_machine | audit before routing change |
| jarvis_v5/app.py | endpoint dispatch and response branching | API ownership | medium | compatibility_branch | do_not_touch now |
| jarvis_v5/tools/builder/workbook_read_preflight_contract.py | workbook safety branching | no-read enforcement | high | safe_guard | wrap under unified gate later |
| jarvis_v5/tools/builder/workbook_metadata_probe_approval.py | approval/content block branching | metadata governance | high | safe_guard | future gate alignment |
| jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py | approval/sheet result branching | legacy sheet owner | high | compatibility_branch | WRAP later |
| jarvis_v5/tools/builder/legacy_import_boundary_audit.py | legacy audit branching | boundary reporting | low | legacy_audit_only | preserve |

Classification values: policy_state_machine, compatibility_branch, patch_debt_candidate, safe_guard, clarification_branch, do_not_touch.
No if/else branch was rewritten in alpha36.7.

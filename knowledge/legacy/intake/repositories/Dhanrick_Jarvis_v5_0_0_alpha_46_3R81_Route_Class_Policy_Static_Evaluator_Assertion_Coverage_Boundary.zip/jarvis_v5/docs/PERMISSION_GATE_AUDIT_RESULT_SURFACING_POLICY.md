# Permission Gate Audit / Result Surfacing Policy

## May surface later
- decision
- allowed
- reason
- action
- requested_scope
- blocked_scope
- contract_id presence only
- approval_granted flag
- contains_workbook_data=false
- safety flags such as workbook_content_read=false, formula_read=false, cell_value_read=false, style_read=false

## Must stay hidden
- saved_path
- raw workbook_ref
- absolute/local file paths
- sheet names in blocked responses
- cell values
- formulas
- styles
- workbook content
- Builder internals
- private attachment path

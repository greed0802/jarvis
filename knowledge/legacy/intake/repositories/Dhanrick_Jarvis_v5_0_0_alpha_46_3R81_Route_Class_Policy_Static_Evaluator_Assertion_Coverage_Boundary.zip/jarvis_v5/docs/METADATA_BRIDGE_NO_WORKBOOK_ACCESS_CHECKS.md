# Metadata Bridge No Workbook Access Checks

Version: v5.0.0-alpha.38.4

## Future test requirements

```text
no openpyxl import
no load_workbook call
no zipfile workbook inspection
no pathlib/open call on workbook path
no workbook object accepted as input
no file handle accepted as input
no sheet count read
no sheet name read from workbook
no cell/formula/style read
no workbook fixture dependency
```

## Test approach

```text
static text scan for forbidden imports/calls
unit tests with manifest-only dictionaries
fail-closed tests for path-like and workbook-like inputs
protected hash compare after test run
```

alpha38.4 does not create or run an adapter. It only defines checks for the later isolated adapter phase.

# Metadata Bridge Post-Approval Adapter Call Policy

Required future ordering:
1. Route receives request.
2. Route validates schema.
3. Route validates source_kind and contract_type.
4. Route verifies approval/permission context.
5. Route fails closed if permission fails.
6. Route calls evaluate_manifest_metadata_request().
7. Adapter returns safe result.
8. Route creates audit/result record.
9. Route returns safe UI response.

Blocked ordering:
- adapter call before approval
- workbook access before approval
- workbook access after approval
- audit after unsafe response
- raw result exposure before redaction

No route integration occurs in alpha38.9.

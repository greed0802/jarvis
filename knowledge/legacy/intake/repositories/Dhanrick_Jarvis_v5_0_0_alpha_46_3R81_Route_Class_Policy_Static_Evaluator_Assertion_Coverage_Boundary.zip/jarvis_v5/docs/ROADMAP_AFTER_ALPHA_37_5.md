# Roadmap After alpha37.5

1. alpha37.6.1 — Sheet-name Execution Permission Contract Expansion.
2. REVIEW alpha37.6.1 evidence package.
3. alpha37.6.2 — Legacy Sheet-name Owner Wrapper Implementation Dry Run.
4. Only after acceptance, consider controlled legacy owner wrapper FIRE.

Do not connect routes or enable workbook access before review and explicit FIRE.

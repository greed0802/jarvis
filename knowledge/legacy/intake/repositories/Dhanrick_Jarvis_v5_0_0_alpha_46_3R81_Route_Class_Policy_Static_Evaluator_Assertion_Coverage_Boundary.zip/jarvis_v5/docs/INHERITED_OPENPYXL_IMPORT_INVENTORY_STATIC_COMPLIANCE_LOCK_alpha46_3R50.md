# v5.0.0-alpha.46.3R50 — Inherited openpyxl Import Inventory Static Compliance Lock

## Status

R50 is an evidence-only static compliance lock from accepted base `v5.0.0-alpha.46.3R49`.

R50 preserves the R49 inherited direct openpyxl import inventory exactly. It does not remove inherited imports, refactor inherited files, select or approve an openpyxl candidate version, add a pin, install dependencies, import Jarvis runtime, call routes, inspect workbook containers, or execute workbook/document/OCR/tool/output/job behavior.

## Compliance boundary statement

```text
Expected inherited direct openpyxl import count: 2.
Expected inherited direct openpyxl import locations are fixed.
No new direct openpyxl import.
No inherited openpyxl import removal.
No inherited openpyxl import refactor.
No openpyxl runtime use.
No openpyxl pin.
No dependency change.
No candidate supplied/selected/invented/approved/applied.
Future removal/refactor requires separate PLAN plus FIRE.
Future dependency candidate/pin requires explicit user approval plus separate FIRE.
```

## Static compliance inventory

- `jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py` — inherited=true; static_compliance_target=true; new_in_R50=false; modified_in_R50=false; removal_approved=false; refactor_approved=false; runtime_executed=false; sha256=`b63618986e5cef827e0154578d3580fa1cf7fd9f08475b67bb04579bac1831c3`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` — inherited=true; static_compliance_target=true; new_in_R50=false; modified_in_R50=false; removal_approved=false; refactor_approved=false; runtime_executed=false; sha256=`5d0dfec79783b73626631baa1b3e17b01e20ef11463b158cf8d8ff759674a17d`

## Classification matrix

| Location | Category | Inherited from base | Static compliance target | New in R50 | Modified in R50 | Removal approved | Refactor approved | Runtime executed in R50 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py` | smoke evidence / historical sheet-name probe hardening | true | true | false | false | false | false | false |
| `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` | Builder tool boundary / sheet-name probe approval bridge | true | true | false | false | false | false | false |

## Locked facts

```text
inherited_openpyxl_import_inventory_static_compliance_lock_only=true
static_compliance_only=true
expected_inherited_direct_openpyxl_import_file_count=2
actual_inherited_direct_openpyxl_import_file_count=2
expected_new_direct_openpyxl_import_file_count=0
new_openpyxl_import_added=false
inherited_imports_removed=false
inherited_imports_refactored=false
implementation_executed=false
source_modified_except_allowed_evidence=false
requirements_txt_changed=false
requirements_txt_change_allowed=false
dependency_installed=false
dependency_changed=false
openpyxl_pin_added=false
candidate_selection_executed=false
candidate_version_supplied=false
candidate_version_selected=false
candidate_version_invented=false
candidate_version_approved=false
candidate_version_applied=false
openpyxl_runtime_used=false
workbook_runtime_enabled=false
workbook_open_read_write=false
workbook_container_inspected=false
builder_execution_enabled=false
output_center_export_executed=false
job_center_execution=false
runtime_imported=false
app_imported=false
fastapi_testclient_used=false
api_route_called=false
route_count=43
route_delta=0
middleware_count=1
future_candidate_requires_explicit_user_approval=true
future_actual_pin_requires_separate_fire=true
future_import_removal_or_refactor_requires_separate_plan_and_fire=true
```

## Stop condition preserved

Any drift from the exact inherited import count/location inventory must stop the phase and require manual review.

## Sidecar identity lock

R50 requires the tracker inside the package, the standalone tracker sidecar, the manifest tracker SHA, and the FIRE outputs tracker copy to match byte-for-byte.

```text
tracker_sha256=154cb619414f655a413a8186666521d457a0aa5460767a375bfd7d1fb4b7d009
```

## Protected source hashes

```text
requirements.txt=a7cdfba90512a58a19d3686ef20f9b5b5ac8c8a155f0bde3e31b1bcb4851922c
jarvis_v5/app.py=9d833409b7d03b0add470dc14dfd19ab2ebaae0d9956e7e6f15e9156e8d98e93
jarvis_v5/router/main_router.py=914194fd4522ddc61dddad0b0d5e25e03aa4e2d8c1d6f1f34c4692a42170e820
jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py=b63618986e5cef827e0154578d3580fa1cf7fd9f08475b67bb04579bac1831c3
jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py=5d0dfec79783b73626631baa1b3e17b01e20ef11463b158cf8d8ff759674a17d
```

## Rollback

`v5.0.0-alpha.46.3R49`

# Metadata Bridge Protected Files Exclusion List

Version: v5.0.0-alpha.38.4

## Protected files excluded from future minimal source patch

```text
jarvis_v5/app.py
jarvis_v5/config.py
jarvis_v5/registry/registry_loader.py
permission-gate modules
owner-wrapper modules
route modules
Builder runtime modules
Formatter runtime modules
QA runtime modules
O&A runtime modules
Document Reader runtime modules
Output Center runtime modules
Job runtime modules
safe path resolver
preview policy
static/UI
inherited workbook fixture files
```

## Rule

Any protected file edit requires separate explicit approval.

alpha38.4 does not edit source, does not create future source files, and does not approve protected edits.

# Inherited Workbook Fixture Runtime Risk Policy

Version: v5.0.0-alpha.37.11.1

## Policy
Runtime/source modules must not use `jarvis_v5/tests/fixtures/*.xlsx` as production defaults. Routes must not directly load inherited workbook fixtures.

## Confirmed test-harness reference
`jarvis_v5/qa_runner/test_executor.py` contains fixture support through a fixtures directory and `step.file_fixture` style references. This is classified as test_harness_source_reference.

## Risk levels

| Finding | Risk | Required action |
|---|---|---|
| Smoke test references fixture | Low | Keep until test replacement is planned |
| JSON test pack references fixture | Low-medium | Keep until pack is superseded |
| Docs/history mentions fixture | Low | Keep as evidence |
| QA runner fixture resolver | Medium | Must remain test-harness scoped |
| Runtime source references tests/fixtures/*.xlsx | High | Stop acceptance and plan patch |
| Route handler can reach tests/fixtures/*.xlsx | High | Stop acceptance and plan patch |
| Metadata-only phase opens inherited fixture | High | Stop acceptance |

## Blocked patterns
- `load_workbook("jarvis_v5/tests/fixtures/Test.xlsx")` in runtime code
- `load_workbook("jarvis_v5/tests/fixtures/SheetProbe.xlsx")` in runtime code
- route handler using `tests/fixtures/*.xlsx`
- default workbook path set to `tests/fixtures/*.xlsx`
- `_safe_attachment_file` resolving to inherited test fixtures

## Required rule
Any expansion of fixture access into runtime routes requires a separate permission contract and approved phase.

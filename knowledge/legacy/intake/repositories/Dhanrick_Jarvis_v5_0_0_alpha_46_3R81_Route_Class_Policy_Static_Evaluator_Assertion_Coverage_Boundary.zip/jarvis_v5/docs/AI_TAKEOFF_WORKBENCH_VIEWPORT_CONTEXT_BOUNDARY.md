# AI Takeoff Workbench Viewport Context Boundary

Version: v5.0.0-alpha.39.0  
Base: v5.0.0-alpha.38.9  
Mode: docs/tests/evidence only


## Boundary

The viewport is conceptual only in alpha39.0.

## Allowed as future metadata concepts

- current_plan_id
- current_page
- visible_scale
- selected_plan_region_id
- selected_takeoff_item_id
- selected_measurement_ids

## Blocked in alpha39.0

No plan viewport implementation, drawing render, image creation, PDF read, OCR, CAD/vector parsing, takeoff measurement engine, selected-plan runtime binding, raw drawing pixels, OCR text, CAD geometry, measurement vectors, plan file path, or private drawing path.

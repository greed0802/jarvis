# Package Artifact Hygiene Policy

Release packages should separate current evidence, historical evidence, runtime source, test assets, user outputs, and temporary artifacts.

## Root package policy

Root package should contain only:

- README.md
- requirements/configuration files
- smoke runner scripts
- current alpha backend status
- current alpha handoff
- current alpha change/test/hash/registry/hygiene/duplicate/changed-files reports
- one current start script if needed

Historical reports should be archived under `docs/version_history`.

Temporary files should not ship in release ZIPs.

Debug/runtime outputs should not ship unless explicitly included as evidence.

## Hygiene rules

- no `__pycache__`
- no `.pyc`
- no `.pytest_cache`
- no runtime data non-.keep files

## Output naming policy

User-facing runtime output files should use short readable names such as:

- `Builder_WallTypes_1417.xlsx`
- `Formatter_WallTypes_1420.xlsx`
- `TEMP_FormatHandoff_WallTypes_1418.xlsx`

Full metadata belongs in JSON/debug metadata, not filenames. Temporary handoffs must include `TEMP` and metadata `temporary=true`.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

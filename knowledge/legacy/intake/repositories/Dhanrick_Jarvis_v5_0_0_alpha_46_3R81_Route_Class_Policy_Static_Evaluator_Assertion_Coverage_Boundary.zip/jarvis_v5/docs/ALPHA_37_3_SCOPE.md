# ALPHA 37.3 Scope — Unified Workbook Permission Gate Implementation Plan

Version target: v5.0.0-alpha.37.3

Mode: Implementation plan only. No runtime implementation.

planning_only=true
implementation_created=false
runtime_called=false
route_behavior_changed=false
endpoint_added=false
workbook_opened=false
sheet_names_read=false
content_read=false
formula_read=false
cell_value_read=false
style_read=false
safe_path_resolver_called=false
builder_runtime_changed=false
workbook_runtime_changed=false
root_launchers_preserved=true
package_hygiene_guard_required=true

Protected boundaries: app.py, routes, registry_loader.py, Builder formula/export engine, workbook policy runtime, safe path resolver, preview policy, Formatter/QA/O&A/Document Reader/Output Center/Job runtime, static/UI.

This document is evidence/planning only. It does not create or call runtime code.

Allowed scope: docs/tests/evidence only. Future implementation must require separate approval.

# alpha46.3R15 — Auth Boundary Phase Closure Regression Lock

**Version:** v5.0.0-alpha.46.3R15  
**Base:** v5.0.0-alpha.46.3R14  
**Rollback checkpoint:** v5.0.0-alpha.46.3R14  

Rollback checkpoint: v5.0.0-alpha.46.3R14
**Scope:** Non-runtime evidence closure only

## 1. Scope statement

R15 closes the R11–R14 auth boundary phase as an evidence and regression-lock layer only.

R15 does not change runtime behavior. R15 does not modify `jarvis_v5/app.py`. R15 does not add, remove, or alter routes, middleware, dependencies, registries, schemas, handlers, Builder systems, workbook policy runtime, Output Center, Job Center, tool execution, safe path resolver, preview/export policy, active-task writing/report guards, UI/runtime modules, OCR, drawing/PDF/image handling, or workbook execution behavior.

## 2. Phase summary

The R11–R14 auth boundary phase follows the current Jarvis architecture principle:

```text
Metadata first.
Contracts before execution.
Permission before workbook access.
Approval before execution.
Preview before export.
```

The phase chain is:

```text
R11 = Auth / API-key Route Enforcement Contract
R12 = Minimal Auth / API-key Enforcement Boundary
R13 = Auth Functional Verification Contract
R14 = Controlled Auth Functional Verification
R15 = Auth Boundary Phase Closure Regression Lock
```

## 3. R11 evidence — contract before implementation

R11 established the auth/API-key route enforcement contract before runtime enforcement was implemented.

Confirmed R11 evidence:

```text
Route count: 43
Route delta: 0
Runtime import: false
app.py import: false
API route calls: false
Auth route classes:
- _AUTH_PUBLIC_ROUTES: 12
- _AUTH_PROTECTED_ROUTES: 26
- _AUTH_DEV_DEBUG_ROUTES: 3
- _AUTH_DEV_TEST_ROUTES: 2
```

R11 defined the future route classification and safe unauthorized-envelope expectations without changing runtime behavior.

## 4. R12 evidence — minimal implementation

R12 implemented the minimal API-key enforcement boundary after the R11 contract.

Confirmed R12 evidence:

```text
Route count: 43
Route delta: 0
Requirements changed: false
Registries changed: false
Runtime verification by TestClient: false
API route calls: false
```

R12 implemented the boundary in `jarvis_v5/app.py` only and preserved route count, route templates, dependencies, registries, Builder/workbook/output/job behavior, and unknown-route behavior.

## 5. R13 evidence — permission contract before functional verification

R13 created the functional verification contract before any approved runtime verification.

Confirmed R13 evidence:

```text
Runtime import: false
app.py import: false
FastAPI TestClient used: false
API route calls: false
Workbook execution by Jarvis runtime: false
Tool execution: false
Output Center export: false
Job Center execution: false
```

R13 explicitly separated permission for a later auth-only functional check from actual execution.

## 6. R14 evidence — controlled auth-only functional verification

R14 executed the approved auth-only FastAPI TestClient route matrix under the R13 permission contract.

Confirmed R14 evidence:

```text
Functional smoke result: 7 passed
Runtime import: true
app.py import: true
FastAPI TestClient used: true
API route calls: true
API route call scope: approved_auth_only_route_matrix
Business-success assertions for valid-key protected routes: false
Workbook execution by Jarvis runtime: false
Tool execution: false
Output Center export: false
Job Center execution: false
R14 new Source of Truth Python references: 0
```

R14 also verified that the safe auth envelope does not expose key/header/env/config values.

## 7. R15 closure rules

R15 locks the completed auth boundary phase under these regression rules:

1. Future auth changes must preserve the R11 route classification intent unless a new approved contract supersedes it.
2. Future protected-route behavior must not assume business success from auth-only verification.
3. Future functional verification must be preceded by an explicit permission contract.
4. Auth tests must not execute Builder, workbook, tool, Output Center, Job Center, OCR, drawing/PDF/image, or takeoff behavior unless separately approved.
5. The Source of Truth tracker remains external evidence/tracker only and must not become runtime policy.
6. R14 remains the rollback checkpoint for the auth functional verification phase.

## 8. Protected systems not touched by R15

R15 does not touch:

```text
jarvis_v5/app.py
requirements.txt
registries
route handlers
middleware behavior
auth runtime behavior
Builder formula/export engine
workbook policy runtime
preview/export policy
active-task writing/report guards
safe path resolver
Output Center runtime
Job Center runtime
UI/runtime modules
OCR / drawing / PDF / image handling
takeoff execution
```

## 9. Static verification expectations

R15 verification is static-only. It must not import Jarvis runtime, import `jarvis_v5.app`, construct FastAPI TestClient, or call API routes.

Expected R15 checks:

```text
R11–R14 evidence files exist.
R15 closure document exists.
R15 manifest exists.
R15 manifest records exact file delta.
R15 manifest records runtime_imported=false.
R15 manifest records app_imported=false.
R15 manifest records fastapi_testclient_used=false.
R15 manifest records api_route_calls=false.
R15 manifest records workbook/tool/output/job execution=false.
R15 manifest records route_count=43.
R15 manifest records route_delta=0.
R15 manifest records middleware_count=1.
R15 manifest records auth counts 12 / 26 / 3 / 2.
R15 manifest records R14 functional result as 7 passed.
R15 manifest records R14 route-call scope as approved_auth_only_route_matrix.
R15 manifest records no business-success assertion for valid-key protected routes.
R15 manifest records R14 new Source of Truth Python references as 0.
Tracker SHA must match source_of_truth_manifest_alpha46_3R15.json.
```

## 10. Closure verdict

The R11–R14 auth boundary phase is closed as of R15 evidence lock. R15 is a non-runtime regression lock only. R14 remains the rollback checkpoint for controlled auth functional verification.

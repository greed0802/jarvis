# v5.0.0-alpha.46.3R11 — Auth / API-key Route Enforcement Contract

## Status

Contract/static regression lock only. No runtime auth/API-key middleware is implemented in R11.

## Base and target

- Base: `v5.0.0-alpha.46.3R10`
- Target: `v5.0.0-alpha.46.3R11`
- Scope: route enforcement contract and static smoke test only
- Runtime behavior changed: `false`
- Route behavior changed: `false`
- Middleware added: `false`
- Route dependencies added: `false`
- Requirements changed: `false`

## Purpose

R11 locks the future auth/API-key route enforcement matrix before any implementation patch. The contract maps all 43 current routes into future auth classes and defines the safe unauthorized response envelope for protected routes.

This contract depends on prior accepted safety checkpoints:

- R6 route access classification contract
- R7 debug/dev route guard contract
- R9 `/api/events` safe projection implementation
- R10 `saved_path` / attachment projection contract

## Future auth classes

| Class | Meaning | Runtime implementation in R11 |
|---|---|---:|
| `PUBLIC_READONLY` | Safe metadata/read-only route planned to remain unauthenticated | No |
| `PROTECTED` | Route planned to require future API-key auth | No |
| `DEV_DEBUG_ONLY` | Debug route governed by R7 `DEBUG_MODE` guard; future auth decision separate | No |
| `DEV_TEST_ONLY` | Dev/test route governed by R7 `DEBUG_MODE` guard; future auth decision separate | No |

## Required class counts

| Class | Count |
|---|---:|
| `PUBLIC_READONLY` | 12 |
| `PROTECTED` | 26 |
| `DEV_DEBUG_ONLY` | 3 |
| `DEV_TEST_ONLY` | 2 |
| **Total** | **43** |

## Public route list

These routes are planned as future public read-only metadata/catalog routes:

| Method | Route | Handler | Future auth class |
|---|---|---|---|
| GET | `/api/version` | `api_version` | `PUBLIC_READONLY` |
| GET | `/api/registry/tools` | `api_registry_tools` | `PUBLIC_READONLY` |
| GET | `/api/registry/capabilities` | `api_registry_capabilities` | `PUBLIC_READONLY` |
| GET | `/api/registry/connectors` | `api_registry_connectors` | `PUBLIC_READONLY` |
| GET | `/api/registry/models` | `api_registry_models` | `PUBLIC_READONLY` |
| GET | `/api/registry/execution-policies` | `api_registry_execution_policies` | `PUBLIC_READONLY` |
| GET | `/api/registry/source-authorities` | `api_registry_source_authorities` | `PUBLIC_READONLY` |
| GET | `/api/registry/scope-advisors` | `api_registry_scope_advisors` | `PUBLIC_READONLY` |
| GET | `/api/registry/file-requirements` | `api_registry_file_requirements` | `PUBLIC_READONLY` |
| GET | `/api/registry/rfi-templates` | `api_registry_rfi_templates` | `PUBLIC_READONLY` |
| GET | `/api/registry/ecosystem-adapters` | `api_registry_ecosystem_adapters` | `PUBLIC_READONLY` |
| GET | `/api/registry/voice-assistants` | `api_registry_voice_assistants` | `PUBLIC_READONLY` |

## Protected route list

These routes are planned to require future API-key auth:

| Method | Route | Handler | Future auth class |
|---|---|---|---|
| POST | `/api/registry/requirement-check` | `api_registry_requirement_check` | `PROTECTED` |
| POST | `/api/chat` | `api_chat` | `PROTECTED` |
| POST | `/api/attach` | `api_attach` | `PROTECTED` |
| POST | `/api/builder/create-snapshot` | `api_builder_create_snapshot` | `PROTECTED` |
| GET | `/api/builder/snapshot/{snapshot_id}` | `api_builder_snapshot` | `PROTECTED` |
| GET | `/api/builder/active-snapshot/{conversation_id}` | `api_builder_active_snapshot` | `PROTECTED` |
| POST | `/api/builder/adapter-dry-run` | `api_builder_adapter_dry_run` | `PROTECTED` |
| POST | `/api/builder/engine-contract` | `api_builder_engine_contract` | `PROTECTED` |
| GET | `/api/builder/engine-contract/latest/{conversation_id}` | `api_builder_engine_contract_latest` | `PROTECTED` |
| GET | `/api/builder/engine-contract/{contract_id}` | `api_builder_engine_contract_replay` | `PROTECTED` |
| POST | `/api/builder/contract-fixture-replay` | `api_builder_contract_fixture_replay` | `PROTECTED` |
| POST | `/api/builder/legacy-bridge-shadow-probe` | `api_builder_legacy_bridge_shadow_probe` | `PROTECTED` |
| POST | `/api/builder/preview-execution-policy` | `api_builder_preview_execution_policy` | `PROTECTED` |
| POST | `/api/builder/safe-workbook-path-resolver-dry-run` | `api_builder_safe_workbook_path_resolver_dry_run` | `PROTECTED` |
| POST | `/api/builder/workbook-read-preflight-dry-run` | `api_builder_workbook_read_preflight_dry_run` | `PROTECTED` |
| POST | `/api/builder/workbook-metadata-probe-approval` | `api_builder_workbook_metadata_probe_approval` | `PROTECTED` |
| POST | `/api/builder/workbook-sheet-name-probe-approval` | `api_builder_workbook_sheet_name_probe_approval` | `PROTECTED` |
| POST | `/api/builder/workbook-read-policy-review` | `api_builder_workbook_read_policy_review` | `PROTECTED` |
| POST | `/api/builder/legacy-import-boundary-audit` | `api_builder_legacy_import_boundary_audit` | `PROTECTED` |
| GET | `/api/builder/legacy-import-boundary-audit/latest/{conversation_id}` | `api_builder_legacy_import_boundary_audit_latest` | `PROTECTED` |
| POST | `/api/builder/engine-preflight` | `api_builder_engine_preflight` | `PROTECTED` |
| POST | `/api/builder/engine-execution-request` | `api_builder_engine_execution_request` | `PROTECTED` |
| POST | `/api/builder/engine-boundary-audit` | `api_builder_engine_boundary_audit` | `PROTECTED` |
| GET | `/api/state/{conversation_id}` | `api_state` | `PROTECTED` |
| GET | `/api/plan/{conversation_id}` | `api_plan` | `PROTECTED` |
| GET | `/api/events/{conversation_id}` | `api_events` | `PROTECTED` |

## Dev/debug route list

These routes remain governed by the existing R7 `DEBUG_MODE` guard. R11 does not change their runtime behavior.

| Method | Route | Handler | Future auth class |
|---|---|---|---|
| POST | `/api/debug/create-test-clarification` | `api_debug_create_test_clarification` | `DEV_DEBUG_ONLY` |
| GET | `/api/debug/pending-clarification/{conversation_id}` | `api_debug_pending_clarification` | `DEV_DEBUG_ONLY` |
| GET | `/api/debug/router-trace/{conversation_id}` | `api_debug_router_trace` | `DEV_DEBUG_ONLY` |

## Dev/test route list

These routes remain governed by the existing R7 `DEBUG_MODE` guard. R11 does not change their runtime behavior.

| Method | Route | Handler | Future auth class |
|---|---|---|---|
| POST | `/api/dev/validate-test-pack` | `api_dev_validate_test_pack` | `DEV_TEST_ONLY` |
| POST | `/api/dev/run-smoke-tests` | `api_dev_run_smoke_tests` | `DEV_TEST_ONLY` |

## Future unauthorized response envelope

Future protected routes should use a generic deterministic envelope. R11 does not implement this response.

```json
{
  "ok": false,
  "error": "auth_required",
  "message": "API key required.",
  "auth_required": true,
  "authenticated": false,
  "execution_enabled": false,
  "workbook_read": false,
  "workbook_content_read": false,
  "tool_execution_performed": false,
  "engine_called": false,
  "excel_created": false,
  "contract_only": true
}
```

Recommended future HTTP behavior:

- `401` for missing or invalid API key on protected routes.
- Existing R7 `403` response remains acceptable for DEBUG_MODE-disabled dev/debug routes.

## Safety requirements for future implementation

Future implementation must not:

- echo provided API keys
- reveal expected key values
- reveal environment variables or config values
- include tracebacks or raw exception strings
- grant workbook read access
- grant workbook content read access
- perform tool execution
- call Builder engines
- create Excel files
- alter route paths or route count
- weaken R7 debug/dev guard behavior
- weaken R9 events safe projection
- weaken R10 saved_path internal-only boundary

## Explicit exclusions for R11

R11 does not add or modify:

- `jarvis_v5/app.py`
- route decorators, route paths, route handlers
- middleware
- FastAPI `Depends` or `Security`
- CORS
- rate limiting
- `requirements.txt`
- registries
- Builder runtime
- Formatter runtime
- QA Checker runtime
- Output Center runtime
- Job Center runtime
- workbook policy runtime
- safe path resolver runtime
- upload/text validation implementation
- saved_path schema implementation

## Verification intent

R11 static smoke test must confirm:

- route count remains 43
- all 43 routes appear in this auth matrix
- class counts are 12 / 26 / 3 / 2
- R6/R7/R9/R10 prerequisite contracts remain present
- no auth runtime implementation is introduced by R11
- no CORS/rate-limit implementation is introduced by R11
- no dependency or registry change is introduced by R11

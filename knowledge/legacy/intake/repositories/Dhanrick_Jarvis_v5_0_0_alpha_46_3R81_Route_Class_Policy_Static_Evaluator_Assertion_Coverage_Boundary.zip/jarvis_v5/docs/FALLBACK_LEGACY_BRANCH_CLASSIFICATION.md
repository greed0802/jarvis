# Fallback / Legacy Branch Classification

Version: v5.0.0-alpha.36.7


- audit_only=true
- refactor_performed=false
- runtime_behavior_changed=false
- duplicates_removed=false
- owners_changed=false
- workbook_runtime_changed=false
- route_behavior_changed=false
- registry_loader_changed=false
- builder_runtime_changed=false
- execution_enabled=false
- workbook_read=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- sheet_name_probe_allowed=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false


Fallback and legacy branches are classified before any future runtime expansion.

| branch_family | concentration | classification | risk | future_action |
|---|---|---|---|---|
| legacy builder boundary | builder audit/bridge modules | protected_boundary | high | do_not_touch |
| workbook preflight fallback | workbook_read_preflight_contract.py | active_compatibility | high | wrap later |
| sheet-name legacy owner | workbook_sheet_name_probe_approval.py | must_remain_until_replacement | high | WRAP later |
| route fallback | router/main_router.py | active_compatibility | medium | audit before change |
| advisory fallback | advisory/router layers | active_compatibility | low | preserve |
| test compatibility | tests/smoke + packs | accepted legacy compatibility | low | version drift management |
| old alpha reports | root/docs history | historical evidence | low | artifact cleanup later |

alpha36.7 does not remove fallback or legacy branches.

Classification token retained for branch taxonomy: legacy_audit_only.

# Metadata Bridge Future Candidate File Review

## Status
List-only. Review-only. Not approved for edit. Not approved for implementation.

| Candidate | Future purpose | alpha38.2 status |
|---|---|---|
| `jarvis_v5/app.py` | route inventory / no endpoint change verification | review-only |
| `jarvis_v5/config.py` | feature flag / status reference check only if needed | review-only |
| `jarvis_v5/registry/registry_loader.py` | registry protection check | review-only |
| permission-gate related modules, if present | contract boundary review | review-only |
| owner-wrapper related modules, if present | workbook access ordering review | review-only |
| route registration files, if present | route behavior review | review-only |
| metadata/result/audit helper modules, if present | possible future isolated helper | review-only |
| `jarvis_v5/tests/smoke` | future metadata bridge tests | docs/tests only |
| `jarvis_v5/tests/packs` | future JSON evidence tests | docs/tests only |

## Required rule
No candidate file is approved for editing in alpha38.2. Future edits require separate approved PLAN, DRY RUN, FIRE, and REVIEW.

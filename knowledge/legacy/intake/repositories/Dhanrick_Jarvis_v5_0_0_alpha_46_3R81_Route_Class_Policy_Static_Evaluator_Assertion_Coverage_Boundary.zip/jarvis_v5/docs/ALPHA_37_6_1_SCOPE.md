# alpha37.6.1 Scope — Sheet-name Execution Permission Contract Expansion

Base: v5.0.0-alpha.37.5
Target: v5.0.0-alpha.37.6.1

Allowed scope: update isolated workbook permission gate contract files only. Add `sheet_name_probe_execute_after_approval` and `ALLOW_SHEET_NAME_ONLY_AFTER_APPROVAL`.

Excluded: no legacy owner wrapping, no route integration, no workbook open, no sheet-name probe execution, no safe path resolver call, no Builder runtime change.


Safety flags:
- execution_enabled=false
- workbook_read=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false

Scope locks:
- legacy_owner_wrapping=false
- route_integration=false
- workbook_opened=false
- sheet_name_probe_executed=false
- content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- safe_path_resolver_called=false
- builder_runtime_changed=false
- stable_root_layout_preserved=true


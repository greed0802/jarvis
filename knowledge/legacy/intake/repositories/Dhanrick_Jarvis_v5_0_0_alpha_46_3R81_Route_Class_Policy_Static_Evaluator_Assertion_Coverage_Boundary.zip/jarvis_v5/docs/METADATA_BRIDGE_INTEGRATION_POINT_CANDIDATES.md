# Metadata Bridge Integration Point Candidates

All integration candidates are review-only in alpha38.7.

| Candidate | Future purpose | alpha38.7 status |
|---|---|---|
| metadata_bridge/manifest_metadata_adapter.py | existing isolated adapter | review-only |
| app.py | possible future route inventory check | review-only, no edit |
| route modules | possible future route exposure layer | review-only, no edit |
| permission-gate modules | possible future permission precheck | review-only, no edit |
| owner-wrapper modules | possible future access ordering review | review-only, no edit |
| audit/result helper modules | possible future safe audit/result support | review-only, no edit |
| tests/smoke | future tests | review-only |
| tests/packs | future JSON tests | review-only |

candidate_status=review_only
approved_for_edit=false
approved_for_route_integration=false
approved_for_runtime=false

No integration point is approved for edit in alpha38.7.
No endpoint is approved in alpha38.7.
No route exposure is approved in alpha38.7.

# Manifest-only Metadata Dry Run Contract Schema

Version: v5.0.0-alpha.37.10

## Synthetic input schema

```json
{
  "contract_type": "manifest_only_workbook_metadata_dry_run",
  "contract_version": "alpha37.10",
  "source_kind": "attachment_manifest",
  "approval": {
    "explicit_user_approval": true,
    "approved_scope": "manifest_metadata_only",
    "production_workbook_access_allowed": false
  },
  "requested_metadata_fields": [
    "declared_extension",
    "declared_file_size_bytes"
  ],
  "manifest": {
    "attachment_id_present": true,
    "contract_id_present": true,
    "original_filename_display": "Example.xlsx",
    "sanitized_filename_display": "Example.xlsx",
    "declared_extension": ".xlsx",
    "declared_mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "declared_file_size_bytes": 12345,
    "manifest_created_at": "fixture-only",
    "manifest_modified_at": "fixture-only"
  },
  "safety_flags": {
    "workbook_opened": false,
    "workbook_container_inspected": false,
    "workbook_content_read": false,
    "formula_read": false,
    "cell_value_read": false,
    "style_read": false,
    "engine_called": false,
    "tool_execution_called": false
  }
}
```

## Allow output schema

```json
{
  "decision": "allow",
  "allowed": true,
  "reason": "requested fields are manifest-only and explicitly allowed",
  "requested_scope": "manifest_metadata_only",
  "metadata_fields_requested": [],
  "metadata_fields_allowed": [],
  "metadata_fields_blocked": [],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "production_workbook_access": false,
  "safe_ui_summary": {},
  "audit": {
    "contract_type": "manifest_only_workbook_metadata_dry_run",
    "contract_version": "alpha37.10",
    "approval_granted": true,
    "fail_closed": false
  }
}
```

## Block output schema

```json
{
  "decision": "block",
  "allowed": false,
  "reason": "requested metadata field is not manifest-only or is unknown",
  "metadata_fields_allowed": [],
  "metadata_fields_blocked": ["sheet_count"],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "safe_ui_summary": {},
  "audit": {
    "approval_granted": false,
    "fail_closed": true
  }
}
```

# Metadata Bridge Safe UI Summary Requirements

Version: v5.0.0-alpha.38.1

## Allowed safe summary values

- Sanitized filename display.
- Declared extension.
- Declared MIME/type.
- Declared file size.
- Manifest timestamp if available.
- Approval status summary.
- Allowed/blocked field count.
- Safe reason code.

## Blocked from UI summary

- Raw path.
- Private attachment path.
- Raw workbook reference.
- Sheet names in blocked responses.
- Cell values.
- Formulas.
- Styles.
- Runtime internals.
- Tracebacks.

## Rule

Safe UI summary must remain useful without revealing workbook content, workbook paths, or internal runtime details.

# Manifest-only Metadata Fixture Result Summary Rules

Evidence summaries are expected-record summaries only. They are not runtime execution results. They must not claim that a runtime contract evaluator was executed.

## Allowed summary fields
- total_fixture_records
- records_by_group
- expected_allow_count
- expected_block_count
- expected_fail_closed_count
- expected_redaction_count
- safety_flags_expected_false
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- synthetic_workbook_created=false
- fixture_deleted=false

## Forbidden summary fields
- real workbook path
- path_token
- private attachment path
- raw workbook_ref
- real sheet names
- cell values
- formulas
- cached formula values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- runtime exception traces
- Builder internals
- Job/Output internals

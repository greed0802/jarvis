# Roadmap After Alpha36.5

## Updated sequence

```text
alpha36.6
Package Namespace + Artifact Hygiene Migration Plan

alpha36.7
Root Artifact Cleanup / Current-vs-History Package Hygiene

alpha36.8
Decision: Keep jarvis_v5 internal or migrate to jarvis_app

alpha36.9
If approved: Controlled Namespace Rename Dry Run

alpha37.0
Return to Unified Workbook Permission Gate
```

## Alternative if rename is deferred

```text
alpha36.7
Package artifact cleanup only

alpha36.8
Return to Unified Workbook Permission Gate
```

## Rule

Do not mix namespace migration with workbook runtime governance implementation.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

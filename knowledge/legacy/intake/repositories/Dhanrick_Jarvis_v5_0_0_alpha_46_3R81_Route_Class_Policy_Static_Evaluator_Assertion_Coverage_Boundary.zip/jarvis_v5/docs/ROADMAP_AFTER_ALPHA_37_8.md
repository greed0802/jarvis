# Roadmap After alpha37.8

Current accepted base: v5.0.0-alpha.37.8
Current candidate: v5.0.0-alpha.37.9

## Controlled sequence

1. alpha37.9 — Workbook Metadata Bridge Scope Plan
   - Docs/tests/evidence only.
   - Define allowed/blocked metadata boundary.
   - Define permission contract requirements.
   - Define audit/result policy.
   - Define fixture dry-run strategy.

2. alpha37.10 — Workbook Metadata Bridge Contract Dry Run, manifest-only
   - Synthetic manifest fixtures only.
   - No workbook open.
   - No production/user workbook access.
   - No source behavior change unless explicitly approved.

3. alpha37.11 — Workbook Metadata Audit/Result Fixture Evidence
   - Validate safe allowed and blocked metadata responses.
   - Prove no raw path or workbook internal leakage.
   - Preserve all false safety flags.

4. alpha37.12 — Optional controlled implementation plan
   - Still no production/user workbook access unless explicitly approved.
   - Must pass confidence gate before FIRE.

## Roadmap guard

Do not jump directly from alpha37.9 scope plan to runtime implementation. Metadata bridge execution must be preceded by fixture dry-run evidence and explicit approval.

# Manifest-only Metadata Fixture Matrix

Version: v5.0.0-alpha.37.10

| Fixture ID | Input | Expected decision |
|---|---|---|
| A37_10_ALLOW_EXTENSION | declared_extension | allow |
| A37_10_ALLOW_MIME | declared_mime_type | allow |
| A37_10_ALLOW_SIZE | declared_file_size_bytes | allow |
| A37_10_ALLOW_CREATED_AT | manifest_created_at | allow |
| A37_10_ALLOW_MODIFIED_AT | manifest_modified_at | allow |
| A37_10_ALLOW_ATTACHMENT_ID_PRESENT | attachment_id_present | allow |
| A37_10_ALLOW_CONTRACT_ID_PRESENT | contract_id_present | allow |
| A37_10_ALLOW_ACCEPTED_SHEET_REF_PRESENT | accepted_sheet_name_probe_result_id_present as presence only | allow |
| A37_10_BLOCK_SHEET_COUNT | sheet_count | block |
| A37_10_BLOCK_WORKBOOK_PROPERTIES | workbook_properties_from_file | block |
| A37_10_BLOCK_WORKBOOK_CONTAINER_METADATA | workbook_container_metadata | block |
| A37_10_BLOCK_CELL_VALUES | cell_values | block |
| A37_10_BLOCK_FORMULAS | formulas | block |
| A37_10_BLOCK_CACHED_FORMULA_VALUES | cached_formula_values | block |
| A37_10_BLOCK_STYLES | styles | block |
| A37_10_BLOCK_NAMED_RANGES | named_ranges | block |
| A37_10_BLOCK_TABLES | tables | block |
| A37_10_BLOCK_MERGED_CELLS | merged_cells | block |
| A37_10_BLOCK_COMMENTS | comments | block |
| A37_10_BLOCK_VBA | vba_macros | block |
| A37_10_BLOCK_UNKNOWN | unknown_metadata_field | block |
| A37_10_BLOCK_MISSING_APPROVAL | no approval | block |
| A37_10_BLOCK_WRONG_SOURCE_KIND | source_kind=workbook_file | block |
| A37_10_BLOCK_PRODUCTION_PATH | saved_path or production path present | block |

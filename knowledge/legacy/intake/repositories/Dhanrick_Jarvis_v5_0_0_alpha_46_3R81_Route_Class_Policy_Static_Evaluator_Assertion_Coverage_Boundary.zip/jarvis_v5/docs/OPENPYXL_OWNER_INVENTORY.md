# OpenPyXL Owner Inventory — alpha36.4

Purpose: identify current and future ownership of openpyxl/workbook-opening code so hidden workbook access cannot bypass the future permission model.

| owner_name | file_path | import_or_call | existing_owner | modified_in_alpha36_3 | modified_in_alpha36_4 | targeted_for_alpha36_5_review | opens_workbook | reads_sheet_names | reads_content | reads_formulas | reads_cell_values | reads_styles | runtime_behavior_changed |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| workbook sheet-name probe approval | jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py | from openpyxl import load_workbook; load_workbook(... read_only=True, data_only=False, keep_links=False) | true | false | false | true | true | true | false | false | false | false | false |
| future workbook metadata probe package | jarvis_v5/tools/workbook_metadata_probe/ | future-only candidate, not created in alpha36.4 | false | false | false | true | false | false | false | false | false | false | false |

No new openpyxl/pandas runtime import was added by alpha36.4.


metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
sheet_name_probe_allowed=false
formula_read=false
cell_value_read=false
style_read=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
planned_only=true
implementation_created=false
runtime_imported=false
runtime_called=false
workbook_opened=false
safe_path_resolver_called=false
path_resolved=false
audit_event_written=false
runtime_data_written=false
runtime_behavior_changed=false


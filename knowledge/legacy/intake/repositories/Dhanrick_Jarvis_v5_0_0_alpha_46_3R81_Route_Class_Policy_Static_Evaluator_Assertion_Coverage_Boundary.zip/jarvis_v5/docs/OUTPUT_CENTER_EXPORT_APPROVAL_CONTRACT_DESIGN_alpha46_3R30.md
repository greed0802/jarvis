# Output Center Export Approval Contract Design — alpha46.3R30

**Version:** v5.0.0-alpha.46.3R30  
**Base:** v5.0.0-alpha.46.3R29  
**Mode:** FIRE evidence document  
**Scope:** non-runtime contract design only  
**Rollback:** v5.0.0-alpha.46.3R29

## 1. Current accepted checkpoint

R29 is the accepted checkpoint for Output Center export boundary static compliance lock. R29 locked that no output/export/job/report app route is confirmed, no dedicated `output_center` runtime module is confirmed by path scan, and Output Center export execution remains forbidden unless separately approved.

## 2. R30 purpose

R30 defines the approval contract requirements for any future Output Center export. It does not implement the contract, add a route, change schemas, create an Output Center runtime module, or execute export behavior.

## 3. Approval preconditions

A future Output Center export must require all of the following before execution:

- explicit user export request
- declared artifact type
- declared display filename
- declared export scope
- existing source evidence or approved preview basis
- preview completed or explicitly waived by an approved contract
- preview approval before export
- public metadata field list declared
- private/internal metadata blocked
- raw path exposure blocked
- sidecar/manifest requirements declared
- rollback or cleanup behavior declared
- workbook access separately approved if needed
- Job Center execution separately approved if needed

## 4. Permission fields

Contract shape for future design reference only:

```json
{
  "export_approval_required": true,
  "export_approved": false,
  "approval_source": "user_explicit_message",
  "approval_scope": "single_export_only",
  "requested_artifact_type": "<declared>",
  "display_filename": "<declared>",
  "preview_required": true,
  "preview_completed": false,
  "preview_approved": false,
  "workbook_access_required": false,
  "workbook_permission_contract_id": null,
  "job_execution_required": false,
  "job_permission_contract_id": null,
  "output_center_export_execution_allowed": false,
  "raw_path_public_exposure_allowed": false,
  "sidecar_manifest_required": true,
  "rollback_point": "<checkpoint>"
}
```

This is documentation only in R30. No runtime schema or source implementation is added.

## 5. Preview-before-export requirements

Future export must not proceed unless the preview boundary is satisfied:

- preview exists before export
- preview scope matches export scope
- preview artifact type matches requested artifact type
- preview has no raw path exposure
- preview has no hidden workbook, job, OCR, document, or tool execution
- preview approval is explicit
- export cannot exceed previewed content
- export cannot introduce new workbook-derived data
- export cannot silently package runtime artifacts

## 6. Public/private metadata boundary

Public/export-safe metadata may include only approved fields such as artifact type, display filename, checkpoint, manifest hash, verification status, temporary flag, stable artifact id if approved, and relative package path if approved.

Private/internal metadata must remain private: absolute paths, local paths, storage roots, temp paths, saved paths, resolved paths, source filesystem paths, runtime workspace paths, raw upload paths, user machine paths, environment secrets, internal attachment paths, and private workbook paths.

## 7. Raw path exclusion contract

Future public response, manifest, summary, sidecar, or report must not expose raw/local filesystem values under these keys:

`saved_path`, `path`, `file_path`, `absolute_path`, `resolved_path`, `raw_path`, `local_path`, `stored_path`, `artifact_path`, `export_path`, `output_path`, `download_path`, `directory`, `parent`, `full_path`, `storage_root`, `temp_dir`, `workspace_root`.

## 8. Artifact and sidecar agreement requirements

Future export packaging must require agreement across final ZIP file list, manifest JSON, fire summary JSON, fire summary Markdown, verification CSV, patch diff, Source of Truth tracker SHA, standalone tracker SHA, and FIRE outputs ZIP contents.

Stop conditions include sidecar disagreement, tracker SHA mismatch, unresolved placeholders, verification CSV failed rows, missing manifest artifact, orphan artifact not listed, runtime artifact silently packaged, or temporary file packaged as final.

## 9. Workbook/export bridge restrictions

Future export must not open, read, write, inspect, or package workbook-derived content without a separate workbook permission contract. R30 does not call `load_workbook`, does not inspect workbook containers, and does not add workbook artifacts.

## 10. Job Center interaction restrictions

Future export must not execute Job Center, create job output, mutate job state, expose job result raw paths, package job runtime state, bypass preview/export approval through job identifiers, or mutate the Source of Truth tracker from a job.

## 11. R30 no-execution statement

During R30 FIRE, no runtime import, app import, FastAPI TestClient execution, API route call, attachment upload execution, workbook open/read/write/execution, workbook-container inspection, file execution through Jarvis runtime, OCR, document reader, tool execution, Output Center export execution, or Job Center execution occurred.

## 12. Protected systems

Protected runtime/source files remain unchanged, including app.py, main_router.py, message_schema.py, output_manifest_schema.py, tool_result_schema.py, job_contract_schema.py, preview_execution_policy.py, jarvis_evidence_runner.py, report_writer.py, attachment_store.py, safe_workbook_path_resolver.py, conversation_id_safety.py, workbook_sheet_name_probe_approval.py, and requirements.txt.

## 13. Future approval requirements

Any future Output Center export execution, export route addition, output_center runtime module creation, schema implementation, Job Center interaction, workbook/export bridge, or source patch requires a separate PLAN / DRY RUN / FIRE and explicit approval.

## 14. Backlog quarantine

Backlog source remains quarantined and cannot expand R30 scope.

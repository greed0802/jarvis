# Jarvis Local Git Checkpoint Model

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch

## Purpose

Define local Git as the source of truth for accepted Jarvis checkpoints.

## Recommended Local Structure

```text
D:\Jarvis\
  jarvis_v5\
  reports\
  release_packages\
  evidence_packages\
  patch_packages\
  tools\
```

## Required Accepted Checkpoint Evidence

Every accepted checkpoint should have:

- Git commit
- Git tag
- release ZIP
- SHA256
- review report
- rollback note

## Suggested Commands

```powershell
git status
git add .
git commit -m "Accept v5.0.0-alpha.39.7-batch"
git tag v5.0.0-alpha.39.7-batch
```

## Rule

No accepted checkpoint should exist locally without a Git tag, package hash, evidence report, and rollback note.



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

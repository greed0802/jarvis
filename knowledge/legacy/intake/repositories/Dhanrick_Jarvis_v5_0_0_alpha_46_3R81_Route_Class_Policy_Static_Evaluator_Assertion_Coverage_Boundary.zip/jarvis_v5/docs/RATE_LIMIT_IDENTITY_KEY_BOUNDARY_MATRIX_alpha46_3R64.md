# alpha46.3R64 — Rate Limit Identity-Key Boundary Matrix

Mode: FIRE  
Base: `v5.0.0-alpha.46.3R63`  
Target: `v5.0.0-alpha.46.3R64` — Rate Limit Identity-Key Boundary Matrix  
Rollback: `v5.0.0-alpha.46.3R63`

## Purpose

R64 creates an evidence-only identity-key boundary matrix required before any future rate-limit identity strategy can be selected or implemented.

R64 does not implement rate limiting, identity-key extraction, API-key extraction, IP extraction, forwarded-header trust, user/session identity, route grouping, route exemptions, route limit values, dependency selection, dependency installation, storage backend selection, Redis/cache/in-memory limiter behavior, middleware addition, middleware configuration, route behavior changes, request schema changes, request validation changes, CORS, or `requirements.txt` changes.

## Accepted base context

```text
base_checkpoint=v5.0.0-alpha.46.3R63
target_checkpoint=v5.0.0-alpha.46.3R64
R63_status=accepted_rate_limit_exemption_boundary_matrix
R63_route_count=43
R63_middleware_count=1
R63_rate_limit_implementation=false
R63_exemption_implementation=false
R63_route_exemption_activation=false
R63_route_limit_value_selection=false
R63_dependency_selection=false
R63_storage_backend_selection=false
R63_middleware_addition=false
R63_app_router_modification=false
```

## Identity-key boundary status

```text
identity_key_boundary_matrix_exists=true
identity_key_boundary_matrix_only=true
identity_candidate_classes_defined=true
anonymous_identity_boundary_defined=true
authenticated_api_key_boundary_defined=true
ip_identity_boundary_defined=true
proxy_forwarded_header_boundary_defined=true
privacy_redaction_boundary_defined=true
collision_fallback_boundary_defined=true
identity_strategy_selected=false
identity_key_implemented=false
api_key_extraction_implemented=false
ip_extraction_implemented=false
forwarded_header_trust_implemented=false
user_session_identity_implemented=false
composite_identity_implemented=false
route_grouping_implemented=false
```

## Identity-key candidate class matrix

| Candidate identity class | R64 status | Selected | Implemented | Future question |
| --- | --- | --- | --- | --- |
| Anonymous identity | candidate_only | false | false | How should unauthenticated requests be grouped without overblocking shared networks? |
| Authenticated/API-key identity | candidate_only | false | false | Should an existing validated API key or auth context be the future limiter key? |
| IP-based identity | candidate_only | false | false | Should IP be used at all, and only under what proxy-trust constraints? |
| User/session identity | candidate_only | false | false | Is there a stable approved user/session contract for future limiter use? |
| Route-class identity | candidate_only | false | false | Should route class participate in future key grouping? |
| Composite identity | candidate_only | false | false | Should future policy combine auth, route class, and client category? |
| System/internal identity | candidate_only | false | false | Should internal/system calls have separate treatment later? |
| Unknown/fallback identity | candidate_only | false | false | What happens when no safe identity is available? |

## Anonymous identity boundary

```text
anonymous_identity_boundary_defined=true
anonymous_identity_selected=false
anonymous_identity_implemented=false
anonymous_fallback_enabled=false
anonymous_route_exemption_approved=false
anonymous_limit_value_selected=false
```

Future decisions required: global anonymous bucket, redacted client fingerprint, route-class scoped anonymous behavior, shared-network protection, and malformed identity behavior.

## Authenticated / API-key boundary

```text
authenticated_api_key_boundary_defined=true
api_key_identity_selected=false
api_key_extraction_implemented=false
auth_token_parsing_implemented=false
auth_guard_modified=false
auth_failure_behavior_changed=false
raw_api_key_logging=false
```

Future decisions required: validated auth result source, raw-key nonlogging, hashed/redacted key observability, auth/limiter ordering, and protected-route bucket grouping.

## IP identity boundary

```text
ip_identity_boundary_defined=true
ip_identity_selected=false
client_ip_extraction_implemented=false
proxy_header_trust_implemented=false
forwarded_header_parsing_implemented=false
ip_based_limiter_enabled=false
raw_ip_logging=false
```

Future decisions required: direct client IP trust, ignored forwarded headers by default, trusted proxy list requirement, spoofed `X-Forwarded-For` handling, and IP-derived evidence redaction.

## User/session identity boundary

```text
user_session_identity_boundary_defined=true
user_session_identity_selected=false
session_extraction_implemented=false
user_identity_schema_modified=false
request_schema_modified=false
route_behavior_changed=false
```

Future decisions required: stable user/session contract, availability without runtime refactor, compatibility with auth guards, and privacy/retention risk.

## Composite identity boundary

```text
composite_identity_boundary_defined=true
composite_identity_selected=false
composite_key_construction_implemented=false
route_grouping_implemented=false
fallback_hierarchy_implemented=false
```

Future decisions required: candidate key parts, precedence order, redaction format, collision behavior, fallback behavior, tests, and rollback.

## Proxy / forwarded-header trust boundary

```text
proxy_forwarded_header_boundary_defined=true
forwarded_header_trust_implemented=false
x_forwarded_for_trust_implemented=false
proxy_allowlist_implemented=false
client_ip_extraction_implemented=false
deployment_proxy_contract_selected=false
```

No proxy header is trusted in R64. Future proxy policy requires separate PLAN plus FIRE.

## Privacy and redaction boundary

```text
privacy_redaction_boundary_defined=true
raw_api_key_logging=false
raw_token_logging=false
raw_identity_value_logging=false
raw_ip_logging=false
payload_logging=false
workbook_content_logging=false
document_content_logging=false
ocr_content_logging=false
observability_logging_implemented=false
```

Future observability candidates are limited to redacted identity class, approved hashed identity key, route class, limiter decision outcome, exemption decision outcome, timestamp, existing correlation id, and failure reason category.

## Collision / fallback boundary

```text
collision_fallback_boundary_defined=true
collision_policy_defined=true
collision_policy_implemented=false
fallback_policy_defined=true
fallback_policy_selected=false
fallback_policy_implemented=false
```

Future fallback states remain unresolved: `reject_unknown_identity`, `group_unknown_identity`, `use_anonymous_bucket`, `fail_open`, `fail_closed`, and `manual_review_required`.

## Policy decisions still unresolved

```text
identity_key_strategy
identity_precedence_order
anonymous_identity_behavior
api_key_identity_behavior
ip_identity_behavior
user_session_identity_behavior
composite_key_construction
route_grouping_behavior
proxy_forwarded_header_trust
identity_redaction_format
identity_collision_behavior
identity_fallback_behavior
default_limit_values
per_route_override_values
route_exemptions
dependency_selection
storage_backend_selection
burst_window_algorithm
fail_open_fail_closed_behavior
error_envelope_shape
retry_after_header_policy
middleware_ordering
cors_interaction
deployment_multi_worker_behavior
```

## Middleware-count gate

```text
current_middleware_count=1
middleware_delta=0
middleware_addition=false
middleware_configuration_change=false
app_py_modification=false
identity_middleware_implementation=false
future_rate_limit_middleware_requires_explicit_middleware_count_approval=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

## Protected logic not touched

```text
Builder_formula_export_engine=not_touched
workbook_policy_runtime=not_touched
preview_policy=not_touched
active_task_writing_report_guards=not_touched
safe_path_resolver=not_touched
Output_Center_runtime=not_touched
Job_Center_runtime=not_touched
AI_Takeoff_execution=not_touched
document_reader=not_touched
OCR=not_touched
tool_execution=not_touched
app_py=unchanged
router_main_router_py=unchanged
requirements_txt=unchanged
route_behavior=unchanged
middleware_configuration=unchanged
auth_runtime=unchanged
global_exception_envelope=unchanged
request_schemas=unchanged
request_validation=unchanged
CORS=unchanged
```

## Future gates

```text
future_identity_key_implementation_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
future_dependency_selection_requires_separate_plan_plus_fire=true
future_storage_backend_selection_requires_separate_plan_plus_fire=true
future_middleware_count_approval_required_before_middleware_implementation=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

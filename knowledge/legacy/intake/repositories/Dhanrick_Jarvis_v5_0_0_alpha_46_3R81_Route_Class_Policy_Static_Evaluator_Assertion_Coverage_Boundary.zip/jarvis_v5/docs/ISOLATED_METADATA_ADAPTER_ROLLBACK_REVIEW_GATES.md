# Isolated Metadata Adapter Rollback Review Gates

Future implementation FIRE requires:
- approved PLAN
- approved DRY RUN
- explicit FIRE
- exact source files declared
- exact test files declared
- protected files excluded
- rollback package declared
- smoke tests declared
- compile test declared
- package hygiene declared
- protected hash compare declared
- review checklist declared

Stop future FIRE if:
- source patch touches app.py
- source patch registers endpoint
- source patch changes route behavior
- source patch changes permission-gate contract
- source patch changes owner-wrapper logic
- source patch imports openpyxl
- source patch calls load_workbook
- source patch opens workbook
- source patch inspects workbook container
- source patch calls protected runtime
- tests fail
- protected hash changes unexpectedly

Rollback: replace with last accepted package.

# AI Takeoff Workbench Selected Takeoff Item Context

## Safe selected-item metadata examples

- takeoff_item_id
- item_code
- item_description
- trade
- section
- level
- unit
- quantity_summary
- measurement_type
- source_plan_id
- revision_reference
- qa_status

## Blocked until separate approval

- cell values read from workbook
- formula read
- drawing-derived dimensions
- automatic measurement vectors
- writeback quantity
- plan markup writeback
- production workbook export

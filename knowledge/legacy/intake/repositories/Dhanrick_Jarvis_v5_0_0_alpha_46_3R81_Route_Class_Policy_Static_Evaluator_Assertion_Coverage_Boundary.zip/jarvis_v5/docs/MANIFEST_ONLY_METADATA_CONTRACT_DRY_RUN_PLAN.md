# Manifest-only Metadata Contract Dry Run Plan

Version: v5.0.0-alpha.37.10
Base: v5.0.0-alpha.37.9.1

## Purpose

Define a synthetic fixture-only dry-run plan for validating workbook-adjacent metadata contract decisions from attachment-manifest fields only.

This phase creates docs/tests/evidence only. It is not a runtime metadata bridge. It is not an endpoint. It is not a route. It is not a permission-gate contract implementation. It is not an owner wrapper change. It is not workbook inspection. It is not sheet count extraction.

## Allowed source

Only `source_kind=attachment_manifest` is allowed for the planned contract dry-run. Synthetic fixture records may represent manifest fields, but must not point to or open real production/user workbook files.

## Allowed metadata boundary

Allowed fields are manifest-only display/safety fields: identity presence, contract id presence, safe display filename, declared extension/type, declared file size, manifest timestamps, and accepted sheet-name probe reference presence only.

## Blocked boundary

Workbook-container metadata, sheet count, workbook file properties, workbook content, formulas, cached formula values, cell values, styles, named ranges, tables, merged cells, comments, VBA/macros, and all runtime execution remain blocked.

## Output expectation

The future dry-run validates allow/block decisions, fail-closed behavior, and safe audit/result output without runtime or workbook access.

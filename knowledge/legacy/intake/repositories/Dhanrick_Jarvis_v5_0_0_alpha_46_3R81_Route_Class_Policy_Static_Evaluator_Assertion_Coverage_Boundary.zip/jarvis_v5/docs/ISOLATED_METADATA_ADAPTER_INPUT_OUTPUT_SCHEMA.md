# Isolated Metadata Adapter Input Output Schema

## Input contract
attachment_manifest: dict
permission_context: dict
requested_fields: list[str]

permission_context must contain:
- source_kind=attachment_manifest
- contract_type=manifest_only_metadata_bridge
- approved=true

The adapter must not accept a workbook object, file handle, workbook path, raw workbook_ref, or production/user workbook path.

## Allowed manifest-only fields
attachment_id_present
contract_id_present
declared_extension
declared_mime_type
declared_file_size_bytes
manifest_created_at
manifest_modified_at
sanitized_filename_display
accepted_sheet_name_probe_result_id_present

## Output contract
Success and block results must include:
- decision
- allowed
- reason_code
- source_kind
- contract_type
- requested_fields
- allowed_fields
- blocked_fields
- fail_closed
- safe_ui_summary
- safety_flags
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- production_workbook_access=false

Safe UI summary must not expose paths, raw workbook references, sheet names from workbook read, cells, formulas, styles, or runtime internals.

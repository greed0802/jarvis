# AI Takeoff Selected Plan Panel Metadata Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines safe selected-plan panel metadata without reading drawing content.

## Allowed metadata example

```json
{
  "panel_id": "selected_plan_panel_meta_001",
  "selected_plan_id": "plan_meta_001",
  "safe_display_name": "A-105 Level 05 Floor Plan",
  "sheet_number": "A-105",
  "revision_label": "Rev C",
  "discipline": "architectural",
  "drawing_type": "floor_plan",
  "content_access_granted": false,
  "drawing_read_allowed": false,
  "ocr_allowed": false,
  "measurement_allowed": false
}
```

## Safe wording

Selected plan metadata: A-105 Level 05 Floor Plan. Drawing content has not been read.

## Blocked wording

- I can see the plan.
- I found this note on the drawing.
- I measured this area from the plan.

## Blocked fields

absolute path, local path, resolved path, file bytes, image/PDF preview, OCR text, scale read from plan, and drawing notes read from file are blocked.

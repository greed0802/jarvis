# v5.0.0-alpha.46.3R49 — Inherited openpyxl Import Inventory Boundary Lock

## Status

R49 is an evidence-only inherited direct openpyxl import inventory/classification lock from accepted base `v5.0.0-alpha.46.3R48`.

R49 does not remove inherited imports, refactor inherited files, select or approve an openpyxl candidate version, add a pin, install dependencies, import Jarvis runtime, call routes, inspect workbook containers, or execute workbook/document/OCR/tool/output/job behavior.

## Active boundary statement

```text
No new openpyxl import.
No openpyxl runtime use.
No openpyxl pin.
No dependency change.
No candidate supplied/selected/invented/approved/applied.
Inherited imports remain unchanged and classified only.
Future removal/refactor requires separate PLAN plus FIRE.
```

## Inherited direct import inventory

Expected inherited direct openpyxl import file count: `2`.

- `jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py` — inherited=true; new_in_R49=false; modified_in_R49=false; removal_approved=false; refactor_approved=false; runtime_executed=false; sha256=`b63618986e5cef827e0154578d3580fa1cf7fd9f08475b67bb04579bac1831c3`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` — inherited=true; new_in_R49=false; modified_in_R49=false; removal_approved=false; refactor_approved=false; runtime_executed=false; sha256=`5d0dfec79783b73626631baa1b3e17b01e20ef11463b158cf8d8ff759674a17d`

## Classification matrix

| Location | Category | Inherited from base | New in R49 | Modified in R49 | Removal approved | Refactor approved | Runtime executed in R49 |
|---|---|---:|---:|---:|---:|---:|---:|
| `jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py` | smoke evidence / historical sheet-name probe hardening | true | false | false | false | false | false |
| `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py` | Builder tool boundary / sheet-name probe approval bridge | true | false | false | false | false | false |

## Locked facts

```text
inherited_openpyxl_import_inventory_boundary_lock_only=true
inherited_import_inventory_created=true
expected_inherited_direct_openpyxl_import_file_count=2
expected_new_direct_openpyxl_import_file_count=0
new_openpyxl_import_added=false
inherited_imports_removed=false
inherited_imports_refactored=false
implementation_executed=false
source_modified_except_allowed_evidence=false
requirements_txt_changed=false
requirements_txt_change_allowed=false
dependency_installed=false
dependency_changed=false
openpyxl_pin_added=false
candidate_selection_executed=false
candidate_version_supplied=false
candidate_version_selected=false
candidate_version_invented=false
candidate_version_approved=false
candidate_version_applied=false
openpyxl_runtime_used=false
workbook_runtime_enabled=false
workbook_open_read_write=false
workbook_container_inspected=false
builder_execution_enabled=false
output_center_export_executed=false
job_center_execution=false
runtime_imported=false
app_imported=false
fastapi_testclient_used=false
api_route_called=false
route_count=43
route_delta=0
middleware_count=1
future_candidate_requires_explicit_user_approval=true
future_actual_pin_requires_separate_fire=true
future_import_removal_or_refactor_requires_separate_fire=true
```

## Explicit non-goals

R49 does not implement an import removal/refactor. R49 does not make a dependency decision. R49 does not inspect workbooks or workbook containers. R49 does not run Jarvis runtime code. R49 only records and locks the inherited direct import inventory as evidence.

## Sidecar identity lock

R49 requires the tracker inside the package, the standalone tracker sidecar, the manifest tracker SHA, and the FIRE outputs tracker copy to match byte-for-byte.

```text
tracker_sha256=a46487d1c2572f30c4e59ab61f46fdd17d60c75ce1b1284edf08a07b012a38d3
```

## Protected source hashes

```text
requirements.txt=a7cdfba90512a58a19d3686ef20f9b5b5ac8c8a155f0bde3e31b1bcb4851922c
jarvis_v5/app.py=9d833409b7d03b0add470dc14dfd19ab2ebaae0d9956e7e6f15e9156e8d98e93
jarvis_v5/router/main_router.py=914194fd4522ddc61dddad0b0d5e25e03aa4e2d8c1d6f1f34c4692a42170e820
jarvis_v5/tests/smoke/test_alpha37_7_sheet_name_probe_evidence_hardening.py=b63618986e5cef827e0154578d3580fa1cf7fd9f08475b67bb04579bac1831c3
jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py=5d0dfec79783b73626631baa1b3e17b01e20ef11463b158cf8d8ff759674a17d
```

## Rollback

`v5.0.0-alpha.46.3R48`

# AI Takeoff Workbench Selected Plan Context

## Safe selected-plan metadata examples

- project_id
- plan_id
- plan_name
- drawing_number
- drawing_title
- drawing_revision
- discipline
- trade
- level
- page_number
- declared_scale
- selected_region_id
- plan_context_id

## Blocked until separate approval

- raw drawing file path
- private drawing path
- drawing pixels
- OCR text
- CAD geometry
- PDF internals
- vector paths
- measured dimensions
- automatic quantities
- production/user drawing access

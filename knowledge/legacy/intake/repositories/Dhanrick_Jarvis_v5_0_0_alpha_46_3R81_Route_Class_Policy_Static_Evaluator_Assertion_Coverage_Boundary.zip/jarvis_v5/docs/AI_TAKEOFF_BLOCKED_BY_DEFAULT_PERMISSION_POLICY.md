# AI Takeoff Blocked-by-Default Permission Policy

Version: v5.0.0-alpha.39.6-batch
Base: v5.0.0-alpha.39.5-batch
Scope: metadata-only blocked-by-default permission policy.

## Purpose

Lock the default behavior for every future AI Takeoff Workbench execution-sensitive action: blocked unless later permission runtime and approval token runtime exist and are explicitly approved.

## Required Alpha39.6 State

```json
{
  "drawing_read_allowed": false,
  "ocr_allowed": false,
  "takeoff_engine_allowed": false,
  "workbook_read_allowed": false,
  "quantity_writeback_allowed": false,
  "approval_token_issued": false,
  "execution_allowed": false
}
```

## Blocked-by-Default Rules

- If no valid permission contract exists, action is blocked.
- If no valid approval token exists, action is blocked.
- If action is unknown, action is blocked.
- If scope is unknown, scope is blocked.
- If source is unclear, source is untrusted.
- If field is unknown, field fails closed.
- If requested action implies file reading, OCR, takeoff, workbook access, export, or writeback, action remains blocked in alpha39.6.

## Non-Execution Requirement

Blocked-by-default is not advisory. It is the controlling status for alpha39.6.


## Alpha39.6 Non-Execution Guarantees

- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- workbook_opened=false
- quantity_writeback=false
- approval_token_issued=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false
- jarvis_runtime_imported=false
- fastapi_testclient_used=false
- memory_imported=false
- protected_systems_touched=false

This document is metadata-only. It does not grant permission, issue approval tokens, add runtime routes, add endpoints, open workbooks, read drawings, call OCR, call a takeoff engine, or write quantities.

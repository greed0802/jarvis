# Manifest-only Metadata Fail-closed Fixtures

| Fixture ID | Condition | Expected decision |
|---|---|---|
| A37_11_FAIL_UNKNOWN_FIELD | unknown metadata field | block |
| A37_11_FAIL_MISSING_APPROVAL | approval missing | block |
| A37_11_FAIL_APPROVAL_FALSE | explicit approval false | block |
| A37_11_FAIL_WRONG_SOURCE_KIND | source_kind=workbook_file | block |
| A37_11_FAIL_MISSING_CONTRACT_TYPE | contract type missing | block |
| A37_11_FAIL_WRONG_CONTRACT_TYPE | wrong contract type | block |
| A37_11_FAIL_PRODUCTION_PATH | saved_path or absolute_path present | block |
| A37_11_FAIL_RAW_WORKBOOK_REF | raw_workbook_ref present | block |
| A37_11_FAIL_PRIVATE_ATTACHMENT_PATH | private_attachment_path present | block |
| A37_11_FAIL_REQUESTED_SCOPE_EXPANDED | scope requests workbook access | block |

## Required policy
- Unknown means blocked.
- Missing permission means blocked.
- Wrong source means blocked.
- Path-like input means blocked.
- Expanded scope means blocked.
- Workbook-container request means blocked.
- Workbook-internal request means blocked.

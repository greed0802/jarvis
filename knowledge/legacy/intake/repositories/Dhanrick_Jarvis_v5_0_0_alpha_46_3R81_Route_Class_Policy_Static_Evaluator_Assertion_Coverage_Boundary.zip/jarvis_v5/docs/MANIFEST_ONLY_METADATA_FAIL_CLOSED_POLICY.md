# Manifest-only Metadata Fail-closed Policy

Version: v5.0.0-alpha.37.10

alpha37.10 requires fail-closed behavior for all non-manifest or uncertain requests.

## Required fail-closed rules

- Unknown fields block.
- Missing approval blocks.
- Missing contract type blocks.
- Wrong source_kind blocks.
- Any source_kind other than attachment_manifest blocks.
- Workbook-container metadata blocks.
- Sheet count blocks.
- Workbook content/internal data blocks.
- Any workbook open requirement blocks.
- Any workbook-container inspection requirement blocks.
- Any production/user workbook access blocks.
- Any path-like field blocks.
- Any raw workbook_ref blocks.
- Any request involving formulas, cached values, cell values, styles, named ranges, tables, merged cells, comments, VBA/macros, or runtime execution blocks.

## Examples

| Request | Expected decision |
|---|---|
| declared_extension | allow |
| declared_file_size_bytes | allow |
| sheet_count | block |
| workbook_properties_from_file | block |
| cell_values | block |
| formulas | block |
| styles | block |
| unknown_field | block |
| missing approval | block |
| source_kind=workbook_file | block |
| saved_path present | block |

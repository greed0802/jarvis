# alpha46.3R63 — Rate Limit Exemption Boundary Matrix

Mode: FIRE  
Base: `v5.0.0-alpha.46.3R62`  
Target: `v5.0.0-alpha.46.3R63` — Rate Limit Exemption Boundary Matrix  
Rollback: `v5.0.0-alpha.46.3R62`

## Purpose

R63 creates an evidence-only exemption-boundary matrix required before any future route-specific rate-limit exemption can be approved or implemented.

R63 does not implement rate limiting, implement exemptions, activate route exemptions, select route limit values, select a dependency, install dependencies, select a storage backend, select Redis/cache/in-memory limiter behavior, implement limiter identity key, implement default/per-route/burst-window/fail behavior, implement error envelope, implement observability/logging, add middleware, modify middleware configuration, modify `app.py`, modify `router/main_router.py`, modify route behavior, modify request schema or validation, implement CORS, or modify `requirements.txt`.

R63 defines candidate exemption classes and approval fields only. No exemption is approved, active, or enforceable.

## Accepted base context

```text
base_checkpoint=v5.0.0-alpha.46.3R62
target_checkpoint=v5.0.0-alpha.46.3R63
R62_status=accepted_rate_limit_route_scope_classification_matrix
R62_route_count=43
R62_middleware_count=1
R62_rate_limit_implementation=false
R62_exemption_implementation=false
R62_active_route_exemption_implementation=false
R62_route_limit_value_selection=false
R62_dependency_selection=false
R62_storage_backend_selection=false
R62_middleware_addition=false
R62_app_router_modification=false
```

## R63 exemption-boundary matrix status

```text
exemption_boundary_matrix_exists=true
exemption_boundary_matrix_only=true
exemption_candidate_classes_defined=true
exemption_approval_fields_defined=true
abuse_risk_fields_defined=true
observability_redaction_boundary_defined=true
active_exemption_implemented=false
route_exemption_activation=false
route_limit_value_selected=false
rate_limit_implementation=false
dependency_selected=false
storage_backend_selected=false
middleware_added=false
route_behavior_modified=false
```

## Exemption candidate class matrix

| Candidate class | R63 status | Exemption approval | Active exemption | Future question |
| --- | --- | --- | --- | --- |
| Health/status routes | candidate_only | false | false | Should health/status be exempt, lightly limited, or system-only limited? |
| Public metadata routes | candidate_only | false | false | Should public metadata share a low-cost bucket or remain non-exempt? |
| Auth handshake routes | candidate_only | false | false | Should auth-related routes be protected from brute force separately? |
| Debug/dev routes | candidate_only | false | false | Should guarded dev routes be separately limited while preserving guards? |
| Event/projection routes | candidate_only | false | false | Should read-only event/projection routes have separate throttling later? |
| Upload/attachment routes | candidate_only | false | false | Should upload routes ever be exempt? They remain high-risk. |
| Output Center routes | candidate_only | false | false | Should export/status routes have distinct policies later? |
| Job Center routes | candidate_only | false | false | Should job polling/status routes have special throttling later? |
| Workbook-disabled routes | candidate_only | false | false | Should disabled workbook/document/OCR routes remain blocked and non-exempt? |
| AI/tool-intent routes | candidate_only | false | false | Should AI/tool routes have stricter future policy? |
| Unknown/unclassified routes | candidate_only | false | false | Should unknown routes default to non-exempt until classified? |

## Exemption approval fields required before future implementation

```text
route_path_or_route_class
route_method
route_owner
exemption_reason
business_justification
security_justification
abuse_risk_rating
authentication_requirement
expected_traffic_profile
blast_radius
observability_requirement
redaction_requirement
fallback_if_abused
test_evidence_required
rollback_path
approval_checkpoint
review_checkpoint
expiry_or_revalidation_date_if_applicable
```

## Approval state boundary

```text
undecided
rejected
approved_for_planning_only
approved_for_future_fire
implemented_after_fire
```

R63 blocks any direct transition from `undecided` to `implemented_after_fire`. Implementation requires a separate PLAN plus FIRE and REVIEW.

## Public route exemption boundary

```text
public_route_exemption_boundary_defined=true
public_route_exemption_approved=false
public_route_exemption_implemented=false
public_route_behavior_changed=false
public_route_limit_value_selected=false
```

Public routes are not automatically exempt. A future public-route exemption requires abuse-risk review, observability/redaction review, and separate PLAN plus FIRE.

## Health/status route exemption boundary

```text
health_status_exemption_boundary_defined=true
health_status_exemption_approved=false
health_status_exemption_implemented=false
health_status_user_facing_429_decision=unresolved
health_status_abuse_protection_decision=unresolved
```

Health/status routes may be considered later, but no exemption is approved in R63.

## Debug/dev exemption boundary

```text
debug_dev_exemption_boundary_defined=true
debug_dev_exemption_approved=false
debug_dev_exemption_implemented=false
debug_dev_guards_preserved=true
debug_dev_public_access_enabled=false
```

Debug/dev exemption must never weaken existing guards. Any future exemption requires guard-preservation evidence.

## Upload/attachment exemption boundary

```text
upload_attachment_exemption_boundary_defined=true
upload_route_exemption_approved=false
upload_route_exemption_implemented=false
attachment_route_exemption_approved=false
payload_size_policy_implemented=false
attachment_payload_enablement=false
```

Upload/attachment routes are high-risk and not exempt by default.

## Workbook-disabled exemption boundary

```text
workbook_disabled_exemption_boundary_defined=true
workbook_read_write_enabled=false
document_reader_enabled=false
ocr_enabled=false
workbook_document_ocr_routes_made_active_by_exemption=false
```

No exemption may enable workbook/document/OCR payloads.

## Abuse-risk boundary

```text
abuse_risk_boundary_defined=true
request_cost_required=true
payload_size_required=true
auth_requirement_required=true
unauthenticated_exposure_required=true
brute_force_risk_required=true
resource_exhaustion_risk_required=true
data_leakage_risk_required=true
backend_dependency_pressure_required=true
multi_worker_impact_required=true
operator_recovery_path_required=true
```

## Observability and redaction boundary

```text
observability_boundary_defined=true
observability_logging_implemented=false
sensitive_identity_logging=false
payload_logging=false
raw_api_key_logging=false
raw_token_logging=false
workbook_document_ocr_content_logging=false
```

Future observability may classify event type, exemption decision outcome, route class, redacted identity key, redacted client category, timestamp, and existing correlation ID only if separately approved.

## Unresolved policy decisions

```text
which_routes_are_exempt=unresolved
which_route_classes_are_exempt=unresolved
health_status_exemption=unresolved
debug_dev_exemption_or_separate_limit=unresolved
upload_exemption_eligibility=unresolved
job_polling_special_rules=unresolved
event_projection_special_rules=unresolved
identity_key_strategy=unresolved
dependency_selection=unresolved
storage_backend_selection=unresolved
default_limit_values=unresolved
per_route_override_values=unresolved
burst_window_algorithm=unresolved
fail_open_fail_closed_behavior=unresolved
error_envelope_shape=unresolved
retry_after_header_policy=unresolved
middleware_ordering=unresolved
cors_interaction=unresolved
deployment_multi_worker_behavior=unresolved
```

## Middleware-count gate

```text
middleware_count=1
middleware_delta=0
middleware_addition=false
middleware_configuration_change=false
app_py_modification=false
future_rate_limit_middleware_requires_middleware_count_approval=true
future_cors_requires_separate_plan_plus_fire=true
future_cors_requires_middleware_count_approval=true
hidden_middleware_exemption_behavior=false
```

## Protected systems not touched

```text
Builder formula/export engine untouched
workbook policy runtime untouched
preview policy untouched
active-task writing/report guards untouched
safe path resolver untouched
Output Center runtime untouched
Job Center runtime untouched
AI Takeoff execution untouched
document reader untouched
OCR untouched
tool execution untouched
app.py unchanged
router/main_router.py unchanged
requirements.txt unchanged
route behavior unchanged
middleware configuration unchanged
auth runtime unchanged
global exception envelope unchanged
request schemas unchanged
request validation unchanged
CORS unchanged
rate-limit implementation=false
exemption implementation=false
active route exemptions=false
route limit values selected=false
```

## Future gates

```text
future_exemption_implementation_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
future_rate_limit_dependency_selection_requires_separate_plan_plus_fire=true
future_rate_limit_storage_backend_selection_requires_separate_plan_plus_fire=true
future_middleware_count_approval_required=true
future_rate_limit_middleware_requires_separate_plan_plus_fire=true
future_cors_implementation_requires_separate_plan_plus_fire=true
future_cors_implementation_requires_middleware_count_approval=true
```

# Code Owner Matrix

Version: v5.0.0-alpha.36.7


- audit_only=true
- refactor_performed=false
- runtime_behavior_changed=false
- duplicates_removed=false
- owners_changed=false
- workbook_runtime_changed=false
- route_behavior_changed=false
- registry_loader_changed=false
- builder_runtime_changed=false
- execution_enabled=false
- workbook_read=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- sheet_name_probe_allowed=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false


This matrix records current code-family ownership. alpha36.7 does not change owners.

| code_family | primary_owner_file | secondary_owner_file_if_any | ownership_status | duplicate_risk | future_action | protected |
|---|---|---|---|---|---|---|
| route_decision | jarvis_v5/app.py | jarvis_v5/router/main_router.py | shared_intentional | medium | keep route owner matrix current | true |
| intent_routing | jarvis_v5/router/main_router.py | router gates | shared_intentional | medium | audit before routing changes | true |
| active_task_state | jarvis_v5/core/active_task_store.py | reducers/slot_reducer.py | shared_intentional | medium | do_not_touch without targeted scope | true |
| preview_policy | jarvis_v5/tools/builder/preview_execution_policy.py | app route callers | single_owner | low | protect | true |
| workbook_permission | jarvis_v5/tools/builder/workbook_read_preflight_contract.py | metadata/sheet approval modules | legacy_overlap | high | future wrapper/gate plan | true |
| workbook_metadata_probe | jarvis_v5/tools/builder/workbook_metadata_probe_approval.py | future workbook_metadata_probe package | legacy_overlap | high | future central governance only | true |
| sheet_name_probe | jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py | future unified gate | legacy_overlap | high | WRAP later, no change now | true |
| safe_path_resolution | jarvis_v5/tools/builder/safe_workbook_path_resolver.py | local safe attachment helpers | duplicate_candidate | medium | inventory only | true |
| Builder engine boundary | jarvis_v5/tools/builder/engine_boundary_audit.py | engine preflight/bridge modules | protected_boundary | high | do_not_touch | true |
| registry ownership | jarvis_v5/registry/registry_loader.py | registry/*.json | single_owner | low | protect | true |
| test pack execution | run_alpha_smoke_tests.py | tests/packs/*.json | single_owner | low | keep | false |
| output manifest | docs/contracts only | none | future_contract | low | future Job/Output phase | true |
| document contracts | docs/contracts only | none | future_contract | low | future phase | true |
| QA contracts | docs/contracts only | none | future_contract | low | future phase | true |
| Formatter contracts | docs/contracts only | none | future_contract | low | future phase | true |
| O&A contracts | roadmap only | none | future_contract | low | future contract phase | true |

Ownership statuses used: single_owner, shared_intentional, legacy_overlap, duplicate_candidate, needs_wrapper, needs_future_centralization, do_not_touch, protected_boundary, future_contract.

# v5.0.0-alpha.46.3R41 — Dependency Pinning / openpyxl Static Compliance Lock

## Status

Static compliance lock only. This file documents and locks the accepted R40 dependency/openpyxl evidence inventory without changing dependency, source, runtime, or workbook behavior.

## Base

- Base checkpoint: `v5.0.0-alpha.46.3R40`
- Accepted R40 package SHA256: `2148547c906af000b269d1717edf378047882fb38ed2bf31bbb139beb32c8683`
- Base file count: `1967`
- Target file count: `1970`

## Static compliance facts locked

```json
{
  "dependency_pinning_openpyxl_static_compliance_lock_only": true,
  "selected_after_r40_inventory": true,
  "source_behavior_changed": false,
  "runtime_behavior_changed": false,
  "requirements_txt_changed": false,
  "dependency_installed": false,
  "dependency_changed": false,
  "openpyxl_present": false,
  "openpyxl_pinned": false,
  "openpyxl_requirement_line": null,
  "openpyxl_imported": false,
  "openpyxl_runtime_used": false,
  "workbook_runtime_enabled": false,
  "workbook_open_read_write": false,
  "workbook_container_inspected": false,
  "builder_execution_enabled": false,
  "output_center_export_executed": false,
  "job_center_execution": false,
  "route_count": 43,
  "route_delta": 0,
  "middleware_count": 1,
  "future_requirements_txt_change_requires_separate_plan_dry_run_fire_review": true,
  "future_openpyxl_pin_requires_separate_fire": true
}
```

## Current dependency / openpyxl footprint summary

Static R40 evidence showed:

- `requirements.txt` remained unchanged.
- `openpyxl` is absent from `requirements.txt`.
- `openpyxl` is not pinned.
- `openpyxl_requirement_line` is `null`.
- No dependency installation occurred.
- No dependency change occurred.
- No `openpyxl` import occurred.
- No `openpyxl` runtime use occurred.
- No workbook runtime was enabled.
- No workbook open/read/write behavior occurred.
- No workbook-container inspection occurred.

## Compliance interpretation

R40 identified the openpyxl dependency gap. R41 does not close that gap. R41 only locks the evidence and the approval requirement before any dependency or workbook-related behavior change.

## Dependency guard facts

- No dependency added.
- No `requirements.txt` change.
- No openpyxl pin.
- No openpyxl import.
- No package manager lockfile change.
- No dependency resolver change.
- No dependency loader change.
- No runtime dependency check added.
- No workbook dependency enabled.

Any future dependency change requires: `PLAN -> DRY RUN -> FIRE -> REVIEW`.

## Workbook boundary guard facts

- No workbook execution.
- No workbook open/read/write through Jarvis runtime.
- No workbook-container inspection.
- No formula evaluation.
- No workbook export.
- No Builder formula/export behavior change.
- No workbook permission runtime change.
- No preview/export policy change.
- No safe path resolver change.
- No attachment-store behavior change.

Future openpyxl pinning does not automatically allow workbook reads, workbook writes, formula evaluation, Builder execution, or Output Center export.

## Protected systems not touched

- `requirements.txt`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/schemas/*`
- Builder formula/export engine
- Workbook permission runtime
- Workbook policy runtime
- Preview/export policy
- Output Center runtime
- Job Center runtime
- Auth runtime boundary
- Exception envelope boundary
- CORS boundary
- Rate-limit boundary
- Sidecar generator source
- UI/runtime modules

## Execution restrictions

R41 executed no Jarvis runtime, imported no `app.py`, used no FastAPI TestClient, called no API route, installed no dependency, imported no openpyxl, opened no workbook through Jarvis runtime, inspected no workbook container, executed no OCR/document/tool behavior, exported no Output Center artifact, and executed no Job Center behavior.

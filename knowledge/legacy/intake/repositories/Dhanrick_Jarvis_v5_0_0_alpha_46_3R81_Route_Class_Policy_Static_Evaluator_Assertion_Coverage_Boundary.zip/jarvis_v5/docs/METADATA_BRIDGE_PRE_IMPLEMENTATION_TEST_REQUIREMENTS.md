# Metadata Bridge Pre-Implementation Test Requirements

Version: v5.0.0-alpha.38.1

Before any future metadata bridge implementation is approved, tests must cover:

- Allowed manifest fields pass.
- Blocked workbook-container fields fail closed.
- Blocked workbook-content fields fail closed.
- Unknown fields fail closed.
- Missing approval fails closed.
- Wrong `source_kind` fails closed.
- Path-like input is redacted/blocked.
- Raw workbook references are redacted/blocked.
- Safe UI summary excludes forbidden values.
- Safety flags remain false.
- No workbook open occurs.
- No workbook-container inspection occurs.
- No route behavior changes unless separately approved.
- Protected source hashes are checked.

## Required future commands

```bash
pytest -q <future metadata bridge readiness or implementation tests>
python -m compileall -q jarvis_v5
```

## Boundary

These are future requirements. alpha38.1 does not execute implementation tests and does not edit implementation source.

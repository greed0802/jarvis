# Alpha 36.6 Scope — Package Namespace + Artifact Hygiene Migration Plan

Version: v5.0.0-alpha.36.6
Base: v5.0.0-alpha.36.5
Scope: docs/tests/evidence only.

Alpha36.6 inventories the risk of renaming the internal package namespace from `jarvis_v5` to `jarvis_app` and documents artifact hygiene rules for future packages.

This release does not rename `jarvis_v5`, does not create `jarvis_app`, does not rewrite imports, does not create a compatibility alias, does not move files, and does not delete files.

## Goals

- inventory namespace migration risk
- classify `jarvis_v5` references by impact
- classify root artifact residue
- define package artifact hygiene policy
- define snake_case / underscore naming policy
- define path alias compatibility options
- define future migration regression tests

## Out of Scope

No runtime changes, no route changes, no workbook permission changes, no workbook open, no Builder/Formatter/QA/O&A/Document Reader/Output Center runtime changes.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

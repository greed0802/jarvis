# Jarvis App Rename Impact Matrix

This matrix documents expected impact if `jarvis_v5` is later renamed to `jarvis_app`.

| reference_type | example_path | current_value | future_value | rename_required | migration_risk | test_required | alpha36_6_action |
|---|---|---|---|---|---|---|---|
| runtime_import | `jarvis_v5/app.py` imports | `jarvis_v5` | `jarvis_app` | yes | high | import smoke + pytest | inventory_only |
| test_import | `jarvis_v5/tests/smoke/*.py` | `jarvis_v5` | `jarvis_app` | yes | high | pytest discovery | inventory_only |
| smoke_runner_reference | `run_alpha_smoke_tests.py` | `jarvis_v5` paths | `jarvis_app` paths | yes | high | pack runner smoke | inventory_only |
| test_pack_path | `jarvis_v5/tests/packs/*.json` | `jarvis_v5` | `jarvis_app` | likely | medium | pack replay | inventory_only |
| report_reference | root reports | `jarvis_v5` | historical/current policy | no for history | low | report scan | inventory_only |
| documentation_reference | docs | `jarvis_v5` | historical/current policy | partial | low | doc scan | inventory_only |
| historical_reference | version history | `jarvis_v5` | preserve historical | no | low | archive scan | inventory_only |
| start_script_reference | `START_*.bat` | `jarvis_v5` | new start target | yes | high | script smoke | inventory_only |
| protected_hash_reference | hash compare JSON | `jarvis_v5/tools/builder/...` | remapped path | yes if rename | high | hash remap check | inventory_only |
| changed_files_report_reference | changed-files JSON | `jarvis_v5/...` | current namespace | yes for future only | medium | changed-file scan | inventory_only |
| external_regression_expectation | old external packs | `jarvis_v5` / old version | classify as drift | maybe | medium | external sample | inventory_only |

## Alpha36.6 conclusion

`jarvis_v5` is deeply embedded and should not be renamed without a dedicated migration release.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

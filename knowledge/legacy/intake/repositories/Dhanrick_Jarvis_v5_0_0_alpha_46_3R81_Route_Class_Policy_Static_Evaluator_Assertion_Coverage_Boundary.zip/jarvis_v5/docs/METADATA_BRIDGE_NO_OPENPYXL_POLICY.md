# Metadata Bridge No Openpyxl Policy

Version: v5.0.0-alpha.38.4

The future metadata bridge adapter must not import openpyxl.  
The future metadata bridge adapter must not call load_workbook.  
The future metadata bridge adapter must not inspect xlsx zip/container data.  
The future metadata bridge adapter must operate only on manifest dictionaries and permission context dictionaries.

## Blocked dependency examples

```text
openpyxl
load_workbook
zipfile workbook container inspection
pandas Excel read
xlrd
pyxlsb
LibreOffice conversion
```

Any dependency that opens workbook content, reads workbook container metadata, or derives workbook internals is blocked.

# Current-Only Flag Scan Policy

Version: v5.0.0-alpha.36.9
Base: v5.0.0-alpha.36.8
Scope: Controlled Package Cleanup Dry Run + Evidence Consistency Gate.

This document is evidence/planning only.

```text
cleanup_executed=false
files_deleted=false
files_moved=false
archive_relocation_performed=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
namespace_renamed=false
jarvis_app_created=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
```

No cleanup execution is performed in alpha36.9. No deletion, file move, archive relocation, source logic change, route change, registry loader change, Builder change, workbook runtime change, namespace rename, or jarvis_app creation is allowed.


## Rule

Flag scans must separate active source and registry/config from historical evidence.

## Current-Only Safety Strings

- execution_enabled=true
- workbook_read=true
- workbook_content_read=true
- formula_read=true
- cell_value_read=true
- style_read=true
- sheet_name_probe_allowed=true
- engine_called=true
- excel_created=true
- legacy_builder_called=true
- tool_execution_called=true

Occurrences inside reports, docs, handoffs, or test packs are classified as `historical_true_string_occurrence`, not runtime enablement.

# Metadata Bridge Audit Result Test Expectations

## Expected future audit/result fields
- decision
- allowed
- reason_code
- source_kind
- contract_type
- requested_fields
- allowed_fields
- blocked_fields
- fail_closed
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- production_workbook_access=false
- safe_ui_summary
- safety_flags

## Forbidden audit/result fields
- saved_path
- absolute_path
- private attachment path
- raw workbook_ref
- real sheet names from workbook read
- cell values
- formulas
- cached values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- tracebacks
- runtime internals

## Redaction expectation
Safe UI and audit summaries must not expose forbidden values. Blocked responses must remain sanitized.

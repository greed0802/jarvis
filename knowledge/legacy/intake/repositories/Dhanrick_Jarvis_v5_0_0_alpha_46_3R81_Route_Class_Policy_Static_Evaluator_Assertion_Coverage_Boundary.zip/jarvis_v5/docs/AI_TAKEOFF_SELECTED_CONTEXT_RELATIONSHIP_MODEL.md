# AI Takeoff Selected Context Relationship Model

## Purpose
Define how selected plan metadata and selected takeoff item metadata relate in a future AI Takeoff Workbench context, without enabling file reads, UI implementation, or runtime execution.

## Relationship model
project_context
  -> selected_plan_context
      -> selected_takeoff_item_context
          -> selected_quantity_summary_context
          -> qa_context
          -> chat_context

## Context handoff to Jarvis
Jarvis may receive declared metadata only:
- selected project identity
- selected plan identity
- selected item identity
- selected unit and measurement type
- declared quantity summary
- QA status metadata
- visible context labels

## Rules
- Jarvis must show which context it is using.
- Missing context triggers clarification, not guessing.
- Context metadata does not grant drawing access.
- Context metadata does not grant workbook access.
- Context metadata does not permit UI implementation.
- Context metadata does not permit automatic takeoff.

## Blocked context behavior
- infer drawing dimensions from selection
- read plan files
- read workbook files
- read cells/formulas/styles
- execute takeoff engine
- write quantities
- expose private paths or raw file references

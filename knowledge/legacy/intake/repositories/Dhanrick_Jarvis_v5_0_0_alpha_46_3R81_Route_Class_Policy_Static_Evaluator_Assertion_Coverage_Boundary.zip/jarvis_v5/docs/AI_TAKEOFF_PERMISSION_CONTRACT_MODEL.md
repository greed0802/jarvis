# AI Takeoff Permission Contract Model

Version: v5.0.0-alpha.39.6-batch
Base: v5.0.0-alpha.39.5-batch
Scope: metadata-only permission contract schema.

## Purpose

Define the future permission contract shape required before any AI Takeoff Workbench action can move from blocked metadata discussion to a later approved runtime action. Alpha39.6 only defines the schema. It does not implement permission runtime.

## Permission Contract Example

```json
{
  "permission_contract_id": "perm_contract_meta_001",
  "contract_version": "ai_takeoff_permission_contract_v1",
  "requested_action": "drawing_read",
  "requested_scope": "selected_plan_only",
  "selected_plan_id": "plan_meta_001",
  "selected_takeoff_item_id": null,
  "metadata_only": true,
  "content_access_requested": false,
  "content_access_granted": false,
  "execution_allowed": false,
  "approval_required": true,
  "approval_token_issued": false,
  "approval_status": "not_requested",
  "blocked_by_default": true,
  "reason": "alpha39.6 defines permission schema only; runtime action remains disabled"
}
```

## Allowed Permission Metadata

- contract id
- contract version
- requested action
- requested safe scope
- selected metadata ids
- approval status
- required disclosures
- blocked reasons
- safety flags

## Blocked Permission Metadata

- raw file path
- resolved file path
- file bytes
- drawing image
- OCR text
- geometry data
- workbook sheet/cell/formula values
- real approval token secret
- execution handle
- tool-call payload
- runtime job id

## Contract Rule

No permission contract can enable execution in alpha39.6. Every contract remains descriptive, metadata-only, and blocked by default.


## Alpha39.6 Non-Execution Guarantees

- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- workbook_opened=false
- quantity_writeback=false
- approval_token_issued=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false
- jarvis_runtime_imported=false
- fastapi_testclient_used=false
- memory_imported=false
- protected_systems_touched=false

This document is metadata-only. It does not grant permission, issue approval tokens, add runtime routes, add endpoints, open workbooks, read drawings, call OCR, call a takeoff engine, or write quantities.

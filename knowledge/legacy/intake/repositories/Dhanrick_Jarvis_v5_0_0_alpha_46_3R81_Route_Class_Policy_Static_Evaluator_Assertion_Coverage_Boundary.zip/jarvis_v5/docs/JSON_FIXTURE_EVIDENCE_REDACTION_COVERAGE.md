# JSON Fixture Evidence Redaction Coverage

Redaction evidence must use sanitized category labels only.

## Required redaction coverage
- path-like category suppressed
- workbook-reference category suppressed
- sheet-name category suppressed on blocked response
- cell-value category suppressed on blocked response
- formula category suppressed on blocked response
- style category suppressed on blocked response
- runtime-internal category suppressed

## Blocked raw values
Do not include real paths, actual workbook refs, real sheet names, actual cell values, actual formulas, style payloads, or exception traces.

## Evidence-only rule
Redaction coverage is declarative. It does not prove runtime execution and does not expose forbidden raw values.

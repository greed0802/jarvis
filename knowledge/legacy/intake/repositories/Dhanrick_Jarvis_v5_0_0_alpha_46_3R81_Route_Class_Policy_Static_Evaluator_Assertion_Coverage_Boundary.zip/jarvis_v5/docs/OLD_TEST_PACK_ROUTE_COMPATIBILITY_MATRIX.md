# Old Test Pack Route Compatibility Matrix

Target checkpoint: `v5.0.0-alpha.39.3-testmap`  
Base checkpoint: `v5.0.0-alpha.39.2-batch`  
Mode: FIRE metadata-only  
Scope: docs/reports/metadata inventory only. No runtime execution.


## Route compatibility principle

This checkpoint is an inventory map only. It does not add, remove, reorder, or modify any route.

## alpha22 observed high-frequency endpoint families

| Endpoint family | Compatibility | Notes |
|---|---|---|
| `/api/chat` | reusable_with_mapping | Route behavior likely evolved after alpha22. |
| `/api/version` | reusable_with_mapping | Version/scope assertions must be remapped. |
| `/api/plan/{conversation_id}` | reusable_with_mapping | Active task wrapper shape may be stale. |
| `/api/attach` | reusable_with_mapping | Attachment contract likely changed. |
| `/api/builder/engine-contract` | reusable_with_mapping | Useful only as contract metadata. |
| `/api/builder/engine-execution-request` | excluded_until_contract_review | Must prove blocked/no execution before reuse. |

## alpha30 observed high-frequency endpoint families

| Endpoint family | Compatibility | Notes |
|---|---|---|
| `/api/registry/*` | reusable_with_mapping | Good metadata-only safety surface. |
| `/api/registry/requirement-check` | reusable_with_mapping | Useful prompt-injection safety surface. |
| `/api/builder/workbook-read-preflight-dry-run` | reusable_with_mapping | Must remain no workbook read. |
| `/api/builder/safe-workbook-path-resolver-dry-run` | reusable_with_mapping | Must not expose raw paths or resolve filesystem. |
| `/api/builder/preview-execution-policy` | reusable_with_mapping | Must enforce approval-before-execution. |
| `/api/builder/engine-execution-request` | excluded_until_contract_review | Must remain blocked unless explicitly approved in a future phase. |

## Observed endpoint counts

### alpha22 top endpoints

- `/api/chat`: 7290
- `/api/builder/engine-contract`: 496
- `/api/attach`: 340
- `/api/builder/create-snapshot`: 257
- `/api/builder/adapter-dry-run`: 257
- `/api/version`: 50
- `/api/builder/engine-boundary-audit`: 17
- `/api/builder/engine-preflight`: 17
- `/api/builder/engine-execution-request`: 16
- `/api/plan/eng_2d_p02_t001`: 1
- `/api/plan/eng_2d_p02_t002`: 1
- `/api/plan/eng_2d_p02_t003`: 1
- `/api/plan/eng_2d_p02_t004`: 1
- `/api/plan/eng_2d_p02_t005`: 1
- `/api/plan/eng_2d_p02_t006`: 1

### alpha30 top endpoints

- `/api/chat`: 28010
- `/api/attach`: 2715
- `/api/builder/create-snapshot`: 2715
- `/api/builder/adapter-dry-run`: 2715
- `/api/builder/engine-contract`: 2465
- `/api/builder/workbook-read-preflight-dry-run`: 1205
- `/api/builder/safe-workbook-path-resolver-dry-run`: 505
- `/api/builder/engine-preflight`: 455
- `/api/builder/engine-execution-request`: 455
- `/api/registry/requirement-check`: 355
- `/api/builder/preview-execution-policy`: 200
- `/api/builder/engine-contract/${contract_id}`: 150
- `/api/version`: 50
- `/api/registry/tools`: 5
- `/api/registry/capabilities`: 5
- `/api/registry/connectors`: 5
- `/api/registry/models`: 5
- `/api/registry/execution-policies`: 5
- `/api/registry/source-authorities`: 5
- `/api/registry/scope-advisors`: 4

# Roadmap After alpha36.4 — alpha36.5 Governance Alignment

Current checkpoint: v5.0.0-alpha.36.5 planning/evidence package.

## Corrected roadmap

```text
alpha36.4
Inventory + dry-run + legacy discovery
DONE

alpha36.5
Workbook Runtime Governance Alignment Matrix
CURRENT

alpha36.6
Unified Workbook Permission Gate

alpha36.7
Safe Sheet-name Probe / Controlled Runtime Validation

alpha37+
Job Center + Output Runtime

alpha38+
Document Reader

alpha39+
Formatter + O&A contracts

alpha40+
Builder bridge governance
```

## alpha36.6 preparation

Recommended next target: design the Unified Workbook Permission Gate that wraps existing sheet-name ownership before runtime expansion.

No Job Center, Output Runtime, O&A implementation, Formatter enforcement, retention enforcement, Document Reader runtime, or Builder bridge should precede this governance step.

## Safety flags


metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
implementation_created=false
runtime_imported=false
runtime_called=false
workbook_opened=false
safe_path_resolver_called=false
path_resolved=false
audit_event_written=false
runtime_data_written=false
no runtime behavior changed
future-only


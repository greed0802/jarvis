# Metadata Bridge Minimal Integration Hash and Rollback Policy

Before any future integration FIRE:
- capture protected hashes
- declare exact files to edit
- declare exact files excluded
- declare rollback package
- run route tests
- run adapter tests
- run compileall
- validate package hygiene

Protected source validation must include:
- jarvis_v5/app.py unchanged unless separately approved
- jarvis_v5/config.py unchanged
- jarvis_v5/registry/registry_loader.py unchanged
- permission-gate runtime unchanged unless separately approved
- owner wrapper unchanged unless separately approved
- route files unchanged unless explicitly approved for route integration
- Builder runtime unchanged
- Formatter runtime unchanged
- QA runtime unchanged
- O&A runtime unchanged
- Document Reader runtime unchanged
- Output/Job runtime unchanged

Rollback triggers:
- route exposed without permission precheck
- endpoint added outside approved file list
- permission-gate contract drift
- owner-wrapper drift
- workbook access detected
- protected hash unexpected change
- test failure
- compile failure

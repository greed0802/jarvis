# Metadata Bridge Minimal Route Handler Boundary

A future minimal route handler, if separately approved later, must:
- Accept JSON only.
- Validate request schema.
- Require source_kind=attachment_manifest.
- Require contract_type=manifest_only_metadata_bridge.
- Require approval_id or approved permission context.
- Run permission precheck before adapter.
- Call adapter only after permission precheck passes.
- Return safe result only.
- Fail closed on invalid input.

The handler must not:
- open workbook
- inspect workbook container
- read attachment bytes
- resolve production workbook path
- call Builder runtime
- call Formatter runtime
- call QA runtime
- call O&A runtime
- call Document Reader runtime
- call Output Center runtime
- call Job runtime
- expose private paths
- expose raw workbook refs
- expose tracebacks/runtime internals

No route integration occurs in alpha38.9. No endpoint is added.

# Manifest-only Metadata Fixture Evidence Plan

Version: v5.0.0-alpha.37.11  
Base: v5.0.0-alpha.37.10

## Purpose
Define evidence for validating manifest-only metadata contract decisions using docs and JSON fixture evidence only.

## This is not
- runtime execution
- metadata bridge implementation
- workbook access
- workbook-container inspection
- sheet count extraction
- route or endpoint change
- source logic change
- synthetic workbook file creation

## Evidence categories
1. allow fixture evidence
2. block fixture evidence
3. fail-closed fixture evidence
4. redaction fixture evidence
5. expected decision record evidence
6. safety flag evidence
7. protected source evidence
8. package hygiene evidence

## Evidence boundary
Fixtures are represented in markdown and JSON only. No `.xlsx`, `.xlsm`, or `.xls` workbook fixture files are created.

# Jarvis Artifact Storage Backup Plan

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch

## Purpose

Define where accepted releases, evidence packages, hashes, and rollback data should live locally.

## Recommended Release Storage

```text
D:\Jarvis_Releases\
  full\
  patch\
  evidence\
  sha256\
  rollback\
```

## Recommended Backup Storage

```text
D:\Jarvis_Backups\
  accepted_checkpoints\
  old_exports\
  test_packs\
```

## Backup Rules

- Keep every accepted `FULL_RELEASE.zip`.
- Keep every evidence package.
- Keep every SHA256.
- Keep Git tags.
- Do not store secrets in release packages.
- Do not store raw workbook/drawing payloads unless explicitly approved and separated.

## Optional Later Support

- External drive backup
- Private Git remote
- NAS / Nextcloud backup
- Evidence manifest mirror



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

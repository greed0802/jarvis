# AI Takeoff Side-Chat Context Contract

Version: v5.0.0-alpha.39.5-batch
Base: v5.0.0-alpha.39.4-accelerated-playbook
Scope: metadata-only side-chat context contract.

## Purpose
This document defines the safe context that may be passed to Jarvis side-chat when the user is working inside the future AI Takeoff Workbench.

## Safe side-chat context example
```json
{
  "conversation_scope": "ai_takeoff_workbench_metadata_only",
  "selected_plan": {
    "safe_display_name": "A-105 Level 05 Floor Plan",
    "discipline": "architectural",
    "revision_label": "Rev C"
  },
  "selected_takeoff_item": {
    "item_label": "External Wall Type A",
    "unit": "m2",
    "measurement_basis": "area"
  },
  "permissions": {
    "drawing_read": false,
    "ocr": false,
    "takeoff_engine": false,
    "workbook_read": false,
    "quantity_writeback": false
  }
}
```

## Allowed side-chat actions
- explain selected metadata
- ask clarifying questions
- suggest safe next steps
- prepare measurement intent draft
- prepare checklist
- prepare QA questions
- flag missing metadata

## Blocked side-chat actions
- claiming visual access
- claiming measurement was performed
- calling tools
- opening files
- reading images/PDFs
- OCR
- calculating from unseen geometry
- writing back quantities
- exporting results


Safety flags required for this contract:
- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- quantity_writeback=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false

Explicit exclusions:
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No quantity writeback.
- No UI implementation.
- No route or endpoint addition.
- No Jarvis runtime import.
- No FastAPI TestClient.


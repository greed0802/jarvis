# AI Takeoff UI Metadata Validation Redaction Policy

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines fail-closed validation and redaction for future UI metadata contracts.

## Rules

- unknown UI metadata field blocked
- unknown panel action blocked
- path-like fields redacted
- raw content fields rejected
- drawing content fields rejected
- OCR text rejected
- geometry/coordinate fields rejected
- workbook fields rejected
- approval token secret rejected
- runtime handle rejected

## Blocked fields

absolute_path, file_path, local_path, stored_path, resolved_path, raw_path, attachment_path, directory, parent, full_path, pdf_bytes, image_bytes, thumbnail_bytes, ocr_text, drawing_text, geometry, coordinates, vector_entities, measurement_result, takeoff_result, workbook_cells, sheet_values, formula_values, style_values, approval_token_secret, runtime_handle, tool_payload, job_id, writeback_target.

## Required false flags

```json
{
  "ui_implemented": false,
  "drawing_read": false,
  "image_rendered": false,
  "pdf_rendered": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "workbook_read": false,
  "quantity_writeback": false,
  "approval_token_issued": false,
  "runtime_execution": false
}
```

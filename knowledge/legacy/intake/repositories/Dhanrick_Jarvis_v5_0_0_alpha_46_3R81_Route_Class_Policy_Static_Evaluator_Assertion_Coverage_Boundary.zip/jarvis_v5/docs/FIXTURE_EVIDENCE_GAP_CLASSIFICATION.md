# Fixture Evidence Gap Classification

Version: v5.0.0-alpha.37.14

## Gap classification rules

| Gap type | Severity | Example | Action |
|---|---:|---|---|
| Missing allow group | Medium | no manifest extension record | add docs/JSON expected evidence |
| Missing block group | High | no formula/style block record | add expected evidence |
| Missing fail-closed group | High | no wrong source_kind record | add expected evidence |
| Missing redaction group | High | no path/raw-ref suppression record | add expected evidence |
| Missing safety flag group | High normally / Medium if top-level safety coverage exists | no explicit safety_flag_evidence records | patch explicit records or accept top-level coverage |
| Raw forbidden value present | Critical | real path, formula, sheet name, cell value | block acceptance |
| Runtime execution claim present | Critical | record says evaluator ran | block acceptance |
| Workbook reference present | Critical | record references .xlsx or inherited fixtures | block acceptance |
| Fixture engine present | Critical | fixture executor added | block acceptance |

## Confirmed alpha37.13 gap
`records_by_group` has no explicit `safety_flag_evidence` group.

## Classification
Severity: Medium  
Reason: top-level `safety_flags_expected_false` exists and documents all safety flags false, but strict group coverage expected two explicit records.  
Runtime risk: none confirmed.  
Workbook risk: none confirmed.  
Recommended action: alpha37.15 JSON/docs-only evidence-gap patch if strict group coverage is required before alpha38.

## Critical gaps not confirmed
No raw workbook path, real sheet name, cell/formula/style value, runtime execution claim, workbook fixture reference, synthetic workbook reference, fixture execution engine, workbook open, or workbook-container inspection was confirmed by this review plan.

## Explicit gap phrase for smoke validation
Missing explicit safety_flag_evidence records.

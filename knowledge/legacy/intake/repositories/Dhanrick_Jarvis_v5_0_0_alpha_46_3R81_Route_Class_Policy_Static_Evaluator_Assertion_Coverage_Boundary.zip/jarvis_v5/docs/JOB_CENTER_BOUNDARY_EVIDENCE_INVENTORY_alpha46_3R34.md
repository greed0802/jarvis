# v5.0.0-alpha.46.3R34 — Job Center Boundary Evidence Inventory

## Status

This document is a non-runtime Job Center boundary evidence inventory.

R34 was selected by v5.0.0-alpha.46.3R33 as the next stability phase after the Output Center boundary closure. R33 is the current accepted checkpoint for this package.

## Scope

Allowed scope is static evidence inventory only.

R34 does not implement Job Center behavior. R34 does not execute Job Center behavior. R34 does not add a route, schema, runtime module, queue, worker, task runner, scheduler, export path, workbook bridge, document reader bridge, OCR bridge, tool bridge, or Output Center export bridge.

## Current accepted checkpoint

Current accepted checkpoint before R34:

- v5.0.0-alpha.46.3R33 — Next Stability Phase Selection
- R33 selected v5.0.0-alpha.46.3R34 — Job Center Boundary Evidence Inventory
- R33 was selection-only.
- R33 did not execute Job Center.
- R33 did not execute Output Center export.
- R33 did not execute workbook, OCR, document reader, or tool behavior.

## Inventory purpose

The purpose of this inventory is to identify where future Job Center behavior could create, mutate, expose, package, schedule, report, export, retry, resume, or leave behind artifacts.

This phase remains aligned with the current architecture principles:

- Metadata first.
- Contracts before execution.
- Permission before workbook access.
- Approval before execution.
- Preview before export.

## Job Center risk classes

The following Job Center risk classes are inventoried as future risks only:

1. Job execution without explicit approval.
2. Job-triggered Output Center export.
3. Job-triggered workbook read/write.
4. Job-triggered tool execution.
5. Job-triggered report writing.
6. Job-triggered sidecar generation.
7. Job-triggered runtime artifact packaging.
8. Job-triggered raw path exposure.
9. Job-triggered active-task mutation.
10. Job-triggered tracker mutation.
11. Job status/result exposing private/internal metadata.
12. Job retry/resume causing duplicate writes.
13. Job cancellation leaving partial artifacts.
14. Job queue/state mismatch with manifest evidence.
15. Job result bypassing preview/export policy.

## Route, module, and static evidence candidates

The following are static evidence candidates only and must not be imported or executed during R34:

- `jarvis_v5/schemas/job_contract_schema.py`
- `jarvis_v5/docs/JOB_CENTER_OUTPUT_MANIFEST_CONTRACT.md`
- `jarvis_v5/schemas/output_manifest_schema.py`
- `jarvis_v5/schemas/tool_result_schema.py`
- `jarvis_v5/tools/builder/preview_execution_policy.py`
- `jarvis_v5/qa_runner/report_writer.py`
- `jarvis_v5/tools/jarvis_evidence_runner.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/docs/PREVIEW_EXPORT_EXECUTION_POLICY.md`
- `jarvis_v5/docs/OUTPUT_MANIFEST_SCHEMA.md`
- `jarvis_v5/docs/PACKAGE_ARTIFACT_HYGIENE_POLICY.md`
- `jarvis_v5/docs/FIRE_SIDECAR_EVIDENCE_HYGIENE_LOCK_alpha46_3R19.md`

Static search patterns for later review may include:

- job
- job_center
- job_id
- job_status
- job_result
- task
- active_task
- queued
- running
- completed
- failed
- cancelled
- retry
- resume
- artifact
- manifest
- report
- output
- export
- saved_path
- raw_path
- download_path

These patterns are inventory aids only. They do not authorize runtime import, route execution, Job Center execution, or tool execution.

## Output Center interaction risks

Future Job Center behavior must not bypass the Output Center boundary closed in R32R1.

Risks to protect:

- job-triggered Output Center export
- job-triggered download/export link
- job-created output artifact without approval
- job bypass of preview-before-export
- job result exposing raw path or download path
- job result mutating an Output Center manifest
- job result packaging runtime or temporary artifacts
- job-to-output bridge without explicit approval contract

## Active-task and report-writing risks

Risks to inventory:

- active task creation
- active task status mutation
- active task result mutation
- report file writing
- report summary creation
- error report creation
- retry/resume records
- partial result records
- sidecar report agreement
- duplicate report writes
- cancelled job residual artifacts

R34 guard:

- No active-task mutation occurs.
- No report writing occurs except static FIRE evidence sidecars.
- No runtime job ledger is created.
- No runtime job queue is created.
- No Job Center state is mutated.

## Artifact, sidecar, and runtime-data risks

Future Job Center behavior could silently create or package:

- runtime job logs
- temporary job outputs
- partial artifacts
- orphan manifests
- debug files
- cache files
- report files
- downloadable outputs
- generated workbooks
- generated documents
- tool results
- raw data dumps

R34 package guards:

- No runtime data artifacts are newly packaged.
- No temporary fixture is packaged.
- No new workbook artifact is packaged.
- No new output artifact is packaged.
- No new runtime artifact is packaged.
- No `.pytest_cache/` is packaged.
- No `__pycache__/` is packaged.
- No `*.pyc` is packaged.
- Final ZIP file list must agree with manifest.
- `fire_summary.json` must agree with final ZIP.
- `fire_summary.md` must agree with JSON.
- verification CSV must have 0 failed rows.
- patch diff must agree with final ZIP.
- tracker SHA must match manifest.
- standalone tracker SHA must match package tracker.
- FIRE outputs ZIP must match standalone sidecars.

## Workbook, tool, and export bridge restrictions

R34 locks the following as future restrictions:

- No job-triggered workbook open/read/write.
- No job-triggered workbook-container inspection.
- No job-triggered load_workbook execution.
- No job-triggered Builder execution.
- No job-triggered tool execution.
- No job-triggered document reader execution.
- No job-triggered OCR execution.
- No job-triggered Output Center export.
- No job-triggered file execution.
- No job-to-workbook bridge without workbook permission contract.
- No job-to-tool bridge without tool approval contract.
- No job-to-export bridge without preview/export approval contract.

## Permission and approval guard requirements

Future Job Center execution should require a declared permission and approval contract. R34 documents this as a future design shape only:

```json
{
  "job_execution_required": true,
  "job_execution_approved": false,
  "approval_source": "user_explicit_message",
  "approval_scope": "single_job_only",
  "job_type": "<declared>",
  "job_input_manifest_id": "<declared>",
  "job_output_manifest_required": true,
  "workbook_access_required": false,
  "tool_execution_required": false,
  "document_reader_required": false,
  "ocr_required": false,
  "output_export_required": false,
  "preview_required_before_export": true,
  "raw_path_public_exposure_allowed": false,
  "runtime_data_packaging_allowed": false,
  "rollback_point": "<checkpoint>"
}
```

R34 does not implement this contract. R34 does not modify a schema or policy module.

## Public/private metadata guards

Public-safe metadata may include only approved fields such as:

- job_id if approved
- job_type
- job_status
- display_name
- checkpoint/version
- manifest_hash
- verification_status
- approved artifact display filename
- relative package reference if approved

Private/internal metadata must remain blocked:

- absolute path
- local path
- storage root
- temp path
- saved_path
- resolved path
- source filesystem path
- runtime workspace path
- raw upload path
- download_path
- internal attachment path
- private workbook path
- environment secret
- machine/user path

## Raw path guards

Forbidden public fields include:

- saved_path
- path
- file_path
- absolute_path
- resolved_path
- raw_path
- local_path
- stored_path
- artifact_path
- export_path
- output_path
- download_path
- directory
- parent
- full_path
- storage_root
- temp_dir
- workspace_root

A future Job Center public response, manifest, report, summary, sidecar, or export package must fail approval if it exposes raw/local filesystem paths.

## R34 non-execution facts

The following facts are locked for R34:

- `job_center_boundary_evidence_inventory_only=true`
- `selected_by_r33=true`
- `source_behavior_changed=false`
- `job_center_execution=false`
- `output_center_export_executed=false`
- `workbook_opened_by_jarvis_runtime=false`
- `workbook_read_by_jarvis_runtime=false`
- `workbook_written_by_jarvis_runtime=false`
- `workbook_container_inspection=false`
- `ocr_executed=false`
- `document_reader_executed=false`
- `tool_execution_performed=false`
- `api_route_calls=false`
- `fastapi_testclient_used=false`
- `runtime_imported=false`
- `app_imported=false`

## Future requirements

Future Job Center execution requires separate approval.

Future implementation/source patch requires separate PLAN / DRY RUN / FIRE.

Backlog source remains quarantined.

## Protected systems not touched

Protected systems include:

- Builder formula/export engine
- workbook policy runtime
- preview policy
- active-task writing/report guards
- safe path resolver
- Output Center runtime
- Job Center runtime
- auth runtime boundary
- workbook permission runtime
- attachment upload boundary
- route handlers
- middleware behavior
- schemas
- registries
- sidecar generator source
- UI/runtime modules

R34 touches none of these systems.

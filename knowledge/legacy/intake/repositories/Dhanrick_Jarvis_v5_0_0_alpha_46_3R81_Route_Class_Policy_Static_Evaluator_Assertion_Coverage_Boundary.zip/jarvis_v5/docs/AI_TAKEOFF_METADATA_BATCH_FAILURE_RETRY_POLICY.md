# AI Takeoff Metadata Batch Failure and Retry Policy

## Failure rule
If any batch fails, later batches must not run.

## Allowed recovery
- Retry the failed batch with minimal docs/tests/evidence correction.
- Stop and report failure.
- Replan the failed batch with narrower scope.
- Roll back failed-batch changes if cleanly separable.

## Blocked recovery
- Continue after a failed batch.
- Skip validation.
- Lower the confidence threshold.
- Touch source/runtime/protected files to make docs pass.
- Widen scope silently.
- Add route, endpoint, UI, drawing read, OCR, takeoff engine, workbook access, or quantity writeback.

## Required reporting
Failure reports must identify failed batch, failed assertion, files involved, recovery recommendation, and remaining uncertainty.

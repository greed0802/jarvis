# AI Takeoff Metadata Batch Execution Gates

## Gate policy
- Each batch confidence must be >= 98%.
- Final package confidence must be >= 98%.
- Protected systems confidence must remain 99%.
- Batch N+1 starts only after Batch N passes.
- A failed batch stops the sequence.

## Batch gates
### Batch 1 gate
Selected-plan metadata model exists and blocks drawing/PDF/image/OCR/CAD data.

### Batch 2 gate
Selected-item metadata model exists and blocks workbook/cell/formula/drawing-derived fields and quantity writeback.

### Batch 3 gate
Selected-context relationship model exists and does not imply drawing/workbook/UI access.

### Batch 4 gate
Validation/redaction policy and blocked-field matrix exist with fail-closed behavior.

### Batch 5 gate
Smoke test, JSON test pack, report, status, and handoff exist and confirm safety flags false.

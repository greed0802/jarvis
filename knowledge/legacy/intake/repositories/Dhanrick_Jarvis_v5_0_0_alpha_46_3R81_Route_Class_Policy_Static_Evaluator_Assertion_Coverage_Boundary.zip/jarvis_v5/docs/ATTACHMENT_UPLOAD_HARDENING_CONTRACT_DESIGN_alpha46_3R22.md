# alpha46.3R22 — Attachment Upload Hardening Contract Design

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R22`
- Base: `v5.0.0-alpha.46.3R21`
- Target: `Attachment Upload Hardening Contract Design`
- Rollback: `v5.0.0-alpha.46.3R21`

## Scope Statement

R22 is contract design only. It is not an implementation phase.

R22 makes no runtime behavior change, no source behavior change, no upload behavior change, no route behavior change, no metadata schema implementation, and no sidecar generator source patch.

R22 performs no runtime import, no `app.py` import, no FastAPI TestClient execution, no API route calls, no attachment upload execution, no file upload route execution, no workbook open/read/write/execution, no workbook-container inspection, no file execution through Jarvis runtime, no drawing/PDF/image read, no OCR, no tool execution, no Output Center export, and no Job Center execution.

## Accepted R21 Inventory Summary

R21 was accepted as `PASS / ACCEPTABLE` and carried forward these inventory facts:

- `/api/attach` route exists as a static route boundary.
- `AttachmentStore.save_upload` exists as the static upload persistence boundary.
- `AttachmentMeta.saved_path` exists as internal attachment metadata.
- `public_workbook_ref` omits `saved_path` from the public workbook reference projection.
- `safe_workbook_path_resolver` forbidden raw path keys include `saved_path`.
- `safe_workbook_path_resolver` remains metadata-only with `path_resolved=false`, `filesystem_checked=false`, `workbook_opened=false`, and `workbook_read=false`.
- The workbook sheet-name probe approval flow preserves permission-before-workbook-access ordering: permission gate before `_safe_attachment_file`, and `_safe_attachment_file` before `load_workbook`.

## Contract Design Goals

1. Keep `saved_path` private.
2. Define a public/private attachment metadata boundary.
3. Define an upload response allow-list.
4. Forbid raw path exposure in public responses.
5. Preserve permission-before-workbook-access.
6. Prevent upload from authorizing workbook read.
7. Keep safe path resolver metadata-only unless separately approved.
8. Require a separate PLAN / DRY RUN / FIRE before any implementation.

## Public Metadata Contract

Public attachment references must be path-free and built from an explicit allow-list projection.

Allowed public fields are limited to:

- `attachment_id`
- `display_name` or `original_filename`
- `content_type`
- `size_bytes`
- `uploaded_at` or `created_at`
- `status` or `accepted`
- public workbook reference, if applicable and still path-free

Forbidden public fields include:

- `saved_path`
- `path`
- `file_path`
- `absolute_path`
- `resolved_path`
- `raw_path`
- `local_path`
- `stored_path`
- `attachment_path`
- `directory`
- `parent`
- `full_path`
- `storage_root`

Public responses must be built from an explicit path-free allow-list projection, not from direct `AttachmentMeta.model_dump()` output.

## Private Metadata Contract

Private/internal attachment metadata may include storage details required for internal lookup, including `saved_path`, but private metadata must stay inside trusted storage/runtime boundaries.

`saved_path` internal-only contract:

- `saved_path` is private storage metadata.
- `saved_path` must never be accepted from user input.
- `saved_path` must never appear in public API responses.
- `saved_path` must never appear in public workbook references.
- `saved_path` must not be serialized through generic model dumps into client-visible response bodies.
- `saved_path` must not authorize workbook read by itself.
- `saved_path` lookup must remain behind permission approval and safe attachment resolution.

## Upload Response Contract

Future `/api/attach` behavior must return a public attachment reference only.

The upload response must not return:

- direct `AttachmentMeta` objects
- `saved_path`
- raw filesystem paths
- absolute, local, stored, resolved, or raw path fields
- parent directories
- storage root
- resolver output containing raw paths
- any implicit workbook-read authorization

Upload response acceptance requires:

1. explicit allow-list schema check;
2. forbidden raw path key scan;
3. `saved_path` negative assertion;
4. permission-before-workbook-access ordering check.

## Workbook Boundary Contract

Upload does not authorize workbook read.

Future hardening must preserve:

- permission gate before workbook file lookup;
- safe attachment lookup only after permission approval;
- workbook open/read/write only after explicit approved workbook permission;
- safe path resolver metadata-only behavior;
- no upload-to-workbook-read bypass.

## Future Implementation Gates

Any hardening patch after R22 requires a separate PLAN / DRY RUN / FIRE cycle.

Future implementation must define:

- explicit affected files list;
- public response projection before code patch;
- private metadata boundary preservation;
- negative public response tests for raw path keys;
- negative `saved_path` response tests;
- public workbook reference saved_path omission tests;
- permission-before-workbook-access ordering checks;
- no route, middleware, or dependency change unless separately approved;
- no workbook fixtures opened unless separately approved;
- final ZIP, sidecars, standalone tracker, manifest, JSON, MD, CSV, and patch diff agreement.

Functional route tests may only be used if separately approved in a later phase. R22 itself uses static evidence only.

## R22 Sidecar Consistency Guard

The final ZIP is the package truth source.

The standalone R22 tracker must match the final package tracker SHA.

The R22 FIRE outputs ZIP must match the standalone sidecar files.

The R22 manifest, `fire_summary.json`, `fire_summary.md`, verification CSV, patch diff, and final ZIP must agree.

## Excluded Scope

R22 excludes:

- attachment upload behavior patch;
- `attachment_store.py` source patch;
- `app.py` route modification;
- `message_schema.py` patch;
- `main_router.py` patch;
- public response schema change;
- metadata schema implementation;
- `saved_path` redaction implementation;
- upload response implementation;
- file access enablement;
- workbook access enablement;
- permission runtime patch;
- safe path resolver patch;
- TestClient upload test;
- runtime import;
- route call;
- dependency change;
- source behavior change.

## Protected Systems Not Touched

R22 does not modify:

- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`
- `requirements.txt`
- registries
- route handlers
- middleware behavior
- auth runtime boundary
- workbook permission runtime
- workbook policy runtime
- Builder formula/export engine
- Formatter workbook behavior
- QA Checker workbook behavior
- Description / BOQ Writer workbook behavior
- preview/export policy
- active-task writing/report guards
- Output Center runtime
- Job Center runtime
- schemas
- UI/runtime modules
- sidecar generator source

## Quarantined Backlog Rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for future ideas, but it cannot expand R22 scope, add R22 files, change the R22 target, promote connectors, promote OCR/document reader, promote personal assistant features, promote structural engineering engine, or override checkpoint evidence.

## Closure Verdict

R22 designs the attachment upload hardening contract only. It does not implement hardening.

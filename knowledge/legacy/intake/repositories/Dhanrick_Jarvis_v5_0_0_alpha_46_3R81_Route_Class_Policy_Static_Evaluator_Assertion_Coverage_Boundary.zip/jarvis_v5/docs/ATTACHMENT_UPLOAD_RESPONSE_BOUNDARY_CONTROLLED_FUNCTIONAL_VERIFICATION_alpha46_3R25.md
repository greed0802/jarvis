# alpha46.3R25 — Attachment Upload Response Boundary Controlled Functional Verification

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R25`
- Base: `v5.0.0-alpha.46.3R24`
- Target: `Attachment Upload Response Boundary Controlled Functional Verification`
- Rollback: `v5.0.0-alpha.46.3R24`

## Scope Statement

R25 is a controlled functional verification package for the attachment upload response boundary.

R25 is not a source patch and not an implementation phase. It makes no source behavior change, no runtime behavior change, no `app.py` patch, no `attachment_store.py` patch, no `message_schema.py` patch, no `main_router.py` patch, no dependency change, and no sidecar generator source patch.

R25 functional execution is strictly limited to the explicitly approved gate set:

- FastAPI TestClient import and use;
- `app.py` import through `jarvis_v5.app` for TestClient setup;
- `/api/attach` route call;
- temporary non-workbook text upload fixture creation;
- attachment upload execution;
- public response-body JSON inspection;
- recursive negative assertions for `saved_path` and raw path keys;
- cleanup verification for the temporary fixture and runtime upload artifacts.

## Accepted R24 Evidence Summary

R24 was accepted as a no-source-change static compliance lock. R24 locked the prior dry-run finding that no confirmed public `saved_path` exposure was proven in the `/api/attach` `ChatResponse` path.

R24 confirmed:

- `/api/attach` `response_model` is `ChatResponse`;
- `/api/attach` calls `kernel.attachments.save_upload(file)`;
- saved metadata is wrapped as `AttachmentMeta(**saved)`;
- `/api/attach` returns `router.route(req)`, not the saved dictionary directly;
- `ChatResponse` has no direct `attachments` field;
- `AttachmentMeta` keeps `saved_path` internally;
- `public_workbook_ref` is path-free and omits `saved_path` and raw path keys;
- attachment `reducer_result` uses `public_workbook_ref`;
- `_finalize` keeps raw request metadata internal;
- `/api/events` uses safe projection;
- future functional upload verification requires separate approval.

## Controlled Functional Verification Design

The R25 smoke test uses one scoped TestClient request to `/api/attach` with a tiny non-workbook `text/plain` upload fixture named `r25_upload_probe.txt`.

The test sets `JARVIS_API_KEY` to a test-only value with `pytest.monkeypatch`, sends the same value in the `X-Jarvis-API-Key` header, and inspects only the public response JSON.

The test does not use a workbook, workbook-like file extension, document, image, PDF, OCR fixture, or user file.

## Response-Body Negative Assertions

The public response JSON is recursively scanned to confirm the following keys are absent:

- `saved_path`
- `path`
- `file_path`
- `absolute_path`
- `resolved_path`
- `raw_path`
- `local_path`
- `stored_path`
- `attachment_path`
- `directory`
- `parent`
- `full_path`
- `storage_root`


The response string values are also scanned to confirm they do not expose obvious absolute local paths, upload storage roots, or parent directory traversal.

## Positive Boundary Assertions

The test asserts:

- the response does not return HTTP 5xx;
- the response is JSON-parseable;
- `workbook_read` is not `true`;
- `workbook_content_read` is not `true`;
- `tool_execution_performed` is not `true`;
- `saved_path_public_exposure_found` is `false`;
- `raw_path_public_exposure_found` is `false`.

## Cleanup Verification

The temporary text fixture is created only under `tmp_path` and removed by pytest cleanup. Runtime data files generated during the scoped upload test are cleaned after the response assertion. The final package must not include runtime upload artifacts, temporary fixture files, `.pytest_cache`, `__pycache__`, or `*.pyc` files.

## Forbidden Scope Preserved

Even with R25 functional approval, the following remain forbidden and are not executed:

- workbook open/read/write;
- workbook-container inspection;
- upload-to-workbook-read bridge;
- OCR;
- document reader;
- drawing/PDF/image read;
- Output Center export;
- Job Center execution;
- tool execution;
- dependency install/update;
- source modification;
- sidecar generator source patch;
- route count change;
- middleware count change.

## Protected Systems Not Touched

Protected runtime/source files remain byte-for-byte unchanged from R24:

- `jarvis_v5/app.py`;
- `jarvis_v5/core/attachment_store.py`;
- `jarvis_v5/schemas/message_schema.py`;
- `jarvis_v5/router/main_router.py`;
- `jarvis_v5/core/conversation_id_safety.py`;
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`;
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`;
- `requirements.txt`;
- registries;
- Builder/workbook/output/job files;
- UI/runtime modules;
- sidecar generator source.

## Backlog Quarantine

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for ideas only and cannot expand R25 scope, add files, change the target, promote OCR/document reader, promote workbook access, promote tool execution, or override checkpoint evidence.

## Closure Verdict

R25 is a controlled functional verification checkpoint. It verifies the public `/api/attach` response boundary under approved TestClient/upload conditions and does not change source behavior.

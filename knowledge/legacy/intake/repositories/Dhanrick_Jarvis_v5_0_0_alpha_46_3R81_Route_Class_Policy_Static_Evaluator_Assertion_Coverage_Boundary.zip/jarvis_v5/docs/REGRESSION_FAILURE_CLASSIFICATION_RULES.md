# Regression Failure Classification Rules — alpha36.5

Version: v5.0.0-alpha.36.5

Locked rule:

```text
Do not assume runtime regression.
Classify failures first.
```

## Categories

| category | definition | example handling |
|---|---|---|
| runtime_bug | current runtime changed or violates current contract | patch only after evidence |
| legacy_runtime_mismatch | legacy owner exists but future tests assume it does not | route to governance alignment |
| test_drift | old test expects old version, status, or response wording | update/carry compatibility layer only after review |
| documentation_governance_mismatch | docs describe future intent but omit current runtime reality | fix docs/evidence |
| version_lock_failure | pack asserts old APP_VERSION | classify as corpus drift |
| status_contract_drift | response status evolved but safety flags stay clean | review schema compatibility |

## Required report format

Every failed external regression should include:

```text
pack_name
case_name
expected
actual
classification
runtime_changed=true/false
safety_flags_clean=true/false
recommended_action
```

## Safety flags


metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
implementation_created=false
runtime_imported=false
runtime_called=false
workbook_opened=false
safe_path_resolver_called=false
path_resolved=false
audit_event_written=false
runtime_data_written=false
no runtime behavior changed
future-only


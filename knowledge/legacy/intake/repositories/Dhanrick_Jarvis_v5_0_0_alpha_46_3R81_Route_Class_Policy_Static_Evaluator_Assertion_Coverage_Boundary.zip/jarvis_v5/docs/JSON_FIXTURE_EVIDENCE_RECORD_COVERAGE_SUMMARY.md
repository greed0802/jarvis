# JSON Fixture Evidence Record Coverage Summary

Coverage counts are declarative expected-evidence counts only. They are not runtime pass/fail results.

| Group | Minimum expected count |
|---|---:|
| allow_manifest_metadata | 8 |
| block_workbook_container_metadata | 4 |
| block_workbook_internal_data | 10 |
| fail_closed_unknown_or_invalid | 5 |
| fail_closed_permission_or_source | 5 |
| redaction_evidence | 6 |
| safety_flag_evidence | 2 |
| package_guard_evidence | 3 |
| inherited_fixture_policy_evidence | 2 |

## Coverage rule
The JSON evidence file may copy-forward alpha37.12 expected records and add a coverage summary. Coverage is declarative evidence only and must not claim runtime execution.

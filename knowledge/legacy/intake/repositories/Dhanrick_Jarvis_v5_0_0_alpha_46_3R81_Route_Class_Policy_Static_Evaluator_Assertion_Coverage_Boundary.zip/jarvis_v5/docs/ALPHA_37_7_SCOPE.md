# Alpha 37.7 Scope — Sheet-name Probe Evidence Hardening / Real Fixture Test Pack

Version: v5.0.0-alpha.37.7
Base: v5.0.0-alpha.37.6.2

Scope: docs/tests/evidence only plus root README freshness metadata cleanup.

Allowed:
- Add controlled synthetic fixture smoke test for wrapped legacy sheet-name owner.
- Add blocked-before-open evidence.
- Add allowed sheet-name-only evidence.
- Add no saved_path leak evidence.
- Add no content/formula/cell/style return evidence.
- Refresh root README.md as non-version-specific package guide.

Excluded:
- No app.py edit.
- No endpoint or route behavior change.
- No registry_loader.py change.
- No owner wrapper logic change.
- No permission-gate contract change.
- No production/user workbook access.
- No content/formula/cell/style read.
- No Builder engine call.

# Permission Gate Route / Policy Review

## Confirmed current route policy
- Total API routes: 43.
- Duplicate route pairs: 0.
- `/api/builder/workbook-sheet-name-probe-approval` remains the only sheet-name probe approval route.
- `app.py` does not directly call `evaluate_workbook_permission_gate()`.
- The legacy owner wrapper is the only active route-to-permission-gate bridge.

## Current accepted path
`/api/builder/workbook-sheet-name-probe-approval` → `api_builder_workbook_sheet_name_probe_approval()` → `evaluate_workbook_sheet_name_probe_approval()` → `evaluate_workbook_permission_gate()`

## Ordering evidence
- Permission gate call line: 156
- `_safe_attachment_file` line: 215
- operational `load_workbook` line: 223

The permission gate is called before safe attachment resolution and workbook open.

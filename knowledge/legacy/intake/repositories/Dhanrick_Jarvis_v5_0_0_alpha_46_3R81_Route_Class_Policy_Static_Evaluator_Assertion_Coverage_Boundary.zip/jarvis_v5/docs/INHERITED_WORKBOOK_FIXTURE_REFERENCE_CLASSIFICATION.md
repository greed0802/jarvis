# Inherited Workbook Fixture Reference Classification

Version: v5.0.0-alpha.37.11.1

## Classification categories

| Class | Meaning | Action |
|---|---|---|
| test_only_reference | Smoke/unit/integration test references fixture directly | Keep until replacement test is approved |
| test_pack_reference | JSON pack references fixture as fixture evidence | Keep until pack is superseded |
| docs_only_reference | Documentation/history/report reference only | Safe to keep; does not require fixture execution |
| test_harness_source_reference | QA/test harness resolves fixtures for controlled tests | Allowed only in test-harness context |
| metadata_phase_reference | Metadata-only docs/tests mention workbook fixtures | Review wording; must not imply workbook open |
| runtime_source_reference | Runtime/source module references tests/fixtures path | Risk; block acceptance until reviewed |
| route_reachable_reference | Endpoint/route can reach tests/fixtures workbook | High risk; stop and plan patch |
| cleanup_candidate | No active tests/packs need fixture | Cleanup only in separate approved phase |
| do_not_delete_yet | Fixture still supports accepted tests/packs | Preserve |


## Inherited fixture names under classification
- Test.xlsx
- SheetProbe.xlsx
- jarvis_v5/tests/fixtures/Test.xlsx
- jarvis_v5/tests/fixtures/SheetProbe.xlsx

## Confirmed classification summary

### Test references
51 files under `jarvis_v5/tests` reference the inherited workbook fixture targets. These are classified as test-only or test-pack references and do-not-delete-yet until each reference is replaced or superseded.

### Docs/history references
38 files under `jarvis_v5/docs` reference the inherited workbook fixture targets. These are classified as docs/history/evidence references.

### Reports references
3 report files reference the inherited workbook fixture targets. These are classified as report/evidence references.

### Test harness source reference
`jarvis_v5/qa_runner/test_executor.py` references `tests/fixtures` through fixture resolver logic. This is classified as test_harness_source_reference, not production route hardcoding, unless future evidence proves production exposure.

### Protected runtime references
Targeted scan found no references in:
- jarvis_v5/app.py
- jarvis_v5/routes
- jarvis_v5/core
- jarvis_v5/registry

If future scan finds references in these areas, classify as runtime-risk or route-reachable risk.

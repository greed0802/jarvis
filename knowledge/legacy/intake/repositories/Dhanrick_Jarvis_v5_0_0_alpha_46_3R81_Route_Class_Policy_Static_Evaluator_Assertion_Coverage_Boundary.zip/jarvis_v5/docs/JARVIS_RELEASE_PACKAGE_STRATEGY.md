# Jarvis Release Package Strategy

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch

## Purpose

Define a package strategy that prevents Jarvis full releases from becoming the only review artifact.

## Package Classes

| Package | Purpose | ChatGPT Review Use |
|---|---|---|
| FULL_RELEASE.zip | Complete recoverable package | Upload only when necessary |
| PATCH_ONLY.zip | Added/changed/deleted files only | Preferred for patch review |
| EVIDENCE_ONLY.zip | Manifests, scans, reports, hashes | Preferred for REVIEW |

## FULL_RELEASE.zip

Complete recoverable release for local archive and rollback. It should be kept locally for every accepted checkpoint.

## PATCH_ONLY.zip

Focused change artifact containing only approved additions, modifications, deletion tombstones, manifests, and rollback instructions.

## EVIDENCE_ONLY.zip

Review artifact containing evidence reports and scan outputs without requiring full source review.

## Required Common Metadata

- base version
- target version
- package class
- SHA256
- changed file manifest
- package hygiene manifest
- rollback notes
- protected-boundary evidence



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

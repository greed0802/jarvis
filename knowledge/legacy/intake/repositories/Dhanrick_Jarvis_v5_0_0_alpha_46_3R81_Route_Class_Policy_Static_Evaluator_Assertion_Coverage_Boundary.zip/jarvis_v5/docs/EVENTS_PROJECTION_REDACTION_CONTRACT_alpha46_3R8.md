# /api/events Projection Redaction Contract — alpha46.3R8

Base: v5.0.0-alpha.46.3R7  
Target: v5.0.0-alpha.46.3R8  
Mode: FIRE / contract-only static regression lock

## Objective

Define the safe projection and redaction contract for `GET /api/events/{conversation_id}` before any runtime implementation patch.

This document is metadata and evidence only. It does not change route behavior, does not add enforcement, does not import runtime, and does not authorize workbook, tool, Output Center, or Job Center execution.

## Current confirmed state

`/api/events/{conversation_id}` currently returns:

```python
{
    "conversation_id": conversation_id,
    "events": kernel.events.list_events(conversation_id),
}
```

`EventLedger.append(...)` stores raw event records with:

```text
event_id
client_event_id
conversation_id
intent
route
request
response
created_at
```

Because stored events include raw `request` and raw `response`, `/api/events` remains `internal_projection_pending` until a future implementation patch adds an allowlist projection.

## Route classification

From `ROUTE_ACCESS_CLASSIFICATION_CONTRACT_alpha46_3R6.md`:

```text
GET /api/events/{conversation_id}
Handler: api_events
Access class: internal_projection_pending
```

## Safe projection allowlist

### Top-level response fields

```text
conversation_id
events
projection
projection_version
count
```

### Per-event fields

```text
event_id
client_event_id
conversation_id
intent
route
created_at
safe_status
safe_flags
```

### `safe_flags` fields

```text
blocked
duplicate
has_attachment
contract_only
execution_enabled
workbook_read
workbook_content_read
tool_execution_performed
engine_called
excel_created
```

`safe_flags` values must be booleans or simple scalar status summaries only. They must not contain nested request, response, attachment, workbook, route-output, state, task, adapter, reducer, or tool objects.

## Forbidden projection fields

The following must not be returned by any future safe `/api/events` projection:

```text
request
response
text
prompt
message body
request body
headers
cookies
authorization
api_key
secret
token
config
env
traceback
exception
stack
internal_path
saved_path
workbook_path
file path
absolute path
attachments
attachment metadata
workbook content
snapshot
adapter
reducer_result
setup_completeness
readiness
raw route output
raw state object
raw task object
raw workbook metadata
raw tool result
```

## Ambiguous field decisions

| Field | R8 decision |
|---|---|
| `client_event_id` | Allow as opaque ID only; reviewable because it is client-provided. |
| `intent` | Allow. |
| `route` | Allow. |
| `created_at` | Allow. |
| `blocked` / `duplicate` | Allow as booleans only. |
| `has_attachment` | Allow as boolean only. |
| `router_step` | Exclude for R8. |
| `reason` | Exclude for R8. |
| `active_task_id` | Exclude for R8. |
| `pending_clarification_id` | Exclude for R8. |
| `snapshot` | Forbid. |
| `adapter` | Forbid. |
| `reducer_result` | Forbid. |
| raw `request` / raw `response` | Forbid. |

## Router trace note

`EventLedger.router_trace(...)` is not the final safe `/api/events` projection. It performs a projection-like transformation but still includes risky/internal fields such as `text`, `reducer`, `snapshot`, and `adapter`.

## Future implementation boundary

A future implementation patch may add a safe allowlist projection helper only after separate PLAN / DRY RUN / REVIEW / FIRE approval.

R8 does not modify:

```text
jarvis_v5/app.py
jarvis_v5/core/event_ledger.py
jarvis_v5/router/main_router.py
routes
runtime modules
requirements.txt
registries
```

R8 does not add:

```text
runtime projection code
route enforcement
auth/API-key middleware
CORS
rate limiting
endpoint wrappers
new routes
API calls
TestClient execution
workbook reads
tool execution
Output Center export
Job Center execution
```

## Required static lock

The R8 static test must confirm:

```text
route count = 43
/api/events exists exactly once
/api/events remains GET /api/events/{conversation_id}
/api/events handler remains api_events
api_events currently returns kernel.events.list_events(conversation_id)
EventLedger.append stores raw request and response
R6 contract classifies /api/events as internal_projection_pending
safe projection allowlist exists
forbidden raw/leak field list exists
```

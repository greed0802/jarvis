# AI Takeoff Workbench Chat Panel Boundary

Version: v5.0.0-alpha.39.0  
Base: v5.0.0-alpha.38.9  
Mode: docs/tests/evidence only


## Boundary

The Jarvis chat panel is future planning only in alpha39.0.

## Future principles

Jarvis should show the context it is using, operate on declared selected-context metadata unless more is approved, not invent quantities, and require human confirmation before writeback/export.

## Safe future chat actions

- Explain selected item metadata.
- Summarize selected quantity metadata.
- Suggest QA checks.
- Draft BOQ wording.
- Identify missing context.
- Prepare a takeoff checklist.

## Blocked in alpha39.0

No automatic takeoff, drawing read, image dimension inference, quantity write, takeoff data modification, workbook export, or protected runtime call.

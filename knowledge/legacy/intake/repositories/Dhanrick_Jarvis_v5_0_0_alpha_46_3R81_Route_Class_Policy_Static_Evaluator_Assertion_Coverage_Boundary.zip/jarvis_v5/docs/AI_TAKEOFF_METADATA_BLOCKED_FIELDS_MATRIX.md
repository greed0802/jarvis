# AI Takeoff Metadata Blocked Fields Matrix

## Drawing / plan content fields — BLOCKED
- drawing_path
- private_drawing_path
- pdf_path
- image_path
- cad_path
- raw_drawing_pixels
- pdf_internals
- ocr_text
- cad_geometry
- vector_paths
- measured_dimensions

## Workbook/content fields — BLOCKED
- workbook_path
- private_workbook_path
- workbook_ref
- sheet_name_from_read
- cell_value
- formula
- cached_formula_value
- style
- named_range
- table_range
- merged_cell_data

## Takeoff engine fields — BLOCKED
- automatic_measurement
- generated_quantity
- measurement_vector
- takeoff_engine_output
- quantity_writeback
- plan_markup_writeback
- workbook_writeback

## Runtime/internal fields — BLOCKED
- traceback
- runtime_internal
- file_handle
- open_file_object
- route_internal
- permission_gate_internal
- owner_wrapper_internal

## Allowed principle
Only declared metadata identity/context fields are allowed. Anything that reads or implies reading drawing/workbook content is blocked.

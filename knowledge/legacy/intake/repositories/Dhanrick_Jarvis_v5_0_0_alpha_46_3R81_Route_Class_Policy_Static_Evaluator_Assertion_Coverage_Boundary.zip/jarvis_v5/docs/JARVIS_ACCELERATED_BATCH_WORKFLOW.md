# Jarvis Accelerated Batch Workflow

Version label: v5.0.0-alpha.39.4-accelerated-playbook  
Base checkpoint: v5.0.0-alpha.39.3-testmap  
Scope type: docs/reports/metadata only

## Goal

Move faster without broad unsafe patches.

## New default pacing

```text
PHASE PLAN
  Define 3-5 related batches once.

PHASE DRY RUN
  Inspect all batches, stop conditions, files, tests, risks.

FIRE BATCH 0
  Baseline only.

FIRE BATCH 1
  Docs/contracts only.

FIRE BATCH 2
  Tests/evidence only.

FIRE BATCH 3
  One runtime family only, if explicitly approved.

FIRE BATCH 4
  Reports/handoff/package.

REVIEW
  Accept or reject checkpoint.
```

## Why this is faster

```text
Planning overhead is reduced because related batches are planned together.
Risk stays controlled because implementation still happens batch by batch.
Failed work is isolated to one batch.
Protected systems stay locked unless explicitly scoped.
```

## Batch 0 — baseline lock

Purpose: prove the base is clean before any change.

Typical checks:

```text
package exists
ZIP integrity PASS
compileall PASS
current smoke tests PASS
package hygiene clean
execution flags false
protected files unchanged
old tests not executed unless scope explicitly allows
Jarvis runtime not imported unless required and approved
```

If Batch 0 fails, stop immediately.

## Batch 1 — docs/contracts

Allowed:

```text
docs
contracts
policy matrices
roadmap notes
handoff planning
metadata-only reports
```

Not allowed:

```text
runtime source changes
route changes
endpoint additions
workbook access
UI implementation
Builder execution
```

## Batch 2 — tests/evidence

Allowed:

```text
smoke test files
JSON test packs
metadata-only test inventories
reports/current evidence files
static scans
```

Not allowed unless explicitly approved:

```text
old pack raw execution
Jarvis runtime import
FastAPI TestClient
workbook read
Builder engine execution
Excel output
```

## Batch 3 — runtime family, only if explicitly approved

One code family only:

```text
router only
or slot reducer only
or one policy module only
or one metadata model module only
```

Never combine runtime families by default.

## Batch 4 — reports/handoff/package

Required:

```text
change report
test report
package hygiene report
protected-boundary report
current status
next handoff
rollback notes
next command script
```

## Review gate

A checkpoint is not accepted until REVIEW verifies:

```text
package hygiene
expected files
no unauthorized changes
tests/scans
safety flags
protected systems
remaining uncertainty
rollback path
```

## Recommended near-term sequence

```text
alpha39.4 — accelerated playbook docs/reports only
alpha39.5 — AI Takeoff Workbench Interaction Contract Batch Plan
alpha39.6 — AI Takeoff Permission / Approval Contract Batch Plan
alpha39.7 — AI Takeoff UI Metadata Contract, no UI implementation
alpha39.8 — Curated alpha22/alpha30 compatibility layer, no raw execution
```

# Metadata Bridge Future Request/Response Schema

Future request schema is documented but not implemented:

```json
{
  "source_kind": "attachment_manifest",
  "contract_type": "manifest_only_metadata_bridge",
  "approval_id": "string",
  "attachment_manifest": {},
  "requested_fields": []
}
```

Request must not include workbook_path, absolute_path, private_attachment_path, raw_workbook_ref, workbook object, file handle, cell references, formula references, or sheet names from workbook read.

Future response schema is documented but not implemented:

```json
{
  "decision": "allow_or_block",
  "allowed": false,
  "reason_code": "safe_reason",
  "requested_fields": [],
  "allowed_fields": [],
  "blocked_fields": [],
  "safe_ui_summary": {},
  "audit": {},
  "safety_flags": {}
}
```

Response must not include private paths, raw workbook references, cell values, formulas, styles, runtime internals, or tracebacks.


## Safety boundary
- no source patch occurs
- no route integration occurs
- no endpoint is added
- no runtime implementation occurs
- no workbook open occurs
- no workbook-container inspection occurs
- no permission-gate contract change occurs
- no owner-wrapper change occurs
- safety flags remain false
- protected systems untouched

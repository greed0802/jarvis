# AI Takeoff Selected Item Panel Metadata Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines safe selected-takeoff-item panel metadata.

## Allowed metadata example

```json
{
  "panel_id": "selected_item_panel_meta_001",
  "selected_takeoff_item_id": "item_meta_001",
  "item_label": "External Wall Type A",
  "trade": "wall finishes",
  "measurement_unit": "m2",
  "measurement_basis": "area",
  "quantity_value": null,
  "quantity_source": "not_measured",
  "takeoff_engine_called": false,
  "quantity_writeback_allowed": false
}
```

## Allowed display

item label, trade/category, intended unit, measurement basis, status, safe notes, and blocked action status.

## Blocked display

engine-calculated quantity, drawing-derived quantity, workbook-derived quantity, raw coordinates, geometry-derived measurement, writeback destination, and hidden workbook/cell mapping are blocked.

# Old Test Pack Compatibility Classification

Target checkpoint: `v5.0.0-alpha.39.3-testmap`  
Base checkpoint: `v5.0.0-alpha.39.2-batch`  
Mode: FIRE metadata-only  
Scope: docs/reports/metadata inventory only. No runtime execution.


## Classification labels

- `reusable`: concept still aligns with alpha39+ and can become a current regression test after version/route review.
- `reusable_with_mapping`: concept is useful, but response paths, endpoint names, or version targets must be mapped first.
- `stale_or_quarantine`: old expectation likely binds to alpha22/alpha30 shape and must not run raw.
- `excluded_until_contract_review`: endpoint or prompt surface includes execution-risk terms and must remain blocked until its no-execution contract is proven.

## Reusable first-pass families

- version metadata after target remap
- active non-mutating language gates
- feedback ownership
- slot reducer ownership
- unit alias normalization
- pending clarification guards
- endpoint safety metadata checks
- registry read-only metadata checks
- preview/export blocked policy checks
- safe path resolver no raw path checks

## Reusable with mapping

- `/api/chat`
- `/api/version`
- `/api/plan/{conversation_id}`
- `/api/attach`
- `/api/registry/*` metadata endpoints
- `/api/builder/engine-contract*`
- `/api/builder/workbook-read-preflight-dry-run`
- `/api/builder/safe-workbook-path-resolver-dry-run`
- `/api/builder/preview-execution-policy`

## Stale or quarantine

- exact alpha22/alpha30 version assertions
- old route count assertions
- old active_task wrapper exact shape
- old known_routes exact lists
- old response field names for preview/export policy
- old contract latest route assumptions

## Excluded until contract review

- `/api/builder/engine-execution-request`
- adversarial prompts asking to bypass policy
- prompts mentioning `openpyxl` / `load_workbook` as desired execution
- any test implying workbook open/read or Builder engine call

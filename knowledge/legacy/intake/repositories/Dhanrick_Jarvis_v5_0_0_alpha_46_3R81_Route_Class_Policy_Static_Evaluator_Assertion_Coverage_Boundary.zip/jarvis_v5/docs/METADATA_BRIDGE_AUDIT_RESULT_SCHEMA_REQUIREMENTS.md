# Metadata Bridge Audit / Result Schema Requirements

Version: v5.0.0-alpha.38.1

## Required future result fields

- `decision`
- `allowed`
- `reason_code`
- `source_kind`
- `contract_type`
- `requested_fields`
- `allowed_fields`
- `blocked_fields`
- `fail_closed`
- `contains_workbook_data=false`
- `workbook_opened=false`
- `workbook_container_inspected=false`
- `production_workbook_access=false`
- `safe_ui_summary`
- `safety_flags`

## Forbidden result fields

- `saved_path`
- `absolute_path`
- private attachment path
- raw workbook reference
- real sheet names from workbook read
- cell values
- formulas
- cached values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- tracebacks
- runtime internals

## Rule

Result records must be safe to surface in UI and audit logs without revealing paths, workbook internals, or runtime internals.

# alpha46.3R19 — FIRE Sidecar Evidence Hygiene Lock

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R19`
- Base: `v5.0.0-alpha.46.3R18R1`
- Rollback: `v5.0.0-alpha.46.3R18R1`
- Target: FIRE Sidecar Evidence Hygiene Lock

## Scope Statement

R19 is an evidence-output hygiene lock only.

R19 does not change runtime behavior. R19 does not change `app.py`. R19 does not change routes, middleware, dependencies, registries, workbook logic, Builder logic, Output Center logic, Job Center logic, safe path resolver behavior, conversation ID safety behavior, attachment store behavior, or sidecar generator source.

R19 performs no workbook open/read/write/execution, no workbook-container inspection, no file execution through Jarvis runtime, no FastAPI TestClient execution, no API route calls, no OCR, and no tool/output/job execution.

## R18 Defect Summary

The original delivered R18 package exposed a package/evidence integrity defect:

- delivered R18 package contradicted manifest and JSON file-count claims;
- delivered R18 removed package files unexpectedly;
- delivered R18 was missing `requirements.txt` while claiming it was unchanged;
- delivered R18 Markdown/CSV sidecars contradicted package evidence;
- delivered R18 `fire_summary.md` said `Result: FAIL`;
- delivered R18 `fire_summary.md` contained unresolved placeholders;
- delivered R18 verification CSV contained a `files_removed` failure.

This defect was treated as blocking package-integrity evidence, not as a harmless sidecar-only issue.

## R18R1 Correction Summary

R18R1 corrected the R18 defect by reissuing the safe path resolver evidence lock from R17.

R18R1 restored the full expected package file set, kept `requirements.txt` present and unchanged, preserved `app.py`, produced zero removed files, and produced coherent sidecars:

- final ZIP file count: `1,901`;
- files removed: `0`;
- `fire_summary.md` said `Result: PASS`;
- `fire_summary.md` had no unresolved placeholders;
- verification CSV had `0` failed rows;
- tracker SHA matched manifest and JSON.

## Final ZIP Truth Rule

The final delivered ZIP is the package truth source.

Manifest, `fire_summary.json`, `fire_summary.md`, verification CSV, patch diff, and tracker SHA must be generated from or validated against the final delivered ZIP. Intended trees, staging trees, and planned deltas are not sufficient if they disagree with the final package.

## Required Sidecar Agreement

Every FIRE cycle must prove agreement among:

1. final delivered ZIP;
2. source-of-truth manifest JSON;
3. `fire_summary.json`;
4. `fire_summary.md`;
5. verification CSV;
6. patch diff note;
7. updated tracker SHA.

Agreement must include target version, base version, base file count, target file count, files added, files changed, files removed, tracker SHA, result status, and verification failed count.

## Forbidden Sidecar Conditions

The following are forbidden in accepted FIRE sidecars:

- result mismatch;
- unresolved placeholders;
- file-count mismatch;
- `files_removed` mismatch;
- `requirements.txt` missing while sidecars claim unchanged;
- failed verification CSV rows without explicit blocking classification;
- tracker SHA mismatch;
- patch diff that does not match the final ZIP.

## Acceptance Rule

Any future FIRE must fail, stop, or require reissue if the final ZIP and sidecars disagree.

Blocking package integrity contradictions require reissue. They cannot be accepted as non-blocking sidecar-only defects.

Non-blocking caveats must be explicitly labeled and must not contradict package truth.

## Protected Systems Not Touched

R19 does not touch:

- `jarvis_v5/app.py`;
- route handlers;
- middleware behavior;
- auth runtime boundary;
- workbook permission runtime;
- workbook policy runtime;
- safe path resolver behavior;
- conversation ID safety behavior;
- attachment store behavior;
- Builder formula/export engine;
- Formatter workbook behavior;
- QA Checker workbook behavior;
- Description / BOQ Writer workbook behavior;
- preview/export policy;
- active-task writing/report guards;
- Output Center runtime;
- Job Center runtime;
- registries;
- `requirements.txt`;
- schemas;
- UI/runtime modules;
- sidecar generator source.

## Quarantined Backlog Rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for future ideas, but it cannot expand R19 scope, add R19 files, change the target, promote connectors, promote OCR/document reader work, promote personal assistant features, promote structural engineering engine work, or override checkpoint integrity evidence.

## Future Recommendation

If sidecar contradictions recur after R19, plan a separate sidecar generator hygiene patch. R19 itself does not patch generator source.

## Closure Verdict

R19 locks FIRE sidecar evidence hygiene expectations. The accepted rollback checkpoint remains `v5.0.0-alpha.46.3R18R1` until R19 review acceptance.

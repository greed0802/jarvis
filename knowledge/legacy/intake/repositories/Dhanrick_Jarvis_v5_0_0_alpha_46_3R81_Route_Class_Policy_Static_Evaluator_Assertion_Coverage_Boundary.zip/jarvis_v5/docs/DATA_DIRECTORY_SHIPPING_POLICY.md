# Data Directory Shipping Policy

Rules:

- `.keep` files may ship.
- Fixtures may ship only under `tests/fixtures`.
- Runtime state should not ship.
- Active task state should not ship.
- Conversation state should not ship.
- Event ledger runtime data should not ship.
- Debug ZIPs should not ship unless evidence package explicitly includes them.
- Preview/temp outputs should not ship.
- Final outputs require confirmation before deletion or exclusion if expected by user.

Retention planning:

- final outputs: keep 90 days
- temporary handoff copies: keep 14 days
- preview files: keep 7 days
- debug ZIPs: keep 30 days
- logs/state_shadow: keep 14 days or cap to 100 MB
- archive projects after 90 days

retention_policy_documented=true
retention_engine_implemented=false

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

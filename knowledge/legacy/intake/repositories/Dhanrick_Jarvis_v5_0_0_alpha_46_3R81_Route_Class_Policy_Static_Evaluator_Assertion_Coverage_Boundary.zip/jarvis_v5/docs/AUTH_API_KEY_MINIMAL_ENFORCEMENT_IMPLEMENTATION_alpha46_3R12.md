# AUTH / API-KEY MINIMAL ENFORCEMENT IMPLEMENTATION — alpha46.3R12

Base: `v5.0.0-alpha.46.3R11`  
Target: `v5.0.0-alpha.46.3R12`  
Mode: FIRE / minimal runtime boundary

## Objective

Implement the accepted R11 route auth matrix with the smallest possible API-key boundary in `jarvis_v5/app.py` while preserving route decorators, route handlers, Builder/workbook logic, Output Center, Job Center, registries, dependencies, and debug/dev guard behavior.

## Scope

R12 changes runtime behavior only at the API boundary for routes classified as `PROTECTED` by the R11 contract.

R12 does not add routes, dependencies, CORS, rate limiting, JWT/OAuth/session auth, user management, database-backed auth, workbook reads, Builder execution, tool execution, Output Center export, or Job Center execution.

## Implemented route classes

| Class | Count | Behavior |
|---|---:|---|
| `PUBLIC_READONLY` | 12 | Pass through without API key. |
| `PROTECTED` | 26 | Require API key before handler execution. |
| `DEV_DEBUG_ONLY` | 3 | Pass through to existing R7 `DEBUG_MODE` guard. |
| `DEV_TEST_ONLY` | 2 | Pass through to existing R7 `DEBUG_MODE` guard. |

Total mapped routes: 43.

## Public read-only routes

- `GET /api/version`
- `GET /api/registry/tools`
- `GET /api/registry/capabilities`
- `GET /api/registry/connectors`
- `GET /api/registry/models`
- `GET /api/registry/execution-policies`
- `GET /api/registry/source-authorities`
- `GET /api/registry/scope-advisors`
- `GET /api/registry/file-requirements`
- `GET /api/registry/rfi-templates`
- `GET /api/registry/ecosystem-adapters`
- `GET /api/registry/voice-assistants`

## Protected routes

Protected routes require a valid API key before handler execution:

- `POST /api/registry/requirement-check`
- `POST /api/chat`
- `POST /api/attach`
- all `/api/builder/*` routes
- `GET /api/state/{conversation_id}`
- `GET /api/plan/{conversation_id}`
- `GET /api/events/{conversation_id}`

## Dev/debug routes

The existing R7 debug/dev guard remains authoritative. R12 passes these requests through to the existing `DEBUG_MODE` guard and does not redesign debug/dev behavior.

## Accepted key sources

- `X-Jarvis-API-Key: <key>`
- `Authorization: Bearer <key>`

Server key source:

- `JARVIS_API_KEY`

Validation uses `hmac.compare_digest(...)`.

## Fail-closed behavior

A protected route returns the same safe `401` envelope when:

- `JARVIS_API_KEY` is missing or empty.
- the client key is missing.
- the client key is invalid.

The response intentionally does not reveal whether the server key is configured.

## Unauthorized response envelope

```json
{
  "ok": false,
  "error": "auth_required",
  "message": "API key required.",
  "auth_required": true,
  "authenticated": false,
  "execution_enabled": false,
  "workbook_read": false,
  "workbook_content_read": false,
  "tool_execution_performed": false,
  "engine_called": false,
  "excel_created": false,
  "contract_only": true
}
```

Forbidden in the auth-failure response:

- submitted key
- expected key
- environment/config values
- request headers
- traceback or raw exception
- internal paths
- `saved_path`
- workbook content
- tool results

## Unknown-route behavior

Unknown routes pass through to FastAPI unchanged, preserving normal `404` behavior. Static tests therefore lock route count and matrix coverage so future route additions cannot silently remain unmapped.

## Protected systems not touched

- Builder formula/export engine
- Builder workbook execution
- Formatter runtime
- QA Checker runtime
- Output Center runtime
- Job Center runtime
- workbook policy runtime
- preview policy
- active-task guards
- safe path resolver runtime
- EventLedger storage
- MainRouter routing
- AttachmentMeta
- AttachmentStore
- registries
- requirements.txt
- CORS
- rate limiting
- upload/text validation
- saved_path schema

## Evidence note carried forward

R10 contains one inherited Python smoke-test reference to the Source of Truth tracker. R12 adds zero new Python references to that tracker. Verification reports the inherited finding separately.

## Rollback

Remove the R12 docs/test/manifest, restore `jarvis_v5/app.py`, and restore `jarvis_v5/docs/source_of_truth/Jarvis_SourceOfTruth_alpha46_3.xlsx` from `v5.0.0-alpha.46.3R11`.

# Metadata Bridge Future Touched Files Plan

Future candidate files are review-only in alpha38.9.

Potential future candidates if integration is later approved:
- possible route module — exact file must be discovered/reviewed before FIRE
- possible route registration file — exact file must be discovered/reviewed before FIRE
- possible smoke test file — tests/smoke metadata bridge route tests
- possible JSON test pack — tests/packs route permission tests

Protected/excluded unless separately approved:
- jarvis_v5/app.py
- jarvis_v5/config.py
- jarvis_v5/registry/registry_loader.py
- permission-gate modules
- owner-wrapper modules
- Builder runtime modules
- Formatter runtime modules
- QA runtime modules
- O&A runtime modules
- Document Reader runtime modules
- Output Center runtime modules
- Job runtime modules
- safe path resolver
- preview policy
- static/UI

Classification:
- candidate_status=review_only
- approved_for_edit=false
- approved_for_route_integration=false
- approved_for_endpoint=false
- approved_for_runtime=false

alpha38.9 does not identify any file as approved for edit. Exact future touched files must be confirmed by a later evidence review before FIRE.

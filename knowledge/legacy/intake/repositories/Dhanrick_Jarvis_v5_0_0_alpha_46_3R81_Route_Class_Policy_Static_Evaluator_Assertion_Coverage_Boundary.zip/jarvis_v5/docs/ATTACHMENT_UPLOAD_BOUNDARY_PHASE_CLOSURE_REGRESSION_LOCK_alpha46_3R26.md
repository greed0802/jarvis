# alpha46.3R26 — Attachment Upload Boundary Phase Closure Regression Lock

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R26`
- Base: `v5.0.0-alpha.46.3R25`
- Target: `Attachment Upload Boundary Phase Closure Regression Lock`
- Rollback: `v5.0.0-alpha.46.3R25`

## Scope Statement

R26 is a no-source-change closure/regression lock for the attachment upload boundary phase. It is static evidence only and does not implement new behavior.

R26 performs no runtime import, no `app.py` import, no FastAPI TestClient execution, no API route call, no attachment upload execution, no temporary fixture creation, no workbook open/read/write, no workbook-container inspection, no OCR, no document reader, no tool execution, no Output Center export, and no Job Center execution.

## Accepted R21-R25 Evidence Chain

### R21 — Attachment Upload Hardening Evidence Boundary Inventory

R21 was accepted as the inventory checkpoint. It documented `/api/attach`, `AttachmentStore.save_upload`, `AttachmentMeta.saved_path`, `public_workbook_ref`, safe path resolver raw-path key guards, and permission-before-workbook-access ordering.

### R22 — Attachment Upload Hardening Contract Design

R22 was accepted as the contract checkpoint. It locked public/private attachment metadata boundaries, `saved_path` internal-only handling, upload response allow-list expectations, forbidden raw path keys, and the requirement that future implementation needs separate PLAN / DRY RUN / FIRE.

### R23 — Attachment Upload Hardening Minimal Implementation Plan

R23 was accepted as the minimal implementation planning checkpoint. It identified response-boundary projection as the future minimal implementation option and recommended no `AttachmentStore` patch in the minimal path.

### R24 — Attachment Upload Response Boundary Static Compliance Lock

R24 was accepted as a no-source-change static compliance checkpoint. It locked that no confirmed public `saved_path` exposure was proven in the `/api/attach` `ChatResponse` path and documented the path-free `public_workbook_ref` boundary.

### R25 — Attachment Upload Response Boundary Controlled Functional Verification

R25 was accepted as the scoped functional verification checkpoint. R25 used the explicitly approved FastAPI TestClient `/api/attach` path with a tiny non-workbook text fixture and public response-body negative assertions.

R25 confirmed:

- `saved_path_public_exposure_found=false`;
- `raw_path_public_exposure_found=false`;
- `workbook_opened_by_jarvis_runtime=false`;
- `workbook_read_by_jarvis_runtime=false`;
- `workbook_written_by_jarvis_runtime=false`;
- `workbook_container_inspection=false`;
- `upload_to_workbook_read_bridge_executed=false`.

## Closure Criteria

R26 closes the attachment upload boundary phase because:

1. R21 inventory is accepted and carried forward.
2. R22 contract is accepted and carried forward.
3. R23 implementation plan is accepted and carried forward.
4. R24 static compliance lock is accepted and carried forward.
5. R25 controlled functional verification is accepted and carried forward.
6. The scoped public `/api/attach` response-body verification found no public `saved_path` exposure.
7. The scoped public `/api/attach` response-body verification found no raw path exposure.
8. No workbook open/read/write/container inspection occurred.
9. No upload-to-workbook-read bridge occurred.
10. Protected runtime/source files remain unchanged.

## Regression Risks

Future phases must guard against:

- accidentally returning `AttachmentMeta.model_dump()` publicly;
- exposing `saved_path` in `/api/attach` responses;
- adding raw path fields to `public_workbook_ref`;
- returning raw event request metadata from router responses;
- exposing raw event request metadata through `/api/events`;
- treating upload as permission for workbook read;
- passing uploaded files into workbook routes without explicit approval;
- changing route count or middleware count unintentionally;
- packaging temporary fixtures or runtime artifacts.

## Regression Guards

The following guards must remain active:

- `saved_path` remains internal-only;
- saved_path remains internal-only;
- public attachment/workbook references remain path-free;
- `public_workbook_ref` must omit raw path keys;
- `/api/events` must continue safe projection rather than raw request metadata;
- upload does not authorize workbook read;
- workbook access requires permission gate approval;
- additional functional upload verification requires separate approval;
- any future source patch requires separate PLAN / DRY RUN / FIRE.

## Protected Systems Not Touched

R26 does not modify:

- `jarvis_v5/app.py`;
- `jarvis_v5/core/attachment_store.py`;
- `jarvis_v5/schemas/message_schema.py`;
- `jarvis_v5/router/main_router.py`;
- `jarvis_v5/core/conversation_id_safety.py`;
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`;
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`;
- `requirements.txt`;
- registries;
- Builder/workbook/output/job files;
- route handlers;
- middleware behavior;
- auth runtime behavior;
- workbook permission runtime;
- workbook policy runtime;
- preview/export policy;
- active-task writing/report guards;
- UI/runtime modules;
- sidecar generator source.

## Backlog Quarantine

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for ideas only and cannot expand R26 scope, add files, change the target, promote OCR/document reader, promote file execution, promote workbook access, promote additional functional upload tests, or override checkpoint evidence.

## Closure Verdict

R26 is a closure/regression lock only. It completes the attachment upload boundary evidence phase after R25 controlled functional verification passed.

# Backend Runtime Readiness Roadmap

Version: v5.0.0-alpha.38.0  
Base: v5.0.0-alpha.37.15

## Current backend status
Jarvis is entering backend runtime readiness planning after alpha37 evidence closeout. This is not an implementation phase.

## Roadmap principles
- Metadata first.
- Contracts before execution.
- Permission before workbook access.
- Approval before execution.
- Preview before export.
- Evidence before runtime.

## What alpha37 proved
Alpha37 documented permission boundaries, metadata scope, manifest-only contracts, fixture evidence, inherited fixture policy, JSON/docs-only expected records, coverage review, and explicit safety flag evidence.

## What remains blocked
Workbook content read, formula read, cell value read, style read, named ranges, tables, merged cells, comments, VBA/macros, production/user workbook access, Builder/Formatter/QA/O&A/Document Reader/Output/Job runtime execution, route changes, and permission-gate changes remain blocked.

## Backend runtime readiness gates
Runtime work may begin only after separate PLAN, DRY RUN, FIRE, and REVIEW phases.

## Recommended next lane
alpha38.1 — Metadata Bridge Implementation Readiness Plan.

This is not implementation. It is the next readiness plan because it directly follows alpha37 metadata/permission evidence and is lower risk than touching Builder, Formatter, QA, O&A, Document Reader, Output, or Job runtime.

## Rollback policy
Rollback is v5.0.0-alpha.37.15 package replacement.

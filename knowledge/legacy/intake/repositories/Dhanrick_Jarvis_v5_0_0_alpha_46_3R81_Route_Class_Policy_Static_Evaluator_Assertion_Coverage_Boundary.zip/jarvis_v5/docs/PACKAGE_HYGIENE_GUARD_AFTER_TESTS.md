# Package Hygiene Guard After Tests

Final release staging must be cleaned after tests so generated runtime data is not included.

Required final package state:
- runtime_data_non_keep_files_final=0
- pycache_final=0
- pyc_final=0
- pytest_cache_final=0
- historical alpha35/alpha36 artifacts at root=0

This is a staging/package exclusion rule, not deletion from user source environments.


planning_only=true
wrapper_dry_run=true
implementation_created=false
runtime_called=false
route_behavior_changed=false
endpoint_added=false
workbook_opened=false
sheet_names_read=false
content_read=false
formula_read=false
cell_value_read=false
style_read=false
safe_path_resolver_called=false
builder_runtime_changed=false
workbook_runtime_changed=false
package_hygiene_guard_enabled=true
runtime_data_non_keep_files_final=0
pycache_final=0
pyc_final=0
pytest_cache_final=0


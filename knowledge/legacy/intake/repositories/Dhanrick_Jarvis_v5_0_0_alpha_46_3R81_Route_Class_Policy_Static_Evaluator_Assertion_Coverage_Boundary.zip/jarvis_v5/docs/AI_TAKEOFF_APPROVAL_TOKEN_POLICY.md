# AI Takeoff Approval Token Policy

Version: v5.0.0-alpha.39.6-batch
Base: v5.0.0-alpha.39.5-batch
Scope: metadata-only approval token policy.

## Purpose

Define the future approval token policy required before drawing-read, OCR, takeoff-engine, workbook-read, or quantity-writeback actions can ever execute in a later checkpoint. Alpha39.6 defines policy only and does not issue or validate tokens.

## Approval Token Policy Example

```json
{
  "approval_token_policy": "ai_takeoff_approval_token_policy_v1",
  "token_issued": false,
  "token_status": "schema_defined_not_issued",
  "token_required_for_future_drawing_read": true,
  "token_required_for_future_ocr": true,
  "token_required_for_future_takeoff_engine": true,
  "token_required_for_future_workbook_read": true,
  "token_required_for_future_quantity_writeback": true,
  "execution_enabled": false,
  "runtime_action_allowed": false
}
```

## Future Token Fields

- token_id
- permission_contract_id
- approved_action
- approved_scope
- approved_by_user
- created_at
- expires_at
- single_use
- revoked
- risk_disclosure_acknowledged

## Explicitly Blocked in Alpha39.6

- real token generation
- token persistence
- token validation runtime
- token-to-action execution
- background job creation
- runtime permission bridge
- approval_token_issued=true

## Policy Rule

A token schema is not a token. A documented future approval model does not authorize execution.


## Alpha39.6 Non-Execution Guarantees

- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- workbook_opened=false
- quantity_writeback=false
- approval_token_issued=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false
- jarvis_runtime_imported=false
- fastapi_testclient_used=false
- memory_imported=false
- protected_systems_touched=false

This document is metadata-only. It does not grant permission, issue approval tokens, add runtime routes, add endpoints, open workbooks, read drawings, call OCR, call a takeoff engine, or write quantities.

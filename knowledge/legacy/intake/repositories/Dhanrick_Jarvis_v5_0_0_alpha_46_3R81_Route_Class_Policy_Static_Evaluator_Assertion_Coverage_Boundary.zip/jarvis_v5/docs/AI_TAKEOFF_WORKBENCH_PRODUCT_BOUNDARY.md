# AI Takeoff Workbench Product Boundary

## What it may become

A QS-focused workspace where Jarvis helps with selected-context explanation, BOQ wording, QA checks, takeoff checklists, missing-context prompts, and eventually carefully approved takeoff assistance.

## What it is not yet

- Not a drawing reader.
- Not an OCR engine.
- Not a takeoff engine.
- Not a Cubit/CostX/PlanSwift clone.
- Not an automatic quantity generator.
- Not a production drawing editor.
- Not a workbook writer.
- Not a UI implementation phase.

## Product principle

Metadata first. Permission before drawing/workbook access. Preview before write/export. Human confirmation before quantity changes.

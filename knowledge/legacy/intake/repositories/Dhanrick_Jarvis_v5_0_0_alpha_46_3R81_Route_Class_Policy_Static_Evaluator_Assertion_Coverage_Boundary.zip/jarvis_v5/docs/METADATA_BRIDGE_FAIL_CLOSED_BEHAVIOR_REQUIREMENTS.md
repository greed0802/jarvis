# Metadata Bridge Fail-Closed Behavior Requirements

Version: v5.0.0-alpha.38.1

## Required fail-closed cases

- Unknown field requested.
- Blocked field requested.
- Missing approval.
- `approval=false`.
- Wrong `source_kind`.
- Missing `contract_type`.
- Wrong `contract_type`.
- Path-like input present.
- Raw workbook reference present.
- Production/user workbook path present.
- Requested scope expanded.
- Workbook access attempted.

## Expected blocked result

```text
decision=block
allowed=false
fail_closed=true
workbook_opened=false
workbook_container_inspected=false
contains_workbook_data=false
safe_ui_summary excludes forbidden data
```

## Rule

Fail closed must be the default for unknown, ambiguous, unauthorized, or path/workbook-related input.

# Roadmap After Alpha36.7

Accepted checkpoint before this plan: v5.0.0-alpha.36.7.

Recommended continuation:

```text
alpha36.8
Root Artifact + Runtime Data Hygiene Cleanup Plan

alpha36.9
Controlled Package Cleanup Dry Run

alpha37.0
Controlled Root Artifact Cleanup FIRE, if approved

alpha37.1
Unified Workbook Permission Gate Plan

alpha37.2
Unified Workbook Permission Gate Dry Run
```

Alternative if alpha36.8 review finds cleanup is low risk:

```text
alpha36.9
Root Artifact Cleanup FIRE directly, docs/reports/package only
```

Preferred route remains dry run before cleanup execution.

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

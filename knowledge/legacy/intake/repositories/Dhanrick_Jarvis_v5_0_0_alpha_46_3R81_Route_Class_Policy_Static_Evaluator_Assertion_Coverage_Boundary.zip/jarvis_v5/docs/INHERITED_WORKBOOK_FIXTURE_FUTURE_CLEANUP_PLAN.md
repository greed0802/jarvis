# Inherited Workbook Fixture Future Cleanup Plan

Version: v5.0.0-alpha.37.11.1

## Current decision
No cleanup in alpha37.11.1.

The inherited workbook fixtures are classified as do-not-delete-yet because current package evidence shows multiple test and test-pack references.

## Future decision tree

| Finding | Future action |
|---|---|
| Fixture used by accepted tests | Keep and document |
| Fixture used by JSON test packs | Keep or replace pack first |
| Fixture only referenced by docs/history | Mark cleanup candidate |
| Fixture referenced by QA runner only | Keep if QA packs require it |
| Fixture referenced by app/routes/core/registry | Stop and investigate |
| No active references remain | Cleanup candidate in separate FIRE |

## Cleanup gate
Any fixture deletion requires a separate explicit command, for example:

```text
PLAN alpha37.11.2 Fixture Cleanup Candidate Review
```

or a later approved FIRE phase.

## Safety rule
Do not delete Test.xlsx or SheetProbe.xlsx until all accepted tests and packs depending on them are replaced or retired.

# Isolated Metadata Adapter Fail Closed Tests

Future tests must prove fail-closed behavior for:
- unknown fields
- blocked workbook fields
- missing approval
- approved=false
- wrong source_kind
- wrong contract_type
- path-like value
- raw workbook_ref
- file-handle-like input
- workbook-object-like input
- production/user workbook path
- scope expansion attempted
- workbook access attempted

Expected blocked output:
decision=block
allowed=false
fail_closed=true
workbook_opened=false
workbook_container_inspected=false
contains_workbook_data=false
safe_ui_summary excludes forbidden values

These are future test requirements only. No runtime implementation occurs in alpha38.5.

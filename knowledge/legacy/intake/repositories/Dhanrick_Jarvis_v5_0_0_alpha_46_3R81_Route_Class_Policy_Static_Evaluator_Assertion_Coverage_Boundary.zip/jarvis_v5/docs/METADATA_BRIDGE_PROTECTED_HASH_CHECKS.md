# Metadata Bridge Protected Hash Checks

## Required protected checks before any future source patch
- jarvis_v5/app.py
- jarvis_v5/config.py
- jarvis_v5/registry/registry_loader.py
- permission-gate module, if identified
- owner-wrapper module, if identified
- Builder runtime files, if identified
- Formatter runtime files, if identified
- QA runtime files, if identified
- O&A runtime files, if identified
- Document Reader runtime files, if identified
- Output/Job runtime files, if identified

## Policy
Before patch: capture baseline hash. After patch: compare hash. Any unexpected protected hash change blocks acceptance.

## alpha38.2 boundary
alpha38.2 documents hash requirements only. It does not approve source edits.

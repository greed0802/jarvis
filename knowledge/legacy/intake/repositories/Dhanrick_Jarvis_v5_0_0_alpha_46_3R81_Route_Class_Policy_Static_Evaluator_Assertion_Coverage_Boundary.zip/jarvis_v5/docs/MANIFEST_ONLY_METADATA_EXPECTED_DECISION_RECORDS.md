# Manifest-only Metadata Expected Decision Records

Decision records must prove:
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- production_workbook_access=false
- safe_ui_summary suppresses forbidden fields

## Allowed manifest field record

```json
{
  "fixture_id": "A37_11_ALLOW_EXTENSION",
  "decision": "allow",
  "allowed": true,
  "reason_code": "manifest_field_allowed",
  "requested_scope": "manifest_metadata_only",
  "metadata_fields_requested": ["declared_extension"],
  "metadata_fields_allowed": ["declared_extension"],
  "metadata_fields_blocked": [],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "production_workbook_access": false,
  "fail_closed": false
}
```

## Blocked sheet_count record

```json
{
  "fixture_id": "A37_11_BLOCK_SHEET_COUNT",
  "decision": "block",
  "allowed": false,
  "reason_code": "field_requires_workbook_container_or_future_gate",
  "requested_scope": "manifest_metadata_only",
  "metadata_fields_requested": ["sheet_count"],
  "metadata_fields_allowed": [],
  "metadata_fields_blocked": ["sheet_count"],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "production_workbook_access": false,
  "fail_closed": true
}
```

## Blocked workbook-container metadata record

```json
{
  "fixture_id": "A37_11_BLOCK_WORKBOOK_CONTAINER",
  "decision": "block",
  "allowed": false,
  "reason_code": "workbook_container_metadata_blocked",
  "metadata_fields_blocked": ["workbook_container_metadata"],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "fail_closed": true
}
```

## Blocked workbook-internal data record

```json
{
  "fixture_id": "A37_11_BLOCK_FORMULAS",
  "decision": "block",
  "allowed": false,
  "reason_code": "workbook_internal_data_blocked",
  "metadata_fields_blocked": ["formulas"],
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "fail_closed": true
}
```

## Unknown-field fail-closed record

```json
{
  "fixture_id": "A37_11_FAIL_UNKNOWN_FIELD",
  "decision": "block",
  "allowed": false,
  "reason_code": "unknown_field_blocked",
  "metadata_fields_blocked": ["unknown_metadata_field"],
  "contains_workbook_data": false,
  "fail_closed": true
}
```

## Missing-approval fail-closed record

```json
{
  "fixture_id": "A37_11_FAIL_MISSING_APPROVAL",
  "decision": "block",
  "allowed": false,
  "reason_code": "missing_approval",
  "contains_workbook_data": false,
  "fail_closed": true
}
```

## Wrong-source fail-closed record

```json
{
  "fixture_id": "A37_11_FAIL_WRONG_SOURCE_KIND",
  "decision": "block",
  "allowed": false,
  "reason_code": "wrong_source_kind",
  "source_kind": "workbook_file",
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "fail_closed": true
}
```

## Path-redaction fail-closed record

```json
{
  "fixture_id": "A37_11_FAIL_PRODUCTION_PATH",
  "decision": "block",
  "allowed": false,
  "reason_code": "forbidden_path_like_input",
  "redaction_required": true,
  "safe_ui_summary": {},
  "forbidden_fields_suppressed": [
    "saved_path",
    "absolute_path",
    "private_attachment_path",
    "raw_workbook_ref"
  ],
  "fail_closed": true
}
```

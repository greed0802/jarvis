# Permission Gate Call Path Inventory

```json
{
  "route": "POST /api/builder/workbook-sheet-name-probe-approval",
  "route_handler": "api_builder_workbook_sheet_name_probe_approval()",
  "owner": "evaluate_workbook_sheet_name_probe_approval()",
  "permission_gate": "evaluate_workbook_permission_gate()",
  "app_direct_permission_gate_call": false,
  "owner_imports_permission_gate": true,
  "owner_calls_permission_gate": true,
  "permission_gate_line": 156,
  "safe_attachment_line": 215,
  "load_workbook_line": 223
}
```

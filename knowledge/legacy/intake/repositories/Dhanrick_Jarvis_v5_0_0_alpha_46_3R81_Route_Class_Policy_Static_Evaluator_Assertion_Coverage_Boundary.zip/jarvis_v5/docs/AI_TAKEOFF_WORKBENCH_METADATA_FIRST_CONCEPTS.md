# AI Takeoff Workbench Metadata-First Concepts

Version: v5.0.0-alpha.39.0  
Base: v5.0.0-alpha.38.9  
Mode: docs/tests/evidence only


## Metadata-first concept fields

- project_id
- plan_id
- plan_name
- drawing_revision
- selected_trade
- selected_item_id
- selected_item_description
- selected_level
- selected_unit
- selected_quantity_summary
- selected_measurement_type
- viewport_page_number
- scale_declared
- takeoff_context_id

## Safe early assistance

Jarvis may later explain selected metadata, summarize selected quantity metadata, suggest QA checks, draft BOQ wording, identify missing context, and prepare takeoff checklists.

## Blocked early actions

Automatic takeoff, drawing content reads, dimension inference from image, quantity writeback, plan/takeoff data modification, workbook export, or protected runtime calls.

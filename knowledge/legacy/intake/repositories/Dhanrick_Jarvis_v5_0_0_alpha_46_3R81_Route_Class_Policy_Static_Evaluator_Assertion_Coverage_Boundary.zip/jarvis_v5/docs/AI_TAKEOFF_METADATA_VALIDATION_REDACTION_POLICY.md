# AI Takeoff Metadata Validation and Redaction Policy

## Purpose
Define validation and redaction rules for selected plan/item/context metadata.

## Validation policy
- Unknown fields fail closed.
- Missing required identity fields fail closed or require clarification.
- Wrong context type fails closed.
- Path-like values are blocked or redacted.
- Workbook-like references are blocked.
- Drawing-like references are blocked.
- OCR/CAD/PDF/internal-data fields are blocked.
- Quantity writeback requests are blocked.

## Safe UI summary policy
Safe UI summaries may include only declared metadata fields that are allowed by the metadata model. Safe UI summaries must not include private paths, raw workbook references, raw drawing references, cell values, formulas, styles, OCR text, CAD geometry, PDF internals, or runtime internals.

## Redaction policy
Redact or block:
- absolute paths
- private attachment paths
- raw drawing paths
- raw workbook paths
- raw workbook_ref values
- file handles
- traceback content
- runtime internals

## Fail-closed policy
If validation cannot confidently classify a field as allowed metadata, the field is blocked.

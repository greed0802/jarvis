# v5.0.0-alpha.46.3R40 — Dependency Pinning / openpyxl Evidence Inventory

**Base:** `v5.0.0-alpha.46.3R39`  
**Target:** `Dependency Pinning / openpyxl Evidence Inventory`  
**Mode:** FIRE / evidence inventory  
**Scope:** no-source-change dependency pinning and openpyxl evidence inventory only

## Purpose

R40 inventories the current dependency-pinning state of Jarvis, with emphasis on `openpyxl` and workbook-related dependency readiness. This phase documents the current static `requirements.txt` state, whether `openpyxl` is present and pinned, workbook-related dependency risk classes, future pinning policy direction, and approval gates before any `requirements.txt` change.

R40 does not modify `requirements.txt`, install dependencies, import `openpyxl`, enable workbook runtime behavior, import `app.py`, use FastAPI TestClient, call API routes, execute workbook open/read/write, inspect workbook containers, execute Output Center export, execute Job Center behavior, execute OCR/document reader/tool behavior, or patch sidecar generator source.

## Current accepted checkpoint

- Current accepted checkpoint: `v5.0.0-alpha.46.3R39` — Rate Limit Boundary Static Compliance Lock.
- R39 accepted package file count: 1,964.
- R39 static smoke: 6 passed.
- R39 verification: 135 passed / 0 failed.
- R39 locked no rate-limit implementation, no dependency change, route count 43, and middleware count 1.

## Current requirements.txt evidence

Static evidence source:

- `requirements.txt`

Static classification:

```json
{
  "requirements_txt_sha256": "a7cdfba90512a58a19d3686ef20f9b5b5ac8c8a155f0bde3e31b1bcb4851922c",
  "requirements_txt_line_count": 5,
  "openpyxl_present": false,
  "openpyxl_pinned": false,
  "openpyxl_requirement_line": null,
  "dependency_pattern_counts": {
    "openpyxl": 0,
    "pandas": 0,
    "xlsxwriter": 0,
    "xlrd": 0,
    "xlwt": 0,
    "pyxlsb": 0,
    "excel": 0,
    "xlsx": 0,
    "xlsm": 0,
    "requirements": 0,
    "dependency": 0,
    "dependencies": 0,
    "pin": 0,
    "pinned": 0,
    "unpinned": 0,
    "version": 0
  }
}
```

R40 classification:

- `openpyxl_present=false`
- `openpyxl_pinned=false`
- `requirements_txt_changed=false`
- `dependency_installed=false`
- `dependency_changed=false`
- `openpyxl_imported=false`
- `openpyxl_runtime_used=false`
- `workbook_runtime_enabled=false`

## Static evidence candidates

R40 evidence inventory considered these static evidence candidates only:

- `requirements.txt`
- accepted source-of-truth manifests
- existing documentation references for dependency, requirements, workbook, Excel, xlsx, xlsm, and pinning policy

No package manager command was executed. No dependency installation was attempted.

## openpyxl and workbook dependency risk classes

1. Missing `openpyxl` can block future controlled workbook gates.
2. Unpinned `openpyxl` can create non-deterministic workbook behavior.
3. Version drift can affect formula preservation, cell styles, merged cells, sheet visibility, and workbook metadata.
4. Dependency installation can change environment behavior outside source diff.
5. Workbook parsing libraries can accidentally enable workbook reads before permission contracts.
6. Workbook writes can bypass preview/export policy if not gated.
7. `xlsx` / `xlsm` handling can trigger macro/security assumptions.
8. Formula handling must not evaluate formulas unless explicitly approved.
9. Dependency changes must not unlock Builder/workbook runtime.
10. Future workbook dependency use must remain permission-first and approval-first.

## Dependency pinning guard facts

R40 locks:

- no `requirements.txt` modification;
- no dependency installation;
- no `openpyxl` import;
- no dependency resolver change;
- no dependency loader change;
- no package manager lockfile change;
- no runtime dependency check added;
- no workbook dependency enabled;
- future `requirements.txt` modification requires separate PLAN / DRY RUN / FIRE / REVIEW.

Future contract direction:

```json
{
  "requirements_txt_change_allowed": false,
  "dependency_install_allowed": false,
  "openpyxl_import_allowed": false,
  "openpyxl_runtime_use_allowed": false,
  "future_dependency_pinning_requires_approval": true,
  "future_openpyxl_pin_requires_separate_fire": true,
  "workbook_runtime_enablement_allowed": false
}
```

## Workbook boundary guard facts

R40 preserves:

- no workbook execution;
- no workbook open/read/write through Jarvis runtime;
- no workbook-container inspection;
- no formula evaluation;
- no workbook export;
- no Builder formula/export behavior change;
- no workbook permission runtime change;
- no preview/export policy change;
- no safe path resolver change;
- no attachment-store behavior change.

Future `openpyxl` pinning must not imply workbook reads are allowed, workbook writes are allowed, formula evaluation is allowed, Builder execution is allowed, or Output Center export is allowed.

## Evidence facts locked

- `dependency_pinning_openpyxl_evidence_inventory_only=true`
- `selected_after_r39_rate_limit_static_compliance=true`
- `source_behavior_changed=false`
- `runtime_behavior_changed=false`
- `requirements_txt_changed=false`
- `dependency_changed=false`
- `dependency_installed=false`
- `openpyxl_present=false`
- `openpyxl_pinned=false`
- `openpyxl_imported=false`
- `openpyxl_runtime_used=false`
- `workbook_runtime_enabled=false`
- `workbook_open_read_write=false`
- `workbook_container_inspected=false`
- `builder_execution_enabled=false`
- `output_center_export_executed=false`
- `job_center_execution=false`
- `route_count=43`
- `route_delta=0`
- `middleware_count=1`
- `runtime_imported=false`
- `app_imported=false`
- `fastapi_testclient_used=false`
- `api_route_calls=false`

## Future work boundary

R40 does not pin dependencies. A future dependency pin, including an `openpyxl` pin, requires a separate PLAN / DRY RUN / FIRE / REVIEW sequence. Any future workbook runtime use remains blocked until explicit permission, approval, preview/export, and workbook boundary contracts exist.

## Protected systems not touched

- `requirements.txt`
- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- schemas and registries
- auth runtime boundary
- exception envelope boundary
- CORS boundary
- rate-limit boundary
- attachment upload boundary
- Output Center runtime
- Job Center runtime
- workbook permission runtime
- workbook policy runtime
- Builder formula/export engine
- sidecar generator source
- UI/runtime modules

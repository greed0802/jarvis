# v5.0.0-alpha.46.3R36 — CORS Boundary Evidence Inventory

**Base:** `v5.0.0-alpha.46.3R35R1`  
**Target:** `CORS Boundary Evidence Inventory`  
**Mode:** FIRE / evidence inventory  
**Scope:** no-source-change CORS boundary inventory only

## Purpose

R36 inventories the current CORS boundary as static evidence only. It documents CORS-related exposure risks, current static footprint, expected future allowed-origin contract direction, blocked-by-default rules, environment/config requirements, route/middleware risks, and cross-origin restrictions for upload, Output Center, and Job Center surfaces.

R36 does not implement CORS, change middleware behavior, change dependencies, import `app.py`, call routes, or run FastAPI TestClient.

## Current accepted checkpoint

- Current accepted checkpoint: `v5.0.0-alpha.46.3R35R1` — Job Center Boundary Static Compliance Lock Reissue.
- R35R1 accepted package file count: 1,952.
- R35R1 locked Job Center non-execution, Output Center non-execution, workbook/tool/OCR/document non-execution, route count 43, route delta 0, and middleware count 1.

## Current CORS static footprint

Static scan of `jarvis_v5/app.py` found:

- `CORSMiddleware` occurrences: 0
- `allow_origins` occurrences: 0
- `allow_credentials` occurrences: 0
- `allow_methods` occurrences: 0
- `allow_headers` occurrences: 0
- `Access-Control-Allow-Origin` occurrences: 0
- `add_middleware` occurrences: 0
- static route decorators: 43
- static middleware decorators: 1

This is evidence-only. It does not prove deployed behavior and does not change runtime behavior.

## CORS risk classes inventoried

1. Wildcard origin exposure such as `allow_origins=["*"]`.
2. Credentials enabled with broad origins.
3. Overbroad allowed methods.
4. Overbroad allowed headers.
5. Missing environment-specific origin contract.
6. Development origins leaking into production.
7. Localhost-only policy not documented.
8. Middleware order accidentally changing auth or exception behavior.
9. Preflight exposing unintended endpoints.
10. CORS policy bypassing API-key expectations.
11. Private, admin, or debug routes exposed cross-origin.
12. Future frontend origins added without approval.
13. Raw path or artifact download routes exposed cross-origin.
14. Upload routes exposed cross-origin without upload boundary constraints.
15. Output Center or Job Center routes exposed before execution gates exist.

## Static evidence candidates

R36 inventories only static text evidence candidates:

- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- `requirements.txt`
- docs mentioning CORS, middleware, origin policy, or cross-origin behavior
- source-of-truth manifests

Search terms include `CORSMiddleware`, `allow_origins`, `allow_credentials`, `allow_methods`, `allow_headers`, `Access-Control-Allow-Origin`, `CORS`, `cors`, `middleware`, and `add_middleware`.

## Expected future allowed-origin policy direction

Future CORS policy should be blocked by default until an explicit contract exists. A future contract should require:

- declared environment-specific origins;
- no wildcard origin in production;
- no credentials with wildcard origins;
- development origins allowed only in development mode;
- production origins requiring explicit approval;
- upload routes requiring upload boundary constraints before cross-origin exposure;
- Output Center routes requiring output/export boundary approval before cross-origin exposure;
- Job Center routes requiring Job Center boundary approval before cross-origin exposure;
- auth boundary preservation for protected routes.

## Blocked-by-default future CORS rules

- No CORS middleware addition without separate PLAN / DRY RUN / FIRE.
- No allowed-origin change without explicit contract.
- No credentials enablement without explicit contract.
- No allowed-method/header expansion without explicit contract.
- No upload/output/job cross-origin exposure without the corresponding boundary contract.
- No route or middleware order change as part of evidence inventory.

## Environment and config requirements

A future CORS contract should specify:

- development origins;
- production origins;
- preview/staging origins;
- forbidden origins;
- credential behavior;
- allowed methods and headers;
- route groups subject to cross-origin access;
- origin approval source;
- rollback behavior.

R36 only inventories these requirements. It does not implement them.

## Route and middleware risks

- Route count remains 43.
- Route delta remains 0.
- Middleware count remains 1.
- No CORS middleware added.
- No CORS middleware removed.
- No middleware order changed.
- No auth middleware bypass allowed.
- No exception envelope bypass allowed.

## Auth boundary preservation

Future CORS behavior must not weaken API-key middleware, auth classification, debug/dev route guard expectations, upload boundary constraints, Output Center export gates, Job Center execution gates, or workbook/tool/document/OCR permission contracts.

## Upload, Output Center, and Job Center cross-origin restrictions

- Upload cross-origin exposure requires upload boundary compliance and explicit approval.
- Output Center cross-origin exposure requires preview-before-export and export approval contracts.
- Job Center cross-origin exposure requires Job Center execution approval and metadata redaction contracts.
- Raw path, local path, saved path, and download path exposure remain blocked.

## No behavior change facts

- `source_behavior_changed=false`
- `runtime_behavior_changed=false`
- `cors_policy_changed=false`
- `cors_middleware_added=false`
- `cors_middleware_removed=false`
- `middleware_order_changed=false`
- `requirements_txt_changed=false`
- `dependency_changed=false`
- `runtime_imported=false`
- `app_imported=false`
- `fastapi_testclient_used=false`
- `api_route_calls=false`

## Protected systems not touched

- `jarvis_v5/app.py`
- `jarvis_v5/router/main_router.py`
- schemas and registries
- auth runtime boundary
- global exception envelope
- upload boundary
- Output Center runtime
- Job Center runtime
- workbook permission runtime
- Builder formula/export engine
- preview/export policy
- active-task writing/report guards
- sidecar generator source
- `requirements.txt`

## Future work boundary

R36 does not implement CORS. Future CORS policy implementation requires a separate PLAN / DRY RUN / FIRE cycle.

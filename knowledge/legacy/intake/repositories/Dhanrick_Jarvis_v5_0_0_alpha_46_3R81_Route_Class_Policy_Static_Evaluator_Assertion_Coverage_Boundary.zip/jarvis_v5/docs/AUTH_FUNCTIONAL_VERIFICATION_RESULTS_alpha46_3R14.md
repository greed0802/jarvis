# Auth Functional Verification Results — alpha46.3R14

**Version:** v5.0.0-alpha.46.3R14  
**Base:** v5.0.0-alpha.46.3R13  
**Mode:** Controlled auth-only functional verification  
**Runtime behavior changed:** false  
**app.py changed:** false

## Purpose

R14 performs the first controlled runtime/TestClient verification of the R12 API-key boundary under the R13 permission contract. The verification is auth-only. It does not assert business success for protected routes and does not execute workbook, Builder, tool, Output Center, or Job Center behavior.

## Approved Runtime Scope

The R14 functional smoke test may:

- set `JARVIS_API_KEY` only inside pytest `monkeypatch`
- import `jarvis_v5.app` only after temporary environment setup
- create a FastAPI `TestClient` only inside `test_alpha46_3R14_auth_api_key_functional.py`
- call only the approved route matrix

## Approved Route Matrix

| Case | Route | Header | Expected auth assertion |
|---|---|---|---|
| Public route | `GET /api/version` | none | not `401 auth_required` |
| Missing key | `GET /api/events/test-conversation` | none | safe `401 auth_required` envelope |
| Invalid key | `GET /api/events/test-conversation` | `X-Jarvis-API-Key: invalid-test-key` | safe `401 auth_required` envelope |
| Valid header key | `GET /api/events/test-conversation` | `X-Jarvis-API-Key: accepted-test-key` | not `401 auth_required` |
| Valid Bearer key | `GET /api/events/test-conversation` | `Authorization: Bearer accepted-test-key` | not `401 auth_required` |
| Unknown route | `GET /api/not-a-real-route` | none | normal `404`, not auth envelope |
| Debug route | `GET /api/debug/pending-clarification/test-conversation` | none | not intercepted by auth boundary; governed by R7 DEBUG_MODE guard |

## Safe Auth Envelope Verified

For missing and invalid keys, the test requires:

```json
{
  "ok": false,
  "error": "auth_required",
  "auth_required": true,
  "authenticated": false,
  "execution_enabled": false,
  "workbook_read": false,
  "workbook_content_read": false,
  "tool_execution_performed": false,
  "engine_called": false,
  "excel_created": false,
  "contract_only": true
}
```

The test also confirms that the response does not expose the accepted test key, invalid test key, `JARVIS_API_KEY`, `X-Jarvis-API-Key`, `Authorization`, or `Bearer`.

## Forbidden Assertions

R14 does not assert:

- `status_code = 200` for valid-key protected routes
- event business payload correctness
- state correctness
- workbook behavior
- tool behavior
- Output Center behavior
- Job Center behavior

## Forbidden Actions

R14 does not perform:

- workbook read or execution
- workbook content read
- Builder execution
- Formatter execution
- QA Checker execution
- real Jarvis tool execution
- Output Center export
- Job Center execution
- OCR
- drawing/PDF/image read
- document read
- dependency change
- registry change
- route change

## Test Command

```text
PYTHONDONTWRITEBYTECODE=1 python -m pytest -q jarvis_v5/tests/smoke/test_alpha46_3R14_auth_api_key_functional.py -p no:cacheprovider
```

## Result

Functional smoke test result: `7 passed` using the approved TestClient route matrix. No business-success assertions were made for valid-key protected routes.

## Protected Systems

R14 leaves protected systems unchanged:

- `jarvis_v5/app.py`
- route decorators / paths / methods / handlers
- Builder formula/export engine
- workbook policy runtime
- preview policy
- active-task guards
- safe path resolver runtime
- Output Center runtime
- Job Center runtime
- `requirements.txt`
- registries
- CORS
- rate limiting
- EventLedger storage
- MainRouter routing
- AttachmentMeta
- AttachmentStore

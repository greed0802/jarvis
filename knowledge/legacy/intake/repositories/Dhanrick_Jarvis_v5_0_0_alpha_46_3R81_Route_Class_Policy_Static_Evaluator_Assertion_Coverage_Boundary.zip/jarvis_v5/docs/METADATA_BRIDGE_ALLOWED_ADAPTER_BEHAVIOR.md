# Metadata Bridge Allowed Adapter Behavior


Version: v5.0.0-alpha.38.3
Base version: v5.0.0-alpha.38.2
Target: Metadata Bridge Minimal Source Patch Plan
Mode: docs/tests/evidence only

Runtime behavior changed: false
Source behavior changed: false
Route behavior changed: false
Endpoint added: false
Workbook opened: false
Workbook container inspected: false
Workbook content read: false
Formula read: false
Cell value read: false
Style read: false
Permission gate changed: false
Owner wrapper changed: false
Builder runtime changed: false
Formatter runtime changed: false
QA runtime changed: false
O&A runtime changed: false
Document Reader runtime changed: false
Output Center runtime changed: false
Job runtime changed: false
Production/user workbook access: false
Synthetic workbook files: false
Fixture deletion: false
Fixture execution engine: false


## Allowed future adapter behavior

A future isolated manifest-only metadata adapter may:

- accept attachment manifest dict
- accept approval/permission context dict
- accept requested metadata fields list
- validate source_kind
- validate contract_type
- validate explicit approval
- allow only manifest-safe fields
- block unknown fields
- block workbook-container/content fields
- return safe decision/result dict
- return safe UI summary only
- set safety flags false

## Allowed manifest-only fields

- attachment_id_present
- contract_id_present
- declared_extension
- declared_mime_type
- declared_file_size_bytes
- manifest_created_at
- manifest_modified_at
- sanitized_filename_display
- accepted_sheet_name_probe_result_id_present

## Adapter boundary

The adapter must not open a workbook, inspect a workbook container, read workbook data, expose raw paths, or call protected runtime systems.

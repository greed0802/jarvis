# Output and Temporary File Naming Policy

User-facing output filenames should be short and readable while full metadata remains in JSON/debug metadata.

Preferred examples:

```text
Builder_WallTypes_1417.xlsx
Formatter_WallTypes_1420.xlsx
QA_WallTypes_1425.xlsx
TEMP_FormatHandoff_WallTypes_1418.xlsx
```

Rules:

- Use compact `Tool_Source_HHMM` pattern where practical.
- Avoid stuffing conversation_id, original workbook path, profile, or debug metadata into filenames.
- Temporary files must include `TEMP`.
- Temporary metadata must include `temporary=true`.
- Preserve source workbook and final outputs unless user confirms deletion.

Alpha36.8 documents naming policy only.

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

# Inherited Workbook Fixture Dependency Inventory Plan

Version: v5.0.0-alpha.37.11.1  
Base: v5.0.0-alpha.37.11

## Inventory targets
- Test.xlsx
- SheetProbe.xlsx
- tests/fixtures
- jarvis_v5/tests/fixtures

## Method
The inventory is text/code reference inspection only. It does not open workbook files and does not execute routes or QA packs.

Recommended evidence-only scan:

```bash
grep -RIn --exclude='*.xlsx' --exclude='*.xlsm' --exclude='*.xls' \
  "Test.xlsx\|SheetProbe.xlsx\|tests/fixtures\|jarvis_v5/tests/fixtures" .
```

## Confirmed inherited workbook fixtures
- jarvis_v5/tests/fixtures/SheetProbe.xlsx
- jarvis_v5/tests/fixtures/Test.xlsx

## Confirmed reference categories from alpha37.11.1 scan
- tests references: 51 files
- docs/history references: 38 files
- reports references: 3 files
- qa_runner references: 1 file
- app.py protected runtime references: 0 files
- routes protected runtime references: 0 files
- core protected runtime references: 0 files
- registry protected runtime references: 0 files

## Required inventory output fields
- file path
- matched target
- reference context
- classification
- risk level
- recommended action

## Required rule
No fixture deletion is allowed in alpha37.11.1. Cleanup requires a separate approved phase.

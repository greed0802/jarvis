# AI Takeoff Workbench Blocked Actions

The following are blocked until separately planned, dry-run, approved, fired, and reviewed:

- Drawing read.
- PDF/image/CAD parsing.
- OCR.
- Automatic measurement.
- Takeoff engine.
- Quantity writeback.
- Workbook writeback.
- UI implementation.
- Route integration.
- Endpoint creation.
- Builder runtime calls.
- Formatter runtime calls.
- QA runtime calls.
- O&A runtime calls.
- Document Reader runtime calls.
- Output/Job runtime calls.
- Production/user project access.
- Synthetic workbook/drawing fixture creation.

# Jarvis Local Evidence Runner Plan

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch  
Scope: metadata plan only; no script implementation.

## Purpose

Plan a future local evidence runner that can generate repeatable evidence before ChatGPT REVIEW. The runner is planned but not implemented in alpha39.8.

## Future Tool Name

`tools/jarvis_evidence_runner.py`

## Allowed Future Behavior

- Run `python -m compileall -q jarvis_v5`.
- Run selected metadata-only smoke tests.
- Scan execution flags.
- Scan route decorators.
- Scan forbidden enablement strings with context classification.
- Compare protected file hashes.
- Compare base-vs-target file lists.
- Generate package hygiene reports.
- Generate SHA256 reports.
- Write evidence summary JSON and Markdown.

## Prohibited Future Behavior Unless Explicitly Approved

- No app import by default.
- No FastAPI TestClient by default.
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No runtime route execution.
- No source mutation.
- No local script execution in alpha39.8.

## Evidence Runner Levels

| Level | Name | Allowed | Blocked |
|---|---|---|---|
| 0 | Inventory only | file diff, package hygiene, SHA256 | test execution, runtime import |
| 1 | Static smoke | compileall, metadata-only smoke tests | app import, TestClient |
| 2 | Runtime route tests | future explicit approval only | default blocked |
| 3 | Workbook/drawing/takeoff tests | future permission/runtime contract only | default blocked |



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

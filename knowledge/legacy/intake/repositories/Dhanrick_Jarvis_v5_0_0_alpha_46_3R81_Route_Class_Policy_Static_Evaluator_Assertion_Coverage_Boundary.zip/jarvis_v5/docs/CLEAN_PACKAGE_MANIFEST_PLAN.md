# Clean Package Manifest Plan

Future manifests:

- MANIFEST_CURRENT_RELEASE.md
- MANIFEST_VERSION_HISTORY.md
- MANIFEST_RUNTIME_DATA_EXCLUSIONS.md
- MANIFEST_PACKAGE_HYGIENE.md

Purpose:

Make every release package auditable without opening old random root reports.

Manifest policy:

- Current release manifest lists current version docs, tests, reports, package file, and handoff.
- Version history manifest lists archived alpha evidence.
- Runtime data exclusions manifest lists paths intentionally excluded from release ZIP.
- Package hygiene manifest records root artifact scan and runtime data residue scan.

Alpha36.8 does not create the final cleanup manifests; it defines the plan.

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

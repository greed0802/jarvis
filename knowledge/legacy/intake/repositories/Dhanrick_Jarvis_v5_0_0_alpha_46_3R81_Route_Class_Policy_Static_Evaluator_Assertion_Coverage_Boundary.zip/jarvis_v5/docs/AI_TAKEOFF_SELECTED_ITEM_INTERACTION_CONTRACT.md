# AI Takeoff Selected Takeoff Item Interaction Contract

Version: v5.0.0-alpha.39.5-batch
Base: v5.0.0-alpha.39.4-accelerated-playbook
Scope: metadata-only interaction contract.

## Purpose
This document defines what Jarvis side-chat may know when a user selects a takeoff item in the future AI Takeoff Workbench. The selected item is an intent metadata object, not a measured result.

## Allowed selected-takeoff-item metadata
```json
{
  "selected_takeoff_item_id": "item_meta_001",
  "item_label": "External Wall Type A",
  "trade": "wall finishes",
  "measurement_unit": "m2",
  "measurement_basis": "area",
  "classification": "planned_takeoff_item",
  "quantity_value": null,
  "quantity_source": "not_measured",
  "takeoff_engine_called": false,
  "quantity_writeback_allowed": false
}
```

## Allowed item fields
- item label
- trade/category
- intended unit
- measurement basis
- status metadata
- user-entered notes
- safe classification

## Blocked item fields
- drawing-derived quantity
- geometry-derived quantity
- workbook-derived quantity
- formula-derived quantity
- unverified measurement result
- raw coordinates
- engine output
- hidden item data
- quantity writeback target

## Manual quantity future allowance
A user-entered quantity may be allowed in a later contract only if explicitly marked quantity_source=user_provided, drawing_derived=false, workbook_derived=false, and takeoff_engine_called=false. Alpha39.5 keeps quantity_value null by default.


Safety flags required for this contract:
- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- quantity_writeback=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false

Explicit exclusions:
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No quantity writeback.
- No UI implementation.
- No route or endpoint addition.
- No Jarvis runtime import.
- No FastAPI TestClient.


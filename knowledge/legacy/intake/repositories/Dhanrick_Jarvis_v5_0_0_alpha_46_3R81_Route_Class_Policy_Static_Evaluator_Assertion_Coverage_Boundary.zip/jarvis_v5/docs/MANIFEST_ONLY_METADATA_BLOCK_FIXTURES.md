# Manifest-only Metadata Block Fixtures

Blocked fixtures include workbook-container and workbook-internal requests.

| Fixture ID | Requested field | Expected decision |
|---|---|---|
| A37_11_BLOCK_SHEET_COUNT | sheet_count | block |
| A37_11_BLOCK_WORKBOOK_PROPERTIES | workbook_properties_from_file | block |
| A37_11_BLOCK_WORKBOOK_CONTAINER | workbook_container_metadata | block |
| A37_11_BLOCK_WORKSHEET_DIMENSIONS | worksheet_dimensions | block |
| A37_11_BLOCK_CELL_VALUES | cell_values | block |
| A37_11_BLOCK_FORMULAS | formulas | block |
| A37_11_BLOCK_CACHED_VALUES | cached_formula_values | block |
| A37_11_BLOCK_STYLES | styles | block |
| A37_11_BLOCK_NAMED_RANGES | named_ranges | block |
| A37_11_BLOCK_TABLES | tables | block |
| A37_11_BLOCK_MERGED_CELLS | merged_cells | block |
| A37_11_BLOCK_COMMENTS | comments | block |
| A37_11_BLOCK_VBA | vba_macros | block |
| A37_11_BLOCK_EXTERNAL_LINKS | external_links | block |
| A37_11_BLOCK_HIDDEN_SHEETS | hidden_sheets | block |
| A37_11_BLOCK_SHEET_VISIBILITY | sheet_visibility | block |

## Required policy
sheet_count remains blocked/future gated because it may require workbook-container inspection.

## Expected block record shape

```json
{
  "decision": "block",
  "allowed": false,
  "fail_closed": true,
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "metadata_fields_allowed": [],
  "safe_ui_summary": {}
}
```

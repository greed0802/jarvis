# Metadata Bridge Adapter Input Output Contract

Version: v5.0.0-alpha.38.4

## Future adapter input contract

```text
attachment_manifest: dict
permission_context: dict
requested_fields: list[str]
```

## Required input constraints

- `attachment_manifest` must be manifest-only.
- `permission_context` must include `source_kind`, `contract_type`, and approval state.
- `requested_fields` must be compared against a strict allowlist.
- No workbook object may be accepted.
- No file handle may be accepted.
- No workbook path may be accepted.
- No path-like value may be required.

## Future adapter output contract

```text
decision
allowed
reason_code
source_kind
contract_type
requested_fields
allowed_fields
blocked_fields
fail_closed
safe_ui_summary
safety_flags
contains_workbook_data=false
workbook_opened=false
workbook_container_inspected=false
production_workbook_access=false
```

## Allowed manifest-only fields

```text
attachment_id_present
contract_id_present
declared_extension
declared_mime_type
declared_file_size_bytes
manifest_created_at
manifest_modified_at
sanitized_filename_display
accepted_sheet_name_probe_result_id_present
```

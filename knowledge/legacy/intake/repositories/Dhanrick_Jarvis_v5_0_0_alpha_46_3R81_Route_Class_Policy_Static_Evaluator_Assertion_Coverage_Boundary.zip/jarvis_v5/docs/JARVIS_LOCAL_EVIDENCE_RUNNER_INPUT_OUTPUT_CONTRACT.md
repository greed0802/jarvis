# Jarvis Local Evidence Runner Input / Output Contract — alpha39.9

Target: v5.0.0-alpha.39.9-batch  
Status: contract only. No local script exists or executes in this checkpoint.

## Allowed Future Inputs

The future evidence runner may accept:

```text
--base-zip path/to/base.zip
--target-zip path/to/target.zip
--base-dir path/to/base_tree
--target-dir path/to/target_tree
--output-dir reports/current
--mode static
--allowed-added-files approved_added_files.txt
--protected-files protected_files.txt
```

## Allowed Text File Types

The future runner may read these text formats for static scans:

```text
.py
.md
.json
.txt
.yaml
.yml
.toml
```

## Allowed Archive Inspection

ZIP inspection is limited to:

- ZIP entry list
- ZIP entry count
- ZIP entry names
- ZIP entry sizes
- ZIP integrity
- package SHA256

The script may list workbook, PDF, image, and drawing filenames if they appear in a package. It must not open, parse, preview, OCR, or infer content from those files.

## Forbidden Inputs

The future runner must not accept or use:

- live workbook file for content inspection
- drawing/PDF/image for content inspection
- OCR payload
- runtime API URL
- FastAPI app object
- database connection
- external tool credentials
- approval token secret
- production local paths containing secrets

## Forbidden Actions

The future runner must not perform:

- Path.resolve on workbook/drawing payload paths as permission proof
- Path.exists on workbook/drawing payload paths as access proof
- openpyxl.load_workbook
- pandas.read_excel
- PDF parsing
- image loading
- OCR
- network calls
- subprocess runtime execution
- local AI/model calls
- route calls
- endpoint calls
- Builder engine calls
- Formatter calls
- QA/O&A calls

The runner may use pathlib for its own output/report paths only.

## Planned Output Manifests

```text
MANIFEST_CHANGED_FILES.json
MANIFEST_CHANGED_FILES.md
MANIFEST_PACKAGE_HYGIENE.json
MANIFEST_PACKAGE_HYGIENE.md
MANIFEST_PROTECTED_HASH_COMPARE.json
MANIFEST_PROTECTED_HASH_COMPARE.md
MANIFEST_SAFETY_FLAGS.json
MANIFEST_SAFETY_FLAGS.md
MANIFEST_ROUTE_SCAN.json
MANIFEST_ROUTE_SCAN.md
MANIFEST_SHA256.json
MANIFEST_SHA256.md
MANIFEST_EVIDENCE_RUNNER_SUMMARY.json
MANIFEST_EVIDENCE_RUNNER_REPORT.md
```

## Minimum Summary Fields

```json
{
  "base_version": "v5.0.0-alpha.39.8-batch",
  "target_version": "v5.0.0-alpha.39.9-batch",
  "runtime_imported": false,
  "fastapi_testclient_used": false,
  "workbook_opened": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "route_added": false,
  "endpoint_added": false,
  "source_modified_by_runner": false
}
```

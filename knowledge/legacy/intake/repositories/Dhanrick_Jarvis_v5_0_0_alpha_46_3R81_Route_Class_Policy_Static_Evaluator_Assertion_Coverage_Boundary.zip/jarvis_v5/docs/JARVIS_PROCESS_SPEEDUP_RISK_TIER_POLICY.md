# Jarvis Process Speed-Up Risk Tier Policy

## Goal

Speed up Jarvis development without reducing confidence.

## Tier 0 — docs/tests/evidence only

Examples: roadmap notes, scope docs, decision matrices, JSON test packs.

Recommended flow: PLAN -> FIRE -> REVIEW.  
DRY RUN may be skipped when file list and scope are already clear.

## Tier 1 — isolated helper source, no runtime wiring

Examples: deterministic helper module with no route/runtime integration.

Recommended flow: combined PLAN/DRY RUN -> FIRE -> REVIEW.

## Tier 2 — route/API integration

Examples: endpoint, route registration, permission precheck path.

Recommended flow: PLAN -> DRY RUN -> FIRE -> REVIEW.

## Tier 3 — workbook/drawing/OCR/UI/takeoff/runtime

Examples: workbook open, PDF/drawing read, OCR, takeoff engine, UI implementation, Builder/Formatter/QA/O&A runtime.

Recommended flow: RESEARCH -> PLAN -> DRY RUN -> CONFIDENCE -> FIRE -> REVIEW.

## Non-negotiable gates

No source/runtime/workbook/drawing/UI access without explicit approval. Permission before access. Preview before export/write. Evidence before assumptions.

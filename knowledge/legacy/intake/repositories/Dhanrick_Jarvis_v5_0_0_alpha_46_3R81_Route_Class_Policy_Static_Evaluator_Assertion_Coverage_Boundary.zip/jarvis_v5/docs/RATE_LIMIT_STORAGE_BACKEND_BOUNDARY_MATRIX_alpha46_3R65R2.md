# Rate Limit Storage Backend Boundary Matrix Reissue 2

**Version:** `v5.0.0-alpha.46.3R65R2`  
**Base:** `v5.0.0-alpha.46.3R64`  
**Mode:** Evidence-only boundary matrix  
**Rollback:** `v5.0.0-alpha.46.3R64`

## Purpose

This checkpoint defines the storage-backend boundary matrix required before any future rate-limit backend strategy can be selected or implemented.

R65R2 supersedes rejected R65 and R65R1. It is rebuilt from clean accepted R64 and fixes the artifact hygiene requirements:

- exact R65R2 approved filenames only;
- no stale R65/R65R1 sidecars;
- tracker SHA parity across package, manifest, standalone tracker, and FIRE-output archive;
- standalone FIRE summary package SHA equals the final R65R2 package SHA.

## Boundary lock

```text
storage_backend_boundary_matrix_exists=true
storage_backend_boundary_matrix_only=true
storage_backend_candidate_classes_defined=true
in_memory_boundary_defined=true
cache_backend_boundary_defined=true
redis_boundary_defined=true
external_backend_boundary_defined=true
single_process_multi_worker_distributed_boundary_defined=true
failure_mode_boundary_defined=true
persistence_privacy_redaction_boundary_defined=true
dependency_boundary_defined=true
storage_backend_selected=false
redis_selected=false
cache_backend_selected=false
in_memory_limiter_selected=false
external_backend_selected=false
backend_client_implemented=false
environment_variable_implemented=false
dependency_selected=false
dependency_installed=false
rate_limit_implementation=false
```

## Candidate backend classes

| Candidate | R65R2 status | Future decision required |
|---|---:|---|
| In-memory process-local limiter | Candidate only | Determine whether it is restricted to dev/single-process use. |
| Local cache-backed limiter | Candidate only | Determine cache type, lifecycle, eviction, privacy, and rollback. |
| Redis-backed limiter | Candidate only | Determine whether Redis is approved as an operational dependency. |
| External managed limiter service | Candidate only | Determine privacy, latency, vendor, and network dependency policy. |
| Database-backed limiter | Candidate only | Determine whether DB pressure and persistence risk are acceptable. |
| No-backend static contract mode | Candidate only | Keep implementation blocked until backend approval exists. |
| Hybrid/fallback backend | Candidate only | Determine fallback ordering and outage behavior. |

No candidate is selected in this checkpoint.

## In-memory boundary

```text
in_memory_limiter_candidate=true
in_memory_limiter_selected=false
in_memory_limiter_implemented=false
process_local_state_enabled=false
```

Future questions:

- Is single-process only acceptable?
- Is multi-worker correctness required?
- Does restart reset quota?
- Is in-memory only acceptable for tests/dev?
- What happens during process recycle?

## Cache backend boundary

```text
cache_backend_candidate=true
cache_backend_selected=false
cache_client_implemented=false
cache_config_added=false
```

Future questions:

- What cache mechanism is approved?
- What TTL and eviction rules apply?
- What happens on cache outage?
- What redaction policy applies to keys/counters?
- How is test isolation guaranteed?

## Redis boundary

```text
redis_candidate=true
redis_selected=false
redis_dependency_selected=false
redis_client_implemented=false
redis_environment_variables_added=false
redis_connection_attempted=false
```

Future questions:

- Is Redis approved for Jarvis deployment?
- What dependency/version pin policy is required?
- What timeout policy applies?
- What fail-open/fail-closed policy applies?
- Who owns Redis deployment configuration?

## External backend boundary

```text
external_backend_candidate=true
external_backend_selected=false
external_service_dependency_selected=false
external_network_call_implemented=false
```

Future questions:

- Is an external network dependency allowed?
- Can identity metadata leave the local environment?
- What latency budget applies?
- What outage and rollback policy applies?

## Single-process / multi-worker / distributed boundary

```text
single_process_policy_defined=true
multi_worker_policy_defined=true
distributed_policy_defined=true
deployment_mode_selected=false
runtime_enforcement=false
```

R65R2 does not choose a deployment mode. Future implementation must decide whether rate-limit state must be correct across multiple workers or distributed instances.

## Failure-mode boundary

```text
failure_mode_boundary_defined=true
fail_open_selected=false
fail_closed_selected=false
failure_behavior_implemented=false
```

Future failure modes to decide:

- backend unavailable;
- backend timeout;
- partial read/write;
- state corruption;
- quota reset;
- clock skew;
- operator override;
- rollback.

R65R2 does not select fail-open or fail-closed.

## Persistence, privacy, and redaction boundary

```text
raw_api_key_stored=false
raw_token_stored=false
raw_ip_stored=false
raw_identity_value_stored=false
request_payload_stored=false
workbook_content_stored=false
document_content_stored=false
ocr_content_stored=false
```

Future allowed storage candidates, if separately approved:

- hashed/redacted identity key;
- identity class;
- route class;
- window counter;
- expiry timestamp;
- decision outcome category.

No persistence implementation is allowed in R65R2.

## Dependency boundary

```text
dependency_boundary_defined=true
dependency_selected=false
dependency_installed=false
requirements_txt_modified=false
redis_dependency_selected=false
cache_dependency_selected=false
external_service_dependency_selected=false
```

Future dependency approval must include dependency name, version policy, license review, security review, maintenance status, FastAPI compatibility, testability, deployment impact, and rollback plan.

## Nonimplementation lock

```text
rate_limit_implementation=false
storage_backend_selection=false
redis_selection=false
cache_backend_selection=false
in_memory_limiter_selection=false
backend_client_implementation=false
environment_variable_implementation=false
dependency_selection=false
dependency_installation=false
identity_key_implementation=false
route_exemption_activation=false
route_limit_value_selection=false
default_limit_policy_implementation=false
per_route_limit_policy_implementation=false
burst_window_policy_implementation=false
fail_open_fail_closed_implementation=false
error_envelope_implementation=false
observability_logging_implementation=false
middleware_addition=false
middleware_configuration_change=false
route_behavior_modification=false
request_schema_modification=false
request_validation_implementation=false
cors_implementation=false
requirements_txt_modification=false
```

## Future gates

```text
future_storage_backend_selection_requires_separate_plan_plus_fire=true
future_dependency_selection_requires_separate_plan_plus_fire=true
future_rate_limit_implementation_requires_separate_plan_plus_fire=true
future_middleware_count_approval_required=true
future_cors_implementation_requires_separate_plan_plus_fire_and_middleware_count_approval=true
```

## Protected logic not touched

```text
app.py unchanged
router/main_router.py unchanged
requirements.txt unchanged
route_count=43
middleware_count=1
Builder untouched
workbook runtime untouched
safe path resolver untouched
Output Center untouched
Job Center untouched
AI Takeoff untouched
document reader untouched
OCR untouched
tool execution untouched
```

# Manifest-only Metadata Redaction Evidence Plan

## Forbidden output fields
- saved_path
- absolute_path
- private_attachment_path
- raw_workbook_ref
- raw exception trace
- sheet names in blocked responses
- cell values
- formulas
- cached formula values
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- Builder internals
- Job/Output internals
- runtime internals

## Required redaction evidence
- Path-like fixture input is blocked and not echoed.
- raw_workbook_ref fixture input is blocked and not echoed.
- private_attachment_path fixture input is blocked and not echoed.
- Blocked sheet-name response does not echo sheet names.
- Formula/cell/style blocked responses do not echo requested values.
- Runtime internals do not appear in audit output.

## Safe output
safe_ui_summary must be empty for blocked/redaction failures and must never contain path-like fields, workbook internals, formulas, cell values, styles, or runtime internals.

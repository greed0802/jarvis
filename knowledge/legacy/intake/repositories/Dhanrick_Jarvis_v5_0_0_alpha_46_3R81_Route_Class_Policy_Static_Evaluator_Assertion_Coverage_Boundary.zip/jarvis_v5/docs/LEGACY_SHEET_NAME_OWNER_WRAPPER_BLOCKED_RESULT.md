# Legacy Sheet-name Owner Wrapper Blocked Result

A blocked permission result returns before `_safe_attachment_file()`, `load_workbook()`, or `workbook.sheetnames`.

Blocked results preserve safety fields: workbook_opened=false, sheet_names_read=false, workbook_content_read=false, cells_read=false, formulas_read=false, engine_called=false, excel_created=false, legacy_builder_called=false.

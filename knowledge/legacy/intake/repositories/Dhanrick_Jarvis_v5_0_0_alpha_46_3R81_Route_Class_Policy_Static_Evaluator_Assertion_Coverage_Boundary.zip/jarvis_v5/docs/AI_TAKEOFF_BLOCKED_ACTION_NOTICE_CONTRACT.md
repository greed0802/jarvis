# AI Takeoff Blocked Action Notice Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines concise blocked-action notices for metadata-only UI state.

## Metadata example

```json
{
  "notice_id": "blocked_notice_meta_001",
  "attempted_action": "takeoff_engine",
  "status": "blocked",
  "reason": "Takeoff engine is not implemented or approved in alpha39.7.",
  "safe_next_step": "Prepare a measurement intent contract or request a future permission-gated phase.",
  "runtime_action_performed": false
}
```

## Required blocked notices

- drawing_read_blocked
- ocr_blocked
- takeoff_engine_blocked
- workbook_read_blocked
- quantity_writeback_blocked
- ui_action_disabled
- approval_token_not_issued

Blocked notices must not trigger runtime actions.

# Old Jarvis Test Pack Integration Map

Target checkpoint: `v5.0.0-alpha.39.3-testmap`  
Base checkpoint: `v5.0.0-alpha.39.2-batch`  
Mode: FIRE metadata-only  
Scope: docs/reports/metadata inventory only. No runtime execution.


## Purpose

This metadata-only checkpoint records how the recovered old Jarvis alpha22 and alpha30 JSON test suites can be mapped into the current alpha39+ testing strategy without destabilizing the current runtime.

## Evidence payloads

| Suite | ZIP integrity | Packs | Tests | Historical target |
|---|---:|---:|---:|---|
| alpha22 engineering-language weakness suite | PASS | 80 | 4000 | `v5.0.0-alpha.22.2D-engineering-language-target` |
| alpha30 reference-informed weakness suite | PASS | 160 | 8000 | `v5.0.0-alpha.30` |

Combined inventory: **240 packs / 12000 tests**.

## Current target mapping

Historical versions must not be overwritten destructively. The mapped current target is:

```text
v5.0.0-alpha.39.2-batch -> v5.0.0-alpha.39.3-testmap metadata checkpoint
```

Old packs are classified as historical regression assets. They are not approved for raw execution against alpha39+.

## Integration rule

Do not change current alpha39+ routes, protected runtime behavior, or workbook policies to satisfy old alpha22/alpha30 tests. Old tests must be mapped to current contracts.

## Execution status

```text
old_tests_executed=false
jarvis_runtime_imported=false
fastapi_testclient_used=false
workbook_opened=false
source_behavior_changed=false
runtime_route_changes=false
endpoint_added=false
```

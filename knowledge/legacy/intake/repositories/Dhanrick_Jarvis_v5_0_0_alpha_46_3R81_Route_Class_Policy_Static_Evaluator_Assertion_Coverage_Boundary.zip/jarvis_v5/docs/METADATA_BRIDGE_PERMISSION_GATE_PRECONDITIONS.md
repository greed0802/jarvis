# Metadata Bridge Permission Gate Preconditions

Before future integration, the permission-mediated request must preserve:
- source_kind=attachment_manifest
- contract_type=manifest_only_metadata_bridge
- approval=true
- requested_fields allowlisted
- unknown fields fail closed
- blocked fields fail closed
- path-like values blocked/redacted
- workbook-like values blocked
- audit record created
- safe result returned

alpha38.7 does not change the permission gate.
alpha38.7 only defines preconditions for future permission-gated integration.

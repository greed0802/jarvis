# AI Takeoff Blocked Action Matrix

Version: v5.0.0-alpha.39.5-batch
Base: v5.0.0-alpha.39.4-accelerated-playbook
Scope: metadata-only blocked action matrix.

Blocked does not mean not planned forever. Blocked means not allowed in alpha39.5 without later permission/runtime contracts.

| Action | Status | Reason |
|---|---:|---|
| Read drawing/PDF/image | Blocked | No drawing-read permission contract |
| OCR plan | Blocked | OCR excluded |
| Detect geometry | Blocked | No plan engine |
| Measure area/length/count | Blocked | No takeoff engine |
| Read workbook | Blocked | No workbook permission contract |
| Read workbook cells/formulas/styles | Blocked | Workbook read excluded |
| Write quantity | Blocked | No quantity writeback contract |
| Export takeoff | Blocked | No export contract |
| Add endpoint | Blocked | Metadata-only checkpoint |
| Implement UI viewport | Blocked | UI implementation excluded |
| Discuss selected metadata | Allowed | Safe metadata only |
| Ask clarification | Allowed | No execution |
| Draft intent contract | Allowed | Metadata only |
| Validate/redact metadata | Allowed | Contract only |


Safety flags required for this contract:
- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- quantity_writeback=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false

Explicit exclusions:
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No quantity writeback.
- No UI implementation.
- No route or endpoint addition.
- No Jarvis runtime import.
- No FastAPI TestClient.


# Metadata Bridge No-Workbook-Access Integration Policy

Any future integration path must preserve:
- workbook_opened=false
- workbook_container_inspected=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- production_workbook_access=false

Blocked integration behavior:
- openpyxl
- load_workbook
- zipfile xlsx inspection
- pandas read_excel
- xlrd
- pyxlsb
- LibreOffice conversion
- open workbook path
- read attachment file bytes
- read sheet count
- read sheet names from workbook
- read cell/formula/style data

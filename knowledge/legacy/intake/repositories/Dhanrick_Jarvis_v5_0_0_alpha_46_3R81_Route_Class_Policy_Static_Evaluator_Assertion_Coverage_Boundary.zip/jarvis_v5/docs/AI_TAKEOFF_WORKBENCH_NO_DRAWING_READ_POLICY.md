# AI Takeoff Workbench No Drawing Read Policy

Version: v5.0.0-alpha.39.0  
Base: v5.0.0-alpha.38.9  
Mode: docs/tests/evidence only


## Policy

No drawing read is allowed in alpha39.0.

## Explicitly blocked

- drawing_read=true
- OCR
- PDF/image/CAD parsing
- CAD/vector extraction
- drawing file path access
- private drawing path exposure
- raw drawing pixels
- plan markup writeback
- takeoff engine execution
- AI-generated quantities

## Future requirement

Any future drawing access requires a dedicated permission contract, approval workflow, preview, audit/result policy, and separate explicit FIRE.

# Jarvis Local Evidence Runner No-Runtime-Import Policy — alpha39.9

Target: v5.0.0-alpha.39.9-batch  
Status: policy only. No script implementation.

## Guarantee

The future local evidence runner must guarantee:

```text
No import jarvis_v5.app.
No import app.
No import FastAPI TestClient.
No endpoint call.
No runtime object creation.
No registry runtime import.
No workbook engine import.
No Builder engine import.
No UI runtime import.
```

## Forbidden Import / Runtime Tokens

Future self-checks should scan the future script source for:

```text
from fastapi.testclient import TestClient
import jarvis_v5.app
from jarvis_v5 import app
load_workbook
requests.
httpx.
subprocess
```

## Explicitly Blocked Behavior

The evidence runner must not:

- execute app.py
- instantiate the FastAPI app
- call routes/endpoints
- use TestClient
- import registry runtime
- import workbook runtime
- import Builder runtime
- import UI runtime
- call local AI/model tooling
- open workbook contents
- inspect drawing/PDF/image contents
- run OCR
- call takeoff engine

## Alpha39.9 Required False Flags

```json
{
  "local_script_implemented": false,
  "local_script_execution_allowed": false,
  "local_script_executed": false,
  "runtime_execution": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "workbook_opened": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "route_added": false,
  "endpoint_added": false
}
```

## Manual Review Rule

If static scan context is unknown, the future evidence runner must classify it as `manual_review_required`, not pass.

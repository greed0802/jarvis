# AI Takeoff Interaction Validation and Redaction Policy

Version: v5.0.0-alpha.39.5-batch
Base: v5.0.0-alpha.39.4-accelerated-playbook
Scope: metadata-only validation/redaction policy.

## Fail-closed validation rules
- unknown fields are rejected or placed into blocked_fields
- path-like fields are redacted
- raw content fields are rejected
- quantity values without safe source are blocked
- drawing-derived claims are blocked
- workbook-derived claims are blocked
- tool-call intent is blocked
- execution intent is blocked
- unsafe action request is blocked

## Blocked fields
- absolute_path
- file_path
- local_path
- stored_path
- resolved_path
- raw_path
- attachment_path
- directory
- parent
- full_path
- pdf_bytes
- image_bytes
- ocr_text
- drawing_text
- geometry
- coordinates
- vector_entities
- measurement_result
- takeoff_result
- workbook_cells
- sheet_values
- formula_values
- style_values

## Required safety flags
```json
{
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "workbook_read": false,
  "quantity_writeback": false,
  "runtime_execution": false,
  "tool_execution_called": false
}
```


Safety flags required for this contract:
- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- quantity_writeback=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false

Explicit exclusions:
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No quantity writeback.
- No UI implementation.
- No route or endpoint addition.
- No Jarvis runtime import.
- No FastAPI TestClient.


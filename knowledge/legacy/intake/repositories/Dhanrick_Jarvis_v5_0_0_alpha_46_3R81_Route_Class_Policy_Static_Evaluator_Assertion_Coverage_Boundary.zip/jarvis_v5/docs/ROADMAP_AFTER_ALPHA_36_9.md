# Roadmap After Alpha36.9

- alpha37.0: Controlled Package Cleanup FIRE.
- alpha37.1: Unified Workbook Permission Gate Plan.
- alpha37.2: Unified Workbook Permission Gate Dry Run.

Package cleanup remains separate from runtime, workbook, Builder, route, registry, and namespace work.

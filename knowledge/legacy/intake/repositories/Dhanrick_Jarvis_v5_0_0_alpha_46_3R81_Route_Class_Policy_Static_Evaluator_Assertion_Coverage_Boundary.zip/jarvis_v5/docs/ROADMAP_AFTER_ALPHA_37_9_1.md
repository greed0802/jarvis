# Roadmap After alpha37.9.1

Current accepted checkpoint: v5.0.0-alpha.37.9.1
Current target: v5.0.0-alpha.37.10 — Manifest-only Workbook Metadata Bridge Contract Dry Run Plan

## Controlled roadmap

1. alpha37.10 — Manifest-only Workbook Metadata Bridge Contract Dry Run Plan.
2. alpha37.11 — Manifest-only Metadata Contract Fixture Evidence, docs/tests/evidence only.
3. alpha37.12 — Optional manifest-only contract implementation plan, still no workbook open and no production/user workbook access.
4. Later gated phase — optional workbook-container metadata research only if explicitly approved, fixture-proven, and still content-safe.

## Do not skip

Do not jump directly from alpha37.10 to runtime metadata bridge implementation. Do not add workbook-container inspection or sheet count extraction without a separate plan, dry run, confidence gate, and FIRE authorization.

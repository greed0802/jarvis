# Metadata Bridge Permission Precheck Boundary

No permission-gate contract change in alpha38.9.

Future route must use existing permission/approval concepts only unless separate permission-gate change is approved.

Permission precheck must occur before adapter invocation.
Missing approval must fail closed.
Wrong source_kind must fail closed.
Wrong contract_type must fail closed.
Unknown/blocked fields must fail closed.

Future permission context to adapter:

```json
{
  "source_kind": "attachment_manifest",
  "contract_type": "manifest_only_metadata_bridge",
  "approved": true,
  "approval_id_present": true
}
```

The adapter must never receive workbook paths, private attachment paths, raw workbook_refs, workbook objects, file handles, cell values, formulas, styles, or workbook-container data.

# alpha46.3R28 — Output Center Export Boundary Evidence Inventory

## Version / Base / Target

- Version: `v5.0.0-alpha.46.3R28`
- Base: `v5.0.0-alpha.46.3R27`
- Target: `Output Center Export Boundary Evidence Inventory`
- Rollback: `v5.0.0-alpha.46.3R27`

## Scope Statement

R28 is a no-source-change static evidence inventory for Output Center/export boundaries. It does not implement Output Center behavior and does not execute any export.

R28 performs no runtime import, no `app.py` import, no FastAPI TestClient execution, no API route call, no attachment upload execution, no file upload route execution, no temporary fixture creation, no workbook open/read/write, no workbook-container inspection, no file execution through Jarvis runtime, no drawing/PDF/image read, no OCR, no document reader, no tool execution, no Output Center export execution, and no Job Center execution.

## Current Accepted Checkpoint

R27 is the accepted base checkpoint. R27 selected `v5.0.0-alpha.46.3R28 — Output Center Export Boundary Evidence Inventory` as the next stability phase.

## Static Scan Method

R28 uses static ZIP/file-text evidence from the accepted R27 package only.

Scan categories:

- file paths containing output/export/artifact/package/sidecar/report/job terms;
- source text containing export/output/artifact/package/sidecar/report/job terms;
- app route decorators with output/export/artifact/download/job/report terms;
- schema/policy/docs candidates related to output manifests and export policy;
- package hygiene and sidecar agreement candidates.

No runtime execution was used for this inventory.

## Static Scan Result

- Base R27 file count: `1928`.
- App routes matching output/export/job/report terms: `0`.
- No output/export/job/report app route confirmed.
- No dedicated `output_center` runtime module confirmed by path scan.
- Inherited `.xlsx` package footprint: `5`.
- Inherited `reports/current` package footprint: `161`.
- Inherited total `reports/` package footprint: `269`.
- Inherited cache/pyc footprint: `0`.

## Confirmed Output/Export Boundary Candidates

The following candidates are confirmed by static path and content evidence:

1. `jarvis_v5/schemas/output_manifest_schema.py`
   - `OutputManifestSpec`
   - `DownloadPolicyPlaceholder`
   - `OutputRetentionPolicy`
   - `file_path_future`
   - `download_ref_future`
   - `safe_path_required`

2. `jarvis_v5/schemas/tool_result_schema.py`
   - `OutputRecord`
   - `output_path`
   - `download_url`
   - `temporary`

3. `jarvis_v5/docs/OUTPUT_MANIFEST_SCHEMA.md`
   - output manifest rules
   - allowed future output types
   - relative-path rule

4. `jarvis_v5/docs/JOB_CENTER_OUTPUT_MANIFEST_CONTRACT.md`
   - schema-only job/output contract
   - no output file creation
   - no download routes
   - no Output Center runtime

5. `jarvis_v5/docs/PREVIEW_EXPORT_EXECUTION_POLICY.md`
   - export disabled policy
   - preview-before-export rule
   - explicit export approval requirement

6. `jarvis_v5/tools/builder/preview_execution_policy.py`
   - export approval policy references
   - raw path-like key list
   - output manifest schema references
   - background job boundary references

7. `jarvis_v5/docs/PACKAGE_ARTIFACT_HYGIENE_POLICY.md`
   - package artifact hygiene
   - temporary artifact exclusion
   - output naming policy

8. `jarvis_v5/docs/OUTPUT_AND_TEMP_FILE_NAMING_POLICY.md`
   - output filename policy
   - TEMP file policy
   - metadata belongs in JSON/debug metadata

9. `jarvis_v5/docs/FIRE_SIDECAR_EVIDENCE_HYGIENE_LOCK_alpha46_3R19.md`
   - final ZIP as truth source
   - sidecar agreement rules

## Likely Export-Adjacent Candidates

Likely candidates that need continued protection but are not confirmed Output Center runtime modules:

- `jarvis_v5/schemas/job_contract_schema.py`
- `jarvis_v5/router/action_aliases.py`
- `jarvis_v5/router/active_task_action_language_gate.py`
- `jarvis_v5/router/active_task_language_gate.py`
- `jarvis_v5/router/clarification_gate.py`
- `jarvis_v5/router/no_active_task_language_gate.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/tests/harness/runtime_json_harness/classification_engine.py`

These contain export/download/report/job language or schema-adjacent intent, but no active Output Center export route was confirmed.

## Evidence/Package-Adjacent Candidates

- `jarvis_v5/tools/jarvis_evidence_runner.py`
  - static evidence/package identity/report generation
  - package manifest/hash/diff/report logic
  - not confirmed as Output Center runtime

- `jarvis_v5/qa_runner/report_writer.py`
  - QA report writer
  - writes JSON/Markdown QA reports
  - report-output adjacent, not Output Center runtime

- `reports/current/`
  - accepted package report/summary/manifest footprint
  - package hygiene risk area

## False-Positive Classes

The following are not primary R28 scope unless separately promoted:

- historical docs under `jarvis_v5/docs/version_history/`;
- old alpha reports;
- static smoke tests that mention Output Center only as a protected boundary;
- docs or reports containing output/export words without active boundary role.

## Raw Path / Temporary Artifact Leakage Risks

Forbidden public/export keys include:

- `saved_path`
- `path`
- `file_path`
- `absolute_path`
- `resolved_path`
- `raw_path`
- `local_path`
- `stored_path`
- `artifact_path`
- `export_path`
- `output_path`
- `download_path`
- `directory`
- `parent`
- `full_path`
- `storage_root`
- `temp_dir`
- `workspace_root`

Risk highlights:

- `output_manifest_schema.py` includes `file_path_future` and `download_ref_future`.
- `tool_result_schema.py` includes `output_path` and `download_url`.
- `preview_execution_policy.py` already contains raw path-like key policy language.

These are treated as boundary risks and future placeholders, not as current runtime bugs.

## Artifact / Sidecar / Runtime-Data Packaging Risks

Future packages must continue to exclude:

- `.pytest_cache/`;
- `__pycache__/`;
- `*.pyc`;
- runtime upload artifacts;
- temporary upload fixtures;
- temporary export files;
- unapproved workbook artifacts;
- unapproved PDF/image/document fixtures;
- local logs;
- generated runtime state;
- orphaned reports not listed in manifests.

Sidecar agreement must continue to require:

- final ZIP file list agrees with manifest;
- `fire_summary.json` agrees with final ZIP;
- `fire_summary.md` agrees with JSON;
- verification CSV has 0 failed rows;
- patch diff agrees with final ZIP;
- tracker SHA matches manifest;
- standalone tracker SHA matches package tracker;
- FIRE outputs ZIP matches standalone sidecars.

## Workbook / Export Bridge Risks

R28 does not open/read/write workbooks and does not inspect workbook containers.

Future export phases must prevent:

- workbook export without explicit preview/export approval;
- workbook-derived output packaging without permission contract;
- upload-to-export or upload-to-workbook-read shortcut;
- `load_workbook` execution in an evidence-only phase;
- adding workbook artifacts without approval.

## Job Center Interaction Risks

R28 documents but does not execute Job Center behavior.

Static risks:

- `job_id` exists in output manifest schema;
- Job contract schemas can connect job safety envelopes to output manifests;
- Job Center output manifest contract exists as schema-only evidence;
- job-triggered export requires separate approval;
- no job runtime execution is approved in R28.

## Protected Systems Not Touched

R28 does not modify:

- `jarvis_v5/app.py`;
- `jarvis_v5/router/main_router.py`;
- `jarvis_v5/schemas/message_schema.py`;
- `jarvis_v5/core/attachment_store.py`;
- `jarvis_v5/core/conversation_id_safety.py`;
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`;
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`;
- `jarvis_v5/schemas/output_manifest_schema.py`;
- `jarvis_v5/schemas/tool_result_schema.py`;
- `jarvis_v5/schemas/job_contract_schema.py`;
- `jarvis_v5/tools/builder/preview_execution_policy.py`;
- `jarvis_v5/tools/jarvis_evidence_runner.py`;
- `jarvis_v5/qa_runner/report_writer.py`;
- `requirements.txt`;
- registries;
- route handlers;
- middleware behavior;
- auth runtime boundary;
- workbook permission runtime;
- workbook policy runtime;
- Builder formula/export engine;
- preview/export policy;
- active-task writing/report guards;
- Output Center runtime;
- Job Center runtime;
- sidecar generator source;
- UI/runtime modules.

## Future Approval Requirements

Future Output Center export requires separate explicit approval.
Future Job Center execution requires separate explicit approval.
Future workbook/export bridge behavior requires separate explicit approval.
Future source patch requires separate PLAN / DRY RUN / FIRE.

## Backlog Quarantine

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for ideas only and cannot expand R28 scope, add files, change the target, promote OCR/document reader, promote file execution, promote workbook access, promote Output Center export execution, promote Job Center execution, or override checkpoint evidence.

## R28 Verdict

R28 is a no-source-change static Output Center export boundary evidence inventory. It locks the current schema/policy/package evidence and confirms no Output Center export or Job Center execution occurred.

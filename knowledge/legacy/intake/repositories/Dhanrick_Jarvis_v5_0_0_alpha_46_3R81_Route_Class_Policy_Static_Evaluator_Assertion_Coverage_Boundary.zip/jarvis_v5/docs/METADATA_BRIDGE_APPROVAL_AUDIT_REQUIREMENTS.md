# Metadata Bridge Approval and Audit Requirements

Future integration audit/result must include:
- decision
- allowed
- reason_code
- source_kind
- contract_type
- requested_fields
- allowed_fields
- blocked_fields
- fail_closed
- safe_ui_summary
- safety_flags
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- route_integration_used=true/false
- permission_gate_checked=true/false
- approval_checked=true/false

Future audit/result must not include:
- raw workbook path
- private attachment path
- raw workbook_ref
- cell values
- formulas
- cached values
- styles
- sheet names from workbook read
- tracebacks
- runtime internals

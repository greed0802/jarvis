# Manifest-only Metadata Fixture Record Schema

Records are expected evidence only. Records are not execution results. Records must contain no workbook data. Records must not reference inherited workbook fixtures. Records must not reference synthetic workbook files. Records must not include real paths, sheet names, cell values, formulas, styles, or runtime internals.

## Required fields
- fixture_id
- group
- source_kind
- requested_fields
- input_summary
- expected_decision
- redaction_expectation
- safety_flags_expected_false

## Expected allowed record shape
```json
{
  "fixture_id": "A37_12_ALLOW_EXTENSION",
  "group": "allow_manifest_metadata",
  "source_kind": "attachment_manifest",
  "requested_fields": ["declared_extension"],
  "input_summary": {
    "contains_path_like_data": false,
    "contains_workbook_data": false,
    "uses_inherited_workbook_fixture": false,
    "uses_synthetic_workbook_file": false
  },
  "expected_decision": {
    "decision": "allow",
    "allowed": true,
    "reason_code": "manifest_field_allowed",
    "metadata_fields_allowed": ["declared_extension"],
    "metadata_fields_blocked": [],
    "contains_workbook_data": false,
    "workbook_opened": false,
    "workbook_container_inspected": false,
    "production_workbook_access": false,
    "fail_closed": false
  },
  "redaction_expectation": {
    "safe_ui_summary_allowed": true,
    "forbidden_fields_suppressed": []
  }
}
```

## Expected blocked record shape
```json
{
  "fixture_id": "A37_12_BLOCK_SHEET_COUNT",
  "group": "block_workbook_container_metadata",
  "source_kind": "attachment_manifest",
  "requested_fields": ["sheet_count"],
  "expected_decision": {
    "decision": "block",
    "allowed": false,
    "reason_code": "field_requires_workbook_container_or_future_gate",
    "metadata_fields_allowed": [],
    "metadata_fields_blocked": ["sheet_count"],
    "contains_workbook_data": false,
    "workbook_opened": false,
    "workbook_container_inspected": false,
    "production_workbook_access": false,
    "fail_closed": true
  },
  "redaction_expectation": {
    "safe_ui_summary_allowed": false,
    "forbidden_fields_suppressed": ["sheet_names", "workbook_path", "raw_workbook_ref"]
  }
}
```

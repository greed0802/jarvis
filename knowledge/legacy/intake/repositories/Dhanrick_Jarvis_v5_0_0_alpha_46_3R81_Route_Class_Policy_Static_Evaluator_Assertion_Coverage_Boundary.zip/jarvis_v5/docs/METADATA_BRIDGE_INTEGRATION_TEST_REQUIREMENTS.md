# Metadata Bridge Integration Test Requirements

Future integration tests must verify:
- route disabled until explicitly added
- adapter remains isolated
- permission precheck occurs before adapter call
- missing approval blocks
- wrong source_kind blocks
- wrong contract_type blocks
- unknown fields block
- blocked workbook fields block
- safe UI summary excludes forbidden values
- no workbook open occurs
- no workbook-container inspection occurs
- no openpyxl/load_workbook use appears in integration path
- no Builder runtime call occurs
- no Formatter runtime call occurs
- no QA runtime call occurs
- no O&A runtime call occurs
- no Document Reader runtime call occurs
- no Output Center runtime call occurs
- no Job runtime call occurs
- protected hashes checked

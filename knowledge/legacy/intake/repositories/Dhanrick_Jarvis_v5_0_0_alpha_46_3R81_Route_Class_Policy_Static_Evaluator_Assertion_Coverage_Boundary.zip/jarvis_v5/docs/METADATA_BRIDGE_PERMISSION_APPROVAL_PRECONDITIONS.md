# Metadata Bridge Permission and Approval Preconditions

Version: v5.0.0-alpha.38.1

Before future implementation can be considered:

- `source_kind` must equal `attachment_manifest`.
- `contract_type` must equal `manifest_only_metadata_bridge`.
- Approval must be explicit.
- Requested fields must be allowlisted.
- Unknown fields must fail closed.
- Blocked fields must not appear in safe UI summary.
- Workbook paths must not be exposed.
- Workbook open must not occur.
- Workbook-container inspection must not occur.

## Boundary

alpha38.1 does not change the permission gate. It defines future requirements only.

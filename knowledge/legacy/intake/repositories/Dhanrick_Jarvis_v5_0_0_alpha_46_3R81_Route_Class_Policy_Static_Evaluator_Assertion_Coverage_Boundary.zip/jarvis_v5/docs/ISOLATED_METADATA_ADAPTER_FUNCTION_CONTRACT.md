# Isolated Metadata Adapter Function Contract

Future module:
`jarvis_v5/metadata_bridge/manifest_metadata_adapter.py`

Future public function:
```python
def evaluate_manifest_metadata_request(
    attachment_manifest: dict,
    permission_context: dict,
    requested_fields: list[str],
) -> dict:
    ...
```

Future constants:
```python
ALLOWED_MANIFEST_METADATA_FIELDS = frozenset({...})
BLOCKED_METADATA_FIELDS = frozenset({...})
```

Allowed internal helper functions:
```python
def _safe_bool(value: object) -> bool: ...
def _sanitize_filename_display(value: object) -> str | None: ...
def _is_path_like(value: object) -> bool: ...
def _build_block_result(reason_code: str, requested_fields: list[str]) -> dict: ...
def _build_allow_result(requested_fields: list[str], allowed_values: dict) -> dict: ...
```

Future adapter functions are documented only. No source file is created in alpha38.5.

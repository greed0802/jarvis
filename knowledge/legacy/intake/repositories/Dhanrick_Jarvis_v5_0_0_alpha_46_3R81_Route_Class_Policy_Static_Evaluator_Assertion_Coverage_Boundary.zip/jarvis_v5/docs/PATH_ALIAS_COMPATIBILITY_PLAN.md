# Path Alias Compatibility Plan

This plan evaluates whether a future `jarvis_v5` to `jarvis_app` migration needs a compatibility alias.

## Options

### No alias

Cleaner migration. Old imports/tests fail immediately and reveal incomplete migration.

### Temporary alias

Safer for external packs and start scripts, but may hide incomplete migration. If used, it must have a removal target.

### Permanent alias

Not recommended. It preserves technical debt permanently.

## Recommendation

Use no alias unless external regression packs or start scripts prove aliasing is necessary. If required, make it temporary and documented.

## Alpha36.6 status

No alias is created in alpha36.6.

## Safety Flags / Non-Runtime Markers

```text
metadata_only=true
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
runtime_behavior_changed=false
rename_performed=false
jarvis_app_created=false
imports_rewritten=false
compat_alias_created=false
files_deleted=false
files_moved=false
```

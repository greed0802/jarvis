# Jarvis Protected Hash and Safety Scan Plan

Version target: v5.0.0-alpha.39.8-batch  
Base checkpoint: v5.0.0-alpha.39.7-batch

## Purpose

Define how local scans protect stable Jarvis boundaries during future package growth.

## Protected Hash Compare Set

At minimum, protected compare should include:

- `app.py`
- `config.py`
- `registry_loader.py`
- `preview_execution_policy.py`
- `safe_workbook_path_resolver.py`
- Builder engine files
- Workbook permission runtime files
- Output Center runtime files
- UI runtime files
- route files
- endpoint files

## Protected Hash Compare Process

1. Hash protected files in base.
2. Hash protected files in target.
3. Compare unchanged / changed / missing / new.
4. Fail if protected file changed outside allowed scope.

## Safety Flag Scan Strings

Scan for actual enablement of:

- `WORKBOOK_READ_ENABLED = True`
- `BUILDER_ENGINE_EXECUTION_ENABLED = True`
- `LEGACY_BUILDER_CALLABLE = True`
- `EXCEL_OUTPUT_ENABLED = True`
- `ui_implemented=true`
- `drawing_read=true`
- `image_rendered=true`
- `pdf_rendered=true`
- `ocr_called=true`
- `takeoff_engine_called=true`
- `workbook_read=true`
- `workbook_opened=true`
- `quantity_writeback=true`
- `approval_token_issued=true`
- `runtime_execution=true`
- `local_script_execution_allowed=true`

## Context Classification Required

Raw string scans must classify context:

- actual enabled flag
- blocked/prohibited example
- inherited base reference
- test assertion
- report evidence flag

## Route / Endpoint Scan

Count and compare:

- `@app.get`
- `@app.post`
- `@app.put`
- `@app.delete`
- `router.get`
- `router.post`
- `router.put`
- `router.delete`

If scope says no route/endpoint addition, route delta must be 0.



## Alpha39.8 Safety Evidence Flags

```json
{
  "runtime_behavior_changed": false,
  "source_behavior_changed": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "ui_implemented": false,
  "local_script_execution_allowed": false,
  "old_tests_executed": false,
  "jarvis_runtime_imported": false,
  "fastapi_testclient_used": false,
  "route_added": false,
  "endpoint_added": false,
  "memory_imported": false,
  "protected_systems_touched": false
}
```

This document is metadata-only. It does not implement local scripts, execute local scripts, import Jarvis runtime, add endpoints, add routes, open workbooks, read drawings, use OCR, call takeoff engines, or implement UI.

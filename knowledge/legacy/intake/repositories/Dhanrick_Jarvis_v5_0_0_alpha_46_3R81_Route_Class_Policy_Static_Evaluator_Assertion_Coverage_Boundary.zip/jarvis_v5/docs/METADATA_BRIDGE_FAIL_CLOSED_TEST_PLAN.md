# Metadata Bridge Fail-Closed Test Plan

## Future fail-closed tests
- unknown field requested
- blocked field requested
- missing approval
- approval=false
- wrong source_kind
- missing contract_type
- wrong contract_type
- path-like input present
- raw workbook_ref present
- production/user workbook path present
- requested scope expanded
- workbook access attempted

## Expected decision
- decision=block
- allowed=false
- fail_closed=true
- workbook_opened=false
- workbook_container_inspected=false
- contains_workbook_data=false
- safe_ui_summary excludes forbidden data

## Scope boundary
These tests are documented for future implementation dry-run planning only. alpha38.2 does not execute a fixture engine and does not implement runtime behavior.

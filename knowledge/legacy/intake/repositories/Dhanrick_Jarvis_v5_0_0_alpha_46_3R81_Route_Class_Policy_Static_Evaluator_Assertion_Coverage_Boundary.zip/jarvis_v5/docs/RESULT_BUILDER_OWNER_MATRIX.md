# Result Builder Owner Matrix

Version: v5.0.0-alpha.36.7


- audit_only=true
- refactor_performed=false
- runtime_behavior_changed=false
- duplicates_removed=false
- owners_changed=false
- workbook_runtime_changed=false
- route_behavior_changed=false
- registry_loader_changed=false
- builder_runtime_changed=false
- execution_enabled=false
- workbook_read=false
- workbook_content_read=false
- formula_read=false
- cell_value_read=false
- style_read=false
- sheet_name_probe_allowed=false
- engine_called=false
- excel_created=false
- legacy_builder_called=false
- tool_execution_called=false


This matrix tracks result/response shape ownership to avoid drift.

| result_family | current_owner | duplicate_risk | safety_flags_required | future_action |
|---|---|---|---|---|
| Builder response | app/router response layer | medium | engine_called=false excel_created=false | protect |
| blocked result | multiple policy modules | high | workbook_read=false content/formula/cell/style=false | future shared contract candidate |
| permission result | workbook preflight/approval modules | high | approval does not imply content read | future unified gate |
| workbook preflight result | workbook_read_preflight_contract.py | medium | all workbook read flags false | wrap later |
| metadata probe result | workbook_metadata_probe_approval.py | medium | no content read | governance review |
| sheet-name probe result | workbook_sheet_name_probe_approval.py | high | content/formula/cell/style false | WRAP later |
| advisory result | advisory modules/router | low | execution false | keep |
| test runner result | run_alpha_smoke_tests.py | low | pack result only | keep |
| audit/status result | report docs/status files | low | evidence only | keep |

alpha36.7 does not centralize result builders.

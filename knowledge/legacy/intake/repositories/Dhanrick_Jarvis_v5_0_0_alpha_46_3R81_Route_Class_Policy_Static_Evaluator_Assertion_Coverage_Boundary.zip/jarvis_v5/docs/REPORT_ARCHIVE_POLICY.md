# Report Archive Policy

Version: v5.0.0-alpha.37.4.1

Root report clutter is prohibited. Detailed release evidence must be organized as:

```text
reports/current/
reports/history/<version>/
```

Root may keep stable user-facing files only: `CURRENT_BACKEND_STATUS.md`, `NEXT_CHAT_HANDOFF.md`, manifests, launchers, README, requirements, conftest, and smoke runner.

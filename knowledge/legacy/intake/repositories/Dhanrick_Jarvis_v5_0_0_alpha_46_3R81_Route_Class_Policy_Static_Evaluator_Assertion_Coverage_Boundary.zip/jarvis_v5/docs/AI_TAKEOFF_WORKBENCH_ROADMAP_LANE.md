# AI Takeoff Workbench Roadmap Lane

Version: v5.0.0-alpha.39.0  
Base: v5.0.0-alpha.38.9  
Mode: docs/tests/evidence only


## Future concept

Jarvis may evolve into an AI-assisted QS takeoff workbench with a plan viewport, selected plan context, selected item context, takeoff technical panels, and a Jarvis side conversation panel.

## Roadmap status

Roadmap lane only. No implementation in alpha39.0.

## Future user experience concept

- Plan viewport / drawing area.
- Takeoff item tree or measurement context.
- Selected trade, level, item, unit, and quantity metadata.
- Jarvis side chat panel for questions, QA, and BOQ wording assistance.

## Blocked until separately approved

Drawing read, OCR, automatic measurement, AI-generated quantities, UI implementation, workbook/drawing access, plan markup writeback, export/writeback, or takeoff engine execution.

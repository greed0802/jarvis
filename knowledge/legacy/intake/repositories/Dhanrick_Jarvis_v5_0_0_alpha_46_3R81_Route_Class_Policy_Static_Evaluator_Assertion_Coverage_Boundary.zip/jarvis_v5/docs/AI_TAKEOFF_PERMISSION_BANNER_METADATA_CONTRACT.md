# AI Takeoff Permission Banner Metadata Contract

Version target: `v5.0.0-alpha.39.7-batch`  
Base checkpoint: `v5.0.0-alpha.39.6-batch`  
Scope: metadata contract only. No UI implementation. No drawing/PDF/image read. No OCR. No takeoff engine. No workbook access. No route or endpoint.

Required false flags: `ui_implemented=false`, `image_rendered=false`, `pdf_rendered=false`, `drawing_read=false`, `ocr_called=false`, `takeoff_engine_called=false`, `workbook_read=false`, `quantity_writeback=false`, `approval_token_issued=false`, `runtime_execution=false`, `route_added=false`, `endpoint_added=false`.

## Purpose

Defines safe permission banner metadata without real permission runtime.

## Metadata example

```json
{
  "banner_id": "permission_banner_meta_001",
  "status": "blocked_by_default",
  "message": "Drawing read is blocked until a future permission contract and approval token are available.",
  "approval_required": true,
  "approval_token_issued": false,
  "runtime_action_allowed": false,
  "action_buttons_enabled": false
}
```

## Allowed banner messages

Drawing read is blocked. OCR is blocked. Takeoff engine is blocked. Workbook read is blocked. Quantity writeback is blocked. Approval token has not been issued.

## Blocked banner behavior

real approval button, approval token generation, runtime permission grant, tool execution, route call, and file access are blocked.

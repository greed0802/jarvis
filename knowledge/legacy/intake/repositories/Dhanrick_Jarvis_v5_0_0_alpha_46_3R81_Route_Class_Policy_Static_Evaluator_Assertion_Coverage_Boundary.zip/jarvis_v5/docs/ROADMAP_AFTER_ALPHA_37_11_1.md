# Roadmap After alpha37.11.1

- alpha37.12 — Manifest-only Metadata Fixture Evidence Package Plan
- alpha37.13 — JSON/docs-only Fixture Evidence Package
- alpha37.14 — Fixture Evidence Review / Coverage Summary
- alpha37.15 — Optional implementation plan, still no runtime until separately approved

Do not jump to runtime implementation. Do not introduce workbook access. Do not delete inherited fixtures without a separate cleanup candidate review.

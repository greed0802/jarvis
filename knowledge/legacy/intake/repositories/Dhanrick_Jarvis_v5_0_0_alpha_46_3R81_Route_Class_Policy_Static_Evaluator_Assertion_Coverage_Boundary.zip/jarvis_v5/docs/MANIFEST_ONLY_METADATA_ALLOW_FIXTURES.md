# Manifest-only Metadata Allow Fixtures

All allow fixtures use `source_kind=attachment_manifest` and manifest-only fields.

| Fixture ID | Requested fields | Expected decision |
|---|---|---|
| A37_11_ALLOW_EXTENSION | declared_extension | allow |
| A37_11_ALLOW_MIME_TYPE | declared_mime_type | allow |
| A37_11_ALLOW_FILE_SIZE | declared_file_size_bytes | allow |
| A37_11_ALLOW_CREATED_AT | manifest_created_at | allow |
| A37_11_ALLOW_MODIFIED_AT | manifest_modified_at | allow |
| A37_11_ALLOW_ATTACHMENT_ID_PRESENT | attachment_id_present | allow |
| A37_11_ALLOW_CONTRACT_ID_PRESENT | contract_id_present | allow |
| A37_11_ALLOW_SAFE_FILENAME_DISPLAY | sanitized_filename_display | allow |
| A37_11_ALLOW_ACCEPTED_SHEET_REF_PRESENT | accepted_sheet_name_probe_result_id_present | allow presence only |

## Expected allow record shape

```json
{
  "decision": "allow",
  "allowed": true,
  "contains_workbook_data": false,
  "workbook_opened": false,
  "workbook_container_inspected": false,
  "production_workbook_access": false,
  "metadata_fields_blocked": [],
  "fail_closed": false
}
```

# Alpha36.8 Scope — Root Artifact + Runtime Data Hygiene Cleanup Plan

Version: v5.0.0-alpha.36.8
Base: v5.0.0-alpha.36.7
Mode: docs/tests/evidence only.

Purpose: define package hygiene governance before cleanup execution. Alpha36.8 does not delete, move, archive, rename, refactor, or clean files.

Allowed scope:
- Define cleanup rules.
- Define root artifact inventory.
- Define current-vs-history policy.
- Define runtime data shipping policy.
- Define future cleanup tests.
- Generate reports and handoff.

Excluded scope:
- No cleanup execution.
- No deletion.
- No file moves.
- No runtime execution.
- No refactor.
- No owner changes.
- No workbook runtime changes.
- No Builder changes.
- No route changes.
- No registry loader changes.
- No namespace rename.
- No jarvis_app creation.

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

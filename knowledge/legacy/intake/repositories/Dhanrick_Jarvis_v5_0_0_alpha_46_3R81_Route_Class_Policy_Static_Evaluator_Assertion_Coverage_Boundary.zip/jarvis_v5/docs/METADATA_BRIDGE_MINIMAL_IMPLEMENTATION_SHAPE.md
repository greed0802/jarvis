# Metadata Bridge Minimal Implementation Shape

## Status
This document describes a future implementation shape only. No source files are edited in alpha38.2.

## Future input shape

Input:
- attachment_manifest
- permission approval context
- requested metadata fields

## Future process shape

Process:
- validate source_kind
- validate contract_type
- validate explicit approval
- validate requested fields against manifest-only allowlist
- block unknown fields
- block forbidden fields
- produce safe audit/result summary

## Future output shape

Output:
- decision
- allowed
- allowed_fields
- blocked_fields
- reason_code
- safe_ui_summary
- safety_flags

## Required future invariants
- Pure manifest-only metadata adapter.
- No workbook file handle.
- No openpyxl usage.
- No workbook ZIP/container inspection.
- No route registration change unless separately approved.
- No permission-gate contract change unless separately approved.
- No Builder, Formatter, QA, O&A, Document Reader, Output, or Job runtime call.

## Still blocked
- workbook open
- workbook-container inspection
- sheet count
- sheet names from workbook read
- cell values
- formulas
- styles
- named ranges
- tables
- merged cells
- comments
- VBA/macros
- external links
- production workbook path exposure

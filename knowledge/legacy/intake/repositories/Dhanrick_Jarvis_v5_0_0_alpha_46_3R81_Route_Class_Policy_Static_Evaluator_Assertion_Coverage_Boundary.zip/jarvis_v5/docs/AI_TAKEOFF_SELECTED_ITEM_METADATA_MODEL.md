# AI Takeoff Selected Item Metadata Model

## Purpose
Define safe selected-takeoff-item metadata for future Jarvis assistance without reading workbooks, drawings, cells, formulas, styles, or measurement geometry.

## Allowed selected-item metadata fields
- takeoff_item_id
- item_code
- item_description
- trade
- section
- level
- unit
- quantity_summary
- measurement_type
- source_plan_id
- revision_reference
- qa_status
- selected_item_context_id

## Rules
- Quantity summary is declared metadata only.
- Jarvis must not create, edit, or write quantities in this phase.
- Missing item metadata must trigger clarification, not guessing.
- Unit and measurement-type checks are allowed as metadata reasoning only.

## Blocked selected-item fields
- formula read
- cell values read from workbook
- cell styles
- workbook sheet contents
- drawing-derived dimensions
- measurement vectors
- automatic measurement output
- quantity writeback
- workbook writeback
- plan markup writeback
- Builder/Formatter/QA/O&A runtime calls

## Safety
No workbook open is planned or permitted.
No drawing read is planned or permitted.
No quantity writeback is planned or permitted.

# AI Takeoff Workbench Batch-Gated Metadata Model Plan

Version: v5.0.0-alpha.39.2-batch
Base version: v5.0.0-alpha.39.1

This package defines a faster docs/tests/evidence workflow for the AI Takeoff Workbench metadata model. It does not implement UI, drawing access, OCR, route integration, endpoint exposure, runtime behavior, workbook access, or takeoff execution.

## Batch-gated execution policy
- Batch 1 must pass before Batch 2.
- Batch 2 must pass before Batch 3.
- Batch 3 must pass before Batch 4.
- Batch 4 must pass before Batch 5.
- Each batch requires confidence >= 98%.
- Failed batch stops later batches.
- Retry is limited to the failed batch with minimal docs/tests/evidence correction.
- Protected systems must not be touched to make a batch pass.

## Batches
### Batch 1: Selected Plan Metadata Model
Defines safe selected-plan metadata fields and blocks drawing/PDF/image/OCR/CAD data.

### Batch 2: Selected Takeoff Item Metadata Model
Defines safe selected-takeoff-item metadata fields and blocks workbook/cell/formula/drawing-derived quantity data.

### Batch 3: Selected Context Relationship Model
Defines relationship between project, plan, item, quantity summary, QA context, and chat context.

### Batch 4: Validation, Redaction, and Blocked Fields
Defines fail-closed validation, redaction, and blocked-field matrix.

### Batch 5: Smoke Test, JSON Test Pack, Reports, Handoff
Validates all docs and refreshes evidence only.

## Out of scope
No source patch. No route integration. No endpoint. No runtime implementation. No workbook open. No drawing read. No OCR. No takeoff engine. No UI implementation. No quantity writeback.

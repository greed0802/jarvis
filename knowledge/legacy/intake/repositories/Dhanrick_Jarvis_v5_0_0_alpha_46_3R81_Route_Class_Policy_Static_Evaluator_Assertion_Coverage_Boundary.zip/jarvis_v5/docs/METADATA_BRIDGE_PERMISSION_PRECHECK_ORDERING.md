# Metadata Bridge Permission Precheck Ordering

Future integration ordering:
1. Receive request.
2. Validate request schema.
3. Confirm source_kind=attachment_manifest.
4. Confirm contract_type=manifest_only_metadata_bridge.
5. Confirm explicit approval/approval_id.
6. Run permission precheck.
7. Fail closed if permission/approval fails.
8. Only after approval, call isolated adapter.
9. Generate audit/result.
10. Return safe UI summary.

Adapter invocation before permission approval is blocked. Workbook access before permission approval is blocked. Workbook access after permission approval remains blocked.


## Safety boundary
- no source patch occurs
- no route integration occurs
- no endpoint is added
- no runtime implementation occurs
- no workbook open occurs
- no workbook-container inspection occurs
- no permission-gate contract change occurs
- no owner-wrapper change occurs
- safety flags remain false
- protected systems untouched

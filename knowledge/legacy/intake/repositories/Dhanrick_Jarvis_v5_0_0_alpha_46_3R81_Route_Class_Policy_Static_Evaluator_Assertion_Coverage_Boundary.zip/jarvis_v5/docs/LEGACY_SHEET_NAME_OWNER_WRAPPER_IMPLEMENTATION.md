# Legacy Sheet-name Owner Wrapper Implementation

The owner `evaluate_workbook_sheet_name_probe_approval()` now calls `evaluate_workbook_permission_gate()` before `_safe_attachment_file()` and before `load_workbook()`.

The wrapper uses action `sheet_name_probe_execute_after_approval` and requested scope `["sheet_name_probe"]`.

Blocked permission results return immediately before path resolution or workbook open.

Allowed decision `ALLOW_SHEET_NAME_ONLY_AFTER_APPROVAL` continues the existing owner sheet-name-only behavior unchanged.

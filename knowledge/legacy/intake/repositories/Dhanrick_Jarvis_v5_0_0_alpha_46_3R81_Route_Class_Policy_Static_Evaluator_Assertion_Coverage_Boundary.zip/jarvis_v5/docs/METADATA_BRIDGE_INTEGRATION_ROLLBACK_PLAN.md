# Metadata Bridge Integration Rollback Plan

Future integration rollback must declare base package, target version, exact files edited, exact routes added, protected files touched or excluded, tests run, package hygiene, rollback package, and review checklist.

Rollback triggers include test failure, unexpected protected hash change, route exposed without permission precheck, adapter invoked before approval, workbook access detected, permission-gate contract drift, or owner-wrapper drift.


## Safety boundary
- no source patch occurs
- no route integration occurs
- no endpoint is added
- no runtime implementation occurs
- no workbook open occurs
- no workbook-container inspection occurs
- no permission-gate contract change occurs
- no owner-wrapper change occurs
- safety flags remain false
- protected systems untouched

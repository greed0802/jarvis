# AI Takeoff Selected Plan Metadata Model

## Purpose
Define safe selected-plan metadata for the future AI Takeoff Workbench without reading drawings, PDFs, images, CAD files, OCR output, or production project files.

## Allowed selected-plan metadata fields
- project_id
- plan_id
- plan_name
- drawing_number
- drawing_title
- drawing_revision
- discipline
- trade
- level
- page_number
- declared_scale
- plan_context_id
- selected_region_id
- viewport_page_reference

## Rules
- Fields are declared metadata only.
- Metadata may identify a selected plan but must not imply file access.
- Missing plan metadata must trigger clarification, not guessing.
- Plan viewport remains concept only.

## Blocked selected-plan fields
- drawing file path
- private drawing path
- raw drawing pixels
- PDF internals
- OCR text
- CAD geometry
- vector paths
- measured dimensions
- automatic quantities
- production project file references
- tracebacks or runtime internals

## Safety
No drawing read is planned or permitted in this metadata model.
No OCR is planned or permitted.
No UI implementation is planned or permitted.

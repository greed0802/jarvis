# JSON Fixture Evidence Record Completeness Rules

Every JSON evidence record should include:
- fixture_id
- group
- source_kind
- requested_fields
- input_summary
- expected_decision
- redaction_expectation
- safety_flags_expected_false
- execution_performed=false
- contains_workbook_data=false
- workbook_opened=false
- workbook_container_inspected=false
- synthetic_workbook_created=false
- fixture_deleted=false

Every record must avoid raw values for:
- real workbook paths
- private attachment paths
- raw workbook references
- real sheet names
- cell values
- formulas
- cached formula values
- style data
- named range values
- table data
- comment text
- VBA/macros
- runtime traces
- Builder internals
- Job/Output internals

## Boundary
Completeness checks are evidence checks only. They do not execute a fixture evaluator and do not inspect workbook files.

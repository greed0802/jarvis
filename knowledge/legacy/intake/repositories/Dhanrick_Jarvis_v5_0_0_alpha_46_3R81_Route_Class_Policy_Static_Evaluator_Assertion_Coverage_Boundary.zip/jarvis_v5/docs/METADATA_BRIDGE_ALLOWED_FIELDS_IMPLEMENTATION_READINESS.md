# Metadata Bridge Allowed Fields — Implementation Readiness

Version: v5.0.0-alpha.38.1

## Allowed manifest-only fields

The future bridge may only consider fields already present in an attachment manifest or previously accepted metadata evidence:

- `attachment_id_present`
- `contract_id_present`
- `declared_extension`
- `declared_mime_type`
- `declared_file_size_bytes`
- `manifest_created_at`
- `manifest_modified_at`
- `sanitized_filename_display`
- `accepted_sheet_name_probe_result_id_present`

## Allowed field rules

- Fields must come from `attachment_manifest` or accepted evidence.
- Fields must not require opening a workbook file.
- Fields must not require workbook-container inspection.
- Fields must not expose raw saved paths or private attachment paths.
- Fields must be safe for UI summary.

## Not allowed here

Sheet count, workbook properties, worksheet dimensions, sheet names from workbook read, cell values, formulas, cached values, styles, named ranges, tables, merged cells, comments, VBA/macros, external links, hidden sheet state, runtime internals, production/user workbook paths, and raw workbook references remain blocked.

# AI Takeoff Permission Validation and Redaction Policy

Version: v5.0.0-alpha.39.6-batch
Base: v5.0.0-alpha.39.5-batch
Scope: metadata-only validation and redaction policy for permission/approval contracts.

## Purpose

Define fail-closed validation and redaction rules for future permission and approval metadata.

## Fail-Closed Rules

- unknown permission action blocked
- unknown scope blocked
- unknown source blocked
- path-like fields redacted
- raw content fields rejected
- approval token secret never exposed
- runtime handle rejected
- tool-call payload rejected
- quantity writeback target rejected

## Blocked Fields

- absolute_path
- file_path
- local_path
- stored_path
- resolved_path
- raw_path
- attachment_path
- directory
- parent
- full_path
- pdf_bytes
- image_bytes
- ocr_text
- drawing_text
- geometry
- coordinates
- vector_entities
- measurement_result
- takeoff_result
- workbook_cells
- sheet_values
- formula_values
- style_values
- approval_token_secret
- runtime_handle
- tool_payload
- job_id
- writeback_target

## Required False Flags

```json
{
  "drawing_read": false,
  "ocr_called": false,
  "takeoff_engine_called": false,
  "workbook_read": false,
  "workbook_opened": false,
  "quantity_writeback": false,
  "runtime_execution": false,
  "tool_execution_called": false,
  "approval_token_issued": false
}
```

## Redaction Outcome

Unsafe fields must be removed, replaced with a redaction marker, or moved into blocked_fields. They must not be passed to a runtime action in alpha39.6.


## Alpha39.6 Non-Execution Guarantees

- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- workbook_opened=false
- quantity_writeback=false
- approval_token_issued=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false
- jarvis_runtime_imported=false
- fastapi_testclient_used=false
- memory_imported=false
- protected_systems_touched=false

This document is metadata-only. It does not grant permission, issue approval tokens, add runtime routes, add endpoints, open workbooks, read drawings, call OCR, call a takeoff engine, or write quantities.

# AI Takeoff Workbench Plan Viewport Concept

## Concept only

The plan viewport is a future visual area where drawings/plans may eventually be displayed and where selected-plan metadata may be provided to Jarvis.

## Allowed in this phase

- Define viewport role.
- Define possible metadata fields.
- Define blocked drawing-read boundary.
- Define no-UI-implementation boundary.

## Possible future metadata

- current_plan_id
- current_page
- declared_scale
- selected_region_id
- selected_takeoff_item_id
- selected_measurement_ids
- viewport_context_id

## Blocked now

- Plan rendering.
- PDF/image/CAD parsing.
- OCR.
- Geometry extraction.
- Scale calibration implementation.
- Zoom/pan/markup code.
- Measurement tools.
- UI files.

# Release Package Hygiene Gate

Future release gate must verify:

- only current alpha reports at root
- no historical alpha reports at root
- no obsolete start scripts at root
- no runtime data non-.keep files unless evidence-approved
- no __pycache__
- no .pyc
- no .pytest_cache
- no temporary handoff files unless TEMP and temporary=true
- package manifest exists
- history manifest exists

Gate status for alpha36.8: documented_only=true. Cleanup is not executed.

## Safety Markers

```text
planning_only=true
cleanup_executed=false
files_deleted=false
files_moved=false
runtime_behavior_changed=false
source_logic_changed=false
routes_changed=false
registry_loader_changed=false
builder_runtime_changed=false
workbook_runtime_changed=false
execution_enabled=false
workbook_read=false
workbook_content_read=false
formula_read=false
cell_value_read=false
style_read=false
sheet_name_probe_allowed=false
engine_called=false
excel_created=false
legacy_builder_called=false
tool_execution_called=false
retention_engine_implemented=false
```

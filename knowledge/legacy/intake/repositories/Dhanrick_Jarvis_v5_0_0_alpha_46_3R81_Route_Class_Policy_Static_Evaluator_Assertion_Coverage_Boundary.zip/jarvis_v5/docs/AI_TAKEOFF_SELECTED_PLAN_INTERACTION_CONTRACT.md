# AI Takeoff Selected Plan Interaction Contract

Version: v5.0.0-alpha.39.5-batch
Base: v5.0.0-alpha.39.4-accelerated-playbook
Scope: metadata-only interaction contract.

## Purpose
This document defines what Jarvis side-chat may know when a user selects a plan in the future AI Takeoff Workbench. Plan selection is metadata-only and never grants visual, PDF, image, OCR, geometry, vector, or measurement access.

## Allowed selected-plan metadata
```json
{
  "selected_plan_id": "plan_meta_001",
  "project_id": "project_meta_001",
  "plan_label": "Level 05 Floor Plan",
  "discipline": "architectural",
  "drawing_type": "floor_plan",
  "revision_label": "Rev C",
  "sheet_number": "A-105",
  "safe_display_name": "A-105 Level 05 Floor Plan",
  "source_kind": "drawing_metadata_only",
  "content_access_granted": false,
  "drawing_read_allowed": false,
  "ocr_allowed": false,
  "measurement_allowed": false
}
```

## Blocked selected-plan fields
- absolute_path
- file_path
- local_path
- stored_path
- resolved_path
- raw_path
- attachment_path
- directory
- parent
- full_path
- pdf_bytes
- image_bytes
- ocr_text
- drawing_text
- drawing_geometry
- vector_entities
- coordinates
- measurement_result
- takeoff_result
- page bitmap
- thumbnail requiring image read

## Required behavior
Plan metadata does not mean visual access. Jarvis may discuss plan labels, sheet numbers, discipline, revision labels, and safe display names. Jarvis must not claim visual access, measurement access, OCR access, drawing-read access, or quantity access from this metadata.


Safety flags required for this contract:
- drawing_read=false
- ocr_called=false
- takeoff_engine_called=false
- workbook_read=false
- quantity_writeback=false
- runtime_execution=false
- tool_execution_called=false
- route_added=false
- endpoint_added=false
- ui_implemented=false

Explicit exclusions:
- No workbook open.
- No workbook-container inspection.
- No drawing/PDF/image read.
- No OCR.
- No takeoff engine.
- No quantity writeback.
- No UI implementation.
- No route or endpoint addition.
- No Jarvis runtime import.
- No FastAPI TestClient.


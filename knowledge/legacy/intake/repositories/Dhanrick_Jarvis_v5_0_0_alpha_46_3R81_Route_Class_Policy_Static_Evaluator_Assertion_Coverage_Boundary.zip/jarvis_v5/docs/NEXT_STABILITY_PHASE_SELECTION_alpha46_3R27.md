# v5.0.0-alpha.46.3R27 — Next Stability Phase Selection

## Status

R27 is a no-source-change phase-selection lock. It selects the next Jarvis stability phase after the accepted R26 attachment upload boundary phase closure.

## Base checkpoint

Base: `v5.0.0-alpha.46.3R26 — Attachment Upload Boundary Phase Closure Regression Lock`

R26 is treated as the current accepted checkpoint for this phase-selection lock.

## R21–R26 attachment upload phase closure carried forward

- R21 carried forward the attachment upload hardening evidence boundary inventory.
- R22 carried forward the attachment upload hardening contract design.
- R23 carried forward the minimal implementation plan without source implementation.
- R24 carried forward static compliance evidence for the `/api/attach` response boundary.
- R25 carried forward controlled functional verification of `/api/attach` public response-body negative assertions.
- R26 closed the attachment upload boundary phase as a no-source-change closure/regression lock.

Locked carry-forward facts:

- `saved_path_public_exposure_found=false`
- `raw_path_public_exposure_found=false`
- workbook runtime flags remain false for the attachment upload boundary phase
- `upload_to_workbook_read_bridge_executed=false`
- future functional upload verification requires separate approval
- future source patch requires separate PLAN / DRY RUN / FIRE

## Candidate next stability phases

| Candidate | Reason | Risk | Selection |
| --- | --- | --- | --- |
| Output Center Export Boundary Evidence Inventory | Export/output behavior can accidentally package temporary files, runtime artifacts, raw paths, workbook artifacts, or stale sidecars. Output Center is a protected runtime boundary. | High | Selected for R28 |
| Job Center Execution Boundary Inventory | Jobs can cross execution/background boundaries and create persistent side effects. | High | Later |
| Project Memory Metadata Boundary Inventory | Project memory requires metadata-first and permission-before-execution design. | Medium | Later |
| Document Reader / OCR Disabled Boundary Lock | Document/OCR execution must remain approval-gated and disabled unless separately authorized. | Medium | Later |
| Workbook Permission Boundary Refresh | Workbook boundary remains protected; recent attachment bridge flags were locked through R26. | High | Later |
| UI Runtime Boundary Evidence Inventory | UI/runtime modules remain protected unless approved. | Medium | Later |

## Selected next phase

Selected next target after R27:

`v5.0.0-alpha.46.3R28 — Output Center Export Boundary Evidence Inventory`

## Why Output Center next

The attachment upload boundary is closed at R26. The next high-risk stability area is export/output behavior because Jarvis packages, summaries, output manifests, and user-facing artifacts must not accidentally include:

- temporary fixtures
- runtime data artifacts
- raw filesystem paths
- unapproved workbook artifacts
- stale or mismatched sidecars
- execution output from unapproved jobs/tools
- package/manifest/summary disagreement

## R27 scope

R27 is phase-selection only.

R27 does not implement Output Center inventory. R27 only selects it as the next phase.

## Required R27 package shape

Expected package shape:

- base file count: `1925`
- target file count: `1928`
- added files: exactly three R27 evidence files
- changed files: Source of Truth tracker only
- removed files: none

Approved R27 added files:

- `jarvis_v5/docs/NEXT_STABILITY_PHASE_SELECTION_alpha46_3R27.md`
- `jarvis_v5/docs/source_of_truth/source_of_truth_manifest_alpha46_3R27.json`
- `jarvis_v5/tests/smoke/test_alpha46_3R27_next_stability_phase_selection_static.py`

Approved changed file:

- `jarvis_v5/docs/source_of_truth/Jarvis_SourceOfTruth_alpha46_3.xlsx`

## Runtime and execution boundaries

R27 must not perform:

- runtime import
- `app.py` import
- FastAPI TestClient execution
- API route call
- attachment upload execution
- file upload route execution
- temporary fixture creation
- workbook open/read/write/execution
- workbook-container inspection
- OCR
- document reader execution
- tool execution
- Output Center export
- Job Center execution
- dependency change
- sidecar generator source patch


## Explicit negative execution evidence phrases

- No runtime import.
- No Output Center export execution.
- No Job Center execution.
- No workbook open/read/write/execution.

## Protected systems

Protected and unchanged in R27:

- `jarvis_v5/app.py`
- `jarvis_v5/core/attachment_store.py`
- `jarvis_v5/schemas/message_schema.py`
- `jarvis_v5/router/main_router.py`
- `jarvis_v5/core/conversation_id_safety.py`
- `jarvis_v5/tools/builder/safe_workbook_path_resolver.py`
- `jarvis_v5/tools/builder/workbook_sheet_name_probe_approval.py`
- `requirements.txt`
- registries
- route handlers
- middleware behavior
- auth runtime boundary
- workbook permission runtime
- workbook policy runtime
- Builder formula/export engine
- Formatter workbook behavior
- QA Checker workbook behavior
- preview/export policy
- active-task writing/report guards
- Output Center runtime
- Job Center runtime
- UI/runtime modules
- sidecar generator source

## Quarantined backlog rule

`Jarvis_v5_Master_Plan.md` remains backlog-only. It may be referenced for ideas only. It cannot expand R27 scope, add R27 files, change the R27 target, promote OCR/document reader/file execution/workbook access, or override checkpoint evidence.

## Future R28 starting boundary

R28 should start as a PLAN-only Output Center Export Boundary Evidence Inventory. It should inventory output/export files, sidecar package rules, output manifest behavior, and packaging hygiene before any implementation or export execution is considered.

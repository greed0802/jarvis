# Metadata Bridge Minimal Integration Appropriateness Decision

Decision: conditionally appropriate for future planning only.

Reason: isolated adapter is accepted and deterministic. A future route could be thin and permission-first. The adapter can operate on manifest dictionaries only. No workbook access is required.

Constraints:
- no integration without explicit approved FIRE
- no workbook access under any route path
- permission/approval must happen before adapter invocation
- owner wrapper remains out of scope unless separately approved
- no permission-gate contract drift
- no route exposure without tests and rollback

Block integration if route requires workbook path, workbook open, workbook-container inspection, permission-gate contract change, owner-wrapper edit, Builder or workbook runtime call, raw workbook_ref exposure, or private path exposure.

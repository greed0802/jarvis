# DEBUG / DEV ROUTE GUARD CONTRACT — alpha46.3R7

Base: v5.0.0-alpha.46.3R6  
Target: v5.0.0-alpha.46.3R7  
Mode: FIRE / contract-only static regression lock

## Objective

Lock the existing debug/dev route guard behavior with documentation and a static smoke test. This document is evidence/contract only. It does not change runtime behavior, route decorators, route handlers, middleware, CORS, rate limiting, API-key policy, workbook access, tool execution, Output Center export, or Job Center execution.

## First-read / last-update rule

Every future Jarvis PLAN / DRY RUN / REVIEW / FIRE / HANDOFF run must:

1. Read `jarvis_v5/docs/source_of_truth/Jarvis_SourceOfTruth_alpha46_3.xlsx` first.
2. Read companion Markdown and manifest evidence next.
3. Inspect package/source evidence only after the tracker/handoff evidence.
4. Update the Source of Truth tracker last during FIRE only.

The Source of Truth tracker remains evidence-only and non-runtime.

## Scope boundary

Allowed in alpha46.3R7:

- Add this debug/dev route guard contract.
- Add a static smoke test that locks the five debug/dev route guard expectations.
- Add a Source of Truth alpha46.3R7 manifest.
- Update the Source of Truth tracker last.

Not allowed in alpha46.3R7:

- Modify `jarvis_v5/app.py`.
- Change route count, route decorators, route paths, or handler names.
- Add or change runtime enforcement.
- Add API-key middleware, CORS, rate limiting, validators, or projections.
- Touch `/api/events`, upload/text validation, `saved_path` schema/projection, Builder, Formatter, QA Checker, Output Center, Job Center, safe path resolver, workbook policy runtime, preview policy, active-task guards, requirements, or registries.
- Import `jarvis_v5.app`, use FastAPI TestClient, or call API routes during the R7 static test.

## Current debug/dev route set

| # | Method | Path | Handler | R6 access class | Required disabled guard |
|---:|---|---|---|---|---|
| 1 | POST | `/api/debug/create-test-clarification` | `api_debug_create_test_clarification` | `dev_debug_only` | `if not _debug_routes_enabled(): return _dev_route_disabled_response()` |
| 2 | GET | `/api/debug/pending-clarification/{conversation_id}` | `api_debug_pending_clarification` | `dev_debug_only` | `if not _debug_routes_enabled(): return _dev_route_disabled_response()` |
| 3 | GET | `/api/debug/router-trace/{conversation_id}` | `api_debug_router_trace` | `dev_debug_only` | `if not _debug_routes_enabled(): return _dev_route_disabled_response()` |
| 4 | POST | `/api/dev/validate-test-pack` | `api_dev_validate_test_pack` | `dev_test_only` | `if not _debug_routes_enabled(): return _dev_route_disabled_response()` |
| 5 | POST | `/api/dev/run-smoke-tests` | `api_dev_run_smoke_tests` | `dev_test_only` | `if not _debug_routes_enabled(): return _dev_route_disabled_response()` |

## Guard function contract

`_debug_routes_enabled()` is the only current debug/dev enablement switch.

Current static contract:

```text
os.environ.get("DEBUG_MODE", "").strip().lower() in {"1", "true", "yes"}
```

Allowed truthy values:

```text
1
true
yes
```

No other environment variable is approved by R7 as a debug/dev enablement switch.

## Disabled response contract

`_dev_route_disabled_response()` must return a safe 403 JSON response:

```text
status_code=403
ok=false
error=dev_route_disabled
message=This endpoint is disabled outside debug mode.
execution_enabled=false
workbook_read=false
workbook_content_read=false
tool_execution_performed=false
engine_called=false
excel_created=false
contract_only=true
legacy_builder_called=false
```

The disabled response must not expose traceback, raw exception strings, internal paths, `saved_path`, workbook paths, request bodies, secrets, API keys, or config values.

## Static test design decisions accepted from dry-run review

- The guard check must be the first non-docstring executable statement in every debug/dev route handler.
- Existing `TestClient` / `TestPackExecutor` references may remain only as existing dev-route implementation details and must not be executed by the R7 test.
- The R7 test itself must not import FastAPI TestClient, import `jarvis_v5.app`, call routes, or execute any Jarvis runtime behavior.
- Top-level import bindings already present in `app.py` are not runtime execution; R7 locks executable route behavior, not dependency cleanup.

## Global permission denial rule

R7 does not grant any runtime permission:

```text
runtime_read_allowed=false
workbook_read_allowed=false
workbook_execution_allowed=false
tool_execution_allowed=false
engine_execution_allowed=false
output_export_allowed=false
job_execution_allowed=false
```

## Future patch separation

R7 intentionally leaves these for separate PLAN / DRY RUN / REVIEW / FIRE cycles:

- Debug/dev route removal or movement to a separate dev router.
- API-key/auth middleware.
- CORS and rate limiting.
- `/api/events` redacted projection.
- Upload/text validation.
- `saved_path` schema/projection correction.
- Any Builder/Workbook/Tool execution approval workflow.

## Protected systems not touched

```text
jarvis_v5/app.py
routes
runtime modules
Builder
Formatter
QA Checker
Output Center
Job Center
safe path resolver
workbook policy runtime
preview policy
active-task guards
requirements.txt
registries
API-key middleware
CORS
rate limiting
/api/events implementation
upload/text validation implementation
saved_path schema implementation
```

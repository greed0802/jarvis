# Jarvis v5 Package

This package is a Jarvis v5 release bundle with stable root launchers, current status files, and organized release evidence.

## Start Jarvis

Use one of the stable launchers at the package root:

- `START_JARVIS.bat` — starts Jarvis with reload enabled for local development.
- `START_JARVIS_SIMPLE_NO_RELOAD.bat` — starts Jarvis without reload.

Both launchers run `python -m uvicorn jarvis_v5.app:app` from the package root.

## Current version and evidence

Root `README.md` is intentionally non-version-specific to avoid stale release metadata. For the current release version, scope, test evidence, and next handoff, see:

- `CURRENT_BACKEND_STATUS.md`
- `NEXT_CHAT_HANDOFF.md`
- `MANIFEST_CURRENT_RELEASE.md`
- `reports/current/`

Historical reports are archived under `reports/history/<version>/`.

## Safety note

Jarvis v5 remains governed by contract-first, permission-before-workbook-access rules. Do not infer workbook, Builder, route, or tool execution permission from this README. Current permissions and restrictions are documented in the current status and reports.


Alpha40.7: Blank BOQ Template XLSX Creation package created. Artifact: Australia_BOQ_Showcase_Portfolio_Template.xlsx. No source/runtime changes.

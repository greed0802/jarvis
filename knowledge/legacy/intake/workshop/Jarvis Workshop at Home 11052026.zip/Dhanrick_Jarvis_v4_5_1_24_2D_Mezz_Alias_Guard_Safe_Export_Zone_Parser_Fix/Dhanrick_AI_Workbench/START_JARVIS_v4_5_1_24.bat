@echo off
setlocal
cd /d "%~dp0"
title Dhanrick Jarvis v4.5.1.24 - localhost:8505

echo ==========================================
echo  Dhanrick Jarvis v4.5.1.24
echo  Starting on http://127.0.0.1:8505
echo ==========================================
echo.

REM Create local virtual environment if missing.
if not exist ".venv\Scripts\python.exe" (
    echo Creating local Python environment .venv ...
    py -3 -m venv .venv
    if errorlevel 1 (
        echo py launcher failed. Trying python...
        python -m venv .venv
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo ERROR: Could not create .venv. Please install Python 3.10+ and tick "Add Python to PATH".
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"

REM Install requirements only once per folder, or when the marker is removed.
if not exist ".venv\jarvis_requirements_installed_v4_5_1_23.txt" (
    echo Installing/updating required packages...
    python -m pip install --upgrade pip
    pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo ERROR: Package installation failed. Check the messages above.
        pause
        exit /b 1
    )
    echo installed>%USERPROFILE%\AppData\Local\Temp\jarvis_last_install_marker.tmp
    echo installed>".venv\jarvis_requirements_installed_v4_5_1_23.txt"
)

echo.
echo Opening Jarvis in browser...
start "" "http://127.0.0.1:8505"
echo.
echo Jarvis is running. Keep this window open.
echo Press CTRL+C in this window to stop Jarvis.
echo.
python app.py

echo.
echo Jarvis stopped.
pause

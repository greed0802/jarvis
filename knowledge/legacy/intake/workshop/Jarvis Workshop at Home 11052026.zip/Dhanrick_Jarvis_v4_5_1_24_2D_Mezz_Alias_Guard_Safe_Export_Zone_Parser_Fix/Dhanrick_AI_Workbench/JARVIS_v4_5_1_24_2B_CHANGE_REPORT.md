# Jarvis v4.5.1.24.2B Change Report

## Patch name
Preview Cache + Export Restore + Level Reducer Fix

## Base
`Dhanrick_Jarvis_v4_5_1_24_2A_Snapshot_Slot_Memory_Export_State_Hotfix.zip`

## Scope
Data-core hotfix only. No UI redesign. Builder formula/export engine preserved.

## Issues fixed

### 1. Export-ready task restored as Preview after refresh
File: `static/assets/app.js`
Functions:
- `restoreConversationMessages()`

Fix:
- Rehydrates `lastOutputDownloadUrl` from `activeConversationTask.last_export_job.result.download_url` during conversation restore.
- Allows `export_ready`, `done`, and `completed` statuses to render a recovery card.
- Shows `Download output` / `Open Output Center` first for export-ready tasks, with `Open Preview` only as secondary.

### 2. Trade changed to Structural Steel but preview card stayed Wall Types
File: `static/assets/app.js`
Functions:
- `activeActionFromText()`
- `renderRouteResult()`
- `applyBuilderCommandPlan()`
- `previewBuilderOutput()`

Fix:
- Adds a Builder plan fingerprint covering trade/function/custom quantity/unit/zone mode/project hierarchy/builder levels/workbook.
- Stores the fingerprint on preview data.
- Invalidates cached preview/output state when the active Builder plan changes.
- Typed `Preview` opens cached preview only when the cached preview fingerprint matches the current active plan.

### 3. Levels missing `L11 Mezz`; fallback used old workspace levels
File: `app.py`
Functions:
- `parse_levels_from_prompt()`
- `apply_active_builder_plan_amendment()`
- `apply_builder_run_context_snapshot()`

Fix:
- `GF to Level 11` now expands to `GF, L1 ... L11`.
- `Level 11 Mezzanine use Mezz as Code for Mezzanine` no longer returns early before the level reducer.
- The active Builder plan stores `explicit_level_instruction = True` when user level edits are applied.
- Export/preview snapshot no longer silently falls back to default workspace levels if an explicit level instruction exists but parsing fails.

## Files changed
- `app.py`
- `static/assets/app.js`
- `static/index.html` cache-buster only

## Files intentionally not changed
- Builder formula generation engine
- CostX formula construction
- Formatter
- Output Center architecture
- Database / large framework architecture
- UI redesign

# Jarvis v4.5.1.24.2A Test Report

## Static checks
- PASS — `python -m py_compile app.py`
- PASS — `node --check static/assets/app.js`

## Parser / reducer checks
- PASS — `Zone 2 contains Old and New while Zone 4 contains External and Internal` -> Zone 2 = `Old, New`; Zone 4 = `External, Internal`.
- PASS — `Use Zone 2 and 4` no longer creates a fake Zone 2 value of `4`.
- PASS — `Use Zone 2 and 4` while Builder trade clarification is pending stores selected zone slots and keeps trade clarification open.
- PASS — `Zone 2 at Head 1 and Zone 4 at Head 2` preserves Zone 2/4 values and assigns Head1/Head2.
- PASS — `Use Concrete instead` updates to `Concrete / Reo · XGETCUSTOM · Formworks · m2` while preserving project hierarchy.

## Snapshot / preview-export checks
- PASS — Backend request models accept `builder_run_snapshot`.
- PASS — Snapshot normalizer prioritizes snapshot `current_work_setup`, `builder_levels`, and `project_zone_hierarchy` before legacy request values.
- PASS — Preview formula smoke test generated `2|Old;3|B2;4|External` style tokens and did not contain `Milestone`.
- PASS — Export formula smoke test generated `2|Old;3|B2;4|External` style tokens and did not contain `Milestone`.
- PASS — Export report now shows `Run-only dynamic project hierarchy` instead of old `Walls - Milestone 2 by Level` when snapshot hierarchy is active.

## UI recovery check
- PASS — `export_ready` branch exists in `static/assets/app.js` recovery flow.

## Known remaining bugs / next patch
- Support Log visible-message pollution is intentionally excluded from 24.2A and should be patched in 24.2B.
- Delete Conversation remains archive/cleanup work for 24.2B.
- Recents naming/title update remains 24.2B.
- Framework scaffold remains v4.5.1.25 after this data-core build passes user testing.

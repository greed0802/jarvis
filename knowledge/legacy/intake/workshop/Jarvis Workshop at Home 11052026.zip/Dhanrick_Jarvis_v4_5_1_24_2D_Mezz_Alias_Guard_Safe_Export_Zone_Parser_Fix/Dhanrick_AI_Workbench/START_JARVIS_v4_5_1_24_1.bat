@echo off
setlocal
cd /d "%~dp0"
title Dhanrick Jarvis v4.5.1.24.1 - localhost:8505

echo ==========================================
echo  Dhanrick Jarvis v4.5.1.24.1
echo  Preview State + Support Log Leak + Dynamic Setup Snapshot Fix
echo  Starting on http://127.0.0.1:8505
echo ==========================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Creating local Python environment .venv ...
    py -3 -m venv .venv
    if errorlevel 1 python -m venv .venv
)

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: Could not create .venv. Install Python 3.10+ and tick Add Python to PATH.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"

if not exist ".venv\jarvis_requirements_installed_v4_5_1_24_1.txt" (
    python -m pip install --upgrade pip
    pip install -r requirements.txt
    if errorlevel 1 (
        echo ERROR: Package installation failed.
        pause
        exit /b 1
    )
    echo installed>".venv\jarvis_requirements_installed_v4_5_1_24_1.txt"
)

start "" "http://127.0.0.1:8505"
echo Jarvis is running. Keep this window open. Press CTRL+C to stop.
python app.py
pause

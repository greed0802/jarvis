# Jarvis UI Pack

Reusable SVG asset pack for the Jarvis ChatGPT-style interface.

## Included
- Jarvis hex J logo
- Sidebar icons (expanded + collapsed rail)
- Project / folder / menu icons
- Topbar icons
- Chat composer icons
- Compact action icons
- CSS design tokens
- CSS font pack recommendations
- SVG preview sheet

## Style
- Premium monochrome UI with blue Jarvis accent
- Clean outline iconography
- Rounded / squircle-friendly system
- Noob-friendly and minimal

## Font pack note
No font files are included in this pack.
Instead, `css/jarvis_font_pack.css` provides safe CSS font-family recommendations consistent with the Jarvis UI requirements.

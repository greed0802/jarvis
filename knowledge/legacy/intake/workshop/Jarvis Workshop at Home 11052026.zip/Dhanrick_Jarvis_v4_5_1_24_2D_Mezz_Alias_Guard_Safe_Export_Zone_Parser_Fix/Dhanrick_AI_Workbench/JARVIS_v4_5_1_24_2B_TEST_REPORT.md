# Jarvis v4.5.1.24.2B Test Report

## Static checks
- `node --check static/assets/app.js` — PASS
- `python -m py_compile app.py` — PASS

## Source-only regression checks

### Level parser exact prompt
Prompt:
`Levels are from GF to Level 11 with Level 11 Mezzanine use Mezz as Code for Mezzanine`

Expected:
`GF, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, L11 Mezzanine`

Result: PASS

### GF to Level 11 parser
Prompt:
`GF to Level 11`

Expected:
`GF, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11`

Result: PASS

### Active plan level reducer + Mezz alias
Prompt:
`Levels are from GF to Level 11 with Level 11 Mezzanine use Mezz as Code for Mezzanine`

Expected:
- `project_zone_hierarchy.level_values` populated
- `explicit_level_instruction = True`
- `mezzanine_token_alias = Mezz`
- Builder level rows include `L11 Mezz`

Result: PASS

## Manual tests to run in Jarvis after install

1. Export-ready refresh test
   - Run Builder export until output is ready.
   - Refresh browser.
   - Expected: recovery card shows Download output / Open Output Center first, not Preview-first.

2. Stale preview test
   - Start Wall Types Builder flow.
   - Preview.
   - Change to Structural Steel.
   - Type Preview.
   - Expected: Structural Steel preview regenerates; old Wall Types preview does not reopen.

3. Level output smoke test
   - Use zones Old/New and External/Internal.
   - Use levels `GF to Level 11 with Level 11 Mezzanine use Mezz as Code for Mezzanine`.
   - Expected workbook includes applicable `L11 Mezz` rows and no old B2/B3/LGF fallback unless requested.

# Jarvis v4.5.1.24.2D Test Report

Version: v4.5.1.24.2D Mezz Alias Guard + Safe Export Gate + Multiline Zone Parser Fix
Base: v4.5.1.24.2C Setup Review Action + Mezz Alias Direction + Level Summary Fix

## Static validation

- `python3 -m py_compile app.py` — PASS
- `node --check static/assets/app.js` — PASS
- Import `app.py` — PASS

## Targeted smoke tests

1. **Multiline zone parser**
   - Input:
     - `Zone 1: Old and New`
     - `Zone 2: External and Internal`
   - Expected: Zone 1 = Old/New, Zone 2 = External/Internal.
   - Result: PASS

2. **Mezz alias Formula Integrity Guard**
   - Project levels include `L11 Mezzanine` with `mezzanine_token_alias = Mezz`.
   - Formula token uses `3|L11 Mezz`.
   - Expected: Formula Integrity Guard passes.
   - Result: PASS

3. **Invalid level still blocked**
   - Formula token uses `3|Fake Level`.
   - Expected: Formula Integrity Guard blocks export.
   - Result: PASS

4. **Full Mezzanine without alias**
   - Formula token uses `3|L11 Mezzanine`.
   - Expected: Formula Integrity Guard passes.
   - Result: PASS

## Manual tests still required

Run the exact 24.2C problem flow and confirm:

- `Mezz as Code for Mezzanine` exports successfully.
- `Change Mezz to Mezzanine instead` exports with full `Mezzanine`.
- Review shows levels once only.
- Unsafe previews do not show/run export.
- Multiline zones do not create fake values such as `New Zone 2: External`.

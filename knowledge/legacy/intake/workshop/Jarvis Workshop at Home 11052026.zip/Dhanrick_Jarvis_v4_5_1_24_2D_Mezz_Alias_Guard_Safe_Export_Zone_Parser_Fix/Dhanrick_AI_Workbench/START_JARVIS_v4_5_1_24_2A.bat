@echo off
setlocal
cd /d "%~dp0"
echo Starting Jarvis v4.5.1.24.2A...
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if exist requirements.txt (
  python -m pip install -r requirements.txt
)
start "" http://127.0.0.1:8505
python -m uvicorn app:app --host 127.0.0.1 --port 8505
pause

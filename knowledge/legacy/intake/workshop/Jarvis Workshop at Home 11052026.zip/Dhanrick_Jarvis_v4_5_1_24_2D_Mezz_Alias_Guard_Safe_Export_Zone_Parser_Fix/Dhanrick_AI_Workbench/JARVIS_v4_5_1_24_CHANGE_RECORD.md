# Jarvis v4.5.1.24 Change Record

**Build:** v4.5.1.24 Router Clarification Bypass Fix + Active Plan Edit Fix + Alias Command Fix
**Date:** 2026-05-10
**Base:** v4.5.1.23

---

## Bugs Fixed

### Bug 1 (Critical) — Clarification bypass (app.py ~line 6114)
**Symptom:** When Jarvis is waiting for a clarification answer, user replies like
"1: Stage 1, 2, 3b" or "Project Type: Residential" triggered the fallback
"I'm not sure what you want me to do yet" instead of keeping the card open.

**Root cause:** `resolve_pending_clarification` returned `None` for replies that
didn't match any explicit keyword branch (e.g. zone-value replies to a
`hierarchy_option_choice` card). With `resolved_pending = None` and
`query_intent.intent == "clarification_answer"`, the outer router fell through
to `build_builder_command_plan` on a bare trade-free prompt, which returned
`None`, landing in `general_ai`.

**Fix:** Added a guard immediately after `resolve_pending_clarification`:
if `query_intent.intent == "clarification_answer"` and `resolved_pending is None`
and a pending clarification exists, re-wrap the pending dict as `resolved_pending`
so the clarification card stays open.

---

### Bug 2 (Critical) — Active-plan edit ignored for "use zone X and zone Y" (app.py)
**Symptom:** "Use two Zone 2 and Zone 4" → `general_ai` even though
`active_builder_plan` was True and `query_intent` detected `possible_active_plan_edit`.

**Root cause:** `is_active_builder_plan_amendment` only matched `zone N:` or
`zone N =` patterns. "zone 2 and zone 4" (no colon) was not matched, so
`apply_active_builder_plan_amendment` returned `None`, falling to `general_ai`.

**Fix 1:** Added regex `zone\s*\d+\s+and\s+zone\s*\d+` to `is_active_builder_plan_amendment`.
**Fix 2:** Added a normaliser at the top of `apply_active_builder_plan_amendment`
that converts "use zone 2 and zone 4" into "use zone 2; use zone 4" before
passing to the zone parsers.

---

### Bug 3 (High) — Alias commands not recognized as plan amendments (app.py)
**Symptom:** "Use Mezz as Mezzanine for formula" and "Mezz instead of Mezzanine"
returned `general_ai` even though an active builder plan was present and
`mezzanine_token_alias` logic already existed in `build_builder_command_plan`.

**Root cause:** Neither `is_active_builder_plan_amendment` nor
`apply_active_builder_plan_amendment` checked for `mezz`/`instead of`/`use X as Y`
patterns when operating on an active plan.

**Fix 1:** Added `mezz` + `instead of`/`as`/`use` pattern to `is_active_builder_plan_amendment`.
**Fix 2:** Added a short-circuit at the top of `apply_active_builder_plan_amendment`
that intercepts any mezzanine alias command and injects `mezzanine_token_alias: "Mezz"`
directly into the active plan and returns a patched copy.

---

### Bug 4 (High) — "Create" not a recognized build trigger when plan is active (app.py ~line 6020)
**Symptom:** Single-word "Create" with an active builder plan → `general_ai`.

**Root cause:** The approve-action hard-guard set did not include "create", "build",
"go", etc. `looks_like_fresh_command_backend` requires `len > 18` so single-word
prompts always fell through.

**Fix:** Added "create", "build", "go", "make it", "do it", "run it", "go ahead"
to the approve-action trigger set.

---

## Files Changed
- `app.py` — 5 targeted patches, ~45 lines added
- `JARVIS_v4_5_1_24_CHANGE_RECORD.md` — this file (new)
- `START_JARVIS_v4_5_1_24.bat` — updated launcher

## Files Unchanged
- All settings JSON files
- Frontend (static/index.html, styles.css, app.js)
- requirements.txt

# Jarvis v4.5.1.24.2C Test Report

Version: v4.5.1.24.2C Setup Review Action + Mezz Alias Direction + Level Summary Fix
Base: v4.5.1.24.2B Preview Cache + Export Restore + Level Reducer Fix
Date: 2026-05-11

## Static validation
- python3 -m py_compile app.py: PASS
- node --check static/assets/app.js: PASS

## Targeted source validation
- Repeated levels summary now prefers project_zone_hierarchy.level_values and dedupes fallback builder_levels: PASS
- Setup drawer primary action is Approve & Preview, secondary is Use setup only: PASS
- Low-confidence/review-risk approve message added: PASS
- Mezz directional parser added and used by active plan amendment path: PASS
- Cache-busting string updated in static/index.html: PASS
- Imported app.py and checked Mezz alias direction samples: PASS
- apply_active_builder_plan_amendment() cleared Mezz alias for “Change Mezz to Mezzanine instead”: PASS

## Required manual regression tests
1. Build flow with Zone 1 Old/New, Zone 2 External/Internal, GF-L11 + L11 Mezzanine.
   - Expected: Review setup shows each level once only.
2. Type Reviw.
   - Expected: Builder setup review opens; no Local AI fallback.
3. Type Change Mezz to Mezzanine instead.
   - Expected: active Builder plan amendment; no Local AI fallback.
4. Click Use setup only.
   - Expected: setup applied only; no preview/export.
5. Click Approve & Preview.
   - Expected: /api/builder/preview runs and Preview ready appears.
6. Low-confidence plan then Approve.
   - Expected: Jarvis says review is required and opens the setup review.

## Not tested here
- Live browser click/network behavior.
- Real Excel preview/export with Test.xlsx.

# Jarvis v4.5.1.24.2C Change Report

Version: v4.5.1.24.2C Setup Review Action + Mezz Alias Direction + Level Summary Fix
Base: v4.5.1.24.2B Preview Cache + Export Restore + Level Reducer Fix
Date: 2026-05-11

## Approved scope
- Fix repeated Levels display in Builder Setup Preview.
- Fix Mezz/Mezzanine directional active-plan amendment.
- Clarify Review / Approve / Use Setup action behavior.
- Add lightweight UI action diagnostics for review/approve/preview actions.

## Files changed
- app.py
- static/assets/app.js
- static/index.html

## Functions/areas changed
- app.py: APP_VERSION and health detail.
- app.py: is_active_builder_plan_amendment().
- app.py: _extract_replace_pair().
- app.py: new _parse_mezzanine_alias_direction().
- app.py: apply_active_builder_plan_amendment().
- static/assets/app.js: builderSetupSummaryHtml().
- static/assets/app.js: ensureBuilderSetupReviewDrawer().
- static/assets/app.js: activeActionFromText().
- static/assets/app.js: handleActiveActionReply().
- static/assets/app.js: approveBuilderCommandPlanAndPreview().
- static/assets/app.js: previewBuilderOutput().
- static/assets/app.js: review/use/approve click handlers.
- static/index.html: cache-busting asset query string.

## What changed
1. Builder Setup Preview now displays unique project levels from project_zone_hierarchy.level_values first. It only falls back to builder_levels after deduplication, because builder_levels is the expanded run list.
2. Setup Review drawer now uses Approve & Preview as the primary action and Use setup only as the secondary action.
3. Typed Review/Reviw/Revie is handled locally against the active Builder plan before falling through to /api/route.
4. Low-confidence/review-risk Approve now shows a clear assistant message that review is required first.
5. Mezz alias handling is directional:
   - Use Mezz as code for Mezzanine => set alias to Mezz.
   - Change Mezz to Mezzanine instead => clear alias and use full Mezzanine wording.
6. Lightweight UI diagnostic traces were added for review_setup_opened, use_setup_only, approve_preview, preview_started, preview_succeeded, and preview_failed.

## Stable logic not touched
- Builder formula/export engine.
- CostX formula string creation.
- Workbook export structure.
- Formatter.
- QA Checker.
- Output Center engine.

## Rollback
Replace this build with the previous v4.5.1.24.2B ZIP if action handling regresses.

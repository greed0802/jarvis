# Jarvis v4.5.1.24.2A — Snapshot + Slot Memory + Export State Hotfix

## Base
Built from `Dhanrick_Jarvis_v4_5_1_24_1_Preview_State_Support_Log_Snapshot_Fix.zip`.

## Scope
Focused data-core hotfix only. This patch does not include Support Log visible-message cleanup, Delete Conversation, Recents naming, framework scaffold, router migration, parser module migration, or Builder formula/export engine rewrite.

## Fixes included
1. Backend now accepts `builder_run_snapshot` on Builder preview/export/job requests.
2. Added `normalize_builder_run_snapshot_request()` so preview/run/jobs prioritize the locked snapshot before legacy Workspace/default setup.
3. Active project hierarchy is preserved when changing trade/profile, e.g. `Use Concrete instead` no longer drops Zone 2 / Zone 4 mapping.
4. Added slot-only zone handling for replies like `Use Zone 2 and 4`; this stores zone slots and keeps asking for trade instead of defaulting to Walls.
5. Dirty chained zone values are cleaned: `Zone 2 contains Old and New while Zone 4 contains External and Internal` parses as Zone 2 = Old/New and Zone 4 = External/Internal.
6. When a dynamic project hierarchy exists but explicit levels were not provided, preview/export rebuilds level rows from active hierarchy using the existing level labels only, avoiding old Milestone/default token leakage.
7. Output reports now mark the active preset/combo as `Run-only dynamic project hierarchy` when a snapshot hierarchy is used.
8. Recovery UI now has an `export_ready` branch so completed/exported tasks do not reopen as `Approve & Preview`.

## Excluded by design
- Support Log visible-message pollution — moved to 24.2B.
- Delete Conversation — moved to 24.2B because physical deletion is data-risky.
- Recents naming/title locking — moved to 24.2B.
- Framework scaffold — moved to v4.5.1.25 after data-core patch passes.
- Builder formula/export engine rewrite — not touched.

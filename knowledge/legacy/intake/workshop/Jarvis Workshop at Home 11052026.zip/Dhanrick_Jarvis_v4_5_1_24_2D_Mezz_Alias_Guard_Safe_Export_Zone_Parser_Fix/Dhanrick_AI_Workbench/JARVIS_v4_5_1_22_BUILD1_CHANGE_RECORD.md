# Jarvis v4.5.1.22 Build 1 — Conversation State Stabilizer + Recents Repair

## Scope kept
This Build 1 patch is limited to conversation stability and Recents/Resume/export alignment.

No Builder formula/export engine rewrite was made in this Build 1 edit.

Important source note: the uploaded source files already contained `APP_VERSION = v4.5.1.22 Conversation State Stabilizer + Builder Plan Reducer` and already matched the uploaded v4.5.1.22 handoff core files. This Build 1 package only adds safety/stability corrections around that source.

## Files changed
- `app.py`
- `static/assets/app.js`
- `static/index.html`

## Main fixes added in this Build 1 edit
- Relabelled app version to `v4.5.1.22 Build 1 Conversation State Stabilizer + Recents Repair` so this package is clearly the stability build.
- Preserved `event_ids` when compacting duplicate conversation shells, so browser retries or double-click events remain deduped after store compaction.
- Made chat export use the selected canonical conversation record when `conversation_id` is passed.
- Added conversation ID/title/project metadata to exported chat summaries.
- Added a frontend sidebar refresh in-flight guard and short throttle to reduce repeated `/api/conversations?limit=80` GET storms.
- Aligned frontend New Chat/Resume meaning check with backend behavior: a short real user message like `Hi` now keeps the conversation visible.
- Strengthened visible chat duplicate guard for repeated assistant and quick repeated user events.
- Added `cache: "no-store"` to canonical conversation event POSTs.
- Updated the `app.js` / `styles.css` cache keys in `static/index.html` to force the browser to load the Build 1 frontend.

## Not included
- No large database / Dexie / IndexedDB.
- No roadmapStore / patch ledger UI.
- No new Builder formula generation logic.
- No deep CostX/Excel export validation on the real Windows laptop.

## Suggested install
1. Stop the current Jarvis server.
2. Backup or rename the current folder first, for example:
   `D:\QS-GPT-App\Dhanrick_AI_Workbench_BACKUP_before_v4_5_1_22_Build1`
3. Extract this zip so the folder becomes:
   `D:\QS-GPT-App\Dhanrick_AI_Workbench`
4. Start Jarvis normally.
5. Open `http://localhost:8505`.
6. Hard refresh browser with `Ctrl + F5`.

## First retest
1. New Chat.
2. Type `Hi Jarvis`.
3. Jarvis should reply once only.
4. Recents should show one clean chat.
5. Refresh browser.
6. The same chat should reopen correctly.
7. Share / Export conversation should match the visible chat.
8. CMD / browser Network should not show continuous POST/GET spam while idle.

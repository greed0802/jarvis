@echo off
cd /d "%~dp0"
title Dhanrick Jarvis v4.5.1.24.1 - Simple Start
echo Starting Jarvis v4.5.1.24.1 using your current Python environment...
start "" "http://127.0.0.1:8505"
python app.py
pause

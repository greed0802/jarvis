# Jarvis v4.5.1.22 Build 1 — Test Report

## Static checks
- `python3 -m py_compile app.py` — PASS
- `node --check static/assets/app.js` — PASS

## Backend conversation store smoke test
- Duplicate conversation shell compaction keeps one canonical conversation row — PASS
- Greeting-only user message keeps conversation visible — PASS
- Merged duplicate shell preserves both message IDs/event IDs — PASS
- `/api/conversations` returns the canonical chat — PASS

## HTTP API smoke test
Using FastAPI TestClient:
- `POST /api/conversations` creates one conversation — PASS
- `POST /api/conversations/{id}/event` saves user message — PASS
- duplicate event ID is deduped — PASS
- `GET /api/conversations?limit=80` returns one visible chat — PASS
- `GET /api/conversations/{id}` returns the same saved message — PASS
- `GET /api/chat/export?kind=conversation&conversation_id={id}` exports the selected visible conversation — PASS

## Still needs laptop/browser retest
- Confirm no repeated `/api/conversations?limit=80` loop while idle.
- Confirm no repeated assistant reply after one send.
- Confirm Send button remains responsive after refresh.
- Confirm Recents, Resume, Share/Export conversation match the visible chat.
- Confirm current startup BAT points to the extracted Build 1 folder, not an old folder.

@echo off
cd /d "%~dp0"
title Dhanrick Jarvis v4.5.1.23 - Simple Start

echo Starting Jarvis with your current Python environment...
echo URL: http://127.0.0.1:8505
echo.
start "" "http://127.0.0.1:8505"
python app.py
pause

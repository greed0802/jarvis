@echo off
cd /d %~dp0
echo Starting Jarvis v4.5.1.24.2D simple mode...
python app.py
pause

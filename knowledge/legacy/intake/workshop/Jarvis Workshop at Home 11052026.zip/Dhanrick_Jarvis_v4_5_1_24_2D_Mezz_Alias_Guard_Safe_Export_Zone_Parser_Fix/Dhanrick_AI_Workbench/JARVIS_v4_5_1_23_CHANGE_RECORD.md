# Jarvis v4.5.1.23 Change Record

## Build name
Jarvis v4.5.1.23 — Builder Slot Memory + Attachment Recovery + Action Router Hard Fix

## Source base
Started from uploaded v4.5.1.22 Build 1 source package.

## Scope kept
This patch is a focused continuity/router repair patch. It does not rewrite the Builder formula/export engine, Formatter, Output Center, or add Dexie/IndexedDB/workbench database features.

## Main fixes

1. Builder action router hard fix
   - `review`, `reviw`, `revie`, `setup`, `show setup`, and similar short replies now route to the active Builder task when a Builder plan exists.
   - `approve`, `approved`, `ok approve`, `use this setup`, `use this run only setup`, and `run only` now route to Builder approval/preview instead of generic/local/support-log behavior.

2. Active Builder slot memory
   - Follow-up replies can amend the active Builder plan instead of starting unrelated new routes.
   - Zone heading replies such as `Head1 for Zone2 and Head2 for Zone1` seed a run-only project slot model if no project hierarchy exists yet.
   - Zone value replies such as `Zone 1: Old and New`, `Zone 2: Internal and External`, and `1: Stage 1, 2, 3b` merge into the active Builder plan.

3. Attachment/workbook recovery
   - Active Builder tasks now store and restore workbook metadata in the frontend active task.
   - Review/approve/preview/export paths restore the active workbook from the task before asking for a new upload.
   - Recovery after refresh shows a restored Builder setup when a plan exists instead of immediately treating the workbook as missing.

4. Level parser fix
   - `Levels are from GF to 11` and `Ground Floor to Level 11` now expand to `GF, L1, L2, ... L11`.
   - Mezz/Mezzanine aliases are preserved in level parsing.

5. No-hard-default blocker guard
   - Door BOQ remains `Doors / Windows · XGETCOUNT · no` instead of falling back to Walls / Partitions.
   - Steel quantity clarification still resolves to `Metalwork / Structural Steel · XGETCUSTOM · Weight · t` when the user answers `Use Weight`.
   - This is the emergency blocker version only, not the later full no-hard-defaults phase.

6. Phantom action guard
   - Sidebar/context actions no longer persist a fake `Delete confirmation` assistant message into chat unless the actual conversation action handler owns it.
   - Support log UI stays explicit and is not used for normal Builder review/approve routing.

7. Debug export canonical repair
   - `/api/debug/export` accepts the current `conversation_id` and uses that canonical conversation for visible messages, active task, active Builder plan, and active workbook.
   - Workflow health snapshot reports Builder activity if an active Builder plan exists, even if no separate builder job event has occurred yet.

## Known limitations
- This patch makes the active Builder task stable enough to continue testing, but it is not the full Phase 4/5 Builder intelligence overhaul.
- Full no-hard-default policy, advanced reducer behavior, project memory separation, and preview/export reliability remain later patch targets.

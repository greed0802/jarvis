@echo off
setlocal
cd /d "%~dp0"
echo Starting Jarvis v4.5.1.24.2A using existing Python environment...
start "" http://127.0.0.1:8505
python -m uvicorn app:app --host 127.0.0.1 --port 8505
pause

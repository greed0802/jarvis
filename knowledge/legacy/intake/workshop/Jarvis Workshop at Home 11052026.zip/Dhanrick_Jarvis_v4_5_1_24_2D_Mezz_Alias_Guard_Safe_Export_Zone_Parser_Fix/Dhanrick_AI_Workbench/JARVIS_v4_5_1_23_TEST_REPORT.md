# Jarvis v4.5.1.23 Test Report

## Static checks
- PASS — `python3 -m py_compile app.py`
- PASS — `node --check static/assets/app.js`

## Smoke tests passed

1. Level parser
   - PASS — `Levels are from GF to 11` -> `GF, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11`
   - PASS — `Ground Floor to Level 11` -> `GF, L1, ... L11`
   - PASS — Mezz/Mezzanine alias preserved.

2. Door BOQ routing
   - PASS — `Create me a Door BOQ base sheet` -> `Doors / Windows · XGETCOUNT · no`
   - PASS — Does not fall back to `Walls / Partitions · XGETWALLAREA · m2`.

3. Door zone/head merge
   - PASS — `Head1 for Zone2 and Head2 for Zone1`
   - PASS — `Zone 1: Old and New`
   - PASS — `Zone 2: Internal and External`
   - Final plan preserved Zone 2 = Head1, Zone 1 = Head2, Zone 1 values Old/New, Zone 2 values Internal/External.

4. Action router
   - PASS — `review` routes to active Builder setup.
   - PASS — `Reviw` routes to active Builder setup.
   - PASS — `Approve` routes to Builder approval/preview.
   - PASS — `Use this run only setup` routes to Builder approval/preview.
   - PASS — These did not route to Support Log.

5. Structural Concrete multi-zone merge
   - PASS — `Head1 for Zone 1, Head2 for Zone 4, Head3 for Zone 5`
   - PASS — `1: Stage 1, 2, 3b`
   - PASS — `4: Old and New`
   - PASS — `5: External and Internal`
   - Final plan preserved Zone 1 = Head1 with Stage 1/2/3b, Zone 4 = Head2 with Old/New, Zone 5 = Head3 with External/Internal.

6. Steel clarification flow
   - PASS — `Use Steel` asks which custom quantity.
   - PASS — `Use Weight` resolves to `Metalwork / Structural Steel · XGETCUSTOM · Weight · t`.

7. Debug export consistency
   - PASS — Debug export built from a selected conversation reported `visible_chat_messages > 0`.
   - PASS — Debug export reported `builder_or_job_events > 0` when an active Builder plan existed.
   - PASS — Debug export included active workbook metadata.

## Not covered by this build
- Full Builder preview/export regression on real workbook formulas.
- Full project memory separation.
- Full no-hard-default policy for every trade/profile.
- Full UI redesign.

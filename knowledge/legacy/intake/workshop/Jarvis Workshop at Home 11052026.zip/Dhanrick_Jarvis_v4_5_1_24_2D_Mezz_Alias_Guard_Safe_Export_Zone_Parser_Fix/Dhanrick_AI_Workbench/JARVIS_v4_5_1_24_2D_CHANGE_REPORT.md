# Jarvis v4.5.1.24.2D Change Report

Version: v4.5.1.24.2D Mezz Alias Guard + Safe Export Gate + Multiline Zone Parser Fix
Base: v4.5.1.24.2C Setup Review Action + Mezz Alias Direction + Level Summary Fix

## Scope

This patch fixes the issues found in the 24.2C test where export failed after using `Mezz` as the CostX token/code for `Mezzanine`, and where multiline zone values could be swallowed into the previous zone.

## Files changed

- `app.py`
- `static/assets/app.js`
- `static/index.html`

## Fixes

1. **Mezz alias Formula Integrity Guard acceptance**
   - `validate_builder_preview_integrity()` now accepts both raw/display level values such as `L11 Mezzanine` and alias-transformed CostX token values such as `L11 Mezz`.
   - This aligns validation with `build_project_builder_levels()` and `_level_label_for_project()`.

2. **Unsafe preview export gate**
   - If preview returns `safe_to_export: false`, the UI now shows `Preview blocked`, hides/disables export actions, and blocks `runBuilderCopy()` from starting the background export.
   - Formula Integrity Guard issues are shown directly in the preview drawer.

3. **Multiline zone parser fix**
   - `_parse_chained_zone_value_phrases()` now stops Zone N value capture before a newline followed by another `Zone N` clause.
   - This prevents `Zone 1: Old and New\nZone 2: External and Internal` from becoming `Old, New Zone 2: External, Internal`.

## Not touched

- Builder formula/export engine
- CostX formula generation
- Workbook export structure
- Formatter
- QA Checker
- Output Center engine

## Rollback

Rollback to v4.5.1.24.2C if this patch introduces UI/export gate regressions.

# Jarvis v4.5.1.24.1 — Preview State + Support Log Leak + Dynamic Setup Snapshot Fix

## Base
Built from `Dhanrick_Jarvis_v4_5_1_24_PATCHED.zip` because that branch had the better Claude-patched active-router flow.

## Scope
Hotfix only. Builder formula/export engine remains locked and unchanged.

## Fixes
- Hard-stops Support Log leakage when the current typed command is a Builder action such as Preview, Approved, Approve, Create, Proceed, Run Preview, or Use This.
- Keeps typed Preview in Builder flow. If a preview already exists, Preview opens the preview drawer instead of routing to Support Log or re-routing.
- Updates active task state to `preview_ready` after Builder preview succeeds.
- Updates active task state to `export_ready` after Builder export job completes.
- Review now opens the Builder Setup Preview drawer and shows the real setup summary instead of only saying “Builder plan ready.”
- Builder setup summary now renders dynamic zones and hierarchy zones properly.
- Preview/export payload now carries a locked `builder_run_snapshot` containing active plan, active workbook, active current_work_setup, active builder levels, and project name.
- `collectCurrentWorkSetupForRun()` now uses the active Builder plan/setup first, then falls back to UI workspace values. If active dynamic project hierarchy exists, preview/export sends `zone_token_mode = rebuild` instead of silently falling back to old Workspace/default zone combo.
- Export job polling persists `export_ready` state.

## Not changed
- No Builder formula/export engine rewrite.
- No Formatter change.
- No Output Center redesign.
- No Dexie/IndexedDB/database refactor.
- No automatic permanent project memory save.

const JARVIS_FRONTEND_VERSION_45125 = "v4.5.1.25 Framework Scaffold + Doors/Windows Source-Preserve Guard";
const sidePanel = document.getElementById("sidePanel");
const jTrigger = document.getElementById("jTrigger");
const panelClose = document.getElementById("panelClose");
const railButtons = document.querySelectorAll(".rail-btn");
const panelActions = document.querySelectorAll(".panel-action");
const views = document.querySelectorAll(".view");
const promptInput = document.getElementById("promptInput");
const fileInput = document.getElementById("fileInput");
const attachButton = document.getElementById("attachButton");
const attachmentMenu = document.getElementById("attachmentMenu");
const modeDropdownBtn = document.getElementById("modeDropdownBtn");
const modeDropdownMenu = document.getElementById("modeDropdownMenu");
const modeDropdownLabel = document.getElementById("modeDropdownLabel");
const quickActionRow = document.getElementById("quickActionRow");
const homeStack = document.querySelector(".home-stack");
const welcomeHero = document.getElementById("welcomeHero");
const profileMenuButton = document.getElementById("profileMenuButton");
const profileMenu = document.getElementById("profileMenu");
const topbarMoreButton = document.getElementById("topbarMoreButton");
const topbarMoreMenu = document.getElementById("topbarMoreMenu");
const shareButton = document.getElementById("shareButton");
const shareMenu = document.getElementById("shareMenu");
const activityLogButton = document.getElementById("activityLogButton");
const activityDrawer = document.getElementById("activityDrawer");
const activityCloseButton = document.getElementById("activityCloseButton");
const activityList = document.getElementById("activityList");
const activitySummary = document.getElementById("activitySummary");
const refreshActivityButton = document.getElementById("refreshActivityButton");
const sidebarContextMenu = document.getElementById("sidebarContextMenu");
const sidebarRestoreButton = document.getElementById("sidebarRestoreButton");
const appShell = document.getElementById("app");
const attachmentList = document.getElementById("attachmentList");
const sendBtn = document.getElementById("sendBtn");
const resultCard = document.getElementById("resultCard");
const resultTitle = document.getElementById("resultTitle");
const resultMeta = document.getElementById("resultMeta");
const resultBody = document.getElementById("resultBody");
const chatThread = document.getElementById("chatThread");
const toast = document.getElementById("toast");
const modeBtns = document.querySelectorAll(".mode-btn");
const modeSummary = document.getElementById("modeSummary");
const quickBtns = document.querySelectorAll(".quick-btn");
let lastActionMessageId = "";
const notifiedExportJobIds451242E = new Set();

const searchInput = document.getElementById("searchInput");
const searchList = document.getElementById("searchList");
const toolGrid = document.getElementById("toolGrid");
const outputList = document.getElementById("outputList");
const jobList = document.getElementById("jobList");
const healthGrid = document.getElementById("healthGrid");
const runQASmokeBtn = document.getElementById("runQASmokeBtn");
const runQAPanicBtn = document.getElementById("runQAPanicBtn");
const replayQALogBtn = document.getElementById("replayQALogBtn");
const qaLabResult = document.getElementById("qaLabResult");
const qaStableGate = document.getElementById("qaStableGate");
const qaCoverageResult = document.getElementById("qaCoverageResult");
const runQACoverageBtn = document.getElementById("runQACoverageBtn");
const runQAReleaseGateBtn = document.getElementById("runQAReleaseGateBtn");
const bugStatusFilter = document.getElementById("bugStatusFilter");
const bugScopeFilter = document.getElementById("bugScopeFilter");
const refreshBugStatusBtn = document.getElementById("refreshBugStatusBtn");
const previewLogCleanupBtn = document.getElementById("previewLogCleanupBtn");
const archiveLogCleanupBtn = document.getElementById("archiveLogCleanupBtn");
const restoreLogCleanupBtn = document.getElementById("restoreLogCleanupBtn");
const bugStatusResult = document.getElementById("bugStatusResult");
const qaSmartResult = document.getElementById("qaSmartResult");
const qaGenerateCategory = document.getElementById("qaGenerateCategory");
const qaGenerateCount = document.getElementById("qaGenerateCount");
const generateQAPackBtn = document.getElementById("generateQAPackBtn");
const refreshQAPacksBtn = document.getElementById("refreshQAPacksBtn");
const qaPackSelect = document.getElementById("qaPackSelect");
const runImportedQAPackBtn = document.getElementById("runImportedQAPackBtn");
const showQASchemaBtn = document.getElementById("showQASchemaBtn");
const qaImportText = document.getElementById("qaImportText");
const importQAPackBtn = document.getElementById("importQAPackBtn");
const importRunQAPackBtn = document.getElementById("importRunQAPackBtn");
const helperPromptBtn = document.getElementById("helperPromptBtn");
const helperBox = document.getElementById("helperBox");
const profileSelect = document.getElementById("profileSelect");
const setActiveProfileBtn = document.getElementById("setActiveProfileBtn");
const saveProfileBtn = document.getElementById("saveProfileBtn");
const profileKeyInput = document.getElementById("profileKeyInput");
const profileNameInput = document.getElementById("profileNameInput");
const profileDescriptionInput = document.getElementById("profileDescriptionInput");
const protectedUpperText = document.getElementById("protectedUpperText");
const protectedExactText = document.getElementById("protectedExactText");
const properPhrasesText = document.getElementById("properPhrasesText");
const slashWordsText = document.getElementById("slashWordsText");
const safetySummary = document.getElementById("safetySummary");
const backupList = document.getElementById("backupList");
const approvalList = document.getElementById("approvalList");
const createBackupBtn = document.getElementById("createBackupBtn");
const refreshSafetyBtn = document.getElementById("refreshSafetyBtn");
const restoreBackupSelect = document.getElementById("restoreBackupSelect");
const restoreTargetSelect = document.getElementById("restoreTargetSelect");
const requestRestoreApprovalBtn = document.getElementById("requestRestoreApprovalBtn");
const restoreSettingsBtn = document.getElementById("restoreSettingsBtn");
const localAIStatus = document.getElementById("localAIStatus");
const localAIResult = document.getElementById("localAIResult");
const localAIModelInput = document.getElementById("localAIModelInput");
const localAIPromptInput = document.getElementById("localAIPromptInput");
const refreshLocalAIBtn = document.getElementById("refreshLocalAIBtn");
const analyzeLocalAIBtn = document.getElementById("analyzeLocalAIBtn");
const analyzeAndFormatBtn = document.getElementById("analyzeAndFormatBtn");
const feedbackTextInput = document.getElementById("feedbackTextInput");
const previewFeedbackBtn = document.getElementById("previewFeedbackBtn");
const applyFeedbackBtn = document.getElementById("applyFeedbackBtn");
const feedbackPreview = document.getElementById("feedbackPreview");
const correctionTextInput = document.getElementById("correctionTextInput");
const correctionOutputFileInput = document.getElementById("correctionOutputFileInput");
const correctionRawFileInput = document.getElementById("correctionRawFileInput");
const correctionSampleFileInput = document.getElementById("correctionSampleFileInput");
const previewCorrectionBtn = document.getElementById("previewCorrectionBtn");
const applyCorrectionBtn = document.getElementById("applyCorrectionBtn");
const correctionPreview = document.getElementById("correctionPreview");
const outputSummary = document.getElementById("outputSummary");
const showLatestOutputsBtn = document.getElementById("showLatestOutputsBtn");
const archiveOldOutputsBtn = document.getElementById("archiveOldOutputsBtn");
const exportDebugLogBtn = document.getElementById("exportDebugLogBtn");
const clearAIReviewsBtn = document.getElementById("clearAIReviewsBtn");
const clearOldJobsBtn = document.getElementById("clearOldJobsBtn");
const termLibrarySummary = document.getElementById("termLibrarySummary");
const refreshTermLibraryBtn = document.getElementById("refreshTermLibraryBtn");
const scanUnknownTermsBtn = document.getElementById("scanUnknownTermsBtn");
const unknownTermsBox = document.getElementById("unknownTermsBox");
const teachTermInput = document.getElementById("teachTermInput");
const teachTermAction = document.getElementById("teachTermAction");
const teachTermValue = document.getElementById("teachTermValue");
const saveTeachTermBtn = document.getElementById("saveTeachTermBtn");
const analyzeClientLayoutBtn = document.getElementById("analyzeClientLayoutBtn");
const applyClientLayoutBtn = document.getElementById("applyClientLayoutBtn");
const clientLayoutResult = document.getElementById("clientLayoutResult");
const sampleFileInput = document.getElementById("sampleFileInput");
const sampleAttachButton = document.getElementById("sampleAttachButton");
const sampleFileStatus = document.getElementById("sampleFileStatus");
const sampleFormatResult = document.getElementById("sampleFormatResult");
const analyzeSampleFormatBtn = document.getElementById("analyzeSampleFormatBtn");
const learnSampleFormatBtn = document.getElementById("learnSampleFormatBtn");
const runFormatterSelfTestBtn = document.getElementById("runFormatterSelfTestBtn");
const formatterSelfTestResult = document.getElementById("formatterSelfTestResult");
const builderProjectNameInput = document.getElementById("builderProjectNameInput");
const builderTradeProfileSelect = document.getElementById("builderTradeProfileSelect");
const builderApplyTradeProfileBtn = document.getElementById("builderApplyTradeProfileBtn");
const builderTradeProfileSummary = document.getElementById("builderTradeProfileSummary");
const builderExpectedUnitInput = document.getElementById("builderExpectedUnitInput");
const builderCustomQuantitySelect = document.getElementById("builderCustomQuantitySelect");
const builderCustomQuantityUnitInput = document.getElementById("builderCustomQuantityUnitInput");
const builderTradeTypeSelect = document.getElementById("builderTradeTypeSelect"); // legacy only; v4.3.8 UI removed this duplicate selector
const builderFormulaModeSelect = document.getElementById("builderFormulaModeSelect");
const builderDefaultCostXFunctionSelect = document.getElementById("builderDefaultCostXFunctionSelect");
const builderCostXFunctionModeSelect = document.getElementById("builderCostXFunctionModeSelect");
const currentWorkSectionSummary = document.getElementById("currentWorkSectionSummary");
const zoneComboSectionSummary = document.getElementById("zoneComboSectionSummary");
const activeZonesSectionSummary = document.getElementById("activeZonesSectionSummary");
const builderRowsSectionSummary = document.getElementById("builderRowsSectionSummary");
const zoneLibrarySectionSummary = document.getElementById("zoneLibrarySectionSummary");
const builderSetupNotesInput = document.getElementById("builderSetupNotesInput");
const builderCurrentWorkSummary = document.getElementById("builderCurrentWorkSummary");
const builderPreviewBtn = document.getElementById("builderPreviewBtn");
const builderOutputReviewPanel = document.getElementById("builderOutputReviewPanel");
const builderPresetNameInput = document.getElementById("builderPresetNameInput");
const builderLoadLevelsBtn = document.getElementById("builderLoadLevelsBtn");
const builderAddLevelBtn = document.getElementById("builderAddLevelBtn");
const builderResetLevelsBtn = document.getElementById("builderResetLevelsBtn");
const builderSaveLevelsBtn = document.getElementById("builderSaveLevelsBtn");
const builderLevelTableBody = document.getElementById("builderLevelTableBody");
const builderLevelTableHead = document.getElementById("builderLevelTableHead");
const builderZoneLibraryTableBody = document.getElementById("builderZoneLibraryTableBody");
const builderAddZoneBtn = document.getElementById("builderAddZoneBtn");
const builderImportStandardZonesBtn = document.getElementById("builderImportStandardZonesBtn");
const builderActiveZonesGrid = document.getElementById("builderActiveZonesGrid");
const builderTokenPreview = document.getElementById("builderTokenPreview");
const builderZoneCategorySelect = document.getElementById("builderZoneCategorySelect");
const builderZoneComboSelect = document.getElementById("builderZoneComboSelect");
const builderApplyComboBtn = document.getElementById("builderApplyComboBtn");
const builderSaveComboBtn = document.getElementById("builderSaveComboBtn");
const builderDeleteComboBtn = document.getElementById("builderDeleteComboBtn");
const builderLevelZoneStatus = document.getElementById("builderLevelZoneStatus");

let currentMode = "Ask First";
let uploadedFile = null;
let uploadedFileRecord = null;
let uploadedFileRecords = [];
let tools = {};
let lastRouteData = null;
let lastBuilderCommandPlan = null;
let pendingClarification = null;
let pendingNewCommandText = "";
let chatMessages = [];
let activeResultMessageId = null;
let lastOutputDownloadUrl = "";
let isSubmittingCommand = false;
let lastSubmittedCommandText = "";
let commandRunOnlyBuilderLevels = null;
let commandRunOnlyProjectSetup = null;
let commandRunOnlyItemCodeConfig = null;
let formatterProfiles = {};
let activeFormatterProfile = "default_qs_boq";
let latestRestoreApprovalId = "";
let latestAIReview = null;
let qsTermLibrary = null;
let sampleFileRecord = null;
let builderLevelZoneSetup = null;
let builderCurrentWorkPersistTimer = null;
let builderCurrentWorkPersistInFlight = false;
let builderCurrentWorkPersistPendingOptions = null;
let sidebarContextTarget = null;
let latestBuilderPreviewData = null;
let activeConversationTask = null;
let setupApplyInFlight45122 = false;
let conversationInitialRefreshDone45122 = false;

const recent = [
  "QS CheckMate report",
  "Workbook Formatter",
  "Base Sheet Builder",
  "Local GPT setup",
  "Cloudflare tunnel",
  "Nextcloud Storage",
  "Jarvis UI mockup"
];

function setSidebarCollapsed(collapsed) {
  appShell?.classList.toggle("sidebar-collapsed", !!collapsed);
  sidePanel?.classList.toggle("open", !collapsed);
  if (sidebarRestoreButton) sidebarRestoreButton.hidden = !collapsed;
}

jTrigger?.addEventListener("click", () => setSidebarCollapsed(false));
panelClose?.addEventListener("click", () => setSidebarCollapsed(true));
sidebarRestoreButton?.addEventListener("click", () => setSidebarCollapsed(false));

railButtons.forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.view)));
panelActions.forEach(btn => btn.addEventListener("click", () => {
  if (btn.dataset.view) showView(btn.dataset.view);
}));

document.querySelectorAll(".recent-item[data-view]").forEach(btn => {
  btn.addEventListener("click", () => showView(btn.dataset.view));
});

document.querySelectorAll("[data-tool]").forEach(btn => {
  btn.addEventListener("click", () => openTool(btn.dataset.tool));
});

function setCurrentMode(mode) {
  currentMode = mode || "Ask First";
  modeBtns.forEach(b => b.classList.toggle("active", b.dataset.mode === currentMode));
  document.querySelectorAll(".mode-option").forEach(b => b.classList.toggle("active", b.dataset.mode === currentMode && !b.dataset.configureMode));
  if (modeSummary) modeSummary.textContent = currentMode;
  if (modeDropdownLabel) modeDropdownLabel.textContent = currentMode;
  showToast(`${currentMode} mode`);
}

function applyDensity(density) {
  const clean = density === "comfortable" ? "comfortable" : "compact";
  document.body.classList.toggle("density-compact", clean === "compact");
  document.body.classList.toggle("density-comfortable", clean === "comfortable");
  try { localStorage.setItem("jarvis_ui_density", clean); } catch {}
  showToast(`${clean === "compact" ? "Compact" : "Comfortable"} density applied`);
}
try { applyDensity(localStorage.getItem("jarvis_ui_density") || "compact"); } catch { document.body.classList.add("density-compact"); }

function hideFloatingMenus() {
  profileMenu?.classList.remove("show");
  topbarMoreMenu?.classList.remove("show");
  topbarMoreButton?.setAttribute("aria-expanded", "false");
  shareMenu?.classList.remove("show");
  shareButton?.setAttribute("aria-expanded", "false");
  sidebarContextMenu?.classList.remove("show");
}

function compactAction(label, attrs = "", danger = false) {
  const lower = String(label || "").toLowerCase();
  const isDanger = danger || lower.includes("cancel") || lower.includes("delete") || lower.includes("remove");
  const isPrimary = lower.includes("approve") || lower.includes("preview") || lower.includes("build base") || lower.includes("attach workbook") || lower.includes("export support") || lower.includes("export conversation");
  const tone = isDanger ? " danger" : isPrimary ? " primary" : " secondary";
  return `<button class="inline-action${tone}" type="button" ${attrs}>${escapeHtml(label)}</button>`;
}

function retireOldInlineActionRows() {
  if (!chatThread) return;
  const actionMessages = Array.from(chatThread.querySelectorAll(".chat-message.assistant")).filter(msg => msg.querySelector(".inline-action"));
  const latest = actionMessages[actionMessages.length - 1] || null;
  actionMessages.forEach(msg => {
    const isCurrent = msg === latest;
    msg.querySelectorAll(".inline-actions-row, .compact-action-row").forEach(row => row.classList.toggle("completed-actions", !isCurrent));
    msg.querySelectorAll("button.inline-action").forEach(btn => {
      if (!isCurrent) {
        btn.disabled = true;
        btn.setAttribute("aria-disabled", "true");
        btn.setAttribute("title", "This action belongs to an older step.");
      }
    });
  });
}

function isStaleActionButton(btn) {
  if (!btn || !btn.classList?.contains("inline-action")) return false;
  const msg = btn.closest(".chat-message.assistant");
  if (!msg || !chatThread) return false;
  const actionMessages = Array.from(chatThread.querySelectorAll(".chat-message.assistant")).filter(item => item.querySelector(".inline-action"));
  const latest = actionMessages[actionMessages.length - 1] || null;
  return !!latest && msg !== latest;
}

function copyableBlock(lines = [], actions = "", options = {}) {
  const text = lines.filter(Boolean).join("\n\n");
  const body = lines.filter(Boolean).map(line => `<p>${escapeHtml(line)}</p>`).join("");
  const cls = options.warn ? " warn" : options.danger ? " danger" : "";
  return `<div class="compact-response-block${cls}" data-copy-text="${escapeAttr(text)}">
    <button class="copy-block-btn" data-copy-block="1" title="Copy" aria-label="Copy response"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 0 1 1-1h9"/></svg></button>
    <div class="compact-block-body">${body}${actions ? `<div class="inline-actions-row">${actions}</div>` : ""}</div>
  </div>`;
}

function showSidebarContextMenu(event, type, label) {
  if (!sidebarContextMenu) return;
  event.preventDefault();
  event.stopPropagation();
  sidebarContextTarget = { type, label };
  sidebarContextMenu.classList.add("show");
  const rect = (event.currentTarget || event.target).getBoundingClientRect();
  const menuW = 232;
  const left = Math.min(rect.right + 6, window.innerWidth - menuW - 12);
  const top = Math.min(rect.top, window.innerHeight - 310);
  sidebarContextMenu.style.left = `${Math.max(8, left)}px`;
  sidebarContextMenu.style.top = `${Math.max(8, top)}px`;
  sidebarContextMenu.querySelectorAll('[data-context-action="new-project-chat"], [data-context-action="settings"]').forEach(btn => {
    btn.style.display = type === "project" ? "flex" : "none";
  });
  sidebarContextMenu.querySelector('[data-context-action="move"]')?.style.setProperty("display", type === "recent" ? "flex" : "none");
}

function setProjectFolderExpanded(folder, expanded) {
  const conversations = folder?.querySelector(".project-conversations");
  folder?.classList.toggle("expanded", !!expanded);
  conversations?.classList.toggle("collapsed", !expanded);
  const togglePath = folder?.querySelector(".folder-toggle .chevron-icon path");
  if (togglePath) togglePath.setAttribute("d", expanded ? "m6 9 6 6 6-6" : "m9 18 6-6-6-6");
}

function setActiveProjectFolder(projectName) {
  const folder = document.querySelector(`.project-folder[data-project="${CSS.escape(projectName)}"]`);
  if (folder) setProjectFolderExpanded(folder, true);
  document.querySelectorAll(".project-folder-head").forEach(head => head.classList.remove("active-folder-head"));
  folder?.querySelector(".project-folder-head")?.classList.add("active-folder-head");
}

function toggleProjectFolder(projectName) {
  const folder = document.querySelector(`.project-folder[data-project="${CSS.escape(projectName)}"]`);
  if (!folder) return;
  setProjectFolderExpanded(folder, !folder.classList.contains("expanded"));
}

modeBtns.forEach(btn => {
  btn.addEventListener("click", () => setCurrentMode(btn.dataset.mode));
});

document.querySelectorAll(".mode-option").forEach(btn => {
  btn.addEventListener("click", () => {
    if (btn.dataset.configureMode) {
      showView("settings");
      modeDropdownMenu?.classList.remove("show");
      return;
    }
    setCurrentMode(btn.dataset.mode);
    modeDropdownMenu?.classList.remove("show");
  });
});

modeDropdownBtn?.addEventListener("click", (event) => {
  event.stopPropagation();
  attachmentMenu?.classList.remove("show");
  modeDropdownMenu?.classList.toggle("show");
});

quickBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    if (!promptInput) return;
    promptInput.value = btn.dataset.prompt;
    handlePrompt();
  });
});

sendBtn?.addEventListener("click", handlePrompt);

promptInput?.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    handlePrompt();
  }
});

attachButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  modeDropdownMenu?.classList.remove("show");
  attachmentMenu?.classList.toggle("show");
});

document.querySelectorAll("[data-upload-files]").forEach(btn => btn.addEventListener("click", () => {
  attachmentMenu?.classList.remove("show");
  if (!fileInput) return;
  fileInput.value = ""; // allow selecting the same file again during testing
  fileInput.click();
}));

document.querySelectorAll("[data-future-capability]").forEach(btn => btn.addEventListener("click", () => {
  const capability = btn.dataset.futureCapability || "capability";
  attachmentMenu?.classList.remove("show");
  showToast(`${btn.textContent.trim()} ready for future routing`);
}));

document.addEventListener("click", (event) => {
  if (!event.target.closest("#attachmentMenu") && !event.target.closest("#attachButton")) attachmentMenu?.classList.remove("show");
  if (!event.target.closest("#modeDropdownMenu") && !event.target.closest("#modeDropdownBtn")) modeDropdownMenu?.classList.remove("show");
  if (!event.target.closest("#profileMenu") && !event.target.closest("#profileMenuButton")) profileMenu?.classList.remove("show");
  if (!event.target.closest("#topbarMoreMenu") && !event.target.closest("#topbarMoreButton")) {
    topbarMoreMenu?.classList.remove("show");
    topbarMoreButton?.setAttribute("aria-expanded", "false");
  }
  if (!event.target.closest("#shareMenu") && !event.target.closest("#shareButton")) {
    shareMenu?.classList.remove("show");
    shareButton?.setAttribute("aria-expanded", "false");
  }
  if (!event.target.closest("#sidebarContextMenu") && !event.target.closest("[data-project-menu]") && !event.target.closest("[data-recent-menu]")) {
    sidebarContextMenu?.classList.remove("show");
  }
});

profileMenuButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  topbarMoreMenu?.classList.remove("show");
  topbarMoreButton?.setAttribute("aria-expanded", "false");
  shareMenu?.classList.remove("show");
  shareButton?.setAttribute("aria-expanded", "false");
  profileMenu?.classList.toggle("show");
});

topbarMoreButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  profileMenu?.classList.remove("show");
  attachmentMenu?.classList.remove("show");
  modeDropdownMenu?.classList.remove("show");
  shareMenu?.classList.remove("show");
  shareButton?.setAttribute("aria-expanded", "false");
  topbarMoreMenu?.classList.toggle("show");
  topbarMoreButton?.setAttribute("aria-expanded", topbarMoreMenu?.classList.contains("show") ? "true" : "false");
});

shareButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  profileMenu?.classList.remove("show");
  topbarMoreMenu?.classList.remove("show");
  topbarMoreButton?.setAttribute("aria-expanded", "false");
  shareMenu?.classList.toggle("show");
  shareButton?.setAttribute("aria-expanded", shareMenu?.classList.contains("show") ? "true" : "false");
});

activityLogButton?.addEventListener("click", async (event) => {
  event.stopPropagation();
  await toggleActivityDrawer();
});
activityCloseButton?.addEventListener("click", () => closeActivityDrawer());
refreshActivityButton?.addEventListener("click", () => loadActivityLog());

document.querySelectorAll("[data-new-global-chat]").forEach(btn => btn.addEventListener("click", () => startNewChat({ project: "" })));
document.querySelectorAll("[data-project-open]").forEach(btn => btn.addEventListener("click", (event) => {
  if (event.target.closest("[data-project-menu]")) return;
  toggleProjectFolder(btn.dataset.projectOpen || "Jarvis");
}));
document.querySelectorAll("[data-project-chat]").forEach(btn => btn.addEventListener("click", () => startProjectChat(btn.dataset.projectChat || "Jarvis", btn.textContent.trim())));
document.querySelectorAll("[data-toggle-project-more]").forEach(btn => btn.addEventListener("click", () => toggleProjectMore(btn.dataset.toggleProjectMore || "Jarvis", btn)));
document.querySelectorAll("[data-project-menu]").forEach(btn => {
  btn.addEventListener("click", (event) => showSidebarContextMenu(event, "project", btn.dataset.projectMenu || "Project"));
  btn.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") showSidebarContextMenu(event, "project", btn.dataset.projectMenu || "Project");
  });
});

document.querySelectorAll("[data-recent-menu]").forEach(btn => {
  btn.addEventListener("click", (event) => showSidebarContextMenu(event, "recent", btn.dataset.recentMenu || "Recent chat"));
  btn.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") showSidebarContextMenu(event, "recent", btn.dataset.recentMenu || "Recent chat");
  });
});

document.querySelectorAll("[data-ui-density]").forEach(btn => btn.addEventListener("click", () => applyDensity(btn.dataset.uiDensity)));


fileInput?.addEventListener("change", async () => {
  const files = Array.from(fileInput.files || []);
  uploadedFile = files[0] || null;
  uploadedFileRecord = null;
  uploadedFileRecords = [];
  renderAttachmentList();
  setAttachState(files.length ? "Saving..." : "Attach");
  if (!files.length) return;
  try {
    for (const file of files) {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      let data = {};
      try { data = await res.json(); } catch { data = {}; }
      if (!res.ok) throw new Error(data.detail || `Upload failed for ${file.name} with HTTP ${res.status}`);
      data.filename = data.filename || file.name;
      data.file_type = detectAttachmentType(data.filename || file.name);
      data.is_workbook = isWorkbookName(data.filename || file.name);
      data.is_zip = isZipName(data.filename || file.name);
      uploadedFileRecords.push(data);
    }
    uploadedFileRecord = choosePrimaryWorkbook(uploadedFileRecords) || uploadedFileRecords[0] || null;
    setAttachState(uploadedFileRecords.length > 1 ? `${uploadedFileRecords.length} files` : "Attached");
    renderAttachmentList();
    showToast(uploadedFileRecords.length > 1 ? `${uploadedFileRecords.length} file(s) ready to send` : `${uploadedFileRecord?.filename || "File"} ready to send`);
  } catch (error) {
    uploadedFile = null; uploadedFileRecord = null; uploadedFileRecords = [];
    setAttachState("Attach"); renderAttachmentList();
    renderResult("Upload failed", "No file saved", copyableBlock(["Could not attach file.", error.message || "Unknown upload error"], "", { warn: true }));
    showToast(error.message || "Upload failed");
  }
});


exportDebugLogBtn?.addEventListener("click", async () => {
  const original = exportDebugLogBtn.textContent;
  exportDebugLogBtn.disabled = true;
  exportDebugLogBtn.textContent = "Preparing log...";
  try {
    const cid = currentConversationId ? `?conversation_id=${encodeURIComponent(currentConversationId)}` : "";
    const res = await fetch(`/api/debug/export${cid}`);
    if (!res.ok) {
      let detail = "Could not export support log";
      try { const data = await res.json(); detail = data.detail || detail; } catch {}
      throw new Error(detail);
    }
    const blob = await res.blob();
    const cd = res.headers.get("content-disposition") || "";
    const match = cd.match(/filename=\"?([^\";]+)\"?/i);
    const filename = match ? match[1] : `Jarvis_Debug_Report_${new Date().toISOString().slice(0,19).replace(/[:T]/g, "-")}.zip`;
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Support log exported");
    // v4.5.1.24.2E: keep support/debug export as a toast-only utility action.
    // Do not inject "Support log ready" into the visible chat, because it can
    // appear after Export and make successful Builder exports look like they
    // routed to Support Log.
  } catch (error) {
    showToast(error.message || "Export failed");
    renderResult("Support log export failed", "No file created", `<div class="notice warn"><strong>Could not export support log.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`);
  } finally {
    exportDebugLogBtn.disabled = false;
    exportDebugLogBtn.textContent = original;
  }
});

sampleAttachButton?.addEventListener("click", () => {
  if (!sampleFileInput) return;
  sampleFileInput.value = "";
  sampleFileInput.click();
});

sampleFileInput?.addEventListener("change", async () => {
  const file = sampleFileInput.files && sampleFileInput.files[0];
  sampleFileRecord = null;
  if (!file) return;
  if (sampleFileStatus) sampleFileStatus.textContent = "Saving sample...";
  const form = new FormData();
  form.append("file", file);
  try {
    const res = await fetch("/api/upload", { method: "POST", body: form });
    const data = await readJsonOrThrow(res, "Sample upload failed");
    sampleFileRecord = data;
    if (sampleFileStatus) sampleFileStatus.textContent = `Sample attached: ${data.saved_name || data.filename}`;
    if (sampleAttachButton) sampleAttachButton.textContent = "Sample Attached";
    showToast("Sample workbook saved");
    const html = `<div class="notice safe"><strong>Sample workbook attached.</strong><br>${escapeHtml(data.saved_name || "")}</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
  } catch (error) {
    sampleFileRecord = null;
    if (sampleFileStatus) sampleFileStatus.textContent = "Sample upload failed.";
    if (sampleFormatResult) sampleFormatResult.innerHTML = `<div class="notice warn">${escapeHtml(error.message || "Sample upload failed")}</div>`;
    showToast(error.message || "Sample upload failed");
  }
});

searchInput?.addEventListener("input", () => {
  const q = searchInput.value.toLowerCase();
  renderSearch(recent.filter(item => item.toLowerCase().includes(q)));
});

helperPromptBtn?.addEventListener("click", async () => {
  try {
    const res = await fetch("/api/helper-prompt");
    const data = await res.json();
    helperBox.textContent = data.template || "No helper prompt found.";
    helperBox.classList.add("show");
  } catch {
    helperBox.textContent = "Could not load helper prompt.";
    helperBox.classList.add("show");
  }
});


profileSelect?.addEventListener("change", () => fillProfileEditor(profileSelect.value));

setActiveProfileBtn?.addEventListener("click", async () => {
  const key = profileSelect?.value || activeFormatterProfile;
  try {
    const res = await fetch("/api/formatter/profiles/active", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ profile_key: key })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not set active profile");
    activeFormatterProfile = data.active_profile || key;
    showToast(`Active profile: ${activeFormatterProfile}`);
    await loadFormatterProfiles();
loadSafety();
loadOutputSummary();
  } catch (error) {
    showToast(error.message || "Profile error");
  }
});

saveProfileBtn?.addEventListener("click", async () => {
  try {
    const payload = {
      profile_key: profileKeyInput?.value || profileSelect?.value || "custom_profile",
      display_name: profileNameInput?.value || "Custom Formatter Profile",
      description: profileDescriptionInput?.value || "Custom Jarvis formatter profile.",
      protected_upper_text: protectedUpperText?.value || "",
      protected_exact_text: protectedExactText?.value || "",
      proper_phrases_text: properPhrasesText?.value || "",
      slash_words_text: slashWordsText?.value || "",
      set_active: true
    };
    const res = await fetch("/api/formatter/profiles/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not save profile");
    activeFormatterProfile = data.active_profile || data.profile_key;
    showToast("Formatter profile saved");
    await loadFormatterProfiles();
loadSafety();
    renderResult("Formatter profile saved", "Profile memory updated", `<div class="notice safe"><strong>${escapeHtml(data.profile?.display_name || data.profile_key)}</strong><br>Jarvis will use this profile for the next Formatter background job.</div>`);
  } catch (error) {
    renderResult("Profile save failed", "No profile changed", `<div class="notice warn">${escapeHtml(error.message || "Could not save profile")}</div>`);
  }
});


createBackupBtn?.addEventListener("click", async () => {
  await createSafetyBackup("Manual safety backup from Jarvis UI");
});

refreshSafetyBtn?.addEventListener("click", async () => {
  await loadSafety();
});

runFormatterSelfTestBtn?.addEventListener("click", async () => {
  await runFormatterSelfTest();
});

requestRestoreApprovalBtn?.addEventListener("click", async () => {
  const target = restoreTargetSelect?.value || "formatter_profiles.json";
  try {
    const res = await fetch("/api/approvals/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action_key: "backup_restore",
        description: `Restore ${target} from selected safety backup`,
        risk_level: 5,
        target
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not request approval");
    latestRestoreApprovalId = data.approval_id;
    showToast("Restore approval requested");
    renderResult("Restore approval requested", "Protected action", `<div class="notice warn"><strong>Approval ID:</strong> ${escapeHtml(data.approval_id)}<br>Type <strong>I APPROVE</strong> when prompted to approve restore.</div>`);
    await loadSafety();
  } catch (error) {
    showToast(error.message || "Approval request failed");
  }
});

restoreSettingsBtn?.addEventListener("click", async () => {
  const backup = restoreBackupSelect?.value || "";
  const target = restoreTargetSelect?.value || "formatter_profiles.json";
  if (!backup) { showToast("No backup selected"); return; }
  if (!latestRestoreApprovalId) {
    showToast("Request restore approval first");
    return;
  }
  const typed = window.prompt(`Protected restore for ${target}. Type I APPROVE to continue.`) || "";
  try {
    const approvalRes = await fetch("/api/approvals/decision", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approval_id: latestRestoreApprovalId, decision: "approved", typed_confirmation: typed })
    });
    const approval = await approvalRes.json();
    if (!approvalRes.ok) throw new Error(approval.detail || "Approval failed");
    const restoreRes = await fetch("/api/backups/restore-settings-file", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ backup_file: backup, target_file: target, approval_id: latestRestoreApprovalId })
    });
    const restored = await restoreRes.json();
    if (!restoreRes.ok) throw new Error(restored.detail || "Restore failed");
    showToast("Settings file restored");
    renderResult("Restore complete", "Backup guard", `<div class="notice safe"><strong>${escapeHtml(target)}</strong> restored from ${escapeHtml(backup)}.<br>Rollback backup created: ${escapeHtml(restored.pre_restore_backup || "")}</div>`);
    await loadSafety();
    await loadFormatterProfiles();
loadSafety();
  } catch (error) {
    renderResult("Restore blocked", "No restore applied", `<div class="notice warn">${escapeHtml(error.message || "Restore failed")}</div>`);
    showToast(error.message || "Restore failed");
  }
});

refreshLocalAIBtn?.addEventListener("click", async () => {
  await loadLocalAIStatus();
});

analyzeLocalAIBtn?.addEventListener("click", async () => {
  await analyzeWorkbookWithLocalAI();
});

analyzeAndFormatBtn?.addEventListener("click", async () => {
  await analyzeAndRunFormatter();
});

previewFeedbackBtn?.addEventListener("click", async () => {
  await previewFeedbackRules();
});

applyFeedbackBtn?.addEventListener("click", async () => {
  await applyFeedbackRulesSafely();
});

previewCorrectionBtn?.addEventListener("click", async () => {
  await previewCorrectionLoop();
});

applyCorrectionBtn?.addEventListener("click", async () => {
  await applyCorrectionLoop();
});

runQASmokeBtn?.addEventListener("click", () => runQALab("smoke"));
runQAPanicBtn?.addEventListener("click", () => runQALab("panic"));
replayQALogBtn?.addEventListener("click", replayQALog);
refreshBugStatusBtn?.addEventListener("click", loadBugStatus);
bugStatusFilter?.addEventListener("change", loadBugStatus);
bugScopeFilter?.addEventListener("change", loadBugStatus);
previewLogCleanupBtn?.addEventListener("click", () => runSafeLogCleanup("preview"));
archiveLogCleanupBtn?.addEventListener("click", () => { if (window.confirm("Archive old debug/support logs now? Latest logs and unresolved-bug evidence will be kept.")) runSafeLogCleanup("archive"); });
restoreLogCleanupBtn?.addEventListener("click", () => { if (window.confirm("Restore the latest archived log set?")) runSafeLogCleanup("restore_latest"); });
generateQAPackBtn?.addEventListener("click", generateQAPack);
refreshQAPacksBtn?.addEventListener("click", loadQAPacks);
runImportedQAPackBtn?.addEventListener("click", runSelectedQAPack);
runQACoverageBtn?.addEventListener("click", runQACoverageMap);
runQAReleaseGateBtn?.addEventListener("click", runQAReleaseGate);
showQASchemaBtn?.addEventListener("click", showQASchema);
importQAPackBtn?.addEventListener("click", () => importQAPack(false));
importRunQAPackBtn?.addEventListener("click", () => importQAPack(true));

showLatestOutputsBtn?.addEventListener("click", async () => {
  await loadOutputs(3);
  showToast("Showing latest outputs only");
});

archiveOldOutputsBtn?.addEventListener("click", async () => {
  await cleanupOutputs("archive_old_outputs", 3);
});

clearAIReviewsBtn?.addEventListener("click", async () => {
  await cleanupOutputs("clear_ai_reviews", 2);
});

clearOldJobsBtn?.addEventListener("click", async () => {
  await cleanupOutputs("clear_completed_jobs", 5);
});

refreshTermLibraryBtn?.addEventListener("click", loadTermLibrary);
scanUnknownTermsBtn?.addEventListener("click", scanUnknownTermsFromFeedback);
saveTeachTermBtn?.addEventListener("click", saveTeachTermToLibrary);
teachTermInput?.addEventListener("input", () => {
  if (teachTermValue && !teachTermValue.value) teachTermValue.value = teachTermInput.value;
});

function buildCurrentChatSummary() {
  const lines = ["# Jarvis Chat Summary", "", `Generated: ${new Date().toLocaleString()}`, ""];
  chatMessages.slice(-60).forEach(m => {
    const who = m.role === "user" ? "You" : "Jarvis";
    const files = Array.isArray(m.attachments) && m.attachments.length ? ` · files: ${m.attachments.map(a => a.filename || a.saved_name || a.name || "file").join(", ")}` : "";
    lines.push(`## ${who}${files}`);
    lines.push(String(m.text || "").trim() || "[no text]");
    lines.push("");
  });
  return lines.join("\n");
}

async function downloadChatExport(kind = "conversation") {
  try {
    const res = await fetch(`/api/chat/export?kind=${encodeURIComponent(kind)}`);
    if (!res.ok) throw new Error("Could not export conversation");
    const blob = await res.blob();
    const cd = res.headers.get("content-disposition") || "";
    const match = cd.match(/filename="?([^";]+)"?/i);
    const filename = match ? match[1] : `Jarvis_${kind}_${new Date().toISOString().slice(0,19).replace(/[:T]/g, "-")}.md`;
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast(kind === "project_context" ? "Project context exported" : "Conversation exported");
  } catch (error) {
    showToast(error.message || "Export failed");
  }
}

document.addEventListener("click", async event => {
  const viewAction = event.target.closest("[data-view]");
  if (viewAction && !viewAction.classList.contains("rail-btn") && !viewAction.classList.contains("panel-action")) {
    const view = viewAction.dataset.view;
    if (view) {
      showView(view);
      profileMenu?.classList.remove("show");
      topbarMoreMenu?.classList.remove("show");
      topbarMoreButton?.setAttribute("aria-expanded", "false");
      return;
    }
  }
  const possibleOldInlineAction = event.target.closest("button.inline-action");
  if (isStaleActionButton(possibleOldInlineAction)) {
    event.preventDefault();
    event.stopPropagation();
    appendAssistantConversation(["That action belongs to an older step. I’ll keep your current task active."], `${compactAction("Continue current task", "data-continue-previous-task='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`);
    return;
  }

  const copyBlockBtn = event.target.closest("[data-copy-block]");
  if (copyBlockBtn) {
    const block = copyBlockBtn.closest("[data-copy-text]");
    const text = block?.dataset.copyText || block?.innerText || "";
    try { await navigator.clipboard.writeText(text); showToast("Copied"); }
    catch { showToast("Copy unavailable"); }
    return;
  }
  const shareAction = event.target.closest("[data-copy-chat-summary], [data-export-conversation], [data-export-project-context]");
  if (shareAction) {
    shareMenu?.classList.remove("show");
    shareButton?.setAttribute("aria-expanded", "false");
    if (shareAction.dataset.copyChatSummary !== undefined) {
      const summary = buildCurrentChatSummary();
      try { await navigator.clipboard.writeText(summary); showToast("Chat summary copied"); } catch { showToast("Copy unavailable"); }
    } else if (shareAction.dataset.exportConversation !== undefined) {
      await downloadChatExport("conversation");
    } else if (shareAction.dataset.exportProjectContext !== undefined) {
      await downloadChatExport("project_context");
    }
    return;
  }
  const contextAction = event.target.closest("#sidebarContextMenu [data-context-action]");
  if (contextAction) {
    // v4.5.1.23: real conversation menu actions are handled by the dedicated
    // sidebar listener below. Do not render a chat-persisted Delete confirmation
    // from this generic menu path.
    if (sidebarContextTarget?.conversationId) return;
    const action = contextAction.dataset.contextAction || "action";
    const target = sidebarContextTarget?.label || "item";
    sidebarContextMenu?.classList.remove("show");
    if (action === "new-project-chat") startProjectChat(target, `New chat in ${target}`);
    else if (action === "settings") showView("settings");
    else if (action === "open") startProjectChat(sidebarContextTarget?.type === "project" ? target : "Recent", target);
    else if (action === "delete") { showToast("Delete/Archive is available from the conversation menu only."); }
    else showToast(`${contextAction.textContent.trim()} ready for saved conversations`);
    return;
  }
  const confirmDelete = event.target.closest("[data-confirm-delete]");
  if (confirmDelete) { showToast("Delete is disabled until conversation storage is active"); return; }
  const dismissResult = event.target.closest("[data-dismiss-result]");
  if (dismissResult) { resultCard?.classList.remove("show"); return; }
  const passiveAction = event.target.closest("[data-pin-chat], [data-remove-from-project], [data-archive-chat], [data-delete-chat]");
  if (passiveAction) {
    const label = passiveAction.textContent.trim() || "Action";
    topbarMoreMenu?.classList.remove("show");
    topbarMoreButton?.setAttribute("aria-expanded", "false");
    showToast(`${label} is ready for future saved conversations`);
    return;
  }
  const reviewBtn = event.target.closest("[data-local-ai-review]");
  if (reviewBtn) {
    await analyzeWorkbookWithLocalAI();
    return;
  }
  const applyBtn = event.target.closest("[data-apply-ai-suggestions]");
  if (applyBtn) {
    await applyLatestAISuggestionsSafely();
    return;
  }
  const reviewSetupBtn = event.target.closest("[data-review-builder-setup]");
  if (reviewSetupBtn) {
    traceBuilderUiAction451242C("review_setup_opened", { source: "button" });
    openBuilderSetupReviewDrawer();
    appendAssistantConversation(["Review opened. This is read-only. Use Approve & Preview when you’re ready, or Edit in chat to change the setup."], "", { meta: "review", persistConversation: false });
    return;
  }
  const useSetupBtn = event.target.closest("[data-use-reviewed-builder-setup]");
  if (useSetupBtn) {
    if (setupApplyInFlight45122) return;
    setupApplyInFlight45122 = true;
    traceBuilderUiAction451242C("use_setup_only_clicked", { source: "setup_review_drawer" });
    try {
      closeBuilderSetupReviewDrawer();
      const applied = await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true, openWorkspace: false });
      if (applied) appendAssistantConversation(["Setup applied only. No preview/export has been run yet."], `${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { meta: "setup" });
    } finally {
      window.setTimeout(() => { setupApplyInFlight45122 = false; }, 700);
    }
    return;
  }
  const setupEditChatBtn = event.target.closest("[data-edit-setup-in-chat]");
  if (setupEditChatBtn) {
    closeBuilderSetupReviewDrawer();
    if (promptInput) { promptInput.placeholder = "Tell Jarvis what to change in this Builder setup..."; promptInput.focus(); }
    return;
  }
  const setupAdvancedBtn = event.target.closest("[data-advanced-builder-setup]");
  if (setupAdvancedBtn) {
    restoreActiveBuilderPlanForAction();
    closeBuilderSetupReviewDrawer();
    await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true, openWorkspace: true });
    return;
  }
  const applyPlanBtn = event.target.closest("[data-apply-builder-plan]");
  if (applyPlanBtn) {
    restoreActiveBuilderPlanForAction();
    await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true, openWorkspace: !!applyPlanBtn.dataset.openWorkspace });
    return;
  }
  const clarificationBtn = event.target.closest("[data-clarification-reply]");
  if (clarificationBtn) {
    if (promptInput) promptInput.value = clarificationBtn.dataset.clarificationReply || "";
    await handlePrompt();
    return;
  }
  const startNewCommandBtn = event.target.closest("[data-start-new-command]");
  if (startNewCommandBtn) {
    const next = pendingNewCommandText || "";
    pendingClarification = null;
    pendingNewCommandText = "";
    commandRunOnlyBuilderLevels = null;
    commandRunOnlyProjectSetup = null;
    commandRunOnlyItemCodeConfig = null;
    if (promptInput) promptInput.value = next;
    appendChatMessage("assistant", "Previous pending task cancelled. Starting the new command now.", { meta: "new command" });
    await handlePrompt();
    return;
  }
  const continuePreviousBtn = event.target.closest("[data-continue-previous-task]");
  if (continuePreviousBtn) {
    pendingNewCommandText = "";
    if (!pendingClarification && activeConversationTask?.pending) pendingClarification = activeConversationTask.pending;
    if (pendingClarification) { renderPendingClarificationReminder(); return; }
    if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
    if (activeConversationTask?.workbook && !uploadedFileRecord) { uploadedFileRecord = activeConversationTask.workbook; uploadedFileRecords = [activeConversationTask.workbook]; }
    if (lastBuilderCommandPlan) {
      appendBuilderPlanConversation(lastBuilderCommandPlan, { hasFile: !!uploadedFileRecord || !!activeConversationTask?.workbook });
      return;
    }
    if (activeConversationTask?.status === "waiting_for_workbook") {
      appendAssistantConversation(["I’m ready to continue. Attach the Excel workbook to proceed."], `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "recovery" });
      return;
    }
    appendAssistantConversation(["Task context restored. Tell me the next change or start a new command."], `${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "recovery" });
    return;
  }
  const clearClarificationBtn = event.target.closest("[data-clear-clarification]");
  if (clearClarificationBtn) {
    pendingClarification = null;
    pendingNewCommandText = "";
    commandRunOnlyBuilderLevels = null;
    commandRunOnlyProjectSetup = null;
    commandRunOnlyItemCodeConfig = null;
    appendChatMessage("assistant", "Clarification cancelled. No setup was changed and no files were created.", { meta: "cancelled" });
    hideResultCard();
    return;
  }
  const cancelRouterBtn = event.target.closest("[data-cancel-router-plan]");
  if (cancelRouterBtn) {
    lastBuilderCommandPlan = null;
    pendingClarification = null;
    clearActiveConversationTask();
    commandRunOnlyBuilderLevels = null;
    commandRunOnlyProjectSetup = null;
    commandRunOnlyItemCodeConfig = null;
    hideResultCard();
    appendAssistantConversation(["Command plan cancelled. No Builder setup was applied and no files were changed."]);
    return;
  }
  const attachRequiredBtn = event.target.closest("[data-attach-workbook-required]");
  if (attachRequiredBtn) {
    promptForWorkbookAttachment();
    if (fileInput) {
      fileInput.value = "";
      fileInput.click();
    }
    return;
  }
  const approvePlanBtn = event.target.closest("[data-approve-builder-preview]");
  if (approvePlanBtn) {
    traceBuilderUiAction451242C("approve_preview_clicked", { source: "button" });
    await approveBuilderCommandPlanAndPreview(approvePlanBtn);
    return;
  }
  const previewBtn = event.target.closest("[data-preview-builder]");
  if (previewBtn) {
    await previewBuilderOutput(previewBtn);
    return;
  }
  const openPreviewDrawerBtn = event.target.closest("[data-open-preview-drawer]");
  if (openPreviewDrawerBtn) { openBuilderPreviewDrawer(); return; }
  const closePreviewDrawerBtn = event.target.closest("[data-close-preview-drawer]");
  if (closePreviewDrawerBtn) { closeBuilderPreviewDrawer(); return; }
  const closeSetupReviewBtn = event.target.closest("[data-close-setup-review]");
  if (closeSetupReviewBtn) { closeBuilderSetupReviewDrawer(); return; }
  const downloadPreviewBtn = event.target.closest("[data-download-preview-snapshot]");
  if (downloadPreviewBtn) { downloadBuilderPreviewSnapshot(); return; }
  const builderBtn = event.target.closest("[data-run-builder]");
  if (builderBtn) {
    await runBuilderCopy(builderBtn);
    return;
  }
  const panicFromChatBtn = event.target.closest("[data-run-panic-from-chat]");
  if (panicFromChatBtn) {
    showView("qa");
    await runQATest("panic");
    return;
  }
  const supportLogBtn = event.target.closest("[data-export-support-log]");
  if (supportLogBtn) {
    exportDebugLogBtn?.click();
    return;
  }
  const supportLogDetailsBtn = event.target.closest("[data-support-log-details]");
  if (supportLogDetailsBtn) {
    await openActivityDrawer();
    return;
  }
  const btn = event.target.closest("[data-run-formatter]");
  if (!btn) return;
  await runFormatterCopy(btn);
});

function activityMetaHtml(meta = {}) {
  const pairs = Object.entries(meta || {}).filter(([, value]) => value !== undefined && value !== null && value !== "");
  if (!pairs.length) return "";
  return `<div class="activity-meta-grid">${pairs.map(([key, value]) => `<span><b>${escapeHtml(key.replace(/_/g, " "))}</b>${escapeHtml(String(value))}</span>`).join("")}</div>`;
}

function renderActivityLog(data = {}) {
  if (!activityList) return;
  const items = Array.isArray(data.items) ? data.items : [];
  const workflow = data.workflow || {};
  if (activitySummary) {
    const last = workflow.last_builder_plan_summary || {};
    const active = last.trade ? `${last.trade} · ${last.function || "-"}${last.custom_quantity ? ` · ${last.custom_quantity}` : ""}` : "No active Builder snapshot in recent log";
    activitySummary.innerHTML = `<strong>Current trace</strong><br>${escapeHtml(active)}<br><small>${escapeHtml(workflow.last_prompt || "No recent prompt")}</small>`;
  }
  activityList.innerHTML = items.length ? items.map(item => `
    <article class="activity-item ${escapeHtml(item.status || "info")}">
      <div class="activity-item-top"><span>${escapeHtml(item.category || "Activity")}</span><time>${escapeHtml((item.time || "").replace("T", " "))}</time></div>
      <strong>${escapeHtml(item.title || item.event || "Event")}</strong>
      ${item.body ? `<p>${escapeHtml(item.body)}</p>` : ""}
      ${activityMetaHtml(item.meta)}
    </article>`).join("") : `<div class="activity-empty">No recent activity yet.</div>`;
}

async function loadActivityLog() {
  if (!activityList) return;
  activityList.innerHTML = `<div class="activity-empty">Loading Activity Log...</div>`;
  try {
    const res = await fetch("/api/activity/recent?limit=120&scope=current");
    const data = await readJsonOrThrow(res, "Could not load Activity Log");
    renderActivityLog(data);
  } catch (error) {
    activityList.innerHTML = `<div class="activity-empty warn">${escapeHtml(error.message || "Could not load Activity Log")}</div>`;
  }
}

async function openActivityDrawer() {
  activityDrawer?.classList.add("show");
  activityDrawer?.setAttribute("aria-hidden", "false");
  activityLogButton?.setAttribute("aria-expanded", "true");
  await loadActivityLog();
}

function closeActivityDrawer() {
  activityDrawer?.classList.remove("show");
  activityDrawer?.setAttribute("aria-hidden", "true");
  activityLogButton?.setAttribute("aria-expanded", "false");
}

async function toggleActivityDrawer() {
  if (activityDrawer?.classList.contains("show")) closeActivityDrawer();
  else await openActivityDrawer();
}

function showView(viewName) {
  views.forEach(view => view.classList.remove("active"));
  document.getElementById(`view-${viewName}`)?.classList.add("active");

  railButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.view === viewName));
  panelActions.forEach(btn => btn.classList.toggle("active", btn.dataset.view === viewName));

  if (viewName === "workspace") { loadTools(); renderBuilderTradeProfiles(DEFAULT_BUILDER_TRADE_PROFILES_UI, "walls_partitions");
loadBuilderLevelZoneSetup(); }
  if (viewName === "outputs") { loadOutputSummary(); loadJobs(); loadOutputs(); }
  if (viewName === "profiles") loadFormatterProfiles();
  if (viewName === "brain") { loadLocalAIStatus(); loadTermLibrary(); }
  if (viewName === "safety") loadSafety();
  if (viewName === "settings") loadHealth();
  if (viewName === "qa") renderQAReadyState();
}

function markChatStarted() {
  homeStack?.classList.add("chat-started");
  welcomeHero?.setAttribute("aria-hidden", "true");
  quickActionRow?.setAttribute("aria-hidden", "true");
}

function clearComposerAttachments(options = {}) {
  const keepActiveWorkbook = !!options.keepActiveWorkbook;
  const currentWorkbook = keepActiveWorkbook ? (choosePrimaryWorkbook(uploadedFileRecords) || uploadedFileRecord) : null;
  uploadedFileRecords = [];
  uploadedFile = null;
  if (!keepActiveWorkbook) uploadedFileRecord = null;
  else uploadedFileRecord = currentWorkbook || uploadedFileRecord;
  if (fileInput) fileInput.value = "";
  setAttachState("Attach");
  renderAttachmentList();
}

function resetActiveConversationState() {
  pendingClarification = null;
  pendingNewCommandText = "";
  lastRouteData = null;
  lastBuilderCommandPlan = null;
  latestBuilderPreviewData = null;
  activeResultMessageId = null;
  lastOutputDownloadUrl = "";
  clearActiveConversationTask();
  clearComposerAttachments({ keepActiveWorkbook: false });
  closeBuilderPreviewDrawer?.();
}

function startNewChat(options = {}) {
  chatMessages = [];
  resetActiveConversationState();
  resultCard?.classList.remove("show");
  if (resultBody) resultBody.innerHTML = "";
  if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = "Message Jarvis..."; }
  homeStack?.classList.remove("chat-started");
  welcomeHero?.removeAttribute("aria-hidden");
  quickActionRow?.removeAttribute("aria-hidden");
  renderChatThread();
  showView("home");
  const project = options.project || "";
  if (project) setActiveProjectFolder(project);
  showToast(project ? `New chat in ${project}` : "New chat");
}

function openProjectFolder(projectName) {
  toggleProjectFolder(projectName);
}

function startProjectChat(projectName, label = "") {
  startNewChat({ project: projectName });
  appendChatMessage("assistant", `Project chat ready for ${projectName}. Active, non-archived conversations in this folder can be used as project context in the future.`, { meta: "project context" });
  markChatStarted();
  if (promptInput) promptInput.placeholder = projectName && projectName !== "Jarvis" ? `Message ${projectName}...` : "Message Jarvis...";
}

function toggleProjectMore(projectName, btn) {
  const folder = document.querySelector(`.project-folder[data-project="${CSS.escape(projectName)}"]`);
  const more = folder?.querySelector(".project-more");
  if (!more) return;
  const isHidden = more.classList.toggle("hidden-project-item");
  btn.textContent = isHidden ? "Show more" : "Show less";
}

function normalizeTypos(value) {
  return String(value || "")
    .replace(/\bcreat\b/gi, "create")
    .replace(/\bbuilld\b|\bbuil\b|\bbuld\b/gi, "build")
    .replace(/\battch\b|\batach\b/gi, "attach")
    .replace(/\baprove\b/gi, "approve")
    .replace(/\bdowload\b|\bdwnload\b/gi, "download")
    .replace(/\bformatt\b/gi, "format")
    .replace(/\bcomapre\b|\bcompair\b/gi, "compare")
    .replace(/\bzonning\b/gi, "zoning")
    .replace(/\bmezanine\b/gi, "mezzanine");
}

function normalizeCommandText(value) {
  return normalizeTypos(value).trim().toLowerCase().replace(/\s+/g, " " );
}

function looksLikeNewCommand(value) {
  const text = normalizeCommandText(value);
  if (!text) return false;
  if (text.startsWith("new command:")) return true;
  const commandWords = ["create", "build", "make", "generate", "format", "compare", "write", "prepare", "run", "use new levels"];
  return text.length > 18 && commandWords.some(word => text.startsWith(word) || text.includes(` ${word} `));
}

function matchesPendingOption(value, clarification) {
  const text = normalizeCommandText(value);
  const options = Array.isArray(clarification?.options) ? clarification.options : [];
  return options.some(option => {
    const label = normalizeCommandText(option.label || "");
    const reply = normalizeCommandText(option.reply || "");
    return text && (text === label || text === reply || label.includes(text) || reply.includes(text) || text.includes(label) || text.includes(reply));
  });
}

function pendingClarificationAcceptsFreeformReply(clarification) {
  const type = String(clarification?.type || "").trim().toLowerCase();
  // v4.4.4.15.3: a custom hierarchy reply commonly contains words such as
  // Zone, Head, Stage, and even "make". Those are not new commands while
  // Jarvis is explicitly waiting for a custom hierarchy format.
  return type === "custom_hierarchy_format";
}

function autoResizeComposer() {
  if (!promptInput) return;
  promptInput.style.height = "auto";
  const maxHeight = 150;
  const next = Math.min(Math.max(promptInput.scrollHeight, 34), maxHeight);
  promptInput.style.height = `${next}px`;
  promptInput.style.overflowY = promptInput.scrollHeight > maxHeight ? "auto" : "hidden";
}

promptInput?.addEventListener("input", autoResizeComposer);

function setSendBusy(isBusy) {
  if (!sendBtn) return;
  sendBtn.disabled = !!isBusy;
  sendBtn.classList.toggle("is-busy", !!isBusy);
}

function attachmentKindLabel(record = {}) {
  const name = record.filename || record.saved_name || record.name || "file";
  if (isWorkbookName(name)) return "Excel workbook";
  if (/\.pdf$/i.test(name)) return "PDF";
  if (isZipName(name)) return "ZIP archive";
  if (/\.(png|jpe?g|webp|gif)$/i.test(name)) return "Image";
  return record.file_type || "File";
}

function renderAttachmentChipHtml(record = {}, options = {}) {
  const name = record.filename || record.saved_name || record.name || "file";
  const label = attachmentKindLabel(record);
  const primary = options.primary || record.is_workbook || isWorkbookName(name);
  return `<span class="file-chip${primary ? " primary" : ""}" title="${escapeAttr(name)}"><span class="file-chip-icon">${isWorkbookName(name) ? "XLSX" : label.slice(0, 3).toUpperCase()}</span><span class="file-chip-text"><strong>${escapeHtml(name)}</strong><small>${escapeHtml(label)}</small></span>${options.removable ? `<button class="file-chip-remove" type="button" data-remove-attachment="${escapeAttr(name)}" aria-label="Remove ${escapeAttr(name)}">×</button>` : ""}</span>`;
}

function renderMessageAttachments(records = []) {
  const clean = Array.isArray(records) ? records.filter(Boolean) : [];
  if (!clean.length) return "";
  return `<div class="message-attachments">${clean.map(r => renderAttachmentChipHtml(r)).join("")}</div>`;
}

function getChatScrollContainer() {
  return document.querySelector("#view-home .home-stack") || document.querySelector(".view.active") || document.scrollingElement || document.documentElement;
}

function updateComposerClearance() {
  const composer = document.getElementById("chatComposer");
  const scroller = getChatScrollContainer();
  if (!composer || !scroller) return;
  const rect = composer.getBoundingClientRect();
  const clearance = Math.max(110, Math.ceil(rect.height + 42));
  document.documentElement.style.setProperty("--composer-clearance-real", `${clearance}px`);
}

function scrollLatestChatMessageIntoView() {
  if (!chatThread) return;
  window.requestAnimationFrame(() => {
    updateComposerClearance();
    const scroller = getChatScrollContainer();
    const anchor = document.getElementById("chatBottomAnchor") || chatThread.querySelector(".chat-message:last-child");
    if (!scroller || !anchor) return;
    try {
      scroller.scrollTo({ top: scroller.scrollHeight, behavior: "smooth" });
    } catch {
      scroller.scrollTop = scroller.scrollHeight;
    }
    window.setTimeout(() => {
      try { scroller.scrollTo({ top: scroller.scrollHeight, behavior: "smooth" }); }
      catch { scroller.scrollTop = scroller.scrollHeight; }
    }, 90);
  });
}

window.addEventListener("resize", () => { updateComposerClearance(); scrollLatestChatMessageIntoView(); });

function makeWorkbookWorkflowClarification(record = {}) {
  const name = record.filename || record.saved_name || record.name || "the workbook";
  return {
    type: "tool_choice",
    question: `I received ${name}. What do you want me to do with this workbook?`,
    original_prompt: "Attached file",
    options: [
      { label: "Build base sheet", reply: "Build base sheet using current default setup" },
      { label: "Compare BOQ", reply: "Compare BOQ against measured quantities" },
      { label: "Format workbook", reply: "Format workbook using default QS BOQ format" },
      { label: "Write BOQ description", reply: "Write BOQ descriptions" }
    ],
    context: { source: "attachment_only", workbook: name }
  };
}

function isBaseSheetRequestText(value) {
  const text = normalizeCommandText(value);
  if (!text) return false;
  const direct = ["base sheet", "build base sheet", "boq base sheet", "build boq base sheet", "create boq base sheet", "create base sheet", "make base sheet", "build boq", "create boq"];
  if (direct.includes(text)) return true;
  return /(build|create|make|prepare).*(boq|base sheet)/.test(text) || /\bbase sheet\b/.test(text);
}

function isExplicitLocalAiRequest(value) {
  const text = normalizeCommandText(value);
  return /(open|launch|use|go to).*(open webui|webui|local ai|local gpt|ai\.dhanrickeviota\.com)/.test(text);
}

function setActiveConversationTask(task = null) {
  if (!task) { activeConversationTask = null; return; }
  const enriched = { ...task, updated_at: Date.now() };
  const currentWorkbook = choosePrimaryWorkbook(uploadedFileRecords) || uploadedFileRecord || activeConversationTask?.workbook || null;
  if (!enriched.workbook && currentWorkbook) enriched.workbook = currentWorkbook;
  if (!enriched.plan && lastBuilderCommandPlan) enriched.plan = lastBuilderCommandPlan;
  if (enriched.plan && enriched.workbook) enriched.plan = { ...enriched.plan, has_file: true, workbook: enriched.workbook };
  activeConversationTask = enriched;
}

async function persistActiveConversationTask451241(extra = {}) {
  if (!currentConversationId || !activeConversationTask) return;
  const merged = { ...activeConversationTask, ...extra, updated_at: Date.now() };
  if (lastBuilderCommandPlan && !merged.plan) merged.plan = lastBuilderCommandPlan;
  if ((uploadedFileRecord || merged.workbook) && !merged.workbook) merged.workbook = uploadedFileRecord;
  activeConversationTask = merged;
  try {
    await fetch(`/api/conversations/${encodeURIComponent(currentConversationId)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active_task: activeConversationTask, project: currentConversationProject || activeConversationTask.project || activeConversationTask.project_name || "" })
    });
    scheduleConversationSidebarRefresh45120(currentConversationId, 180);
  } catch {}
}

function clearActiveConversationTask() {
  activeConversationTask = null;
}

function restoreActiveWorkbookForBuilder() {
  const current = choosePrimaryWorkbook(uploadedFileRecords) || uploadedFileRecord;
  if (current?.saved_name) return current;
  const taskWorkbook = activeConversationTask?.workbook || lastBuilderCommandPlan?.workbook || null;
  if (taskWorkbook?.saved_name) {
    uploadedFileRecord = taskWorkbook;
    uploadedFileRecords = [taskWorkbook];
    return taskWorkbook;
  }
  return null;
}

function restoreActiveBuilderPlanForAction() {
  if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
  const wb = restoreActiveWorkbookForBuilder();
  if (lastBuilderCommandPlan && wb) {
    lastBuilderCommandPlan = { ...lastBuilderCommandPlan, has_file: true, workbook: wb };
    setActiveConversationTask({ ...(activeConversationTask || {}), type: activeConversationTask?.type || "build_base_sheet", status: activeConversationTask?.status || "plan_ready", plan: lastBuilderCommandPlan, workbook: wb });
  }
  return lastBuilderCommandPlan;
}

async function logVisibleChatEvent(role, text, options = {}) {
  try {
    const payload = {
      role,
      text: String(text || ""),
      meta: String(options.meta || ""),
      attachments: Array.isArray(options.attachments) ? options.attachments : [],
      active_task: activeConversationTask || null,
      pending_clarification_type: pendingClarification?.type || "",
      route_prompt: String(options.routePrompt || ""),
      source: "jarvis_ui"
    };
    await fetch("/api/chat/event", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  } catch (err) {
    // Logging must never block the user workflow.
  }
}

function traceBuilderUiAction451242C(action, detail = {}) {
  try {
    const payload = {
      action: String(action || ""),
      detail,
      has_plan: !!(lastBuilderCommandPlan || activeConversationTask?.plan),
      active_status: activeConversationTask?.status || "",
      has_workbook: !!(uploadedFileRecord?.saved_name || activeConversationTask?.workbook?.saved_name),
      created_at: new Date().toISOString()
    };
    console.info("[Jarvis UI Action]", payload);
    legacyLogVisibleChatEvent4514?.("system", `ui_action:${payload.action} ${JSON.stringify(payload)}`, { meta: "ui_action", persistConversation: false });
  } catch (err) {
    // Diagnostic action logging must never interrupt the tool workflow.
  }
}

function hideResultCard() {
  resultCard?.classList.remove("show");
}

function actionRowHtml(actions = []) {
  return `<div class="compact-action-row">${actions.filter(Boolean).join("")}</div>`;
}

function conversationalBlockHtml(lines = [], actions = "", options = {}) {
  const body = (Array.isArray(lines) ? lines : [lines]).filter(Boolean).map(line => `<p>${escapeHtml(line)}</p>`).join("");
  const cls = options.warn ? "notice warn" : options.safe ? "notice safe" : "conversational-reply";
  return `<div class="${cls}">${body}${actions ? actionRowHtml([actions]) : ""}</div>`;
}

function appendAssistantConversation(lines = [], actions = "", options = {}) {
  hideResultCard();
  return appendChatMessage("assistant", Array.isArray(lines) ? lines.join("\n") : String(lines || ""), {
    meta: options.meta || "",
    html: conversationalBlockHtml(lines, actions, options),
    kind: options.kind || "chat",
    // v4.5.1.24.2F: preserve UI-only flags so review/support/status
    // messages do not leak into canonical conversation exports.
    persistConversation: options.persistConversation,
    noConversationPersist: options.noConversationPersist,
    legacyTrace: options.legacyTrace
  });
}


function appendExportReadyConversation451242E(job) {
  const result = job?.result || {};
  const jobId = String(job?.job_id || result?.job_id || "");
  if (!jobId || notifiedExportJobIds451242E.has(jobId)) return;
  notifiedExportJobIds451242E.add(jobId);
  const downloadUrl = result.download_url || lastOutputDownloadUrl || "";
  const actions = `${downloadUrl ? `<a class="inline-action primary" href="${escapeAttr(downloadUrl)}">Download output</a>` : ""}${compactAction("Open Output Center", "onclick=\"showView('outputs'); loadJobs(); loadOutputs();\"")}${compactAction("View details", "data-open-output-details='1'")}`;
  appendChatMessage("assistant", "Output ready. Your BOQ base sheet has been exported.", {
    meta: "export",
    html: conversationalBlockHtml([
      "Output ready.",
      "Your BOQ base sheet has been exported."
    ], actions, { safe: true }),
    kind: "chat"
  });
}

function renderConversationalClarification(clarification) {
  const options = Array.isArray(clarification?.options) ? clarification.options : [];
  const actionLinks = options
    .filter(option => String(option.label || option.reply || "").trim().toLowerCase() !== "cancel")
    .map(option => {
      const label = option.label || option.reply || "Option";
      const reply = option.reply || label;
      return compactAction(label, `data-clarification-reply="${escapeAttr(reply)}"`);
    }).join("");
  const cancel = compactAction("Cancel", "data-clear-clarification='1'");
  return conversationalBlockHtml([clarification?.question || "Please clarify what you want Jarvis to do."], `${actionLinks}${cancel}`, { clarification: true });
}

function renderConversationalBuilderPlan(plan, options = {}) {
  if (!plan) return "";
  const setup = plan.current_work_setup || {};
  const hasFile = !!options.hasFile;
  const lowConfidence = isLowConfidenceBuilderPlan(plan);
  const trade = plan.trade_profile_name || setup.trade_profile_id || "BOQ";
  const func = plan.default_function || setup.default_costx_function || "the selected CostX function";
  const unit = plan.unit || setup.expected_unit || "the selected unit";
  if (lowConfidence) {
    return conversationalBlockHtml([
      "I need to review the Builder setup before previewing this BOQ base sheet.",
      "Please check the setup first, then run preview when ready."
    ], `${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { warn: false });
  }
  if (!hasFile) {
    return conversationalBlockHtml([
      "I can prepare this BOQ base sheet, but I need the Excel workbook first.",
      "Attach an .xlsx or .xlsm workbook to continue."
    ], `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { warn: true });
  }
  const projectSummary = renderProjectHierarchySummary(plan);
  return conversationalBlockHtml([
    "Plan ready.",
    `I’ll create a ${trade} base sheet using ${func} with ${unit} units.`
  ], `${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Edit setup", "onclick=\"showView('workspace')\"")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`) + (projectSummary || "");
}

function appendBuilderPlanConversation(plan, options = {}) {
  hideResultCard();
  return appendChatMessage("assistant", "Builder setup ready.", {
    meta: "",
    html: renderConversationalBuilderPlan(plan, options),
    kind: "chat"
  });
}

function appendChatMessage(role, text, options = {}) {
  if (!chatThread) return null;
  markChatStarted();
  const cleanAttachments = Array.isArray(options.attachments) ? options.attachments : [];
  const nowMs = Date.now();
  const last = chatMessages[chatMessages.length - 1];
  const duplicateWindowMs = role === "assistant" ? 2500 : 1200;
  if (!options.allowDuplicate && last && last.role === role && String(last.text || "") === String(text || "") && String(last.meta || "") === String(options.meta || "") && String(last.html || "") === String(options.html || "") && !cleanAttachments.length && (nowMs - Number(last._ms || 0)) < duplicateWindowMs) {
    return last.id;
  }
  const id = options.id || `msg_${nowMs}_${Math.random().toString(36).slice(2)}`;
  chatMessages.push({ id, role, text: String(text || ""), html: options.html || "", kind: options.kind || "chat", meta: options.meta || "", at: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), attachments: cleanAttachments, _ms: nowMs });
  logVisibleChatEvent(role, text, { ...options, attachments: cleanAttachments, message_id: id, event_id: id });
  if (chatMessages.length > 40) chatMessages = chatMessages.slice(-40);
  renderChatThread();
  return id;
}

function updateChatMessage(id, patch = {}) {
  const msg = chatMessages.find(item => item.id === id);
  if (!msg) return false;
  Object.assign(msg, patch, { at: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) });
  renderChatThread();
  return true;
}

function renderChatThread() {
  if (!chatThread) return;
  if (!chatMessages.length) { chatThread.innerHTML = ""; chatThread.classList.remove("show"); return; }
  chatThread.classList.add("show");
  chatThread.innerHTML = chatMessages.map(msg => `
    <div class="chat-message ${msg.role === "user" ? "user" : "assistant"} ${msg.kind === "result" ? "result-message" : ""}" data-message-id="${escapeAttr(msg.id || "")}">
      <div class="chat-avatar">${msg.role === "user" ? "DE" : "J"}</div>
      <div class="chat-bubble">
        <div class="chat-meta"><strong>${msg.role === "user" ? "You" : "Jarvis"}</strong><span>${escapeHtml(msg.meta || "")} ${escapeHtml(msg.at || "")}</span></div>
        <div class="chat-text">${msg.html ? msg.html : escapeHtml(msg.text)}</div>
        ${renderMessageAttachments(msg.attachments)}
      </div>
    </div>`).join("") + `<div id="chatBottomAnchor" class="chat-bottom-anchor" aria-hidden="true"></div>`;
  retireOldInlineActionRows();
  scrollLatestChatMessageIntoView();
}

function appendAssistantRouteMessage(data) {
  const route = data?.route || {};
  let text = data?.message || "I prepared a route.";
  if (route.clarification?.question) text = route.clarification.question;
  else if (route.builder_command_plan) {
    const plan = route.builder_command_plan;
    text = `I prepared a Builder plan: ${plan.trade_profile_name || "Builder"} · ${plan.default_function || ""}${plan.custom_quantity ? ` · ${plan.custom_quantity} (${plan.unit || ""})` : ""}.`;
  }
  appendChatMessage("assistant", text, { meta: "" });
}

function renderPendingClarificationReminder(extraMessage = "") {
  const card = pendingClarification ? renderClarificationCard(pendingClarification) : "";
  renderResult("Clarification", `Mode: ${currentMode}`, `
    ${extraMessage ? copyableBlock([extraMessage]) : ""}
    ${card || copyableBlock(["Please choose one option or type your answer."])}
  `);
}

function renderNewCommandWhilePending(newCommandText) {
  appendChatMessage("assistant", "I’m still waiting for your previous clarification. Do you want to start a new command instead?", { meta: "" });
  const actions = `${compactAction("Start new command", "data-start-new-command='1'")}${compactAction("Continue previous task", "data-continue-previous-task='1'")}${compactAction("Cancel", "data-clear-clarification='1'")}`;
  renderResult("new command?", `Mode: ${currentMode}`, copyableBlock(["I’m still waiting for your previous clarification.", `New command detected: ${newCommandText}`], actions, { warn: true }));
}


function cleanProjectName45120(value) {
  let name = String(value || "").replace(/\s+/g, " ").trim().replace(/^[:=\-–—\s]+|[:=\-–—\s.,;]+$/g, "");
  name = name.replace(/\b(please|pls|thanks|thank you|workbook|excel|file|attach|attached|when ready)\b.*$/i, "").trim();
  const parts = name.split(/\s+/).filter(Boolean);
  if (parts.length > 8) name = parts.slice(0, 8).join(" ");
  return name.slice(0, 120);
}

function extractProjectNameFromText45120(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const lower = raw.toLowerCase();
  if (/\b(what|which|where|who|how)\b.*\bproject\b/.test(lower) || lower.endsWith("?")) return "";
  const patterns = [
    /^\s*project\s*(?:name|title|no\.?|number)?\s*[:=\-–—]\s*(.+?)\s*$/i,
    /^\s*(?:project\s+is|project\s+name\s+is|project\s+title\s+is)\s+(.+?)\s*$/i,
    /\bfor\s+([A-Za-z0-9][A-Za-z0-9 &._/\-]{1,80}?)\s+project\b/i,
    /\bproject\s*(?:name|title)?\s+(?:as|to)\s+([A-Za-z0-9][A-Za-z0-9 &._/\-]{1,80})\b/i
  ];
  for (const pattern of patterns) {
    const match = raw.match(pattern);
    if (match?.[1]) return cleanProjectName45120(match[1]);
  }
  return "";
}

function isProjectQuestion45120(value) {
  const text = normalizeCommandText(value);
  return /\b(what|which)\b.*\bproject\b/.test(text) || /\bproject\b.*\b(are we|current|saved)\b/.test(text);
}

function getCurrentProjectNameFromContext45120(extraText = "") {
  if (currentConversationProject) return currentConversationProject;
  const active = activeConversationTask || {};
  for (const value of [active.project_name, active.project, active.prompt, active.original_prompt, extraText]) {
    const found = extractProjectNameFromText45120(value || "");
    if (found) return found;
  }
  for (let i = chatMessages.length - 1; i >= 0; i--) {
    if (chatMessages[i]?.role !== "user") continue;
    const found = extractProjectNameFromText45120(chatMessages[i].text || "");
    if (found) return found;
  }
  return "";
}

async function patchCurrentConversationProject45120(projectName, activeTask = activeConversationTask) {
  if (!projectName) return;
  currentConversationProject = projectName;
  if (activeTask) {
    activeConversationTask = { ...activeTask, project: projectName, project_name: projectName, updated_at: Date.now() };
  }
  try {
    if (currentConversationId) {
      await fetch(`/api/conversations/${encodeURIComponent(currentConversationId)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project: projectName, active_task: activeConversationTask || null })
      });
      scheduleConversationSidebarRefresh45120(currentConversationId, 120);
    }
  } catch {}
}

function captureProjectFromText45120(rawText) {
  const projectName = extractProjectNameFromText45120(rawText);
  if (!projectName) return "";
  currentConversationProject = projectName;
  if (activeConversationTask) activeConversationTask = { ...activeConversationTask, project: projectName, project_name: projectName, updated_at: Date.now() };
  return projectName;
}

async function handleProjectMemoryReply45120(rawText, outgoingAttachmentsSnapshot = []) {
  const directProject = extractProjectNameFromText45120(rawText);
  const isDirectProjectSlot = /^\s*project\s*(?:name|title|no\.?|number)?\s*[:=\-–—]/i.test(String(rawText || "")) || /^\s*(?:project\s+is|project\s+name\s+is|project\s+title\s+is)\s+/i.test(String(rawText || ""));
  if (isProjectQuestion45120(rawText)) {
    markChatStarted();
    appendChatMessage("user", rawText, { meta: currentMode, attachments: outgoingAttachmentsSnapshot });
    clearComposerAttachments({ keepActiveWorkbook: true });
    if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = currentConversationProject ? `Message ${currentConversationProject}...` : "Message Jarvis..."; }
    const projectName = getCurrentProjectNameFromContext45120(rawText);
    if (projectName) {
      await patchCurrentConversationProject45120(projectName);
      appendAssistantConversation([`We’re working on ${projectName}. I’ll keep that project name with this chat.`], `${activeConversationTask?.status === "waiting_for_workbook" ? compactAction("Attach workbook", "data-attach-workbook-required='1'") : ""}${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "project" });
    } else {
      appendAssistantConversation(["I don’t have a project name saved in this chat yet. Type it like: Project name: SNSW G25."], `${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "project" });
    }
    return true;
  }
  if (directProject && isDirectProjectSlot) {
    markChatStarted();
    setActiveConversationTask(activeConversationTask ? { ...activeConversationTask, project: directProject, project_name: directProject } : { type: "project_context", status: "active", project: directProject, project_name: directProject });
    currentConversationProject = directProject;
    appendChatMessage("user", rawText, { meta: currentMode, attachments: outgoingAttachmentsSnapshot });
    clearComposerAttachments({ keepActiveWorkbook: true });
    if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = `Message ${directProject}...`; }
    await patchCurrentConversationProject45120(directProject);
    appendAssistantConversation([
      `Saved project name: ${directProject}.`,
      activeConversationTask?.status === "waiting_for_workbook" ? "Attach the Excel workbook when ready, or keep adding project details." : "I’ll keep this detail with the current chat."
    ], `${activeConversationTask?.status === "waiting_for_workbook" ? compactAction("Attach workbook", "data-attach-workbook-required='1'") : ""}${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "project" });
    return true;
  }
  return false;
}


function stableJson451242B(value) {
  if (value === null || value === undefined) return "null";
  if (Array.isArray(value)) return `[${value.map(item => stableJson451242B(item)).join(",")}]`;
  if (typeof value === "object") {
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableJson451242B(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function builderPlanFingerprint451242B(plan = lastBuilderCommandPlan) {
  const activePlan = plan || activeConversationTask?.plan || null;
  if (!activePlan) return "";
  const setup = activePlan.current_work_setup || {};
  const pzh = activePlan.project_zone_hierarchy || setup.project_zone_hierarchy || null;
  const wb = uploadedFileRecord || activeConversationTask?.workbook || activePlan.workbook || null;
  return stableJson451242B({
    trade_profile_id: setup.trade_profile_id || activePlan.trade_profile_id || "",
    default_function: setup.default_costx_function || activePlan.default_function || "",
    custom_quantity: setup.custom_quantity_name || activePlan.custom_quantity || "",
    unit: setup.custom_quantity_unit || setup.expected_unit || activePlan.unit || "",
    zone_mode: activePlan.zone_mode || setup.zone_token_mode || "",
    project_zone_hierarchy: pzh || null,
    builder_levels: Array.isArray(activePlan.builder_levels) ? activePlan.builder_levels : [],
    workbook_saved_name: wb?.saved_name || ""
  });
}

function previewFingerprint451242B(data = latestBuilderPreviewData) {
  return String(data?.__builder_plan_fingerprint || data?.builder_plan_fingerprint || data?.builder_run_snapshot?.plan_fingerprint || "");
}

function cachedPreviewMatchesCurrentBuilderPlan451242B() {
  if (!latestBuilderPreviewData) return false;
  const cached = previewFingerprint451242B(latestBuilderPreviewData);
  const current = builderPlanFingerprint451242B();
  return !!cached && !!current && cached === current;
}

function invalidateBuilderPreviewCache451242B(reason = "") {
  latestBuilderPreviewData = null;
  lastOutputDownloadUrl = "";
  if (activeConversationTask) {
    const reset = { ...activeConversationTask };
    delete reset.preview;
    delete reset.last_export_job;
    if (reset.type === "build_base_sheet" && ["preview_ready", "export_ready", "done", "completed"].includes(String(reset.status || ""))) {
      reset.status = "plan_ready";
    }
    if (reason) reset.preview_invalidated_reason = reason;
    activeConversationTask = reset;
  }
}

function activeActionFromText(value) {
  const text = normalizeCommandText(value);
  if (!text) return null;
  const hasBuilderTask = !!(lastBuilderCommandPlan || activeConversationTask?.plan || activeConversationTask?.type === "build_base_sheet" || latestBuilderPreviewData);
  const approveWords = ["approve", "approved", "yes", "y", "proceed", "go", "go ahead", "looks good", "no need", "approve preview", "approve and preview", "approve & preview", "run preview", "create", "build", "do it", "ok", "okay", "ok approve"];
  const setupOnlyWords = ["use setup", "use this setup", "use this run only setup", "run only", "run only setup", "this run only"];
  const previewWords = ["preview", "show preview", "view preview", "open preview"];
  const reviewWords = ["edit", "edit setup", "change setup", "setup", "show setup", "review", "reviw", "revie", "review setup", "view setup", "check setup"];
  if (pendingClarification && (matchesPendingOption(text, pendingClarification) || ["use this setup", "use this run only setup", "run only", "this run only", "yes use it", "ok use setup"].includes(text))) return null;
  if (hasBuilderTask && reviewWords.includes(text)) return "edit_setup";
  if (hasBuilderTask && setupOnlyWords.includes(text)) return "use_setup_only";
  if (hasBuilderTask && latestBuilderPreviewData && previewWords.includes(text) && cachedPreviewMatchesCurrentBuilderPlan451242B()) return "open_preview";
  if (hasBuilderTask && previewWords.includes(text)) return "approve_builder_preview";
  if (hasBuilderTask && approveWords.includes(text)) return "approve_builder_preview";
  if ((lastBuilderCommandPlan || activeConversationTask) && ["cancel", "stop", "cancel task"].includes(text)) return "cancel_plan";
  if ((lastBuilderCommandPlan || activeConversationTask) && ["attach", "attach workbook", "upload workbook", "send file"].includes(text)) return "attach_workbook";
  if (latestBuilderPreviewData && cachedPreviewMatchesCurrentBuilderPlan451242B() && ["export", "export excel", "run", "run builder", "create output", "builder", "run builder in background"].includes(text)) return "export_builder";
  if (hasBuilderTask && ["export", "export excel", "run", "run builder", "create output", "builder", "run builder in background"].includes(text)) return "approve_builder_preview";
  if (lastOutputDownloadUrl && ["download", "download output", "get output", "open output"].includes(text)) return "download_output";
  return null;
}

async function handleActiveActionReply(rawText) {
  restoreActiveBuilderPlanForAction();
  const action = activeActionFromText(rawText);
  if (!action) return false;
  markChatStarted();
  appendChatMessage("user", rawText, { meta: currentMode, attachments: uploadedFileRecords.slice() });
  clearComposerAttachments({ keepActiveWorkbook: true });
  if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = "Message Jarvis..."; }
  if (action === "approve_builder_preview") {
    if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
    if (activeConversationTask?.workbook && !uploadedFileRecord) { uploadedFileRecord = activeConversationTask.workbook; uploadedFileRecords = [activeConversationTask.workbook]; }
    traceBuilderUiAction451242C("approve_preview_typed", { text: rawText });
    await approveBuilderCommandPlanAndPreview(null);
    return true;
  }
  if (action === "use_setup_only") {
    if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
    if (activeConversationTask?.workbook && !uploadedFileRecord) { uploadedFileRecord = activeConversationTask.workbook; uploadedFileRecords = [activeConversationTask.workbook]; }
    traceBuilderUiAction451242C("use_setup_only_typed", { text: rawText });
    const applied = await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true, openWorkspace: false });
    if (applied) appendAssistantConversation(["Setup applied only. No preview/export has been run yet."], `${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { meta: "setup" });
    return true;
  }
  if (action === "open_preview") { traceBuilderUiAction451242C("open_preview_typed", { text: rawText }); openBuilderPreviewDrawer(); return true; }
  if (action === "edit_setup") {
    if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
    if (activeConversationTask?.workbook && !uploadedFileRecord) { uploadedFileRecord = activeConversationTask.workbook; uploadedFileRecords = [activeConversationTask.workbook]; }
    traceBuilderUiAction451242C("review_setup_typed", { text: rawText });
    openBuilderSetupReviewDrawer();
    appendAssistantConversation(["Review opened. This is read-only. Use Approve & Preview when you’re ready, or Edit in chat to change the setup."], "", { meta: "review", persistConversation: false });
    return true;
  }
  if (action === "cancel_plan") {
    lastBuilderCommandPlan = null;
    pendingClarification = null;
    clearActiveConversationTask();
    appendAssistantConversation(["Cancelled. No Builder setup was applied and no files were changed."]);
    return true;
  }
  if (action === "attach_workbook") { promptForWorkbookAttachment(); fileInput?.click(); return true; }
  if (action === "export_builder") { await runBuilderCopy(null); return true; }
  if (action === "download_output") { const a = document.createElement("a"); a.href = lastOutputDownloadUrl; a.download = ""; document.body.appendChild(a); a.click(); a.remove(); return true; }
  return false;
}

async function handlePrompt() {
  let text = promptInput?.value.trim() || "";

  if (!text && uploadedFileRecords.length) text = "Attached file";
  if (!text) {
    appendAssistantConversation(["Tell me what you want to do."]);
    return;
  }

  if (isSubmittingCommand) {
    showToast("Jarvis is already processing this command");
    appendChatMessage("assistant", "I’m already processing your last message. Please wait a moment.", { meta: "" });
    renderChatThread();
    return;
  }

  markChatStarted();
  const rawText = text;
  const lowerText = normalizeCommandText(rawText);
  const pendingOriginal = normalizeCommandText(pendingClarification?.original_prompt || "");
  const outgoingAttachmentsSnapshot = uploadedFileRecords.slice();
  const outgoingWorkbookSnapshot = choosePrimaryWorkbook(outgoingAttachmentsSnapshot);
  const routeHasFile = !!(uploadedFileRecord || outgoingWorkbookSnapshot || activeConversationTask?.workbook);
  const isAttachmentOnlyMessage = lowerText === "attached file" && outgoingAttachmentsSnapshot.length > 0;
  const isPendingClarificationReply = !!pendingClarification && (matchesPendingOption(rawText, pendingClarification) || pendingClarificationAcceptsFreeformReply(pendingClarification));
  captureProjectFromText45120(rawText);

  if (!isAttachmentOnlyMessage && await handleProjectMemoryReply45120(rawText, outgoingAttachmentsSnapshot)) { isSubmittingCommand = false; setSendBusy(false); return; }

  if (!pendingClarification && !isAttachmentOnlyMessage && await handleActiveActionReply(rawText)) return;

  if (pendingClarification) {
    if (lowerText.startsWith("new command:")) {
      pendingClarification = null;
      pendingNewCommandText = "";
      text = rawText.replace(/^new command:\s*/i, "").trim();
      if (!text) {
        appendAssistantConversation(["Previous task cancelled. Type the new command you want Jarvis to run."]);
        return;
      }
    } else if (pendingOriginal && lowerText === pendingOriginal) {
      appendAssistantConversation(["Please choose one option or type your answer."], renderConversationalClarification(pendingClarification));
      if (promptInput) promptInput.value = "";
      return;
    } else if (lastSubmittedCommandText && lowerText === normalizeCommandText(lastSubmittedCommandText)) {
      appendAssistantConversation(["Please choose one option or type your answer."], renderConversationalClarification(pendingClarification));
      if (promptInput) promptInput.value = "";
      return;
    } else if (looksLikeNewCommand(rawText) && !matchesPendingOption(rawText, pendingClarification) && !pendingClarificationAcceptsFreeformReply(pendingClarification)) {
      if (outgoingAttachmentsSnapshot.length || /\b(?:boq|base sheet|window|door|zone|level|head)\b/i.test(rawText)) {
        pendingClarification = null;
        pendingNewCommandText = "";
        clearActiveConversationTask();
      } else {
        pendingNewCommandText = rawText;
        renderNewCommandWhilePending(rawText);
        return;
      }
    }
  }

  const needsWorkbookForBaseSheet45121 = !isAttachmentOnlyMessage && !routeHasFile && isBaseSheetRequestText(rawText);
  if (needsWorkbookForBaseSheet45121) {
    pendingClarification = null;
    lastBuilderCommandPlan = null;
    const projectName45120 = getCurrentProjectNameFromContext45120(rawText);
    setActiveConversationTask({
      type: "build_base_sheet",
      status: "waiting_for_workbook",
      prompt: rawText,
      original_prompt: rawText,
      project: projectName45120 || currentConversationProject || "",
      project_name: projectName45120 || currentConversationProject || "",
      created_at: Date.now()
    });
    if (projectName45120) await patchCurrentConversationProject45120(projectName45120);
  }

  isSubmittingCommand = true;
  setSendBusy(true);
  lastSubmittedCommandText = text;
  if (!isPendingClarificationReply) activeResultMessageId = null;
  await commitConversationShell45121(currentConversationProject || getCurrentProjectNameFromContext45120(rawText) || "");
  const outgoingAttachments = outgoingAttachmentsSnapshot;
  appendChatMessage("user", text, { meta: currentMode, attachments: outgoingAttachments });
  clearComposerAttachments({ keepActiveWorkbook: true });
  if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = "Message Jarvis..."; }

  // v4.5.1.21: If the user asks for a base sheet without a workbook, the
  // active task was already attached before the user message was saved, so
  // Resume/Recents keep the correct Builder contract.
  if (needsWorkbookForBaseSheet45121) {
    appendAssistantConversation(["Sure — I can prepare a BOQ base sheet. Please attach the Excel workbook first."], `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`);
    isSubmittingCommand = false;
    setSendBusy(false);
    return;
  }

  // v4.5.1.8: File-only Excel messages are part of the current conversation state.
  // They should merge into a pending Builder task, or ask what to do with the workbook.
  if (isAttachmentOnlyMessage && outgoingWorkbookSnapshot) {
    if (activeConversationTask?.type === "build_base_sheet" && activeConversationTask.status === "waiting_for_workbook") {
      const originalInstruction = activeConversationTask.original_prompt || activeConversationTask.prompt || lastSubmittedCommandText || "Build base sheet from attached workbook";
      setActiveConversationTask({
        ...activeConversationTask,
        status: "workbook_received",
        workbook: outgoingWorkbookSnapshot,
        original_prompt: originalInstruction,
        prompt: originalInstruction,
        project: currentConversationProject || activeConversationTask.project || activeConversationTask.project_name || "",
        project_name: currentConversationProject || activeConversationTask.project_name || activeConversationTask.project || ""
      });
      // v4.5.1.21: route the original user-visible instruction, not a synthetic
      // file message or Workspace default. This protects Door/Window, Old/New,
      // Internal/External, Zone and Level instructions after attachment.
      text = originalInstruction;
    } else if (lastBuilderCommandPlan) {
      pendingClarification = null;
      setActiveConversationTask({ type: "build_base_sheet", status: "workbook_received", workbook: outgoingWorkbookSnapshot });
      appendBuilderPlanConversation(lastBuilderCommandPlan, { hasFile: true });
      isSubmittingCommand = false;
      setSendBusy(false);
      return;
    } else {
      pendingClarification = makeWorkbookWorkflowClarification(outgoingWorkbookSnapshot);
      setActiveConversationTask({ type: "workbook_uploaded", status: "waiting_for_workflow", workbook: outgoingWorkbookSnapshot });
      hideResultCard();
      appendChatMessage("assistant", pendingClarification.question, { meta: "", html: renderConversationalClarification(pendingClarification) });
      isSubmittingCommand = false;
      setSendBusy(false);
      return;
    }
  }

  try {
    const res = await fetch("/api/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: text, mode: currentMode, has_file: routeHasFile, pending_clarification: pendingClarification, active_builder_plan: lastBuilderCommandPlan })
    });
    const data = await res.json();
    lastRouteData = data;
    const renderedRouteCard = renderRouteResult(data);
    if (!renderedRouteCard) appendAssistantRouteMessage(data);
    maybeRunAutoPreview(data);
  } catch (error) {
    appendChatMessage("assistant", "Could not connect to the Jarvis backend.", { meta: "error" });
    hideResultCard();
  } finally {
    isSubmittingCommand = false;
    setSendBusy(false);
  }
}

function maybeRunAutoPreview(data) {
  const route = data?.route || {};
  if (currentMode !== "AutoPilot") return;
  if (data?.action !== "autopilot_preview") return;
  if (route.tool_key !== "builder") return;
  if (!lastBuilderCommandPlan || isLowConfidenceBuilderPlan(lastBuilderCommandPlan)) return;
  if (!uploadedFileRecord?.saved_name) return;
  const confidence = Number(route.confidence || lastBuilderCommandPlan.confidence || 0);
  const risk = String(lastBuilderCommandPlan.risk || route.risk || "low").toLowerCase();
  if (confidence < 88 || risk !== "low") return;
  window.setTimeout(async () => {
    appendChatMessage("assistant", "AutoPilot is safe to preview. I’ll apply the setup and run Builder preview only. Export still needs approval.", { meta: "AutoPreview" });
    await approveBuilderCommandPlanAndPreview(null);
  }, 250);
}

function renderRouteResult(data) {
  const route = data.route || {};
  const tool = route.tool || {};
  if (route.builder_command_plan) {
    const oldFingerprint = builderPlanFingerprint451242B(lastBuilderCommandPlan || activeConversationTask?.plan || null);
    const newFingerprint = builderPlanFingerprint451242B(route.builder_command_plan);
    if (oldFingerprint && newFingerprint && oldFingerprint !== newFingerprint) invalidateBuilderPreviewCache451242B("builder_plan_changed");
    lastBuilderCommandPlan = route.builder_command_plan;
  }
  if (route.clarification) pendingClarification = route.clarification;
  else if (data.action !== "clarification_needed") pendingClarification = null;

  const intent = String(route.intent || "");
  if (route.tool_key === "health") {
    hideResultCard();
    appendAssistantConversation(["I’ll open the Health view so you can check Jarvis services and folders."], `${compactAction("Open Health", "data-view='settings'")}`);
    return true;
  }
  if (route.tool_key === "qa_lab") {
    hideResultCard();
    appendAssistantConversation(["I can run the Panic / Regression QA test from QA Lab."], `${compactAction("Open QA Lab", "data-view='qa'")}${compactAction("Run Panic Test", "data-run-panic-from-chat='1'")}`);
    return true;
  }
  if (route.tool_key === "support_log") {
    const lastText = normalizeCommandText(lastSubmittedCommandText || "");
    const builderActive = !!(lastBuilderCommandPlan || activeConversationTask?.plan || latestBuilderPreviewData);
    if (builderActive && ["preview", "approved", "approve", "create", "proceed", "run preview", "use this", "go ahead"].includes(lastText)) {
      appendAssistantConversation(["I kept this in the Builder flow. Support log is only for explicit debug/export requests."], `${latestBuilderPreviewData ? compactAction("Open Preview", "data-open-preview-drawer='1'") : compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Review setup", "data-review-builder-setup='1'")}`, { meta: "builder" });
      if (latestBuilderPreviewData) openBuilderPreviewDrawer();
      return true;
    }
    hideResultCard();
    appendAssistantConversation(["Support log ready to export."], `${compactAction("Export support log", "data-export-support-log='1'")}${compactAction("View details", "data-support-log-details='1'")}`, { meta: "support", persistConversation: false });
    return true;
  }
  if (intent.includes("greeting")) {
    hideResultCard();
    return false;
  }

  if (route.clarification) {
    hideResultCard();
    pendingClarification = route.clarification;
    const clarificationPlan = route.builder_command_plan || lastBuilderCommandPlan || activeConversationTask?.plan || null;
    setActiveConversationTask({ type: clarificationPlan ? "build_base_sheet" : "clarification", status: "waiting_for_reply", pending: route.clarification, plan: clarificationPlan, workbook: uploadedFileRecord || activeConversationTask?.workbook || null });
    appendChatMessage("assistant", route.clarification.question || "Please clarify what you want Jarvis to do.", { meta: "", html: renderConversationalClarification(route.clarification) });
    return true;
  }

  const reviewRouteText451242F = normalizeCommandText(data.prompt || lastSubmittedCommandText || "");
  const reviewRouteNext451242F = String(route.next_action || data.next_action || route.action || data.action || "").toLowerCase();
  const isReviewRoute451242F = route.tool_key === "builder"
    && (reviewRouteNext451242F.includes("review") || intent.includes("builder_action_router"))
    && ["review", "reviw", "revie", "review setup", "show setup", "check setup", "setup"].includes(reviewRouteText451242F);
  if (isReviewRoute451242F && (lastBuilderCommandPlan || route.builder_command_plan || activeConversationTask?.plan)) {
    if (!lastBuilderCommandPlan && (route.builder_command_plan || activeConversationTask?.plan)) lastBuilderCommandPlan = route.builder_command_plan || activeConversationTask.plan;
    const activeWorkbook = uploadedFileRecord || activeConversationTask?.workbook || null;
    const hasFile = !!activeWorkbook || !!data?.context_snapshot?.has_file || !!route?.context_snapshot?.has_file;
    setActiveConversationTask({ type: "build_base_sheet", status: hasFile ? "plan_ready" : "waiting_for_workbook", plan: lastBuilderCommandPlan, workbook: activeWorkbook });
    openBuilderSetupReviewDrawer();
    appendAssistantConversation(["Review opened. This is read-only. Use Approve & Preview when you’re ready, or Edit in chat to change the setup."], "", { meta: "review", persistConversation: false });
    return true;
  }

  if (lastBuilderCommandPlan && route.tool_key === "builder") {
    const activeWorkbook = uploadedFileRecord || activeConversationTask?.workbook || null;
    const hasFile = !!activeWorkbook || !!data?.context_snapshot?.has_file || !!route?.context_snapshot?.has_file;
    setActiveConversationTask({ type: "build_base_sheet", status: hasFile ? "plan_ready" : "waiting_for_workbook", plan: lastBuilderCommandPlan, workbook: activeWorkbook });
    appendBuilderPlanConversation(lastBuilderCommandPlan, { hasFile });
    return true;
  }

  if (data.action === "need_more_info") {
    hideResultCard();
    if (route.tool_key === "builder") {
      const activeWorkbook = uploadedFileRecord || activeConversationTask?.workbook || null;
      setActiveConversationTask({ type: "build_base_sheet", status: activeWorkbook ? "plan_ready" : "waiting_for_workbook", plan: lastBuilderCommandPlan || activeConversationTask?.plan || null, workbook: activeWorkbook });
      if (activeWorkbook && (lastBuilderCommandPlan || activeConversationTask?.plan)) {
        if (!lastBuilderCommandPlan && activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
        appendBuilderPlanConversation(lastBuilderCommandPlan, { hasFile: true });
      } else {
        appendAssistantConversation(["Sure — I can prepare a BOQ base sheet. Please attach the Excel workbook first."], `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`);
      }
    } else {
      appendAssistantConversation([data.message || "I need more information before continuing."]);
    }
    return true;
  }

  if (route.tool_key === "boq_writer") {
    appendAssistantConversation([data.message || "I can help write BOQ descriptions. Tell me the item or paste the descriptions you want rewritten."]);
    return true;
  }

  if ((tool.url || tool.local_url) && !isExplicitLocalAiRequest(data.prompt || lastSubmittedCommandText)) {
    appendAssistantConversation(["I’m not sure what you want me to do yet. Tell me the task, or attach a workbook if this is for BOQ work."]);
    return true;
  }

  if (data.action === "approval_required") {
    appendAssistantConversation([data.message || "This action needs approval before running."]);
    return true;
  }

  hideResultCard();
  appendAssistantRouteMessage(data);
  return true;
}

function renderClarificationCard(clarification) {
  const options = Array.isArray(clarification?.options) ? clarification.options : [];
  const filteredOptions = options.filter(option => {
    const label = String(option.label || option.reply || "").trim().toLowerCase();
    return label && label !== "cancel";
  });
  const actionLinks = filteredOptions.map(option => {
    const label = option.label || option.reply || "Option";
    const reply = option.reply || label;
    return compactAction(label, `data-clarification-reply="${escapeAttr(reply)}"`);
  }).join("");
  const footerActions = `${actionLinks}${compactAction("Cancel", "data-clear-clarification='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`;
  return copyableBlock([
    clarification?.question || "Please clarify what you want Jarvis to do."
  ], footerActions, { clarification: true });
}


function isLowConfidenceBuilderPlan(plan) {
  if (!plan) return false;
  const confidence = Number(plan.confidence || 0);
  return !!plan.requires_review_before_preview || plan.next_action === "review_setup_first" || plan.risk === "review" || confidence < 70;
}

function renderProjectHierarchySummary(plan) {
  const project = plan?.project_zone_hierarchy || plan?.current_work_setup?.project_zone_hierarchy || null;
  if (!project) return "";
  const levels = Array.isArray(project.level_values) ? project.level_values.join(", ") : "";
  const zones = Array.isArray(project.dynamic_zones) ? project.dynamic_zones : [];
  const zoneLines = zones.map(z => {
    const idx = z.zone_index || "?";
    const role = z.role || "zone";
    const values = Array.isArray(z.values) ? z.values.join(", ") : "";
    return `Zone ${idx} (${role}): ${values}`;
  }).join("<br>");
  const hierarchy = project.hierarchy_description || `${project.head3_label || "Selected zone"} = Head3; detected dimensions/types${project.head4_combo_label && project.head4_combo_label !== "None" ? " + " + project.head4_combo_label : ""} = Head4; levels = rows.`;
  let summaryLines = [];
  if (Array.isArray(project.hierarchy_summary_lines) && project.hierarchy_summary_lines.length) {
    summaryLines = project.hierarchy_summary_lines;
  } else if (Array.isArray(project.hierarchy_zones) && project.hierarchy_zones.length) {
    summaryLines = project.hierarchy_zones.map(z => {
      const vals = Array.isArray(z.values) ? z.values.join(", ") : "";
      return `Zone ${z.zone_index} / ${z.head || "Head"}: ${vals}`;
    });
    if (Array.isArray(project.dimension_combo_zones) && project.dimension_combo_zones.length) {
      project.dimension_combo_zones.forEach(z => {
        const vals = Array.isArray(z.values) ? z.values.join(", ") : "";
        summaryLines.push(`Detected dimension/type + Zone ${z.zone_index} / ${project.dimension_head || "next Head"}: ${vals}`);
      });
    } else if (project.dimension_head) {
      summaryLines.push(`Detected dimension/type / ${project.dimension_head}: source dimension/type names`);
    }
    if (levels) summaryLines.push(`Levels / Zone ${project.level_zone_index || 3}: ${levels}`);
  } else {
    const dynZones = Array.isArray(project.dynamic_zones) ? project.dynamic_zones : [];
    if (dynZones.length) {
      dynZones.forEach(z => {
        const idx = z.index || z.zone_index || "?";
        const vals = Array.isArray(z.values) ? z.values.join(", ") : "";
        summaryLines.push(`Zone ${idx}: ${vals || "not detected"}`);
      });
    } else {
      const selectedValues = Array.isArray(project.head3_values) && project.head3_values.length
        ? project.head3_values.join(", ")
        : (Array.isArray(project.zone1_values) ? project.zone1_values.join(", ") : "");
      summaryLines.push(`${project.head3_label || "Selected zone"}: ${selectedValues || "not detected"}`);
    }
    if (levels) summaryLines.push(`Levels / Zone ${project.level_zone_index || 3}: ${levels}`);
  }
  const summaryHtml = summaryLines.length ? `<br>${summaryLines.map(line => `<strong>${escapeHtml(String(line).split(":")[0])}:</strong>${escapeHtml(String(line).includes(":") ? String(line).slice(String(line).indexOf(":") + 1) : "")}`).join("<br>")}` : "";
  return `
    <div class="notice safe">
      <strong>Run-only dynamic project hierarchy</strong><br>
      ${escapeHtml(hierarchy)}<br>
      ${zoneLines ? `<br>${zoneLines}` : ""}
      ${summaryHtml}<br>
      <span class="muted-small">Dynamic zone mapping is for this preview/export only. It will not be treated as your stable default unless you save it later as a project preset.</span>
    </div>`;
}

function activeBuilderProjectSetup451241(plan = lastBuilderCommandPlan) {
  const setup = plan?.current_work_setup || {};
  return plan?.project_zone_hierarchy || setup.project_zone_hierarchy || commandRunOnlyProjectSetup || null;
}

function collectBuilderLevelsForRun() {
  if (Array.isArray(lastBuilderCommandPlan?.builder_levels) && lastBuilderCommandPlan.builder_levels.length) return lastBuilderCommandPlan.builder_levels;
  if (Array.isArray(commandRunOnlyBuilderLevels) && commandRunOnlyBuilderLevels.length) return commandRunOnlyBuilderLevels;
  return collectBuilderLevelsFromUI();
}

function collectCurrentWorkSetupForRun() {
  const uiSetup = collectCurrentWorkSetupFromUI();
  const plan = lastBuilderCommandPlan || activeConversationTask?.plan || null;
  const planSetup = plan?.current_work_setup || {};
  const setup = { ...uiSetup, ...planSetup };
  if (plan?.trade_profile_id) setup.trade_profile_id = plan.trade_profile_id;
  if (plan?.default_function) setup.default_costx_function = plan.default_function;
  if (plan?.function_mode) setup.costx_function_mode = plan.function_mode;
  if (plan?.custom_quantity || plan?.custom_quantity_name) setup.custom_quantity_name = plan.custom_quantity || plan.custom_quantity_name;
  if (plan?.unit) { setup.expected_unit = plan.unit; setup.custom_quantity_unit = setup.custom_quantity_unit || plan.unit; }
  const project = activeBuilderProjectSetup451241(plan);
  if (project) {
    setup.project_zone_hierarchy = project;
    setup.zone_token_mode = "rebuild";
    setup.__active_builder_snapshot = true;
  }
  if (commandRunOnlyItemCodeConfig) setup.item_code_config = commandRunOnlyItemCodeConfig;
  return setup;
}

function builderZoneTokenModeForRun451241() {
  return activeBuilderProjectSetup451241() ? "rebuild" : "preserve_source";
}

function builderSetupSummaryHtml(plan) {
  const setup = plan?.current_work_setup || {};
  const project = plan?.project_zone_hierarchy || setup.project_zone_hierarchy || {};
  const levels = Array.isArray(plan?.builder_levels) ? plan.builder_levels : [];
  let levelNames = Array.isArray(project?.level_values) ? project.level_values.map(v => String(v || "")).filter(Boolean) : [];
  if (!levelNames.length) {
    levelNames = levels.map(l => l.label || l.name || l.level || l.level_code || l.description || "").filter(Boolean);
  }
  // builder_levels is the expanded run list (zones × levels), so keep the review summary unique.
  levelNames = Array.from(new Map(levelNames.map(v => [String(v).trim().toLowerCase(), String(v).trim()])).values()).filter(Boolean);
  const zoneMap = project.zone_head_map || project.head_zone_map || {};
  const dynamicZones = Array.isArray(project.dynamic_zones) ? project.dynamic_zones : [];
  const zoneValues = project.zone_values || {};
  const rows = [
    ["Trade/Profile", plan?.trade_profile_name || setup.trade_profile_id || "Not confirmed"],
    ["Function", plan?.default_function || setup.default_costx_function || "Not confirmed"],
    ["Function mode", plan?.function_mode || setup.costx_function_mode || "preserve/detected"],
    ["Custom quantity", setup.custom_quantity_name || plan?.custom_quantity_name || "-"],
    ["Unit", plan?.unit || setup.expected_unit || setup.custom_quantity_unit || "-"],
    ["Workbook", (restoreActiveWorkbookForBuilder()?.filename || restoreActiveWorkbookForBuilder()?.saved_name || plan?.workbook?.filename || plan?.workbook?.saved_name || "No workbook attached")],
    ["Zone mode", plan?.zone_mode || setup.zone_token_mode || "preserve_source"],
    ["Item code", setup.item_code_config?.enabled ? "On" : "Off"]
  ];
  let html = `<div class="preview-drawer-summary safe"><strong>Builder setup preview</strong><span>${escapeHtml(rows[0][1])} · ${escapeHtml(rows[1][1])} · ${escapeHtml(rows[4][1])}</span></div>`;
  html += `<div class="builder-preview-grid">${rows.map(([k,v]) => `<div><strong>${escapeHtml(k)}</strong><br>${escapeHtml(String(v || "-"))}</div>`).join("")}</div>`;
  const hierarchyLines = [];
  if (project.primary_zone_index || project.head_zone_index) hierarchyLines.push(`Primary/head zone: Zone ${project.primary_zone_index || project.head_zone_index}`);
  if (project.combo_zone_index) hierarchyLines.push(`Combo zone: Zone ${project.combo_zone_index}`);
  Object.keys(zoneMap || {}).forEach(k => hierarchyLines.push(`Zone ${k} → ${zoneMap[k]}`));
  if (Array.isArray(project.hierarchy_zones)) {
    project.hierarchy_zones.forEach(z => {
      const vals = Array.isArray(z.values) ? z.values.join(", ") : "";
      hierarchyLines.push(`Zone ${z.zone_index} → ${z.head || "Head"}${vals ? `: ${vals}` : ""}`);
    });
  }
  dynamicZones.forEach(z => {
    const vals = Array.isArray(z.values) ? z.values.join(", ") : "";
    hierarchyLines.push(`Zone ${z.zone_index || z.index || "?"}: ${vals || "not set"}`);
  });
  Object.keys(zoneValues || {}).forEach(k => {
    const vals = Array.isArray(zoneValues[k]) ? zoneValues[k].join(", ") : zoneValues[k];
    if (vals) hierarchyLines.push(`Zone ${k}: ${vals}`);
  });
  if (levelNames.length) hierarchyLines.push(`Levels: ${levelNames.slice(0,40).join(", ")}${levelNames.length > 40 ? ` + ${levelNames.length-40} more` : ""}`);
  const notes = setup.notes || plan?.formatting_note || plan?.formatting_notes || "";
  html += `<div class="notice safe"><strong>Hierarchy / instructions</strong><br>${hierarchyLines.length ? hierarchyLines.map(escapeHtml).join("<br>") : "No explicit project hierarchy detected yet."}${notes ? `<br><br><strong>Notes:</strong> ${escapeHtml(notes)}` : ""}</div>`;
  html += `<div class="muted-small">Review is read-only. To change setup, click Edit in chat and tell Jarvis what to change.</div>`;
  return html;
}

function ensureBuilderSetupReviewDrawer() {
  let drawer = document.getElementById("builderSetupReviewDrawer");
  if (drawer) return drawer;
  drawer = document.createElement("section");
  drawer.id = "builderSetupReviewDrawer";
  drawer.className = "builder-preview-drawer";
  drawer.innerHTML = `<div class="builder-preview-drawer-panel"><div class="builder-preview-drawer-head"><div><strong>Builder Setup Preview</strong><span>Review setup before preview/export</span></div><button class="drawer-close" type="button" data-close-setup-review="1" aria-label="Close setup preview">×</button></div><div class="builder-preview-drawer-body" id="builderSetupReviewBody"></div><div class="builder-preview-drawer-actions"><button class="action primary" data-approve-builder-preview="1">Approve & Preview</button><button class="action secondary" data-use-reviewed-builder-setup="1">Use setup only</button><button class="action secondary" data-edit-setup-in-chat="1">Edit in chat</button><button class="action secondary" data-advanced-builder-setup="1">Advanced manual setup</button><button class="action secondary" data-close-setup-review="1">Close</button></div></div>`;
  document.body.appendChild(drawer);
  return drawer;
}

function openBuilderSetupReviewDrawer() {
  restoreActiveBuilderPlanForAction();
  const drawer = ensureBuilderSetupReviewDrawer();
  const body = drawer.querySelector("#builderSetupReviewBody");
  if (body) body.innerHTML = builderSetupSummaryHtml(lastBuilderCommandPlan || {});
  drawer.classList.add("show");
}

function closeBuilderSetupReviewDrawer() {
  document.getElementById("builderSetupReviewDrawer")?.classList.remove("show");
}

function renderBuilderCommandPlanCard(plan, options = {}) {
  if (!plan) return "";
  const setup = plan.current_work_setup || {};
  const reasons = Array.isArray(plan.reasons) ? plan.reasons : [];
  const hasFile = !!options.hasFile;
  const lowConfidence = isLowConfidenceBuilderPlan(plan);
  const trade = plan.trade_profile_name || setup.trade_profile_id || "Builder";
  const func = plan.default_function || setup.default_costx_function || "-";
  const unit = plan.unit || setup.expected_unit || "-";
  let actions = "";
  let lines = [];
  if (lowConfidence) {
    lines = ["I need to review the setup before previewing this BOQ base sheet.", "Please check the Builder setup first, then run preview when ready."];
    actions = `${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`;
  } else if (hasFile) {
    lines = ["Plan ready.", `I’ll create a ${trade} base sheet using ${func} with ${unit} units.`];
    actions = `${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Edit setup", "onclick=\"showView('workspace')\"")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`;
  } else {
    lines = ["I can prepare this BOQ base sheet, but I need the Excel workbook first.", "Attach an .xlsx or .xlsm workbook to continue."];
    actions = `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Edit setup", "onclick=\"showView('workspace')\"")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`;
  }
  const details = `<details class="technical-details compact-details"><summary>Details</summary><div class="builder-preview-grid"><div><strong>Trade</strong><br>${escapeHtml(trade)}</div><div><strong>Function</strong><br>${escapeHtml(func)}</div><div><strong>Unit</strong><br>${escapeHtml(unit)}</div><div><strong>Function mode</strong><br>${escapeHtml(plan.function_mode || setup.costx_function_mode || "-")}</div><div><strong>Zone mode</strong><br>${escapeHtml(plan.zone_mode || setup.zone_token_mode || "preserve_source")}</div><div><strong>Confidence</strong><br>${escapeHtml(plan.confidence || 0)}%</div></div>${reasons.length ? `<ul>${reasons.map(reason => `<li>${escapeHtml(reason)}</li>`).join("")}</ul>` : ""}${renderProjectHierarchySummary(plan)}</details>`;
  return `${copyableBlock(lines, actions)}${details}`;
}

async function applyBuilderCommandPlan(plan, options = {}) {
  plan = plan || restoreActiveBuilderPlanForAction();
  if (!plan?.current_work_setup) {
    showToast("No Builder command plan to apply");
    return false;
  }
  const existingFingerprint = builderPlanFingerprint451242B(lastBuilderCommandPlan || activeConversationTask?.plan || null);
  const applyingFingerprint = builderPlanFingerprint451242B(plan);
  if (existingFingerprint && applyingFingerprint && existingFingerprint !== applyingFingerprint) invalidateBuilderPreviewCache451242B("builder_plan_applied_changed");
  const setup = plan.current_work_setup || {};
  commandRunOnlyBuilderLevels = Array.isArray(plan.builder_levels) && plan.builder_levels.length ? plan.builder_levels : null;
  commandRunOnlyProjectSetup = plan.project_zone_hierarchy || setup.project_zone_hierarchy || null;
  commandRunOnlyItemCodeConfig = setup.item_code_config || null;
  const profileId = normalizeTradeProfileIdUi(setup.trade_profile_id || plan.trade_profile_id || "walls_partitions");
  const profile = tradeProfileById(profileId);
  if (builderTradeProfileSelect) { ensureBuilderTradeProfilesLoaded(profileId); builderTradeProfileSelect.value = profileId; }
  renderCustomQuantityOptions(profile, setup.custom_quantity_name || "");
  if (setup.custom_quantity_name && builderCustomQuantitySelect) {
    const exists = Array.from(builderCustomQuantitySelect.options).some(opt => opt.value === setup.custom_quantity_name);
    if (!exists) builderCustomQuantitySelect.insertAdjacentHTML("beforeend", `<option value="${escapeAttr(setup.custom_quantity_name)}">${escapeHtml(setup.custom_quantity_name)} (${escapeHtml(setup.custom_quantity_unit || setup.expected_unit || "")})</option>`);
    builderCustomQuantitySelect.value = setup.custom_quantity_name;
  }
  if (builderProjectNameInput) builderProjectNameInput.value = setup.project_name || "Current Project";
  if (builderDefaultCostXFunctionSelect) builderDefaultCostXFunctionSelect.value = setup.default_costx_function || "XGETWALLAREA";
  if (builderCostXFunctionModeSelect) builderCostXFunctionModeSelect.value = setup.costx_function_mode || "preserve_detected";
  if (builderFormulaModeSelect) builderFormulaModeSelect.value = setup.formula_mode || "Compact";
  if (builderCustomQuantityUnitInput) builderCustomQuantityUnitInput.value = setup.custom_quantity_unit || (builderCustomQuantitySelect?.value ? customQuantityUnitUi(profile, builderCustomQuantitySelect.value) : "");
  if (builderSetupNotesInput) builderSetupNotesInput.value = setup.notes || "Created by Jarvis v4.4.4.15.3 Post-Preview Plan Persistence + Negation Precision Fix. Preview first before export.";
  if (commandRunOnlyBuilderLevels && commandRunOnlyBuilderLevels.length) {
    renderBuilderLevelRows(commandRunOnlyBuilderLevels);
    syncBuilderLevelStatus(`Run-only project levels applied for preview/export only: ${commandRunOnlyBuilderLevels.length} row(s). Do not save unless you want a project preset.`, "warn");
  }
  syncExpectedUnitGuard();
  if (setup.expected_unit && builderExpectedUnitInput) builderExpectedUnitInput.value = setup.expected_unit;
  renderTradeProfileSummary(profile);
  syncCurrentWorkSummary();
  if (options.persist !== false && !commandRunOnlyProjectSetup) persistBuilderCurrentWorkSetup({ now: true, silent: true, reason: "command_router_plan_apply" });
  syncBuilderLevelStatus(`Command Router setup applied: ${plan.trade_profile_name || profile?.display_name || profileId} · ${setup.default_costx_function || ""} ${setup.custom_quantity_name ? `· ${setup.custom_quantity_name}` : ""}`, "warn");
  setActiveConversationTask({ ...(activeConversationTask || {}), type: "build_base_sheet", status: activeConversationTask?.status || "plan_ready", plan, workbook: uploadedFileRecord || activeConversationTask?.workbook || null });
  persistActiveConversationTask451241();
  showToast(options.openWorkspace ? "Review the Builder setup before preview" : "Command plan applied to Workspace");
  if (options.openWorkspace) showView("workspace");
  return true;
}

async function approveBuilderCommandPlanAndPreview(btn) {
  restoreActiveBuilderPlanForAction();
  if (!uploadedFileRecord?.saved_name) {
    const applied = await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true });
    if (applied) promptForWorkbookAttachment();
    return;
  }
  if (isLowConfidenceBuilderPlan(lastBuilderCommandPlan)) {
    traceBuilderUiAction451242C("approve_review_blocked", { reason: "low_confidence_or_review_risk" });
    showToast("Review setup first before preview");
    await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true, openWorkspace: false });
    openBuilderSetupReviewDrawer();
    appendAssistantConversation(["This setup needs review first. I opened the Builder setup review. Check it, then use Approve & Preview when ready."], `${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Edit setup", "data-review-builder-setup='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { meta: "review" });
    return;
  }
  const applied = await applyBuilderCommandPlan(lastBuilderCommandPlan, { persist: true });
  if (!applied) return;
  await previewBuilderOutput(btn);
}

async function runFormatterCopy(btn) {
  if (!uploadedFileRecord?.saved_name) {
    showToast("Attach an Excel workbook first");
    return;
  }

  const original = btn.textContent;
  btn.textContent = "Starting job...";
  btn.disabled = true;

  try {
    const res = await fetch("/api/jobs/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tool_key: "formatter",
        input_file: uploadedFileRecord.saved_name,
        prompt: promptInput?.value || "Format my workbook",
        mode: currentMode,
        profile_key: activeFormatterProfile
      })
    });
    const job = await res.json();
    if (!res.ok || !job.job_id) throw new Error(job.detail || "Could not start Formatter job");

    renderJobResult(job, "Formatter background job started");
    showToast("Formatter job started");
    pollJob(job.job_id);
  } catch (error) {
    renderResult("Formatter job error", "No file changed", `<div class="notice warn"><strong>Could not start formatter job.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`);
  } finally {
    if (btn) { btn.textContent = original; btn.disabled = false; }
  }
}



function compactMapLine(values) {
  if (!values || typeof values !== "object" || !Object.keys(values).length) return "None";
  return Object.keys(values).sort().map(key => `${escapeHtml(key)}: ${escapeHtml(values[key])}`).join(" · ");
}

function renderBuilderPreviewRowsTable(review) {
  const rows = (Array.isArray(review?.preview_rows) ? review.preview_rows : []).slice(0, 50);
  if (!rows.length) {
    return `<div class="notice warn"><strong>Builder output sample:</strong><br>No preview rows available.</div>`;
  }
  const remaining = Number(review.preview_rows_remaining || 0);
  const shown = Number(review.preview_rows_shown || rows.length);
  const expected = Number(review.predicted_formula_rows || 0);
  const caption = remaining > 0
    ? `Showing first ${shown} of ${expected} formula row(s). ${remaining} more row(s) will export.`
    : `Showing ${shown} formula row(s).`;
  const hasCodes = rows.some(row => row.item_code);
  const body = rows.map(row => `
    <tr>
      <td>${escapeHtml(row.row_no || "")}</td>
      ${hasCodes ? `<td>${escapeHtml(row.item_code || "")}</td>` : ""}
      <td>${escapeHtml(row.group_description || "")}</td>
      <td>${escapeHtml(row.row_description || "")}</td>
      <td><code>${escapeHtml(row.formula || "")}</code></td>
      <td>${escapeHtml(row.unit || "")}</td>
      <td>${escapeHtml(row.function || "")}</td>
      <td>${escapeHtml(row.custom_quantity || "-")}</td>
    </tr>`).join("");
  return `
    <div class="builder-preview-table-card">
      <div class="builder-preview-table-head">
        <strong>Builder output sample</strong>
        <span>${escapeHtml(caption)}</span>
      </div>
      <div class="builder-preview-table-wrap">
        <table class="builder-preview-table">
          <thead>
            <tr>
              <th>#</th>
              ${rows.some(row => row.item_code) ? `<th>Code</th>` : ""}
              <th>Group / Head</th>
              <th>Row Description</th>
              <th>Formula</th>
              <th>Unit</th>
              <th>Function</th>
              <th>Custom Qty</th>
            </tr>
          </thead>
          <tbody>${body}</tbody>
        </table>
      </div>
      <p class="muted-small">Read-only preview. The actual export still uses the locked Builder engine.</p>
    </div>`;
}

function renderBuilderPreviewHtml(data) {
  const review = data?.review || data?.summary || {};
  const safe = !!data?.safe_to_export;
  const warnings = Array.isArray(review.warnings) ? review.warnings : [];
  const formulaIssues = Array.isArray(data?.formula_integrity?.issues) ? data.formula_integrity.issues : [];
  const measureSummary = review.custom_quantity_name ? `${escapeHtml(review.custom_quantity_name)} ${review.custom_quantity_unit ? `(${escapeHtml(review.custom_quantity_unit)})` : ""}` : `${escapeHtml(review.expected_unit || "-")}`;
  const self = review.self_assessment || {};
  const blockedNotice = !safe ? `<div class="notice warn"><strong>Export blocked until preview issues are fixed.</strong><br>Jarvis will not run the export from this preview because Formula Integrity Guard or setup validation found a mismatch.</div>` : "";
  const formulaNotice = formulaIssues.length ? `<div class="notice warn"><strong>Formula Integrity Guard</strong><ul>${formulaIssues.map(w => `<li>${escapeHtml(w)}</li>`).join("")}</ul></div>` : "";
  return `<div class="preview-drawer-summary ${safe ? "safe" : "warn"}"><strong>${safe ? "Preview ready" : "Preview blocked"}</strong><span>${escapeHtml(review.trade_profile_name || review.trade_profile_id || "Builder")} · ${escapeHtml(review.default_costx_function || "-")} · ${measureSummary}</span></div>${blockedNotice}${formulaNotice}${warnings.length ? `<div class="notice warn"><strong>Warnings</strong><ul>${warnings.map(w => `<li>${escapeHtml(w)}</li>`).join("")}</ul></div>` : ""}${renderBuilderPreviewRowsTable(review)}<details class="technical-details"><summary>Show technical details</summary><div class="builder-preview-grid"><div><strong>Profile</strong><br>${escapeHtml(review.trade_profile_name || review.trade_profile_id || "-")}</div><div><strong>Function mode</strong><br>${escapeHtml(review.function_mode || "-")}</div><div><strong>Default function</strong><br>${escapeHtml(review.default_costx_function || "-")}</div><div><strong>Custom quantity</strong><br>${escapeHtml(review.custom_quantity_name || "-")} ${review.custom_quantity_unit ? `(${escapeHtml(review.custom_quantity_unit)})` : ""}</div><div><strong>Zone mode</strong><br>${escapeHtml(review.zone_token_mode || "preserve_source")}</div><div><strong>Item code</strong><br>${escapeHtml(review.item_code_summary || "Off")}</div><div><strong>Expected formulas</strong><br>${escapeHtml(review.predicted_formula_rows || 0)} row(s)</div><div><strong>Detected entries</strong><br>${escapeHtml(review.entries_detected || 0)}</div><div><strong>Unique groups</strong><br>${escapeHtml(review.unique_dimensions || 0)}</div></div><div class="notice safe"><strong>Detected functions:</strong><br>${compactMapLine(review.functions)}<br><strong>Detected units:</strong><br>${compactMapLine(review.units)}<br><strong>Detected custom quantities:</strong><br>${compactMapLine(review.custom_quantities)}</div>${self.status ? `<div class="notice ${self.status === "PASS" ? "safe" : "warn"}"><strong>Jarvis self-assessment:</strong> ${escapeHtml(self.status)}<br>${escapeHtml((self.checks || []).join(", ") || "Formula and plan checks completed.")}</div>` : ""}</details>`;
}

function ensureBuilderPreviewDrawer() {
  let drawer = document.getElementById("builderPreviewDrawer");
  if (drawer) return drawer;
  drawer = document.createElement("section");
  drawer.id = "builderPreviewDrawer";
  drawer.className = "builder-preview-drawer";
  drawer.innerHTML = `<div class="builder-preview-drawer-panel"><div class="builder-preview-drawer-head"><div><strong>BOQ Preview</strong><span>Review before exporting</span></div><button class="drawer-close" type="button" data-close-preview-drawer="1" aria-label="Close preview">×</button></div><div class="builder-preview-drawer-body" id="builderPreviewDrawerBody"></div><div class="builder-preview-drawer-actions"><button class="action primary" data-run-builder="1">Export Excel</button><button class="action secondary" data-download-preview-snapshot="1">Download preview snapshot</button><button class="action secondary" data-close-preview-drawer="1">Close</button></div></div>`;
  document.body.appendChild(drawer);
  return drawer;
}

function openBuilderPreviewDrawer(data = latestBuilderPreviewData) {
  if (!data) { showToast("No preview data yet"); return; }
  const drawer = ensureBuilderPreviewDrawer();
  const body = drawer.querySelector("#builderPreviewDrawerBody");
  if (body) body.innerHTML = renderBuilderPreviewHtml(data);
  const exportBtn = drawer.querySelector("[data-run-builder]");
  const safe = !!data?.safe_to_export;
  if (exportBtn) {
    exportBtn.disabled = !safe;
    exportBtn.classList.toggle("disabled", !safe);
    exportBtn.textContent = safe ? "Export Excel" : "Export blocked";
    exportBtn.title = safe ? "Export this preview" : "Preview is not safe to export yet";
  }
  drawer.classList.add("show");
}

function closeBuilderPreviewDrawer() { document.getElementById("builderPreviewDrawer")?.classList.remove("show"); }

function downloadBuilderPreviewSnapshot() {
  const review = latestBuilderPreviewData?.review || latestBuilderPreviewData?.summary || {};
  const rows = Array.isArray(review.preview_rows) ? review.preview_rows : [];
  if (!rows.length) { showToast("No preview rows to download"); return; }
  const headers = ["row_no","item_code","group_description","row_description","formula","unit","function","custom_quantity"];
  const csv = [headers.join(",")].concat(rows.map(row => headers.map(h => `"${String(row[h] ?? "").replace(/"/g,'""')}"`).join(","))).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob); const a = document.createElement("a");
  a.href = url; a.download = `Jarvis_Builder_Preview_${new Date().toISOString().slice(0,19).replace(/[:T]/g,"-")}.csv`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  showToast("Preview snapshot downloaded");
}

function updateBuilderOutputReviewPanel(data) {
  if (!builderOutputReviewPanel) return;
  builderOutputReviewPanel.innerHTML = renderBuilderPreviewHtml(data);
}

async function previewBuilderOutput(btn) {
  restoreActiveBuilderPlanForAction();
  if (!uploadedFileRecord?.saved_name) {
    promptForWorkbookAttachment();
    if (builderOutputReviewPanel) builderOutputReviewPanel.innerHTML = `<div class="notice warn">Attach an Excel workbook first, then preview Builder output.</div>`;
    return;
  }
  const original = btn?.textContent || "Preview Builder Output";
  if (btn) { btn.textContent = "Previewing..."; btn.disabled = true; }
  traceBuilderUiAction451242C("preview_started", { source: btn ? "button" : "typed_or_programmatic" });
  if (!btn) showToast("Previewing Builder setup...");
  try {
    const res = await fetch("/api/builder/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tool_key: "builder",
        input_file: uploadedFileRecord.saved_name,
        prompt: promptInput?.value || "Preview CostX base sheet",
        mode: currentMode,
        output_prefix: "Jarvis_Builder_Base",
        builder_levels: collectBuilderLevelsForRun(),
        current_work_setup: collectCurrentWorkSetupForRun(),
        active_categories: collectBuilderActiveCategoriesFromUI(),
        zone_library: collectBuilderZoneLibraryFromUI(),
        zone_combos: builderZoneComboState,
        active_combo_id: builderActiveComboId,
        zone_token_mode: builderZoneTokenModeForRun451241(),
        builder_run_snapshot: {
          plan: lastBuilderCommandPlan || null,
          current_work_setup: collectCurrentWorkSetupForRun(),
          builder_levels: collectBuilderLevelsForRun(),
          workbook: uploadedFileRecord || activeConversationTask?.workbook || null,
          project: currentConversationProject || activeConversationTask?.project || ""
        }
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not preview Builder output");
    data.__builder_plan_fingerprint = builderPlanFingerprint451242B(lastBuilderCommandPlan || activeConversationTask?.plan || null);
    latestBuilderPreviewData = data;
    setActiveConversationTask({ ...(activeConversationTask || {}), type: "build_base_sheet", status: "preview_ready", plan: lastBuilderCommandPlan || activeConversationTask?.plan || null, workbook: uploadedFileRecord || activeConversationTask?.workbook || null, preview: data });
    await persistActiveConversationTask451241({ status: "preview_ready", preview: data });
    updateBuilderOutputReviewPanel(data);
    const review = data?.review || data?.summary || {};
    const trade = review.trade_profile_name || review.trade_profile_id || "BOQ";
    const rows = Number(review.predicted_formula_rows || review.preview_rows_shown || 0);
    const previewTitle = data.safe_to_export ? "Preview ready" : "Preview blocked";
    const previewSubtitle = data.safe_to_export ? "Ready to export" : "Fix preview issues before export";
    const previewLines = data.safe_to_export
      ? ["Preview ready.", `I prepared a ${trade} base sheet preview${rows ? ` with ${rows} formula row(s)` : ""}. Review it before exporting.`]
      : ["Preview blocked.", `I prepared a ${trade} preview, but Formula Integrity Guard or setup validation found issues. Fix the setup before exporting.`];
    const previewActions = `${compactAction("Open Preview", "data-open-preview-drawer='1'")}${data.safe_to_export ? compactAction("Export Excel", "data-run-builder='1'") : ""}${compactAction("Download preview snapshot", "data-download-preview-snapshot='1'")}${compactAction("Edit setup", "data-view='workspace'")}`;
    renderResult(previewTitle, previewSubtitle, copyableBlock(previewLines, previewActions, { warn: !data.safe_to_export }));
    traceBuilderUiAction451242C("preview_succeeded", { safe_to_export: !!data.safe_to_export, rows });
    showToast(data.safe_to_export ? "Builder preview passed" : "Preview has warnings");
  } catch (error) {
    traceBuilderUiAction451242C("preview_failed", { error: error.message || "Unknown error" });
    const html = `<div class="notice warn"><strong>Could not preview Builder output.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (builderOutputReviewPanel) builderOutputReviewPanel.innerHTML = html;
    renderResult("Builder preview error", "No file changed", html);
  } finally {
    if (btn) { btn.textContent = original; btn.disabled = false; }
  }
}

async function runBuilderCopy(btn) {
  restoreActiveBuilderPlanForAction();
  if (!uploadedFileRecord?.saved_name) {
    showToast("Attach an Excel workbook first");
    return;
  }
  if (latestBuilderPreviewData && latestBuilderPreviewData.safe_to_export === false) {
    traceBuilderUiAction451242C("export_blocked_by_unsafe_preview", { safe_to_export: false });
    const html = `<div class="notice warn"><strong>Export blocked.</strong><br>The latest preview is not safe to export. Open Preview to review the Formula Integrity Guard issues, then fix the Builder setup and preview again.</div>`;
    renderResult("Export blocked", "Preview needs fix", html);
    openBuilderPreviewDrawer(latestBuilderPreviewData);
    return;
  }

  const original = btn?.textContent || "Run Builder";
  if (btn) { btn.textContent = "Starting Builder..."; btn.disabled = true; }

  try {
    if (!commandRunOnlyProjectSetup) {
      await saveBuilderLevelZoneSetup();
    }
    const res = await fetch("/api/jobs/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tool_key: "builder",
        input_file: uploadedFileRecord.saved_name,
        prompt: promptInput?.value || "Build CostX base sheet",
        mode: currentMode,
        output_prefix: "Jarvis_Builder_Base",
        builder_levels: collectBuilderLevelsForRun(),
        current_work_setup: collectCurrentWorkSetupForRun(),
        active_categories: collectBuilderActiveCategoriesFromUI(),
        zone_library: collectBuilderZoneLibraryFromUI(),
        zone_combos: builderZoneComboState,
        active_combo_id: builderActiveComboId,
        zone_token_mode: builderZoneTokenModeForRun451241(),
        builder_run_snapshot: {
          plan: lastBuilderCommandPlan || null,
          current_work_setup: collectCurrentWorkSetupForRun(),
          builder_levels: collectBuilderLevelsForRun(),
          workbook: uploadedFileRecord || activeConversationTask?.workbook || null,
          project: currentConversationProject || activeConversationTask?.project || ""
        }
      })
    });
    const job = await res.json();
    if (!res.ok || !job.job_id) throw new Error(job.detail || "Could not start Builder job");

    renderJobResult(job, "Builder background job started");
    showToast("Builder job started");
    pollJob(job.job_id);
  } catch (error) {
    renderResult("Builder job error", "No file changed", `<div class="notice warn"><strong>Could not start Builder job.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`);
  } finally {
    if (btn) { btn.textContent = original; btn.disabled = false; }
  }
}

async function pollJob(jobId, attempt = 0) {
  try {
    const res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`);
    const job = await res.json();
    if (!res.ok) throw new Error(job.detail || "Could not read job status");
    renderJobResult(job, job.status === "completed" ? `${job.tool_name || "Background job"} complete` : `${job.tool_name || "Background job"} running`);
    if (job.status === "completed" || job.status === "failed") {
      loadJobs();
      loadOutputs();
      if (job.status === "completed") {
        await persistActiveConversationTask451241({ status: "export_ready", last_export_job: job });
        appendExportReadyConversation451242E(job);
      }
      showToast(job.status === "completed" ? "Output ready" : "Job failed");
      return;
    }
    setTimeout(() => pollJob(jobId, attempt + 1), Math.min(1200 + attempt * 150, 3000));
  } catch (error) {
    renderResult("Job polling error", "Check terminal", `<div class="notice warn">${escapeHtml(error.message || "Could not poll job")}</div>`);
  }
}

function renderJobResult(job, title = "Background job") {
  const progress = Math.max(0, Math.min(100, Number(job.progress || 0)));
  const result = job.result || {};
  const failed = job.status === "failed";
  const completed = job.status === "completed" && result.download_url;
  if (failed) { renderResult("Job failed", "No output created", copyableBlock(["The background job failed.", job.error || "Unknown error"], "", { warn: true })); return; }
  if (completed) {
    lastOutputDownloadUrl = result.download_url || lastOutputDownloadUrl;
    const actions = `<a class="inline-action primary" href="${escapeAttr(result.download_url)}">Download output</a>${compactAction("Open Output Center", "onclick=\"showView('outputs'); loadJobs(); loadOutputs();\"")}${compactAction("View details", "data-open-output-details='1'")}`;
    const details = `<details class="technical-details compact-details"><summary>Details</summary>${result.note ? `<div class="notice warn"><strong>Formatter note</strong><br>${escapeHtml(result.note)}</div>` : ""}${renderJobSummary(result.summary, job.tool_key)}<p class="muted-small">Job ID: ${escapeHtml(job.job_id || "")} · Stable external tools were not modified.</p></details>`;
    renderResult("Output ready", "Export complete", `${copyableBlock(["Output ready.", "Your BOQ base sheet has been exported."], actions)}${details}`);
    return;
  }
  renderResult(title, `${progress}%`, copyableBlock(["Builder is running in the background.", "I’ll show the download button when the output is ready."], ""));
}

function renderJobSummary(summary, toolKey) {
  if (toolKey === "builder") return renderBuilderSummary(summary);
  return renderFormatterSummary(summary);
}

function renderBuilderSummary(summary) {
  if (!summary) return "";
  const entries = Number(summary.entries_detected || 0);
  const groups = summary.relationship_groups || {};
  const functions = summary.functions || {};
  const groupLine = Object.keys(groups).slice(0, 8).map(k => `${escapeHtml(k)}: ${groups[k]}`).join(" · ");
  const functionLine = Object.keys(functions).map(k => `${escapeHtml(k)}: ${functions[k]}`).join(" · ");
  return `<div class="notice safe"><strong>Builder output:</strong><br>${entries} XGET entries extracted<br>${functionLine}${groupLine ? `<br>${groupLine}` : ""}</div>`;
}

function renderFormatterSummary(summary) {
  if (!summary) return "";
  const rows = Number(summary.rows_styled || 0);
  const heads = ["head1", "head2", "head3", "head4", "level_rows", "item_rows"].map(key => `${key}: ${summary[key] || 0}`).join(" · ");
  const sheets = Array.isArray(summary.sheets) ? summary.sheets.length : 0;
  const costxEntries = Number(summary.costx_entries || 0);
  const profileLine = summary.profile_name ? `<br>Profile: ${escapeHtml(summary.profile_name)} (${escapeHtml(summary.profile_key || "")})` : "";
  const costxLine = costxEntries
    ? `<br>${costxEntries} CostX XGET entries parsed · ${summary.costx_groups || 0} group(s) · Extract sheet added`
    : "";
  return `<div class="notice safe"><strong>Applied changes:</strong><br>${rows} rows styled · ${sheets} sheet(s) cleaned<br>${escapeHtml(heads)}${profileLine}${costxLine}</div>`;
}

function renderResult(title, meta, html) {
  resultCard?.classList.remove("show");
  const body = `<div class="result-inline-card" data-result-title="${escapeAttr(title || "Jarvis")}">${html || ""}</div>`;
  if (activeResultMessageId && updateChatMessage(activeResultMessageId, { role: "assistant", html: body, text: title || "Jarvis", meta: "", kind: "result" })) return;
  activeResultMessageId = appendChatMessage("assistant", title || "Jarvis", { html: body, meta: "", kind: "result" });
}

function showToast(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  toast.classList.remove("warn");
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 1600);
}

function renderQAReadyState() {
  if (qaLabResult && !qaLabResult.dataset.loaded) {
    qaLabResult.innerHTML = `<div class="notice safe"><strong>QA Lab ready.</strong><br>Run Smoke Test, Panic / Regression Test, or import/generate smart fuzz packs.</div>`;
  }
  if (bugStatusResult && !bugStatusResult.dataset.loaded) {
    loadBugStatus();
  }
  if (qaSmartResult && !qaSmartResult.dataset.loaded) {
    qaSmartResult.dataset.loaded = "1";
    loadQAPacks();
  }
}

function bugStatusBadgeClass(status = "") {
  const s = String(status || "").toLowerCase();
  if (s === "fixed" || s === "ignored") return "safe";
  if (s === "reopened" || s === "not_fixed") return "warn";
  return "";
}

function renderBugStatus(data = {}) {
  if (!bugStatusResult) return;
  bugStatusResult.dataset.loaded = "1";
  const summary = data.summary || {};
  const bugs = Array.isArray(data.bugs) ? data.bugs : [];
  const reports = data.reports || {};
  const summaryHtml = `<div class="notice ${Number(summary.active || 0) ? "warn" : "safe"}"><strong>${Number(summary.active || 0)} active issue(s)</strong><br>Pending ${summary.pending || 0} · Needs retest ${summary.needs_retest || 0} · Not fixed ${summary.not_fixed || 0} · Reopened ${summary.reopened || 0} · Fixed ${summary.fixed || 0}</div>`;
  const bugHtml = bugs.length ? `<div class="list wide-list">${bugs.slice(0, 40).map(bug => `<div class="list-item"><strong>${escapeHtml(bug.id || "BUG")}: ${escapeHtml(bug.title || "")}</strong><br><span class="badge ${bugStatusBadgeClass(bug.status)}">${escapeHtml(String(bug.status || "pending").replace(/_/g, " "))}</span> <small>${escapeHtml(bug.severity || "")} · ${escapeHtml(bug.area || "")}</small><br><small>${escapeHtml(bug.notes || "")}</small></div>`).join("")}</div>` : `<p class="muted-small">No bugs match this filter.</p>`;
  const reportHtml = reports.md || reports.json ? `<div class="actions">${reports.md ? `<a class="action secondary" href="${escapeAttr(reports.md)}">Download Bug Report MD</a>` : ""}${reports.json ? `<a class="action secondary" href="${escapeAttr(reports.json)}">Download Bug Report JSON</a>` : ""}</div>` : "";
  bugStatusResult.innerHTML = summaryHtml + bugHtml + reportHtml;
}

async function loadBugStatus() {
  if (!bugStatusResult) return;
  const status = bugStatusFilter?.value || "active";
  const scope = bugScopeFilter?.value || "current";
  bugStatusResult.dataset.loaded = "1";
  bugStatusResult.innerHTML = `<div class="notice safe"><strong>Loading bug register...</strong><br>Checking current fixed / pending / not fixed status.</div>`;
  try {
    const res = await fetch(`/api/bugs/status?status=${encodeURIComponent(status)}&scope=${encodeURIComponent(scope)}`);
    if (!res.ok) throw new Error(await res.text());
    renderBugStatus(await res.json());
  } catch (error) {
    bugStatusResult.innerHTML = `<div class="notice warn"><strong>Bug register unavailable.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function runSafeLogCleanup(action = "preview") {
  if (!bugStatusResult) return;
  const label = action === "archive" ? "Archiving old logs" : action === "restore_latest" ? "Restoring latest archive" : "Previewing log cleanup";
  bugStatusResult.innerHTML = `<div class="notice safe"><strong>${escapeHtml(label)}...</strong><br>Archive-first cleanup keeps latest logs and unresolved-bug evidence protected.</div>`;
  try {
    const res = await fetch("/api/logs/safe-cleanup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, keep_latest_debug_reports: 5, keep_latest_event_lines: 1500 })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const summary = data.summary || {};
    const reports = data.reports || {};
    const actionText = action === "archive" ? "Archived" : action === "restore_latest" ? "Restored" : "Preview ready";
    bugStatusResult.innerHTML = `<div class="notice ${action === "archive" ? "safe" : "safe"}"><strong>${escapeHtml(actionText)}</strong><br>Candidate files ${summary.candidate_files || 0} · moved ${summary.moved_files || 0} · restored ${summary.restored_files || 0} · old event/chat lines ${summary.event_lines_to_archive || 0}</div>
      <p class="muted-small">Protected unresolved bugs: ${(data.unresolved_bugs_protected || []).map(escapeHtml).join(", ") || "none"}</p>
      <div class="actions">${reports.md ? `<a class="action secondary" href="${escapeAttr(reports.md)}">Download Cleanup Report MD</a>` : ""}${reports.json ? `<a class="action secondary" href="${escapeAttr(reports.json)}">Download Cleanup Report JSON</a>` : ""}</div>`;
    if (action === "archive" || action === "restore_latest") await loadBugStatus();
  } catch (error) {
    bugStatusResult.innerHTML = `<div class="notice warn"><strong>Safe log cleanup failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

function renderQATable(results = []) {
  if (!results.length) return `<p class="muted-small">No QA results returned.</p>`;
  return `<div class="list wide-list">${results.map(row => {
    const status = row.status || "-";
    const cls = status === "FAIL" ? "warn" : "safe";
    return `<div class="list-item"><strong>${escapeHtml(row.id || "")}: ${escapeHtml(row.name || "")}</strong><br><span class="badge ${cls}">${escapeHtml(status)}</span><br><small><strong>Expected:</strong> ${escapeHtml(row.expected || "")}<br><strong>Actual:</strong> ${escapeHtml(row.actual || "")}</small></div>`;
  }).join("")}</div>`;
}

async function runQALab(testPack = "smoke") {
  if (qaLabResult) {
    qaLabResult.dataset.loaded = "1";
    qaLabResult.innerHTML = `<div class="notice safe"><strong>Running ${escapeHtml(testPack)} QA...</strong><br>Jarvis is testing router/planner logic locally. No stable tools are modified.</div>`;
  }
  try {
    const res = await fetch("/api/qa/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ test_pack: testPack, include_recent_logs: true })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const report = data.report || {};
    const summary = report.summary || {};
    const file = data.file || {};
    const fail = Number(summary.fail || 0);
    const gate = fail === 0 ? "Stable gate: PASS" : "Stable gate: NEEDS REVIEW";
    if (qaLabResult) qaLabResult.innerHTML = `
      <div class="notice ${fail === 0 ? "safe" : "warn"}"><strong>${escapeHtml(report.status || "-")}</strong><br>${summary.total || 0} test(s): ${summary.pass || 0} PASS · ${summary.blocked_safe || 0} BLOCKED SAFE · ${summary.fail || 0} FAIL</div>
      ${file.download_url ? `<div class="actions"><a class="action primary" href="${escapeAttr(file.download_url)}">Download QA Report ZIP</a></div>` : ""}
      ${renderQATable(report.results || [])}`;
    if (qaStableGate) qaStableGate.innerHTML = `<div class="notice ${fail === 0 ? "safe" : "warn"}"><strong>${gate}</strong><br>${fail === 0 ? "No red failures in this QA pack." : "Review failed tests before marking stable."}</div>`;
    showToast("QA test complete");
  } catch (error) {
    if (qaLabResult) qaLabResult.innerHTML = `<div class="notice warn"><strong>QA run failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function replayQALog() {
  if (qaLabResult) qaLabResult.innerHTML = `<div class="notice safe"><strong>Analyzing latest debug log...</strong><br>Jarvis is replaying route decisions, active plan state, conflicts, and likely patch areas.</div>`;
  try {
    const res = await fetch("/api/qa/replay");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const summary = data.summary || {};
    const issues = data.issues || [];
    const timeline = data.timeline || [];
    const fail = Number(summary.critical || 0) > 0;
    const issueHtml = issues.length
      ? `<div class="list wide-list">${issues.slice(-20).map(issue => `<div class="list-item"><strong>${escapeHtml(issue.type || "Issue")}</strong> · ${escapeHtml(issue.severity || "")}<br><small>${escapeHtml(issue.message || "")}<br><strong>Patch area:</strong> ${escapeHtml(issue.patch_area || "-")}<br><strong>Prompt:</strong> ${escapeHtml(issue.prompt || "")}</small></div>`).join("")}</div>`
      : `<p class="muted-small">No obvious route/context/formula-risk issues detected in the replay window.</p>`;
    const timelineHtml = timeline.length
      ? `<details class="details"><summary>Show replay timeline</summary><div class="list wide-list">${timeline.map(route => `<div class="list-item"><strong>${escapeHtml(route.intent || "-")}</strong> · ${escapeHtml(route.status || "-")} · ${escapeHtml(String(route.confidence ?? "-"))}%<br><small>${escapeHtml(route.prompt || "")}</small></div>`).join("")}</div></details>`
      : "";
    const file = data.file || {};
    if (qaLabResult) qaLabResult.innerHTML = `
      <div class="notice ${fail ? "warn" : "safe"}"><strong>Debug replay: ${escapeHtml(data.status || "-")}</strong><br>Source: ${escapeHtml(data.source || "latest events")}<br>${summary.routes || 0} route(s), ${summary.builder_events || 0} Builder event(s), ${summary.issues || 0} issue(s), ${summary.critical || 0} critical.</div>
      ${file.download_url ? `<div class="actions"><a class="action primary" href="${escapeAttr(file.download_url)}">Download Replay Analysis ZIP</a></div>` : ""}
      ${issueHtml}
      ${timelineHtml}`;
    if (qaStableGate) qaStableGate.innerHTML = `<div class="notice ${fail ? "warn" : "safe"}"><strong>Replay gate: ${fail ? "NEEDS REVIEW" : "PASS"}</strong><br>${fail ? "Critical replay issue(s) found." : "No critical route/context issue found in the replay."}</div>`;
  } catch (error) {
    if (qaLabResult) qaLabResult.innerHTML = `<div class="notice warn"><strong>Replay failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}


function renderQAPackOptions(packs = []) {
  if (!qaPackSelect) return;
  if (!packs.length) {
    qaPackSelect.innerHTML = `<option value="">No imported/generated packs yet</option>`;
    return;
  }
  qaPackSelect.innerHTML = packs.map(pack => `<option value="${escapeAttr(pack.file || "")}">${escapeHtml(pack.pack_name || pack.file || "QA pack")} · ${pack.tests || 0} tests</option>`).join("");
}

async function loadQAPacks() {
  try {
    const res = await fetch("/api/qa/packs");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    renderQAPackOptions(data.packs || []);
    if (qaSmartResult) {
      const providers = data.providers || {};
      const bits = Object.entries(providers).map(([name, info]) => `${name}: ${info.configured ? "configured" : "not configured"}`).join(" · ");
      qaSmartResult.innerHTML = `<div class="notice safe"><strong>QA packs refreshed.</strong><br>${(data.packs || []).length} pack(s) available.<br><small>${escapeHtml(bits)}</small></div>`;
    }
  } catch (error) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>Could not load QA packs.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function generateQAPack() {
  if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice safe"><strong>Generating local fuzz pack...</strong><br>No external API is called.</div>`;
  try {
    const res = await fetch("/api/qa/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        provider: "local_builtin",
        category: qaGenerateCategory?.value || "mixed",
        count: Number(qaGenerateCount?.value || 25),
        save_pack: true
      })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const pack = data.pack || {};
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice safe"><strong>Generated QA pack.</strong><br>${escapeHtml(pack.pack_name || "Generated pack")} · ${(pack.tests || []).length} test(s).${data.saved?.file ? `<br>Saved: ${escapeHtml(data.saved.file)}` : ""}</div>`;
    await loadQAPacks();
    showToast("QA fuzz pack generated");
  } catch (error) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>Generate failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function importQAPack(runAfter = false) {
  const packText = qaImportText?.value || "";
  if (!packText.trim()) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>No JSON provided.</strong><br>Paste a QA test pack first.</div>`;
    return;
  }
  if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice safe"><strong>Importing QA pack...</strong></div>`;
  try {
    const res = await fetch("/api/qa/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pack_text: packText, run_after_import: runAfter })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const report = data.report || null;
    const file = data.file || null;
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice ${report && (report.summary || {}).fail > 0 ? "warn" : "safe"}"><strong>QA pack imported.</strong><br>${escapeHtml(data.pack?.pack_name || "Imported pack")} · ${data.pack?.tests || 0} test(s).${report ? `<br>Run result: ${report.summary?.pass || 0} PASS · ${report.summary?.blocked_safe || 0} BLOCKED SAFE · ${report.summary?.fail || 0} FAIL` : ""}${file?.download_url ? `<br><a href="${escapeAttr(file.download_url)}">Download QA Report ZIP</a>` : ""}</div>`;
    await loadQAPacks();
    showToast(runAfter ? "QA pack imported and run" : "QA pack imported");
  } catch (error) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>Import failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function runSelectedQAPack() {
  const packFile = qaPackSelect?.value || "";
  if (!packFile) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>No QA pack selected.</strong></div>`;
    return;
  }
  if (qaLabResult) qaLabResult.innerHTML = `<div class="notice safe"><strong>Running imported QA pack...</strong><br>${escapeHtml(packFile)}</div>`;
  try {
    const res = await fetch("/api/qa/run-imported", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pack_file: packFile, include_recent_logs: true })
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const report = data.report || {};
    const summary = report.summary || {};
    const file = data.file || {};
    const fail = Number(summary.fail || 0);
    if (qaLabResult) qaLabResult.innerHTML = `
      <div class="notice ${fail === 0 ? "safe" : "warn"}"><strong>${escapeHtml(report.status || "-")}</strong><br>${summary.total || 0} test(s): ${summary.pass || 0} PASS · ${summary.blocked_safe || 0} BLOCKED SAFE · ${summary.fail || 0} FAIL</div>
      ${file.download_url ? `<div class="actions"><a class="action primary" href="${escapeAttr(file.download_url)}">Download QA Report ZIP</a></div>` : ""}
      ${renderQATable(report.results || [])}`;
    if (qaStableGate) qaStableGate.innerHTML = `<div class="notice ${fail === 0 ? "safe" : "warn"}"><strong>Imported pack gate: ${fail === 0 ? "PASS" : "NEEDS REVIEW"}</strong><br>${escapeHtml(report.pack_metadata?.pack_name || packFile)}</div>`;
    showToast("Imported QA run complete");
  } catch (error) {
    if (qaLabResult) qaLabResult.innerHTML = `<div class="notice warn"><strong>Imported QA run failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}

async function showQASchema() {
  try {
    const res = await fetch("/api/qa/schema");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    if (qaImportText) qaImportText.value = JSON.stringify(data.example || {}, null, 2);
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice safe"><strong>Schema example loaded.</strong><br>Edit it or paste an external AI-generated JSON pack, then import.</div>`;
  } catch (error) {
    if (qaSmartResult) qaSmartResult.innerHTML = `<div class="notice warn"><strong>Schema failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}


function renderQACoverageTable(categories = []) {
  if (!categories.length) return `<p class="muted-small">No coverage categories returned.</p>`;
  return `<div class="list wide-list">${categories.map(cat => {
    const status = cat.status || "-";
    const pct = Number(cat.coverage_percent || 0);
    const cls = status === "NEEDS_REVIEW" || pct < 60 ? "warn" : "safe";
    const evidence = (cat.evidence || []).slice(0, 4).map(ev => `${escapeHtml(ev.id || "")}: ${escapeHtml(ev.status || "")}`).join(" · ");
    return `<div class="list-item"><strong>${escapeHtml(cat.label || cat.key || "Coverage")}</strong><br><span class="badge ${cls}">${escapeHtml(status)} · ${pct}%</span><br><small>${escapeHtml(cat.description || "")}<br><strong>Evidence:</strong> ${cat.total || 0} test(s) · PASS ${cat.pass || 0} · BLOCKED ${cat.blocked_safe || 0} · FAIL ${cat.fail || 0}${evidence ? `<br>${evidence}` : ""}</small></div>`;
  }).join("")}</div>`;
}

async function runQACoverageMap() {
  if (qaCoverageResult) qaCoverageResult.innerHTML = `<div class="notice safe"><strong>Generating QA coverage map...</strong><br>Jarvis is scanning recent QA and replay reports. No Builder formulas or stable tools are modified.</div>`;
  try {
    const res = await fetch("/api/qa/coverage");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const coverage = data.coverage || {};
    const summary = coverage.summary || {};
    const file = data.file || {};
    const weak = coverage.weak_areas || [];
    const ok = coverage.status === "PASS";
    const weakHtml = weak.length ? `<details class="details"><summary>Show weak areas</summary><div class="list wide-list">${weak.map(item => `<div class="list-item"><strong>${escapeHtml(item.label || item.key || "Weak area")}</strong><br><span class="badge warn">${escapeHtml(item.status || "") } · ${item.coverage_percent || 0}%</span><br><small>${escapeHtml(item.risk || "")}</small></div>`).join("")}</div></details>` : `<p class="muted-small">No low/no-coverage areas were flagged by the latest coverage map.</p>`;
    if (qaCoverageResult) qaCoverageResult.innerHTML = `
      <div class="notice ${ok ? "safe" : "warn"}"><strong>Coverage Map: ${escapeHtml(coverage.status || "-")}</strong><br>Average coverage: ${summary.average_coverage_percent || 0}% · Strong areas: ${summary.strong || 0}/${summary.categories || 0} · Reports scanned: ${summary.reports_scanned || 0}</div>
      ${file.download_url ? `<div class="actions"><a class="action primary" href="${escapeAttr(file.download_url)}">Download Coverage Map ZIP</a></div>` : ""}
      ${weakHtml}
      ${renderQACoverageTable(coverage.categories || [])}`;
    if (qaStableGate) qaStableGate.innerHTML = `<div class="notice ${ok ? "safe" : "warn"}"><strong>Coverage gate: ${ok ? "PASS" : "NEEDS REVIEW"}</strong><br>${ok ? "Coverage evidence is strong enough for current QA categories." : "Review low/failing coverage areas before marking stable."}</div>`;
    showToast("Coverage map generated");
  } catch (error) {
    if (qaCoverageResult) qaCoverageResult.innerHTML = `<div class="notice warn"><strong>Coverage map failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}


function renderReleaseGateChecks(checks = []) {
  if (!checks.length) return `<p class="muted-small">No release checks returned.</p>`;
  return `<div class="list wide-list">${checks.map(check => {
    const status = check.status || "-";
    const cls = status === "PASS" ? "safe" : "warn";
    return `<div class="list-item"><strong>${escapeHtml(check.label || check.key || "Release check")}</strong><br><span class="badge ${cls}">${escapeHtml(status)}${check.critical ? " · critical" : ""}</span><br><small>${escapeHtml(check.message || "")}</small></div>`;
  }).join("")}</div>`;
}

async function runQAReleaseGate() {
  if (qaStableGate) qaStableGate.innerHTML = `<div class="notice safe"><strong>Running Stable Release Gate...</strong><br>Jarvis is running Smoke, Panic, Fuzz, Replay, Coverage, and packaging checks. No Builder formulas or stable tools are modified.</div>`;
  try {
    const res = await fetch("/api/qa/release-gate");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const gate = data.gate || {};
    const summary = gate.summary || {};
    const file = data.file || {};
    const ok = gate.status === "PASS" && gate.stable_candidate;
    if (qaStableGate) qaStableGate.innerHTML = `
      <div class="notice ${ok ? "safe" : "warn"}"><strong>Stable Release Gate: ${escapeHtml(gate.status || "-")}</strong><br>Stable candidate: ${gate.stable_candidate ? "YES" : "NO"} · Confidence: ${escapeHtml(gate.stable_confidence || "-")}<br>Checks: ${summary.pass || 0}/${summary.checks || 0} PASS · Critical failures: ${summary.critical_failures || 0}</div>
      ${file.download_url ? `<div class="actions"><a class="action primary" href="${escapeAttr(file.download_url)}">Download Stable Release Gate ZIP</a></div>` : ""}
      ${renderReleaseGateChecks(gate.checks || [])}`;
    showToast("Stable Release Gate complete");
  } catch (error) {
    if (qaStableGate) qaStableGate.innerHTML = `<div class="notice warn"><strong>Stable Release Gate failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
  }
}


function isWorkbookName(name) {
  return /\.(xlsx|xlsm)$/i.test(String(name || ""));
}

function isZipName(name) {
  return /\.zip$/i.test(String(name || ""));
}

function detectAttachmentType(name) {
  const value = String(name || "").toLowerCase();
  if (/\.(xlsx|xlsm)$/.test(value)) return "Excel workbook";
  if (/\.zip$/.test(value)) return "ZIP archive";
  if (/\.(png|jpg|jpeg|webp)$/.test(value)) return "Image";
  if (/\.pdf$/.test(value)) return "PDF";
  if (/\.docx$/.test(value)) return "Word";
  if (/\.csv$/.test(value)) return "CSV";
  return "File";
}

function choosePrimaryWorkbook(records) {
  return (records || []).find(item => item?.is_workbook || isWorkbookName(item?.filename || item?.saved_name));
}

function renderAttachmentList() {
  if (!attachmentList) return;
  const records = Array.isArray(uploadedFileRecords) ? uploadedFileRecords.filter(Boolean) : [];
  if (!records.length) { attachmentList.innerHTML = ""; attachmentList.classList.remove("show"); return; }
  attachmentList.innerHTML = records.map(record => renderAttachmentChipHtml(record, { removable: true, primary: record === uploadedFileRecord || record.is_workbook })).join("");
  attachmentList.classList.add("show");
}

function renderAttachmentSummaryHtml() {
  const records = Array.isArray(uploadedFileRecords) ? uploadedFileRecords : [];
  if (!records.length) return "";
  return `<div class="message-attachments status-attachments">${records.map(r => renderAttachmentChipHtml(r, { primary: r === uploadedFileRecord || r.is_workbook })).join("")}</div>`;
}

function promptForWorkbookAttachment() {
  setActiveConversationTask(activeConversationTask || { type: "build_base_sheet", status: "waiting_for_workbook" });
  appendAssistantConversation(["I can prepare this, but I need the Excel workbook first.", "Attach an .xlsx or .xlsm workbook to continue."], `${compactAction("Attach workbook", "data-attach-workbook-required='1'")}${compactAction("Cancel", "data-cancel-router-plan='1'")}`, { warn: true });
  showToast("Attach an Excel workbook first");
}

document.addEventListener("click", event => {
  const remove = event.target.closest("[data-remove-attachment]");
  if (!remove) return;
  const name = remove.dataset.removeAttachment || "";
  uploadedFileRecords = uploadedFileRecords.filter(r => (r.filename || r.saved_name || r.name || "") !== name);
  uploadedFileRecord = choosePrimaryWorkbook(uploadedFileRecords) || uploadedFileRecords[0] || null;
  uploadedFile = uploadedFileRecords.length ? uploadedFile : null;
  if (!uploadedFileRecords.length && fileInput) fileInput.value = "";
  setAttachState(uploadedFileRecords.length ? `${uploadedFileRecords.length} file${uploadedFileRecords.length > 1 ? "s" : ""}` : "Attach");
  renderAttachmentList();
});

function setAttachState(label) {
  if (!attachButton) return;
  const span = attachButton.querySelector("span");
  if (span) span.textContent = label;
  attachButton.classList.toggle("attached", label === "Attached" || /file/i.test(String(label || "")));
}

function renderSearch(items) {
  if (!searchList) return;
  searchList.innerHTML = items.length
    ? items.map(item => `<div class="list-item">${escapeHtml(item)}</div>`).join("")
    : `<div class="list-item">No result found.</div>`;
}


const DEFAULT_BUILDER_LEVELS_UI = [
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "B2", description: "Basement 2 (MH-B2-001-02 to MH-B2-005-02)", token_parts: "1|Milestone 2;3|B2" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "B3", description: "Basement 3 (MH-B3-001-02 to MH-B3-004-02)", token_parts: "1|Milestone 2;3|B3" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "LGF", description: "Lower Ground Floor (MH-B1-001-02 to MH-B1-009-02)", token_parts: "1|Milestone 2;3|LGF" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "GF", description: "Ground Floor (MH-L0-001-03 to MH-L0-010-03)", token_parts: "1|Milestone 2;3|GF" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L1", description: "Level 1 (MH-L1-001-02 to MH-L1-009-02)", token_parts: "1|Milestone 2;3|L1" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L2", description: "Level 2 (MH-L2-001-02 to MH-L2-005-02)", token_parts: "1|Milestone 2;3|L2" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L3", description: "Level 3 (MH-L3-001-02 to MH-L3-005-02)", token_parts: "1|Milestone 2;3|L3" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L4", description: "Level 4 (MH-L4-001-01 to MH-L4-005-01)", token_parts: "1|Milestone 2;3|L4" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L5", description: "Level 5 (MH-L5-001-01 to MH-L5-005-01)", token_parts: "1|Milestone 2;3|L5" },
  { zone_index: 1, zone_name: "Milestone 2", level_index: 3, level_code: "L6", description: "Level 6 (MH-L6-001-01 to MH-L6-003-01)", token_parts: "1|Milestone 2;3|L6" }
];

const DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI = [
  { category_index: 1, category_name: "Stage / Milestone", active: true, behavior: "global", default_value: "Milestone 2", locked_source: "" },
  { category_index: 2, category_name: "Area / System / Package", active: false, behavior: "choosable", default_value: "", locked_source: "" },
  { category_index: 3, category_name: "Level", active: true, behavior: "locked", default_value: "", locked_source: "level_code" },
  { category_index: 4, category_name: "Height / Depth / Range", active: false, behavior: "choosable", default_value: "", locked_source: "" },
  { category_index: 5, category_name: "Location / Internal / External", active: false, behavior: "choosable", default_value: "", locked_source: "" },
  { category_index: 6, category_name: "Strength / Material / Bar Type", active: false, behavior: "choosable", default_value: "", locked_source: "" },
  { category_index: 7, category_name: "Door / Window / Reo Type", active: false, behavior: "choosable", default_value: "", locked_source: "" },
  { category_index: 8, category_name: "Optional", active: false, behavior: "choosable", default_value: "", locked_source: "" }
];

const DEFAULT_BUILDER_TRADE_PROFILES_UI = [
  {
    "profile_id": "walls_partitions",
    "display_name": "Walls / Partitions",
    "description": "Wall and partition dimension groups as Head4, with level rows below each wall type.",
    "default_costx_function": "XGETWALLAREA",
    "default_unit": "m2",
    "recommended_combo_id": "walls_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: Dimension Group / Wall Type as Head4, with ZC3 level rows below.",
    "zones_rule": "ZC1 Global stage/milestone + ZC3 Locked from Builder Row Level Code.",
    "future_notes": "Later add wall description libraries, fire/acoustic/thermal templates, and wall-type grouping rules."
  },
  {
    "profile_id": "doors_windows",
    "display_name": "Doors / Windows",
    "description": "Door/window schedule profile. Project-learned rule: level-first with door/window item rows below each level.",
    "default_costx_function": "XGETCOUNT",
    "default_unit": "no",
    "recommended_combo_id": "doors_milestone_1_by_level_classification",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "level_first_items_below",
    "layout_rule": "Level-first: each Builder level becomes a Head4, then door/window dimension items below that level.",
    "zones_rule": "ZC1 Global stage/milestone + ZC3 Locked level + optional ZC5/ZC7 classification dropdowns.",
    "future_notes": "Confirmed by user: Doors and Windows use level-first layout. Add classification mapping later when real CostX samples are available."
  },
  {
    "profile_id": "doors",
    "display_name": "Doors",
    "description": "Door schedule profile, count-based and level-first.",
    "default_costx_function": "XGETCOUNT",
    "default_unit": "no",
    "recommended_combo_id": "doors_milestone_1_by_level_classification",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "level_first_items_below",
    "layout_rule": "Level-first: Level as Head4, door type/item rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC5/ZC7 for classification/door type.",
    "future_notes": "Use when door formulas and schedule items are separated from windows."
  },
  {
    "profile_id": "windows",
    "display_name": "Windows",
    "description": "Window schedule profile, count-based and level-first.",
    "default_costx_function": "XGETCOUNT",
    "default_unit": "no",
    "recommended_combo_id": "doors_milestone_1_by_level_classification",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "level_first_items_below",
    "layout_rule": "Level-first: Level as Head4, window type/item rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC5/ZC7 for classification/window type.",
    "future_notes": "Use when window schedule items are separated from doors."
  },
  {
    "profile_id": "metalwork_structural_steel",
    "display_name": "Metalwork / Structural Steel",
    "description": "Metalwork, framing and steel member profiles with mixed units depending on member/item type.",
    "default_costx_function": "XGETCUSTOM",
    "default_unit": "m",
    "default_custom_quantity": "Slope Length",
    "default_custom_quantity_unit": "m",
    "custom_quantity_templates": [
      { "name": "Slope Length", "unit": "m" },
      { "name": "Steel Surface Area", "unit": "m2" },
      { "name": "Weight", "unit": "t" },
      { "name": "RAKING CUTTING", "unit": "m" }
    ],
    "recommended_combo_id": "metalwork_milestone_2_by_level_item_type",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: category/member item as Head4 with level rows below. Preserve detected functions where available.",
    "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC7 member/item type.",
    "future_notes": "Later split structural steel into beams, columns, bracing, plates, frames and weight/length/count logic."
  },
  {
    "profile_id": "concrete_reo",
    "display_name": "Concrete / Reo",
    "description": "Concrete and reinforcement workflow; conservative because reo often uses custom CostX exports and metadata.",
    "default_costx_function": "XGETCUSTOM",
    "default_unit": "m2",
    "default_custom_quantity": "Formworks",
    "default_custom_quantity_unit": "m2",
    "custom_quantity_templates": [
      { "name": "Formworks", "unit": "m2" },
      { "name": "Reinforcement by Ratio", "unit": "t" },
      { "name": "PT Reinforcement", "unit": "t" },
      { "name": "Core Filling", "unit": "m3" },
      { "name": "Slab Thickness", "unit": "m" },
      { "name": "Weight", "unit": "t" }
    ],
    "recommended_combo_id": "concrete_reo_milestone_2_by_level_reo_type",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "conservative_structural",
    "layout_rule": "Conservative structural: keep item-first base for now. Future mode should support Level > Pour/Element > Bar/Product type.",
    "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC6 strength/material/bar type and ZC7 reo type.",
    "future_notes": "v4.3.8 supports conservative XGETCUSTOM templates from user samples. Keep output for review until more trade-specific samples are provided."
  },
  {
    "profile_id": "finishes",
    "display_name": "Finishes",
    "description": "Floor, wall, ceiling finishes, waterproofing, plastering, tiling, vinyl and carpet profiles.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: finish type/item as Head4 with level rows below; preserve detected functions where source uses length/count.",
    "zones_rule": "ZC1 Global + ZC3 Locked level; optional ZC5 for internal/external/wet-area classification.",
    "future_notes": "Later support mixed-unit finish schedules and finish-subtype grouping."
  },
  {
    "profile_id": "ceilings",
    "display_name": "Ceilings",
    "description": "Ceiling finish and ceiling item profile, usually item-first with level rows.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: ceiling finish/item as Head4 with level rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked level.",
    "future_notes": "Later support ceiling trims, bulkheads, access panels and mixed m/m2/no units."
  },
  {
    "profile_id": "joinery",
    "display_name": "Joinery / FFE",
    "description": "Joinery and FFE item-code based profile, typically count-based with levels below each item.",
    "default_costx_function": "XGETCOUNT",
    "default_unit": "no",
    "recommended_combo_id": "joinery_milestone_2_by_level",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: joinery/FFE item code or description as Head4, levels below, default unit no",
    "zones_rule": "ZC1 Global + ZC3 Locked level. Optional ZC7 for joinery/FFE type later.",
    "future_notes": "Later add joinery code/description library and schedule-specific grouping."
  },
  {
    "profile_id": "civil_earthworks",
    "display_name": "Civil / Earthworks",
    "description": "Civil, earthworks and external works profile with mixed sections and mixed units.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2 / m3 / m / no / t for review",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "mixed_section_driven",
    "layout_rule": "Mixed section-driven: preserve simple item-first base, but mark output for manual section review.",
    "zones_rule": "ZC1 Global + ZC3 Locked level where applicable; optional zones only when needed.",
    "future_notes": "Needs separate civil/earthworks profile rules for excavation, pavements, drainage and external works."
  },
  {
    "profile_id": "demolition",
    "display_name": "Demolition",
    "description": "Demolition profile with section-driven items and mixed units.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2 / m / no for review",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "mixed_section_driven",
    "layout_rule": "Mixed section-driven: use item-first base for formula generation and flag for manual BOQ section review.",
    "zones_rule": "ZC1 Global + ZC3 Locked level where applicable.",
    "future_notes": "Later support demolition scope categories and exclusions."
  },
  {
    "profile_id": "landscape",
    "display_name": "Landscape",
    "description": "Landscape and external finishes profile with mixed units but usually item-first with levels/areas.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2 / m / no for review",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: landscape/external finish item as Head4 with level/area rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked level/area where applicable.",
    "future_notes": "Later support external zones, landscape areas and civil handoff."
  },
  {
    "profile_id": "ffe",
    "display_name": "FFE",
    "description": "Furniture, fixtures and equipment count profile.",
    "default_costx_function": "XGETCOUNT",
    "default_unit": "no",
    "recommended_combo_id": "joinery_milestone_2_by_level",
    "recommended_function_mode": "force_default",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: FFE item as Head4 with level rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked. Optional ZC7 for FFE type later.",
    "future_notes": "Separate from Joinery so FFE can keep count unit no."
  },
  {
    "profile_id": "floor_finishes",
    "display_name": "Floor Finishes",
    "description": "Floor finish area profile.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: floor finish item as Head4 with level rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked; optional ZC5 wet/internal/external.",
    "future_notes": ""
  },
  {
    "profile_id": "wall_finishes",
    "display_name": "Wall Finishes",
    "description": "Wall finish area profile.",
    "default_costx_function": "XGETWALLAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: wall finish item as Head4 with level rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked; optional ZC5 classification.",
    "future_notes": ""
  },
  {
    "profile_id": "ceiling_finishes",
    "display_name": "Ceiling Finishes",
    "description": "Ceiling finish area profile.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: ceiling finish item as Head4 with level rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked.",
    "future_notes": ""
  },
  {
    "profile_id": "external_finishes_facade",
    "display_name": "External Finishes / Facade",
    "description": "External finishes and facade area/profile workflow.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "item_first_levels_below",
    "layout_rule": "Item-first: facade/external finish item as Head4 with level/area rows below.",
    "zones_rule": "ZC1 Global + ZC3 Locked; optional ZC5 internal/external where needed.",
    "future_notes": ""
  },
  {
    "profile_id": "civil_works",
    "display_name": "Civil Works",
    "description": "Civil works profile with mixed units for review.",
    "default_costx_function": "XGETAREA",
    "default_unit": "m2 / m3 / m / no for review",
    "recommended_combo_id": "finishes_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "mixed_section_driven",
    "layout_rule": "Mixed section-driven: preserve conservative item-first base and flag output for review.",
    "zones_rule": "ZC1 Global + ZC3 Locked where applicable.",
    "future_notes": ""
  },
  {
    "profile_id": "generic_custom",
    "display_name": "Generic / Custom",
    "description": "Generic custom profile. Preserves detected functions and flags units for review.",
    "default_costx_function": "XGETCUSTOM",
    "default_unit": "Review",
    "recommended_combo_id": "walls_milestone_2_by_level",
    "recommended_function_mode": "preserve_detected",
    "recommended_formula_mode": "Compact",
    "layout_mode": "mixed_section_driven",
    "layout_rule": "Mixed section-driven: keep conservative layout and review output manually.",
    "zones_rule": "Use selected zone combo only.",
    "future_notes": ""
  }
];

const DEFAULT_BUILDER_ZONE_COMBOS_UI = [
  {
    combo_id: "walls_milestone_2_by_level",
    combo_name: "Walls - Milestone 2 by Level",
    description: "ZC1 global Milestone 2 + locked ZC3 Level Code.",
    active_categories: [
      { category_index: 1, category_name: "Stage / Milestone", active: true, behavior: "global", default_value: "Milestone 2", locked_source: "" },
      { category_index: 3, category_name: "Level", active: true, behavior: "locked", default_value: "", locked_source: "level_code" }
    ]
  },
  {
    combo_id: "walls_milestone_1_by_level",
    combo_name: "Walls - Milestone 1 by Level",
    description: "ZC1 global Milestone 1 + locked ZC3 Level Code.",
    active_categories: [
      { category_index: 1, category_name: "Stage / Milestone", active: true, behavior: "global", default_value: "Milestone 1", locked_source: "" },
      { category_index: 3, category_name: "Level", active: true, behavior: "locked", default_value: "", locked_source: "level_code" }
    ]
  },
  {
    combo_id: "doors_milestone_1_by_level_classification",
    combo_name: "Doors - Milestone 1 by Level + Classification",
    description: "ZC1 global Milestone 1 + locked ZC3 + choosable ZC5.",
    active_categories: [
      { category_index: 1, category_name: "Stage / Milestone", active: true, behavior: "global", default_value: "Milestone 1", locked_source: "" },
      { category_index: 3, category_name: "Level", active: true, behavior: "locked", default_value: "", locked_source: "level_code" },
      { category_index: 5, category_name: "Location / Internal / External", active: true, behavior: "choosable", default_value: "", locked_source: "" }
    ]
  }
];

const DEFAULT_BUILDER_ZONE_LIBRARY_UI = [
  { category_index: 1, category_name: "Stage / Milestone", value_code: "Milestone 1", description: "Construction of Stage 1" },
  { category_index: 1, category_name: "Stage / Milestone", value_code: "Milestone 1b", description: "Construction of Stage 1" },
  { category_index: 1, category_name: "Stage / Milestone", value_code: "Milestone 2", description: "Construction of Stage 2" },
  { category_index: 3, category_name: "Level", value_code: "B3", description: "Basement 3" },
  { category_index: 3, category_name: "Level", value_code: "B2", description: "Basement 2" },
  { category_index: 3, category_name: "Level", value_code: "LGF", description: "Lower Ground Floor" },
  { category_index: 3, category_name: "Level", value_code: "GF", description: "Ground Floor" },
  { category_index: 3, category_name: "Level", value_code: "L1", description: "Level 1" },
  { category_index: 3, category_name: "Level", value_code: "L2", description: "Level 2" },
  { category_index: 3, category_name: "Level", value_code: "L3", description: "Level 3" },
  { category_index: 3, category_name: "Level", value_code: "L4", description: "Level 4" },
  { category_index: 3, category_name: "Level", value_code: "L5", description: "Level 5" },
  { category_index: 3, category_name: "Level", value_code: "L6", description: "Level 6" },
  { category_index: 5, category_name: "Location / Internal / External", value_code: "internal", description: "internal" },
  { category_index: 5, category_name: "Location / Internal / External", value_code: "external", description: "external" },
  { category_index: 7, category_name: "Door / Window / Reo Type", value_code: "Double Leaf Fire Rated", description: "Double Leaf Fire Rated" },
  { category_index: 7, category_name: "Door / Window / Reo Type", value_code: "Double Leaf Solid Core", description: "Double Leaf Solid Core" },
  { category_index: 7, category_name: "Door / Window / Reo Type", value_code: "Single Leaf Solid Core", description: "Single Leaf Solid Core" },
  { category_index: 7, category_name: "Door / Window / Reo Type", value_code: "Single Leaf Fire Rated", description: "Single Leaf Fire Rated" }
];

const STANDARD_BUILDER_ZONE_LIBRARY_UI = [
  { category_index: 1, value_code: "Loading / BOH", description: "Loading / Back of House" },
  { category_index: 1, value_code: "Commercial", description: "Commercial" },
  { category_index: 1, value_code: "Retail", description: "Retail" },
  { category_index: 1, value_code: "Student Accommodation", description: "Student Accommodation" },
  { category_index: 1, value_code: "Communal/Lobby", description: "Communal/Lobby" },
  { category_index: 1, value_code: "GYM", description: "GYM" },
  { category_index: 1, value_code: "Breezeway", description: "Breezeway" },
  { category_index: 1, value_code: "External Works", description: "External Works" },
  { category_index: 1, value_code: "External Services", description: "External Services" },
  { category_index: 1, value_code: "WH1", description: "WH1" },
  { category_index: 1, value_code: "WH2", description: "WH2" },
  { category_index: 1, value_code: "Building A", description: "Building A" },
  { category_index: 1, value_code: "Building B", description: "Building B" },
  { category_index: 1, value_code: "Stage 1B", description: "Stage 1B" },
  { category_index: 1, value_code: "Stage 2B", description: "Stage 2B" },
  { category_index: 2, value_code: "SI", description: "SI" },
  { category_index: 2, value_code: "S&C", description: "S&C" },
  { category_index: 2, value_code: "P1", description: "Package / Zone P1" },
  { category_index: 2, value_code: "P2", description: "Package / Zone P2" },
  { category_index: 2, value_code: "P3", description: "Package / Zone P3" },
  { category_index: 2, value_code: "P4", description: "Package / Zone P4" },
  { category_index: 2, value_code: "P5", description: "Package / Zone P5" },
  { category_index: 2, value_code: "P6", description: "Package / Zone P6" },
  { category_index: 2, value_code: "Mechanical Cooling", description: "Mechanical Cooling" },
  { category_index: 2, value_code: "FLOOR FRAMING", description: "FLOOR FRAMING" },
  { category_index: 2, value_code: "ROOF FRAMING", description: "ROOF FRAMING" },
  { category_index: 2, value_code: "FACADE FRAMING", description: "FACADE FRAMING" },
  { category_index: 2, value_code: "STAIR FRAMING", description: "STAIR FRAMING" },
  { category_index: 3, value_code: "F", description: "Foundation" },
  { category_index: 3, value_code: "B7", description: "Basement 7" },
  { category_index: 3, value_code: "B6", description: "Basement 6" },
  { category_index: 3, value_code: "B5", description: "Basement 5" },
  { category_index: 3, value_code: "B4", description: "Basement 4" },
  { category_index: 3, value_code: "B3", description: "Basement 3" },
  { category_index: 3, value_code: "B2", description: "Basement 2" },
  { category_index: 3, value_code: "B1", description: "Basement 1" },
  { category_index: 3, value_code: "UGF", description: "Upper Ground Floor" },
  { category_index: 3, value_code: "LGF", description: "Lower Ground Floor" },
  { category_index: 3, value_code: "GF", description: "Ground Floor" },
  { category_index: 3, value_code: "Mezz", description: "Mezzanine" },
  ...Array.from({ length: 30 }, (_, i) => ({ category_index: 3, value_code: `L${i + 1}`, description: `Level ${i + 1}` })),
  { category_index: 3, value_code: "Roof", description: "Roof" },
  { category_index: 4, value_code: "0-3.5m high soffit", description: "0-3.5m high soffit" },
  { category_index: 4, value_code: "3.5-4.5m high soffit", description: "3.5-4.5m high soffit" },
  { category_index: 4, value_code: "4.5-5.5m high soffit", description: "4.5-5.5m high soffit" },
  { category_index: 4, value_code: "5.5-6.5m high soffit", description: "5.5-6.5m high soffit" },
  { category_index: 4, value_code: "<250mm high", description: "<250mm high" },
  { category_index: 4, value_code: ">250mm high", description: ">250mm high" },
  { category_index: 4, value_code: "0-0.5m pit depth", description: "0-0.5m pit depth" },
  { category_index: 4, value_code: "0.5-1.0m pit depth", description: "0.5-1.0m pit depth" },
  { category_index: 4, value_code: "1.0-1.5m pit depth", description: "1.0-1.5m pit depth" },
  { category_index: 4, value_code: "0-3m high brick/block wall", description: "0-3m high brick/block wall" },
  { category_index: 4, value_code: "3-4m high brick/block wall", description: "3-4m high brick/block wall" },
  { category_index: 4, value_code: "4-5m high brick/block wall", description: "4-5m high brick/block wall" },
  { category_index: 5, value_code: "internal", description: "internal" },
  { category_index: 5, value_code: "external", description: "external" },
  { category_index: 5, value_code: "shower area", description: "shower area" },
  { category_index: 5, value_code: "non shower area", description: "non shower area" },
  { category_index: 6, value_code: "20MPa", description: "20MPa" },
  { category_index: 6, value_code: "25MPa", description: "25MPa" },
  { category_index: 6, value_code: "32MPa", description: "32MPa" },
  { category_index: 6, value_code: "40MPa", description: "40MPa" },
  { category_index: 6, value_code: "50MPa", description: "50MPa" },
  { category_index: 6, value_code: "65MPa", description: "65MPa" },
  { category_index: 6, value_code: "80MPa", description: "80MPa" },
  { category_index: 6, value_code: "100MPa", description: "100MPa" },
  { category_index: 6, value_code: "L-Bars", description: "L-Bars" },
  { category_index: 6, value_code: "Z-Bars", description: "Z-Bars" },
  { category_index: 6, value_code: "U-Bars", description: "U-Bars" },
  { category_index: 6, value_code: "C-Bars", description: "C-Bars" },
  { category_index: 6, value_code: "Straight Bars", description: "Straight Bars" },
  { category_index: 6, value_code: "Mesh", description: "Mesh" },
  { category_index: 7, value_code: "Double Leaf Fire Rated", description: "Double Leaf Fire Rated" },
  { category_index: 7, value_code: "Double Leaf Solid Core", description: "Double Leaf Solid Core" },
  { category_index: 7, value_code: "Single Leaf Solid Core", description: "Single Leaf Solid Core" },
  { category_index: 7, value_code: "Single Leaf Fire Rated", description: "Single Leaf Fire Rated" },
  { category_index: 7, value_code: "R-1A", description: "R-1A" },
  { category_index: 7, value_code: "R-1B", description: "R-1B" },
  { category_index: 7, value_code: "R-2A", description: "R-2A" },
  { category_index: 7, value_code: "R-2B", description: "R-2B" },
  { category_index: 7, value_code: "R-3A", description: "R-3A" },
  { category_index: 7, value_code: "R-3B", description: "R-3B" },
  { category_index: 7, value_code: "R-3C", description: "R-3C" }
];

let builderZoneLibraryState = [];
let builderTradeProfileState = DEFAULT_BUILDER_TRADE_PROFILES_UI.map(profile => ({ ...profile }));
let builderZoneComboState = DEFAULT_BUILDER_ZONE_COMBOS_UI.map(combo => ({ ...combo, active_categories: combo.active_categories.map(cat => ({ ...cat })) }));
let builderActiveComboId = "walls_milestone_2_by_level";

function sanitizeTokenPartsUi(token) {
  return String(token || "").replace(/[\[\]"\r\n]/g, "").trim();
}

function parseTokenPartsMap(token) {
  const out = {};
  sanitizeTokenPartsUi(token).split(";").forEach(part => {
    const pieces = part.split("|");
    if (pieces.length >= 2) {
      const idx = String(Number(pieces[0].trim()));
      const value = pieces.slice(1).join("|").trim();
      if (idx && value) out[idx] = value;
    }
  });
  return out;
}

function normalizeZoneBehavior(value, idx) {
  const raw = String(value || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
  if (["global", "global_value"].includes(raw)) return "global";
  if (["locked", "locked_from_level_row", "locked_level_row", "locked_from_row"].includes(raw)) return "locked";
  if (["choosable", "optional", "dropdown", "row_dropdown", "optional_row_dropdown"].includes(raw)) return "choosable";
  if (Number(idx) === 1) return "global";
  if (Number(idx) === 3) return "locked";
  return "choosable";
}

function behaviorLabel(behavior) {
  return { global: "Global", locked: "Locked", choosable: "Choosable" }[normalizeZoneBehavior(behavior)] || "Choosable";
}

function categoryLabel(idx) {
  const cat = collectBuilderActiveCategoriesFromUI().find(c => Number(c.category_index) === Number(idx));
  return cat?.category_name || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI.find(c => Number(c.category_index) === Number(idx))?.category_name || `Zone Category ${idx}`;
}

function normalizeActiveCategories(categories) {
  const map = new Map(DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI.map(cat => [Number(cat.category_index), { ...cat }]));
  (categories || []).forEach(cat => {
    const idx = Number(cat.category_index || 0);
    if (idx < 1 || idx > 8) return;
    const base = map.get(idx) || {};
    let behavior = normalizeZoneBehavior(cat.behavior || cat.role || base.behavior, idx);
    if (idx === 3 && cat.active) behavior = "locked";
    map.set(idx, {
      category_index: idx,
      category_name: cat.category_name || base.category_name || `Zone Category ${idx}`,
      active: !!cat.active,
      behavior,
      default_value: behavior === "global" ? (cat.default_value || cat.global_value || base.default_value || "") : "",
      locked_source: behavior === "locked" ? (cat.locked_source || (idx === 3 ? "level_code" : "manual")) : ""
    });
  });
  return Array.from({ length: 8 }, (_, i) => {
    const row = map.get(i + 1);
    row.behavior = normalizeZoneBehavior(row.behavior, row.category_index);
    if (Number(row.category_index) === 3 && row.active) {
      row.behavior = "locked";
      row.locked_source = "level_code";
    }
    if (row.behavior !== "global") row.default_value = "";
    return row;
  });
}

function comboIdFromName(name) {
  return String(name || "zone_combo").trim().toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "zone_combo";
}

function normalizeZoneCombos(combos) {
  const incoming = (combos && combos.length ? combos : DEFAULT_BUILDER_ZONE_COMBOS_UI);
  const seen = new Set();
  const out = [];
  incoming.forEach(combo => {
    const name = String(combo.combo_name || combo.name || "").trim();
    if (!name) return;
    const id = String(combo.combo_id || comboIdFromName(name)).replace(/[^A-Za-z0-9_-]+/g, "_") || comboIdFromName(name);
    if (seen.has(id)) return;
    seen.add(id);
    out.push({
      combo_id: id,
      combo_name: name,
      description: combo.description || "",
      active_categories: normalizeActiveCategories(combo.active_categories || combo.categories).filter(cat => cat.active)
    });
  });
  DEFAULT_BUILDER_ZONE_COMBOS_UI.forEach(combo => {
    if (!seen.has(combo.combo_id)) out.push({ ...combo, active_categories: combo.active_categories.map(cat => ({ ...cat })) });
  });
  return out;
}

function renderBuilderZoneComboSelect(combos, activeId) {
  if (!builderZoneComboSelect) return;
  builderZoneComboState = normalizeZoneCombos(combos);
  builderActiveComboId = activeId && builderZoneComboState.some(c => c.combo_id === activeId) ? activeId : (builderZoneComboState[0]?.combo_id || "walls_milestone_2_by_level");
  builderZoneComboSelect.innerHTML = builderZoneComboState.map(combo => `<option value="${escapeAttr(combo.combo_id)}" ${combo.combo_id === builderActiveComboId ? "selected" : ""}>${escapeHtml(combo.combo_name)}</option>`).join("");
}

function activeZoneCombo() {
  return builderZoneComboState.find(combo => combo.combo_id === builderActiveComboId) || builderZoneComboState[0] || DEFAULT_BUILDER_ZONE_COMBOS_UI[0];
}


function normalizeTradeProfileIdUi(value) {
  const raw = String(value || "").trim();
  if (!raw) return "walls_partitions";
  const key = raw.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  const alias = {
    "walls_partitions": "walls_partitions",
    "walls": "walls_partitions",
    "partitions": "walls_partitions",
    "doors_windows": "doors_windows",
    "doors_and_windows": "doors_windows",
    "door_window": "doors_windows",
    "doors": "doors_windows",
    "door": "doors_windows",
    "windows": "doors_windows",
    "window": "doors_windows",
    "metalwork_structural_steel": "metalwork_structural_steel",
    "metalwork": "metalwork_structural_steel",
    "structural_steel": "metalwork_structural_steel",
    "steel": "metalwork_structural_steel",
    "concrete_reo": "concrete_reo",
    "concrete": "concrete_reo",
    "reo": "concrete_reo",
    "reinforcement": "concrete_reo",
    "finishes": "finishes",
    "floor_finishes": "finishes",
    "external_finishes": "finishes",
    "internal_finishes": "finishes",
    "ceiling": "ceilings",
    "ceilings": "ceilings",
    "joinery": "joinery",
    "ffe": "joinery",
    "civil": "civil_earthworks",
    "earthworks": "civil_earthworks",
    "civil_earthworks": "civil_earthworks",
    "demolition": "demolition",
    "landscape": "landscape"
  };
  return alias[key] || key || "walls_partitions";
}

function normalizeTradeProfileListUi(profiles) {
  const source = profiles && profiles.length ? profiles : DEFAULT_BUILDER_TRADE_PROFILES_UI;
  const seen = new Set();
  const out = [];
  source.forEach(profile => {
    const id = normalizeTradeProfileIdUi(profile.profile_id || profile.id || profile.display_name);
    if (!id || seen.has(id)) return;
    seen.add(id);
    out.push({ ...profile, profile_id: id });
  });
  return out.length ? out : DEFAULT_BUILDER_TRADE_PROFILES_UI.map(profile => ({ ...profile }));
}

function ensureBuilderTradeProfilesLoaded(activeProfileId = "walls_partitions") {
  builderTradeProfileState = normalizeTradeProfileListUi(builderTradeProfileState);
  if (!builderTradeProfileSelect) return;
  const normalizedActive = normalizeTradeProfileIdUi(activeProfileId);
  builderTradeProfileSelect.innerHTML = builderTradeProfileState.map(profile => {
    const id = normalizeTradeProfileIdUi(profile.profile_id || profile.display_name);
    return `<option value="${escapeAttr(id)}">${escapeHtml(profile.display_name || id)}</option>`;
  }).join("");
  const validValues = new Set(Array.from(builderTradeProfileSelect.options).map(opt => opt.value));
  builderTradeProfileSelect.value = validValues.has(normalizedActive) ? normalizedActive : "walls_partitions";
  if (!builderTradeProfileSelect.value && builderTradeProfileSelect.options.length) builderTradeProfileSelect.selectedIndex = 0;
}

function tradeProfileById(profileId) {
  const wanted = normalizeTradeProfileIdUi(profileId || "walls_partitions");
  const profiles = builderTradeProfileState && builderTradeProfileState.length ? builderTradeProfileState : DEFAULT_BUILDER_TRADE_PROFILES_UI;
  return profiles.find(profile => normalizeTradeProfileIdUi(profile.profile_id || profile.display_name) === wanted) || profiles[0] || DEFAULT_BUILDER_TRADE_PROFILES_UI[0];
}

function renderBuilderTradeProfiles(profiles, activeProfileId) {
  builderTradeProfileState = normalizeTradeProfileListUi(profiles);
  ensureBuilderTradeProfilesLoaded(activeProfileId || builderTradeProfileState[0]?.profile_id || "walls_partitions");
  renderTradeProfileSummary(tradeProfileById(builderTradeProfileSelect?.value || activeProfileId || "walls_partitions"));
}

function renderTradeProfileSummary(profile) {
  if (!builderTradeProfileSummary || !profile) return;
  const fn = builderDefaultCostXFunctionSelect?.value || profile.default_costx_function || "XGETWALLAREA";
  const customName = sanitizeCustomQuantityNameUi(builderCustomQuantitySelect?.value || profile.default_custom_quantity || defaultCustomQuantityTemplatesUi(profile)[0]?.name || "");
  const customUnit = customName ? customQuantityUnitUi(profile, customName) : "";
  const displayUnit = fn.toUpperCase().includes("CUSTOM") ? (customUnit || "Review") : expectedUnitForProfileUi(profile, fn);
  builderTradeProfileSummary.innerHTML = `
    <strong>${escapeHtml(profile.display_name || "Trade Profile")}</strong><br>
    <span>${escapeHtml(profile.description || "")}</span>
    <div class="trade-profile-tag">Function: ${escapeHtml(fn)}</div>
    <div class="trade-profile-tag">Unit: ${escapeHtml(displayUnit || "Review")}</div>
    ${fn.toUpperCase().includes("CUSTOM") ? `<div class="trade-profile-tag">Custom: ${escapeHtml(customName || "Select quantity")}</div>` : ""}
    <div class="trade-profile-tag">Layout: ${escapeHtml((profile.layout_mode || "item_first_levels_below").replaceAll("_", " "))}</div>
    <div class="trade-profile-tag">Combo: ${escapeHtml(profile.recommended_combo_id || "")}</div>
    <ul class="trade-profile-summary-list">
      <li><strong>Layout:</strong> ${escapeHtml(profile.layout_rule || "Base Head4 + level rows")}</li>
      <li><strong>Zones:</strong> ${escapeHtml(profile.zones_rule || "Use selected zone combo")}</li>
      <li><strong>Future:</strong> ${escapeHtml(profile.future_notes || "No future notes")}</li>
    </ul>
  `;
}


function expectedUnitForFunctionUi(functionName) {
  const f = String(functionName || "").toUpperCase();
  if (f.includes("COUNT") || f.includes("NUMBER")) return "no";
  if (f.includes("VOLUME")) return "m3";
  if (f.includes("LENGTH") || f.includes("PERIMETER")) return "m";
  if (f.includes("WEIGHT") || f.includes("MASS")) return "kg";
  if (f.includes("CUSTOM")) return "Review";
  return "m2";
}

function canonicalUnitUi(unitText) {
  const raw = String(unitText || "").trim();
  if (/^no\.?$/i.test(raw)) return "no";
  return raw;
}


function sanitizeCustomQuantityNameUi(value) {
  return String(value || "").replace(/["\r\n\[\];]+/g, " ").trim();
}

function defaultCustomQuantityTemplatesUi(profile) {
  const pid = normalizeTradeProfileIdUi(profile?.profile_id || "generic_custom");
  const map = {
    metalwork_structural_steel: [
      { name: "Slope Length", unit: "m" },
      { name: "Steel Surface Area", unit: "m2" },
      { name: "Weight", unit: "t" },
      { name: "RAKING CUTTING", unit: "m" }
    ],
    concrete_reo: [
      { name: "Formworks", unit: "m2" },
      { name: "Reinforcement by Ratio", unit: "t" },
      { name: "PT Reinforcement", unit: "t" },
      { name: "Core Filling", unit: "m3" },
      { name: "Slab Thickness", unit: "m" },
      { name: "Weight", unit: "t" }
    ],
    civil_earthworks: [
      { name: "RAKING CUTTING", unit: "m" },
      { name: "Slope Length", unit: "m" },
      { name: "Core Filling", unit: "m3" }
    ],
    civil_works: [
      { name: "RAKING CUTTING", unit: "m" },
      { name: "Slope Length", unit: "m" },
      { name: "Core Filling", unit: "m3" }
    ],
    generic_custom: [
      { name: "Slope Length", unit: "m" },
      { name: "Steel Surface Area", unit: "m2" },
      { name: "Weight", unit: "t" },
      { name: "Formworks", unit: "m2" },
      { name: "Reinforcement by Ratio", unit: "t" },
      { name: "PT Reinforcement", unit: "t" },
      { name: "Core Filling", unit: "m3" },
      { name: "RAKING CUTTING", unit: "m" }
    ]
  };
  const raw = [...(profile?.custom_quantity_templates || []), ...(map[pid] || []), ...(pid === "generic_custom" ? [] : map.generic_custom)];
  const seen = new Set();
  return raw.map(item => ({ name: sanitizeCustomQuantityNameUi(item.name || item.custom_quantity_name), unit: canonicalUnitUi(item.unit || item.uom || item.custom_quantity_unit || "Review") }))
    .filter(item => item.name && !seen.has(item.name.toLowerCase()) && seen.add(item.name.toLowerCase()));
}

function customQuantityUnitUi(profile, customQuantityName) {
  const wanted = sanitizeCustomQuantityNameUi(customQuantityName).toLowerCase();
  const found = defaultCustomQuantityTemplatesUi(profile).find(item => item.name.toLowerCase() === wanted);
  if (found?.unit && String(found.unit).toLowerCase() !== "review") return canonicalUnitUi(found.unit);
  const profileDefaultName = sanitizeCustomQuantityNameUi(profile?.default_custom_quantity || "").toLowerCase();
  if (wanted && wanted === profileDefaultName && profile?.default_custom_quantity_unit) return canonicalUnitUi(profile.default_custom_quantity_unit);
  return canonicalUnitUi(profile?.default_unit || "Review");
}


function renderCustomQuantityOptions(profile, selectedName = "") {
  if (!builderCustomQuantitySelect) return;
  const templates = defaultCustomQuantityTemplatesUi(profile);
  const selected = sanitizeCustomQuantityNameUi(selectedName || profile?.default_custom_quantity || templates[0]?.name || "");
  builderCustomQuantitySelect.innerHTML = `<option value="">Not used unless XGETCUSTOM</option>` + templates.map(item => `<option value="${escapeAttr(item.name)}" data-unit="${escapeAttr(item.unit)}">${escapeHtml(item.name)} (${escapeHtml(item.unit)})</option>`).join("");
  if (selected && templates.some(item => item.name === selected)) builderCustomQuantitySelect.value = selected;
  else builderCustomQuantitySelect.value = "";
  if (builderCustomQuantityUnitInput) builderCustomQuantityUnitInput.value = builderCustomQuantitySelect.value ? customQuantityUnitUi(profile, builderCustomQuantitySelect.value) : "";
}

function selectedCustomQuantityUnitUi(profile) {
  const name = sanitizeCustomQuantityNameUi(builderCustomQuantitySelect?.value || profile?.default_custom_quantity || "");
  return name ? customQuantityUnitUi(profile, name) : "Review";
}

function expectedUnitForProfileUi(profile, functionName) {
  const fn = String(functionName || profile?.default_costx_function || "XGETWALLAREA").toUpperCase();
  if (fn.includes("COUNT") || fn.includes("NUMBER")) return "no";
  if (fn.includes("CUSTOM")) {
    const customUnit = selectedCustomQuantityUnitUi(profile);
    if (customUnit && customUnit.toLowerCase() !== "review") return customUnit;
  }
  const profileUnit = canonicalUnitUi(profile?.default_unit || "");
  // Mixed-unit profiles remain guidance, not a forced unit.
  if (profileUnit && (profileUnit.includes("/") || profileUnit.toLowerCase().includes("review"))) return profileUnit;
  if (profileUnit) return profileUnit;
  return expectedUnitForFunctionUi(fn);
}

function syncExpectedUnitGuard() {
  const profile = tradeProfileById(builderTradeProfileSelect?.value || "walls_partitions");
  const fn = builderDefaultCostXFunctionSelect?.value || profile?.default_costx_function || "XGETWALLAREA";
  if (fn.toUpperCase().includes("CUSTOM") && builderCustomQuantityUnitInput && builderCustomQuantitySelect?.value) {
    builderCustomQuantityUnitInput.value = customQuantityUnitUi(profile, builderCustomQuantitySelect.value);
  }
  if (builderExpectedUnitInput) builderExpectedUnitInput.value = expectedUnitForProfileUi(profile, fn);
  return builderExpectedUnitInput?.value || expectedUnitForProfileUi(profile, fn);
}

function applyBuilderTradeProfile(profileId, options = {}) {
  const profile = tradeProfileById(normalizeTradeProfileIdUi(profileId || builderTradeProfileSelect?.value || "walls_partitions"));
  if (!profile) return;
  if (builderTradeProfileSelect) { ensureBuilderTradeProfilesLoaded(profile.profile_id); builderTradeProfileSelect.value = normalizeTradeProfileIdUi(profile.profile_id); }
  renderCustomQuantityOptions(profile, profile.default_custom_quantity || "");
  if (builderDefaultCostXFunctionSelect) builderDefaultCostXFunctionSelect.value = profile.default_costx_function || "XGETWALLAREA";
  if (builderExpectedUnitInput) builderExpectedUnitInput.value = expectedUnitForProfileUi(profile, profile.default_costx_function || "XGETWALLAREA");
  if (builderCostXFunctionModeSelect) builderCostXFunctionModeSelect.value = profile.recommended_function_mode || "preserve_detected";
  if (builderFormulaModeSelect) builderFormulaModeSelect.value = profile.recommended_formula_mode || "Compact";
  if (profile.recommended_combo_id) {
    const combo = builderZoneComboState.find(c => c.combo_id === profile.recommended_combo_id);
    if (combo) {
      builderActiveComboId = combo.combo_id;
      if (builderPresetNameInput) builderPresetNameInput.value = combo.combo_name;
      renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
      renderBuilderActiveZoneCards(combo.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI);
      renderBuilderLevelRows(collectBuilderLevelsFromUI().length ? collectBuilderLevelsFromUI() : DEFAULT_BUILDER_LEVELS_UI, { keepRows: true });
    }
  }
  renderTradeProfileSummary(profile);
  syncCurrentWorkSummary();
  if (options.persist) persistBuilderCurrentWorkSetup({ silent: !!options.silent, reason: "trade_profile_apply" });
  if (!options.silent) syncBuilderLevelStatus(`Applied and locked trade profile: ${profile.display_name}`, "warn");
}

function applyZoneCombo(comboId) {
  const combo = builderZoneComboState.find(c => c.combo_id === comboId) || activeZoneCombo();
  if (!combo) return;
  builderActiveComboId = combo.combo_id;
  if (builderPresetNameInput) builderPresetNameInput.value = combo.combo_name;
  renderBuilderTradeProfiles(builderTradeProfileState, collectCurrentWorkSetupFromUI().trade_profile_id || "walls_partitions");
  renderCurrentWorkSetup({ ...collectCurrentWorkSetupFromUI(), setup_name: combo.combo_name });
  renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
  renderBuilderActiveZoneCards(combo.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI);
  renderBuilderLevelRows(collectBuilderLevelsFromUI().length ? collectBuilderLevelsFromUI() : DEFAULT_BUILDER_LEVELS_UI, { keepRows: true });
  updateMainBuilderTokenPreview();
  syncBuilderLevelStatus(`Applied combo: ${combo.combo_name}`, "warn");
}


function collectCurrentWorkSetupFromUI() {
  return {
    project_name: builderProjectNameInput?.value?.trim() || "Current Project",
    trade_profile_id: normalizeTradeProfileIdUi(builderTradeProfileSelect?.value || "walls_partitions"),
    setup_name: builderPresetNameInput?.value?.trim() || activeZoneCombo()?.combo_name || "Active",
    expected_unit: syncExpectedUnitGuard(),
    formula_mode: builderFormulaModeSelect?.value || "Compact",
    default_costx_function: builderDefaultCostXFunctionSelect?.value || "XGETWALLAREA",
    costx_function_mode: builderCostXFunctionModeSelect?.value || "preserve_detected",
    custom_quantity_name: sanitizeCustomQuantityNameUi(builderCustomQuantitySelect?.value || ""),
    custom_quantity_unit: builderCustomQuantityUnitInput?.value || "",
    zone_token_mode: "preserve_source",
    notes: builderSetupNotesInput?.value?.trim() || ""
  };
}

async function persistBuilderCurrentWorkSetup(options = {}) {
  if (!builderLevelTableBody) return;
  clearTimeout(builderCurrentWorkPersistTimer);
  const delay = options.now ? 0 : 120;
  builderCurrentWorkPersistTimer = setTimeout(async () => {
    if (builderCurrentWorkPersistInFlight) {
      // v4.3.9 guard: do not drop a later custom quantity change while a profile save is still running.
      // The pending save re-reads the live UI after the current request completes, so Weight/t cannot fall back to Slope Length/m.
      builderCurrentWorkPersistPendingOptions = { ...(builderCurrentWorkPersistPendingOptions || {}), ...options, now: true, silent: true };
      return;
    }
    try {
      builderCurrentWorkPersistInFlight = true;
      const res = await fetch("/api/builder/current-work-setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_work_setup: collectCurrentWorkSetupFromUI(),
          active_combo_id: builderActiveComboId,
          active_categories: collectBuilderActiveCategoriesFromUI()
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Could not lock current work setup");
      builderLevelZoneSetup = data;
      builderZoneComboState = normalizeZoneCombos(data.zone_combos || builderZoneComboState);
      builderActiveComboId = data.active_combo_id || builderActiveComboId;
      builderTradeProfileState = normalizeTradeProfileListUi(data.trade_profiles || builderTradeProfileState);
      if (!options.silent) showToast(options.reason === "custom_quantity_change" ? "Custom quantity locked in Workspace" : "Trade profile locked in Workspace");
      const customName = data.current_work_setup?.custom_quantity_name ? ` · ${data.current_work_setup.custom_quantity_name}` : "";
      syncBuilderLevelStatus(`Current work setup locked: ${tradeProfileById(data.current_work_setup?.trade_profile_id)?.display_name || data.current_work_setup?.trade_profile_id || "Trade Profile"}${customName}`);
    } catch (error) {
      syncBuilderLevelStatus(error.message || "Could not lock current work setup", "warn");
    } finally {
      builderCurrentWorkPersistInFlight = false;
      if (builderCurrentWorkPersistPendingOptions) {
        const pending = builderCurrentWorkPersistPendingOptions;
        builderCurrentWorkPersistPendingOptions = null;
        persistBuilderCurrentWorkSetup({ ...pending, now: true, silent: true });
      }
    }
  }, delay);
}

function renderCurrentWorkSetup(currentWork = {}) {
  const setup = {
    project_name: currentWork.project_name || "Current Project",
    trade_profile_id: normalizeTradeProfileIdUi(currentWork.trade_profile_id || currentWork.trade_type || "walls_partitions"),
    setup_name: currentWork.setup_name || builderPresetNameInput?.value || activeZoneCombo()?.combo_name || "Active",
    formula_mode: currentWork.formula_mode || "Compact",
    default_costx_function: currentWork.default_costx_function || currentWork.costx_function || "",
    costx_function_mode: currentWork.costx_function_mode || currentWork.function_mode || "",
    custom_quantity_name: currentWork.custom_quantity_name || currentWork.default_custom_quantity || "",
    custom_quantity_unit: currentWork.custom_quantity_unit || currentWork.default_custom_quantity_unit || "",
    notes: currentWork.notes || ""
  };
  const activeProfile = tradeProfileById(setup.trade_profile_id);
  if (!setup.default_costx_function) setup.default_costx_function = activeProfile?.default_costx_function || "XGETWALLAREA";
  if (!setup.costx_function_mode) setup.costx_function_mode = activeProfile?.recommended_function_mode || "preserve_detected";
  const expectedUnit = expectedUnitForProfileUi(activeProfile, setup.default_costx_function);
  if (builderProjectNameInput) builderProjectNameInput.value = setup.project_name;
  if (builderTradeProfileSelect) { ensureBuilderTradeProfilesLoaded(setup.trade_profile_id); builderTradeProfileSelect.value = setup.trade_profile_id; }
  renderCustomQuantityOptions(activeProfile, setup.custom_quantity_name || activeProfile?.default_custom_quantity || "");
  if (setup.custom_quantity_unit && builderCustomQuantityUnitInput) {
    const templateUnit = customQuantityUnitUi(activeProfile, builderCustomQuantitySelect?.value || setup.custom_quantity_name || activeProfile?.default_custom_quantity || "");
    builderCustomQuantityUnitInput.value = templateUnit && templateUnit.toLowerCase() !== "review" ? templateUnit : setup.custom_quantity_unit;
  }
  const syncedExpectedUnit = expectedUnitForProfileUi(activeProfile, setup.default_costx_function);
  if (builderExpectedUnitInput) builderExpectedUnitInput.value = syncedExpectedUnit;
  if (builderFormulaModeSelect) builderFormulaModeSelect.value = setup.formula_mode;
  if (builderDefaultCostXFunctionSelect) builderDefaultCostXFunctionSelect.value = setup.default_costx_function;
  if (builderCostXFunctionModeSelect) builderCostXFunctionModeSelect.value = setup.costx_function_mode;
  if (builderSetupNotesInput) builderSetupNotesInput.value = setup.notes;
  renderTradeProfileSummary(activeProfile);
  if (builderCurrentWorkSummary) {
    const customSummary = String(setup.default_costx_function || "").toUpperCase().includes("CUSTOM") && builderCustomQuantitySelect?.value ? ` · Custom ${escapeHtml(builderCustomQuantitySelect.value)}` : "";
    builderCurrentWorkSummary.innerHTML = `<strong>${escapeHtml(activeProfile?.display_name || "Trade Profile")}</strong><br><span>${escapeHtml(setup.project_name)} · ${escapeHtml(setup.formula_mode)} mode · ${escapeHtml(setup.default_costx_function)} · Unit ${escapeHtml(syncedExpectedUnit || expectedUnit)}${customSummary} · ${setup.costx_function_mode === "force_default" ? "Force default" : "Preserve detected"}</span>`;
  }
  updateZoneSectionSummaries();
}

function syncCurrentWorkSummary() {
  renderCurrentWorkSetup(collectCurrentWorkSetupFromUI());
}

function optionHtmlForGlobalZone(idx, selected) {
  const selectedSafe = selected || "";
  const options = zoneOptionsForCategory(idx);
  let hasSelected = !selectedSafe;
  let html = `<option value="">Select from ZC${Number(idx)} library...</option>`;
  options.forEach(opt => {
    const val = opt.value_code || "";
    if (val === selectedSafe) hasSelected = true;
    html += `<option value="${escapeAttr(val)}" ${val === selectedSafe ? "selected" : ""}>${escapeHtml(val)}${opt.description && opt.description !== val ? ` — ${escapeHtml(opt.description)}` : ""}</option>`;
  });
  if (!hasSelected && selectedSafe) html += `<option value="${escapeAttr(selectedSafe)}" selected>${escapeHtml(selectedSafe)} — custom saved value</option>`;
  return html;
}

function collectBuilderActiveCategoriesFromUI() {
  if (!builderActiveZonesGrid) return builderLevelZoneSetup?.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI;
  return Array.from(builderActiveZonesGrid.querySelectorAll("[data-zc-card]")).map(card => {
    const idx = Number(card.dataset.zcCard || 1);
    const active = !!card.querySelector(`[data-zc-active]`)?.checked;
    let behavior = normalizeZoneBehavior(card.querySelector(`[data-zc-behavior]`)?.value || "", idx);
    if (idx === 3 && active) behavior = "locked";
    return {
      category_index: idx,
      category_name: card.querySelector(`[data-zc-name]`)?.value?.trim() || `Zone Category ${idx}`,
      active,
      behavior,
      default_value: behavior === "global" ? (card.querySelector(`[data-zc-default]`)?.value?.trim() || "") : "",
      locked_source: behavior === "locked" ? (card.querySelector(`[data-zc-locked-source]`)?.value?.trim() || (idx === 3 ? "level_code" : "manual")) : ""
    };
  });
}

function activeBuilderCategories() {
  return normalizeActiveCategories(collectBuilderActiveCategoriesFromUI()).filter(cat => cat.active).sort((a, b) => Number(a.category_index) - Number(b.category_index));
}

function activeChoosableCategories() {
  return activeBuilderCategories().filter(cat => normalizeZoneBehavior(cat.behavior, cat.category_index) === "choosable");
}

function activeOptionalCategories() {
  return activeChoosableCategories();
}

function collectBuilderZoneLibraryFromUI() {
  return (builderZoneLibraryState.length ? builderZoneLibraryState : (builderLevelZoneSetup?.zone_library || DEFAULT_BUILDER_ZONE_LIBRARY_UI)).map(z => ({
    category_index: Number(z.category_index || 1),
    category_name: z.category_name || categoryLabel(z.category_index || 1),
    value_code: String(z.value_code || "").trim(),
    description: String(z.description || "").trim()
  })).filter(z => z.value_code);
}

function zoneOptionsForCategory(idx) {
  return collectBuilderZoneLibraryFromUI().filter(z => Number(z.category_index) === Number(idx));
}

function optionHtmlForZone(idx, selected) {
  const options = zoneOptionsForCategory(idx);
  const selectedSafe = selected || "";
  let html = `<option value=""></option>`;
  options.forEach(opt => {
    const val = opt.value_code || "";
    html += `<option value="${escapeAttr(val)}" ${val === selectedSafe ? "selected" : ""}>${escapeHtml(val)}${opt.description && opt.description !== val ? ` — ${escapeHtml(opt.description)}` : ""}</option>`;
  });
  return html;
}

function renderBuilderActiveZoneCards(categories) {
  if (!builderActiveZonesGrid) return;
  const rows = normalizeActiveCategories(categories);
  builderActiveZonesGrid.innerHTML = rows.map(cat => {
    const idx = Number(cat.category_index);
    const behavior = normalizeZoneBehavior(cat.behavior, idx);
    const showGlobalValue = !!cat.active && behavior === "global";
    const sourceLabel = idx === 3 && behavior === "locked" ? "from Level Code" : (behavior === "locked" ? "locked/manual" : "");
    return `
      <div class="zone-category-card ${cat.active ? "active" : ""}" data-zc-card="${idx}">
        <label class="zone-check-row">
          <input type="checkbox" data-zc-active ${cat.active ? "checked" : ""} />
          <span>ZC${idx}</span>
        </label>
        <select class="zone-behavior-select" data-zc-behavior ${idx === 3 ? "disabled" : ""}>
          <option value="global" ${behavior === "global" ? "selected" : ""}>Global</option>
          <option value="locked" ${behavior === "locked" ? "selected" : ""}>Locked</option>
          <option value="choosable" ${behavior === "choosable" ? "selected" : ""}>Choosable</option>
        </select>
        <input class="zone-card-name readonly-soft" data-zc-name value="${escapeAttr(cat.category_name || `Zone Category ${idx}`)}" />
        ${showGlobalValue ? `<div class="global-zone-value-wrap">
          <label class="global-zone-value-label">Global Value · from ZC${idx} library</label>
          <select class="zone-card-default global-zone-select" data-zc-default title="Choose from the CostX Zone Library for ZC${idx}">${optionHtmlForGlobalZone(idx, cat.default_value || "")}</select>
        </div>` : ""}
        <input type="hidden" data-zc-locked-source value="${escapeAttr(behavior === "locked" ? (cat.locked_source || (idx === 3 ? "level_code" : "manual")) : "")}" />
        <span class="zone-card-role">${escapeHtml(behavior === "locked" && idx === 3 ? "Locked from Level Code" : behaviorLabel(behavior))}${sourceLabel && !(behavior === "locked" && idx === 3) ? ` · ${escapeHtml(sourceLabel)}` : ""}</span>
      </div>
    `;
  }).join("");
  builderActiveZonesGrid.querySelectorAll("input,select").forEach(input => input.addEventListener("input", () => {
    renderBuilderLevelRows(collectBuilderLevelsFromUI(), { keepRows: true });
    renderBuilderZoneLibraryRows(collectBuilderZoneLibraryFromUI());
    updateMainBuilderTokenPreview();
    syncBuilderLevelStatus("Zone behavior edited. Save setup or save current as a combo.", "warn");
  }));
  builderActiveZonesGrid.querySelectorAll("[data-zc-active],[data-zc-behavior]").forEach(input => input.addEventListener("change", () => {
    const current = collectBuilderActiveCategoriesFromUI();
    renderBuilderActiveZoneCards(current);
    renderBuilderLevelRows(collectBuilderLevelsFromUI(), { keepRows: true });
    renderBuilderZoneLibraryRows(collectBuilderZoneLibraryFromUI());
    updateMainBuilderTokenPreview();
    syncBuilderLevelStatus("Active zone behavior changed. Save setup or save as combo.", "warn");
  }));
}

function buildTokenFromMap(valueMap) {
  const parts = [];
  activeBuilderCategories().forEach(cat => {
    const idx = Number(cat.category_index);
    const behavior = normalizeZoneBehavior(cat.behavior, idx);
    let value = "";
    if (behavior === "global") value = cat.default_value || valueMap[String(idx)] || "";
    if (behavior === "locked") value = idx === 3 ? (valueMap["3"] || "") : (valueMap[String(idx)] || cat.default_value || "");
    if (behavior === "choosable") value = valueMap[String(idx)] || "";
    if (value) parts.push(`${idx}|${value}`);
  });
  return parts.join(";");
}

function builderToken(level) {
  const map = parseTokenPartsMap(level.token_parts || "");
  if (level.level_code) map["3"] = level.level_code;
  return buildTokenFromMap(map);
}

function levelValueMap(level) {
  const map = parseTokenPartsMap(level.token_parts || "");
  if (level.level_code) map["3"] = level.level_code;
  activeBuilderCategories().forEach(cat => {
    if (normalizeZoneBehavior(cat.behavior, cat.category_index) === "global") map[String(cat.category_index)] = cat.default_value || map[String(cat.category_index)] || "";
  });
  return map;
}

function renderBuilderLevelRows(levels, options = {}) {
  if (!builderLevelTableBody || !builderLevelTableHead) return;
  const rows = levels && levels.length ? levels : DEFAULT_BUILDER_LEVELS_UI;
  const choosableCats = activeChoosableCategories();
  const showExtraToken = choosableCats.length > 0;
  builderLevelTableHead.innerHTML = `
    <tr>
      <th>Level / Row Description</th>
      <th>Level Code <span class="locked-inline-note">Locked ZC3</span></th>
      ${choosableCats.map(cat => `<th>ZC${Number(cat.category_index)} — ${escapeHtml(cat.category_name)}</th>`).join("")}
      ${showExtraToken ? `<th>Extra Token Parts</th>` : ""}
      <th>Token Preview</th>
      <th class="remove-col"></th>
    </tr>
  `;
  builderLevelTableBody.innerHTML = rows.map((level, index) => {
    const valueMap = levelValueMap(level);
    return `
      <tr data-builder-level-row="${index}">
        <td><input class="builder-level-input wide" data-field="description" value="${escapeAttr(level.description || level.level_code || "")}" /></td>
        <td><input class="builder-level-input level-code-field" data-field="level_code" value="${escapeAttr(valueMap["3"] || level.level_code || "")}" /></td>
        ${choosableCats.map(cat => {
          const idx = Number(cat.category_index);
          const selected = valueMap[String(idx)] || "";
          return `<td><select class="builder-level-input optional-zone-select" data-zc-value="${idx}">${optionHtmlForZone(idx, selected)}</select></td>`;
        }).join("")}
        ${showExtraToken ? `<td><input class="builder-level-input extra-token-field" data-field="extra_token_parts" placeholder="optional e.g. 7|Double Leaf Fire Rated" value="${escapeAttr(level.extra_token_parts || "")}" /></td>` : ""}
        <td><code class="builder-token-preview">[${escapeHtml(buildTokenFromMap(valueMap))}]</code></td>
        <td><button class="action secondary mini-action remove-builder-row" data-remove-builder-level="${index}" type="button">Remove</button></td>
      </tr>
    `;
  }).join("");
  builderLevelTableBody.querySelectorAll("input,select").forEach(input => input.addEventListener("input", syncBuilderTokenPreviews));
  builderLevelTableBody.querySelectorAll("select").forEach(select => select.addEventListener("change", syncBuilderTokenPreviews));
  builderLevelTableBody.querySelectorAll("[data-remove-builder-level]").forEach(btn => btn.addEventListener("click", () => {
    const rowsNow = collectBuilderLevelsFromUI();
    rowsNow.splice(Number(btn.dataset.removeBuilderLevel || 0), 1);
    renderBuilderLevelRows(rowsNow.length ? rowsNow : DEFAULT_BUILDER_LEVELS_UI);
    syncBuilderLevelStatus("Builder row removed. Save setup to keep the change.", "warn");
  }));
  syncBuilderTokenPreviews();
  updateZoneSectionSummaries();
}

function collectBuilderLevelsFromUI() {
  if (!builderLevelTableBody) return builderLevelZoneSetup?.levels || DEFAULT_BUILDER_LEVELS_UI;
  return Array.from(builderLevelTableBody.querySelectorAll("tr")).map(row => {
    const description = row.querySelector(`[data-field="description"]`)?.value?.trim() || "";
    const levelCode = row.querySelector(`[data-field="level_code"]`)?.value?.trim() || "";
    const map = { "3": levelCode };
    activeBuilderCategories().forEach(cat => {
      const idx = String(Number(cat.category_index));
      const behavior = normalizeZoneBehavior(cat.behavior, cat.category_index);
      if (behavior === "global") map[idx] = cat.default_value || "";
      if (behavior === "choosable") {
        const value = row.querySelector(`[data-zc-value="${idx}"]`)?.value?.trim() || "";
        if (value) map[idx] = value;
      }
    });
    const extra = sanitizeTokenPartsUi(row.querySelector(`[data-field="extra_token_parts"]`)?.value || "");
    let token = buildTokenFromMap(map);
    if (extra) token = [token, extra].filter(Boolean).join(";");
    return {
      zone_index: 1,
      zone_name: activeBuilderCategories().find(cat => Number(cat.category_index) === 1)?.default_value || "",
      level_index: 3,
      level_code: levelCode,
      description,
      extra_token_parts: extra,
      token_parts: token
    };
  }).filter(level => level.description && level.level_code && level.token_parts);
}

function syncBuilderTokenPreviews() {
  if (!builderLevelTableBody) return;
  Array.from(builderLevelTableBody.querySelectorAll("tr")).forEach(row => {
    const description = row.querySelector(`[data-field="description"]`)?.value?.trim() || "";
    const levelCode = row.querySelector(`[data-field="level_code"]`)?.value?.trim() || "";
    const map = { "3": levelCode };
    activeBuilderCategories().forEach(cat => {
      const idx = String(Number(cat.category_index));
      const behavior = normalizeZoneBehavior(cat.behavior, cat.category_index);
      if (behavior === "global") map[idx] = cat.default_value || "";
      if (behavior === "choosable") {
        const value = row.querySelector(`[data-zc-value="${idx}"]`)?.value?.trim() || "";
        if (value) map[idx] = value;
      }
    });
    const extra = sanitizeTokenPartsUi(row.querySelector(`[data-field="extra_token_parts"]`)?.value || "");
    let token = buildTokenFromMap(map);
    if (extra) token = [token, extra].filter(Boolean).join(";");
    const preview = row.querySelector(".builder-token-preview");
    if (preview && description && levelCode) preview.textContent = `[${token}]`;
  });
  updateMainBuilderTokenPreview();
}

function updateMainBuilderTokenPreview() {
  if (!builderTokenPreview) return;
  const first = collectBuilderLevelsFromUI()[0] || DEFAULT_BUILDER_LEVELS_UI[3];
  builderTokenPreview.textContent = `[${builderToken(first)}]`;
}

function syncBuilderLevelStatus(message, tone = "safe") {
  if (!builderLevelZoneStatus) return;
  const count = collectBuilderLevelsFromUI().length;
  const active = activeBuilderCategories().map(cat => `ZC${cat.category_index}:${behaviorLabel(cat.behavior)}`).join(", ") || "none";
  const combo = activeZoneCombo()?.combo_name || builderPresetNameInput?.value || "Active";
  builderLevelZoneStatus.innerHTML = `<div class="notice ${tone}"><strong>${escapeHtml(message)}</strong><br>${count} builder row(s). Combo: ${escapeHtml(combo)}. Active formula zones: ${escapeHtml(active)}. Locked zones are not editable per row. CostX formulas remain live Excel formulas.</div>`;
  updateZoneSectionSummaries();
}

function saveCurrentZoneComboToMemory() {
  const comboName = builderPresetNameInput?.value?.trim() || "New Zone Combo";
  const comboId = comboIdFromName(comboName);
  const activeCats = activeBuilderCategories();
  const payload = { combo_id: comboId, combo_name: comboName, description: "Saved from UI", active_categories: activeCats };
  const idx = builderZoneComboState.findIndex(c => c.combo_id === comboId);
  if (idx >= 0) builderZoneComboState[idx] = payload;
  else builderZoneComboState.push(payload);
  builderActiveComboId = comboId;
  renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
  syncBuilderLevelStatus(`Saved combo in UI memory: ${comboName}. Click Save Zone Manager to persist.`, "warn");
}

function deleteCurrentZoneComboFromMemory() {
  if (!builderZoneComboState.length) return;
  const active = activeZoneCombo();
  builderZoneComboState = builderZoneComboState.filter(c => c.combo_id !== active.combo_id);
  if (!builderZoneComboState.length) builderZoneComboState = DEFAULT_BUILDER_ZONE_COMBOS_UI.map(c => ({ ...c, active_categories: c.active_categories.map(cat => ({ ...cat })) }));
  builderActiveComboId = builderZoneComboState[0].combo_id;
  renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
  applyZoneCombo(builderActiveComboId);
  syncBuilderLevelStatus(`Deleted combo from UI memory: ${active.combo_name}. Click Save Zone Manager to persist.`, "warn");
}

function zoneDescriptionHtml(zone) {
  const desc = String(zone.description || "").trim();
  const descText = desc || "No description";
  const emptyClass = desc ? "" : " empty";
  return `<div class="costx-zone-desc${emptyClass}"><span class="costx-zone-desc-label">Description:</span> ${escapeHtml(descText)}</div>`;
}

function zoneTokenPart(zone) {
  return `${Number(zone.category_index || 1)}|${zone.value_code || ""}`;
}

function renderBuilderZoneLibraryRows(zones) {
  if (!builderZoneLibraryTableBody) return;
  builderZoneLibraryState = (zones && zones.length ? zones : DEFAULT_BUILDER_ZONE_LIBRARY_UI).map(z => ({
    category_index: Number(z.category_index || 1),
    category_name: z.category_name || categoryLabel(z.category_index || 1),
    value_code: String(z.value_code || "").trim(),
    description: String(z.description || "").trim()
  })).filter(z => z.value_code);
  const groups = Array.from({ length: 8 }, (_, i) => i + 1).map(idx => ({ idx, rows: builderZoneLibraryState.filter(z => Number(z.category_index) === idx) }));
  builderZoneLibraryTableBody.innerHTML = groups.map(group => `
    <details class="costx-zone-group">
      <summary><span class="costx-zone-pill">ZC${group.idx}</span><strong>${escapeHtml(categoryLabel(group.idx))}</strong><span class="costx-zone-count">${group.rows.length} zone(s)</span></summary>
      <div class="costx-zone-list">
        ${group.rows.length ? group.rows.map((zone, index) => `
          <div class="costx-zone-row" data-zone-row="${group.idx}-${index}">
            <div class="costx-zone-main">
              <div class="costx-zone-name-line"><span class="costx-zone-name">${escapeHtml(zone.value_code)}</span></div>
              ${zoneDescriptionHtml(zone)}
            </div>
            <code class="costx-zone-token">${escapeHtml(zoneTokenPart(zone))}</code>
            <button class="action secondary mini-action" data-remove-builder-zone="${escapeAttr(`${group.idx}-${index}`)}" type="button">Delete</button>
          </div>
        `).join("") : `<div class="empty-zone-row">No saved zones in this category.</div>`}
      </div>
    </details>
  `).join("");
  updateZoneSectionSummaries();
  builderZoneLibraryTableBody.querySelectorAll("[data-remove-builder-zone]").forEach(btn => btn.addEventListener("click", () => {
    const [catIdx, localIdx] = String(btn.dataset.removeBuilderZone || "").split("-").map(Number);
    const categoryRows = builderZoneLibraryState.filter(z => Number(z.category_index) === catIdx);
    const target = categoryRows[localIdx];
    builderZoneLibraryState = builderZoneLibraryState.filter(z => !(Number(z.category_index) === catIdx && z.value_code === target?.value_code));
    renderBuilderZoneLibraryRows(builderZoneLibraryState);
    renderBuilderLevelRows(collectBuilderLevelsFromUI(), { keepRows: true });
    syncBuilderLevelStatus("CostX zone deleted. Save setup to keep the change.", "warn");
  }));
}

function upsertZoneLibraryValue(idx, value, description) {
  const cleanVal = String(value || "").trim();
  const cleanDesc = String(description || "").trim();
  if (!cleanVal) return false;
  const rows = collectBuilderZoneLibraryFromUI();
  const existing = rows.find(z => Number(z.category_index) === Number(idx) && z.value_code.toLowerCase() === cleanVal.toLowerCase());
  if (existing) {
    existing.value_code = cleanVal;
    existing.description = cleanDesc || existing.description || "";
    existing.category_name = categoryLabel(idx);
  } else {
    rows.push({ category_index: Number(idx), category_name: categoryLabel(idx), value_code: cleanVal, description: cleanDesc });
  }
  renderBuilderZoneLibraryRows(rows.sort((a,b) => Number(a.category_index) - Number(b.category_index) || String(a.value_code).localeCompare(String(b.value_code))));
  renderBuilderActiveZoneCards(collectBuilderActiveCategoriesFromUI());
  return true;
}

function addBuilderZoneRow() {
  const idx = Number(builderZoneCategorySelect?.value || 1);
  const valueInput = document.getElementById("builderZoneValueInput");
  const descInput = document.getElementById("builderZoneDescriptionInput");
  const ok = upsertZoneLibraryValue(idx, valueInput?.value || "", descInput?.value || "");
  if (!ok) {
    syncBuilderLevelStatus("Type a zone name before inserting.", "warn");
    return;
  }
  if (valueInput) valueInput.value = "";
  if (descInput) descInput.value = "";
  renderBuilderLevelRows(collectBuilderLevelsFromUI(), { keepRows: true });
  syncBuilderLevelStatus("CostX zone inserted into library. Save setup to keep the change.", "warn");
}

function importStandardZonesForSelectedCategory() {
  const idx = Number(builderZoneCategorySelect?.value || 1);
  const existing = collectBuilderZoneLibraryFromUI();
  const imported = STANDARD_BUILDER_ZONE_LIBRARY_UI.filter(z => Number(z.category_index) === idx);
  imported.forEach(z => {
    if (!existing.some(row => Number(row.category_index) === idx && String(row.value_code).toLowerCase() === String(z.value_code).toLowerCase())) {
      existing.push({ ...z, category_name: categoryLabel(idx) });
    }
  });
  renderBuilderZoneLibraryRows(existing.sort((a,b) => Number(a.category_index) - Number(b.category_index) || String(a.value_code).localeCompare(String(b.value_code))));
  renderBuilderActiveZoneCards(collectBuilderActiveCategoriesFromUI());
  renderBuilderLevelRows(collectBuilderLevelsFromUI(), { keepRows: true });
  syncBuilderLevelStatus(`Imported ${imported.length} standard ZC${idx} zone(s). Delete unused zones then save.`, "warn");
}

function updateZoneSectionSummaries() {
  try {
    const current = collectCurrentWorkSetupFromUI();
    const combo = activeZoneCombo();
    const levels = collectBuilderLevelsFromUI();
    const activeCats = activeBuilderCategories();
    const activeBits = activeCats.map(cat => {
      const idx = Number(cat.category_index);
      const behavior = behaviorLabel(cat.behavior);
      if (normalizeZoneBehavior(cat.behavior, idx) === "global" && cat.default_value) return `ZC${idx} ${behavior} = ${cat.default_value}`;
      if (normalizeZoneBehavior(cat.behavior, idx) === "locked") return `ZC${idx} ${behavior} = Level Code`;
      return `ZC${idx} ${behavior}`;
    });
    const library = collectBuilderZoneLibraryFromUI();
    const countByCat = Array.from({ length: 8 }, (_, i) => i + 1).map(idx => `ZC${idx}: ${library.filter(z => Number(z.category_index) === idx).length}`).join(" · ");
    if (currentWorkSectionSummary) { const p = tradeProfileById(current.trade_profile_id); currentWorkSectionSummary.textContent = `${current.project_name} · ${p?.display_name || current.trade_profile_id} · ${current.default_costx_function} · Unit ${expectedUnitForProfileUi(p, current.default_costx_function)} · ${current.costx_function_mode === "force_default" ? "Force default" : "Preserve detected"}`; }
    if (zoneComboSectionSummary) zoneComboSectionSummary.textContent = combo?.combo_name || current.setup_name || "Active combo";
    if (activeZonesSectionSummary) activeZonesSectionSummary.textContent = activeBits.join(" · ") || "No active formula zones";
    if (builderRowsSectionSummary) builderRowsSectionSummary.textContent = `${levels.length || 0} row(s) · Token example: ${builderTokenPreview?.textContent || "[token]"}`;
    if (zoneLibrarySectionSummary) zoneLibrarySectionSummary.textContent = `Pre-closed · ${countByCat}`;
  } catch (e) {
    // Summary refresh should never block Zone Manager use.
  }
}

async function loadBuilderLevelZoneSetup() {
  if (!builderLevelTableBody) return;
  try {
    const res = await fetch("/api/builder/level-zone-setup");
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not load Builder Zone Combo Manager");
    builderLevelZoneSetup = data;
    builderZoneLibraryState = data.zone_library || DEFAULT_BUILDER_ZONE_LIBRARY_UI;
    builderTradeProfileState = normalizeTradeProfileListUi(data.trade_profiles && data.trade_profiles.length ? data.trade_profiles : DEFAULT_BUILDER_TRADE_PROFILES_UI);
    builderZoneComboState = normalizeZoneCombos(data.zone_combos || DEFAULT_BUILDER_ZONE_COMBOS_UI);
    builderActiveComboId = data.active_combo_id || builderZoneComboState[0]?.combo_id;
    if (builderPresetNameInput) builderPresetNameInput.value = data.active_preset || activeZoneCombo()?.combo_name || "Walls - Milestone 2 by Level";
    renderBuilderTradeProfiles(builderTradeProfileState, data.current_work_setup?.trade_profile_id || "walls_partitions");
    renderCurrentWorkSetup(data.current_work_setup || { setup_name: data.active_preset || activeZoneCombo()?.combo_name, trade_profile_id: "walls_partitions" });
    renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
    renderBuilderActiveZoneCards(data.active_categories || activeZoneCombo()?.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI);
    renderBuilderZoneLibraryRows(data.zone_library || DEFAULT_BUILDER_ZONE_LIBRARY_UI);
    renderBuilderLevelRows(data.levels || DEFAULT_BUILDER_LEVELS_UI);
    syncBuilderLevelStatus(`Loaded combo preset: ${data.active_preset || activeZoneCombo()?.combo_name || "Default"}`);
  } catch (error) {
    builderTradeProfileState = normalizeTradeProfileListUi(DEFAULT_BUILDER_TRADE_PROFILES_UI);
    builderZoneComboState = normalizeZoneCombos(DEFAULT_BUILDER_ZONE_COMBOS_UI);
    builderActiveComboId = builderZoneComboState[0]?.combo_id;
    if (builderPresetNameInput) builderPresetNameInput.value = activeZoneCombo()?.combo_name || "Walls - Milestone 2 by Level";
    renderBuilderTradeProfiles(builderTradeProfileState, "walls_partitions");
    renderCurrentWorkSetup({ setup_name: activeZoneCombo()?.combo_name || "Walls - Milestone 2 by Level", trade_profile_id: "walls_partitions" });
    renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
    renderBuilderActiveZoneCards(activeZoneCombo()?.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI);
    renderBuilderZoneLibraryRows(DEFAULT_BUILDER_ZONE_LIBRARY_UI);
    renderBuilderLevelRows(DEFAULT_BUILDER_LEVELS_UI);
    syncBuilderLevelStatus(error.message || "Using default Builder Zone Combo Manager", "warn");
  }
}

async function saveBuilderLevelZoneSetup() {
  const levels = collectBuilderLevelsFromUI();
  if (!levels.length) {
    syncBuilderLevelStatus("No valid builder rows to save. Add at least one row with description and level code.", "warn");
    return;
  }
  try {
    // Update the selected combo with the currently shown behavior before saving.
    saveCurrentZoneComboToMemory();
    const res = await fetch("/api/builder/level-zone-setup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        preset_name: builderPresetNameInput?.value || activeZoneCombo()?.combo_name || "Active",
        levels,
        zone_library: collectBuilderZoneLibraryFromUI(),
        active_categories: collectBuilderActiveCategoriesFromUI(),
        zone_combos: builderZoneComboState,
        trade_profiles: builderTradeProfileState,
        active_combo_id: builderActiveComboId,
        current_work_setup: collectCurrentWorkSetupFromUI()
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not save Builder Zone Combo Manager");
    builderLevelZoneSetup = data;
    builderZoneLibraryState = data.zone_library || collectBuilderZoneLibraryFromUI();
    builderZoneComboState = normalizeZoneCombos(data.zone_combos || builderZoneComboState);
    builderTradeProfileState = normalizeTradeProfileListUi(data.trade_profiles || builderTradeProfileState);
    builderActiveComboId = data.active_combo_id || builderActiveComboId;
    renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
    renderBuilderActiveZoneCards(data.active_categories || collectBuilderActiveCategoriesFromUI());
    renderBuilderZoneLibraryRows(data.zone_library || collectBuilderZoneLibraryFromUI());
    renderBuilderLevelRows(data.levels || levels);
    syncBuilderLevelStatus(`Saved combo preset: ${data.active_preset || activeZoneCombo()?.combo_name || "Active"}`);
    showToast("Builder Zone Combo Manager saved");
    return data;
  } catch (error) {
    syncBuilderLevelStatus(error.message || "Could not save setup", "warn");
    throw error;
  }
}

function addBuilderLevelRow() {
  const levels = collectBuilderLevelsFromUI();
  levels.push({ zone_index: 1, zone_name: "", level_index: 3, level_code: "NEW", description: "New Builder Row", token_parts: builderToken({ level_code: "NEW" }) });
  renderBuilderLevelRows(levels);
  syncBuilderLevelStatus("New builder row added. Edit the row description and locked level code, then save setup.", "warn");
}

function resetBuilderLevelRows() {
  builderZoneLibraryState = DEFAULT_BUILDER_ZONE_LIBRARY_UI;
  builderTradeProfileState = DEFAULT_BUILDER_TRADE_PROFILES_UI.map(profile => ({ ...profile }));
  builderZoneComboState = normalizeZoneCombos(DEFAULT_BUILDER_ZONE_COMBOS_UI);
  builderActiveComboId = "walls_milestone_2_by_level";
  const combo = activeZoneCombo();
  if (builderPresetNameInput) builderPresetNameInput.value = combo.combo_name;
  renderBuilderTradeProfiles(builderTradeProfileState, collectCurrentWorkSetupFromUI().trade_profile_id || "walls_partitions");
  renderCurrentWorkSetup({ ...collectCurrentWorkSetupFromUI(), setup_name: combo.combo_name });
  renderBuilderZoneComboSelect(builderZoneComboState, builderActiveComboId);
  renderBuilderActiveZoneCards(combo.active_categories || DEFAULT_BUILDER_ACTIVE_CATEGORIES_UI);
  renderBuilderZoneLibraryRows(DEFAULT_BUILDER_ZONE_LIBRARY_UI);
  renderBuilderLevelRows(DEFAULT_BUILDER_LEVELS_UI);
  syncBuilderLevelStatus("Default Builder Zone Combo Manager restored in UI. Save setup to keep the reset.", "warn");
}


[builderProjectNameInput, builderTradeProfileSelect, builderExpectedUnitInput, builderCustomQuantitySelect, builderFormulaModeSelect, builderDefaultCostXFunctionSelect, builderCostXFunctionModeSelect, builderSetupNotesInput].forEach(el => {
  el?.addEventListener("input", syncCurrentWorkSummary);
  el?.addEventListener("change", syncCurrentWorkSummary);
});

builderApplyTradeProfileBtn?.addEventListener("click", () => applyBuilderTradeProfile(builderTradeProfileSelect?.value || "walls_partitions", { persist: true, now: true }));
builderTradeProfileSelect?.addEventListener("change", () => {
  builderTradeProfileSelect.value = normalizeTradeProfileIdUi(builderTradeProfileSelect.value);
  applyBuilderTradeProfile(builderTradeProfileSelect.value, { silent: true, persist: true });
});

builderDefaultCostXFunctionSelect?.addEventListener("change", () => {
  const profile = tradeProfileById(builderTradeProfileSelect?.value || "walls_partitions");
  if ((builderDefaultCostXFunctionSelect.value || "").toUpperCase().includes("CUSTOM")) renderCustomQuantityOptions(profile, builderCustomQuantitySelect?.value || profile?.default_custom_quantity || "");
  syncExpectedUnitGuard();
  syncCurrentWorkSummary();
  persistBuilderCurrentWorkSetup({ silent: true, reason: "costx_function_change" });
});
builderCostXFunctionModeSelect?.addEventListener("change", () => {
  syncCurrentWorkSummary();
  persistBuilderCurrentWorkSetup({ silent: true, reason: "function_mode_change" });
});
builderFormulaModeSelect?.addEventListener("change", () => {
  syncCurrentWorkSummary();
  persistBuilderCurrentWorkSetup({ silent: true, reason: "formula_mode_change" });
});
builderCustomQuantitySelect?.addEventListener("change", () => {
  const profile = tradeProfileById(builderTradeProfileSelect?.value || "walls_partitions");
  if (builderCustomQuantityUnitInput) builderCustomQuantityUnitInput.value = builderCustomQuantitySelect.value ? customQuantityUnitUi(profile, builderCustomQuantitySelect.value) : "";
  syncExpectedUnitGuard();
  syncCurrentWorkSummary();
  persistBuilderCurrentWorkSetup({ silent: true, now: true, reason: "custom_quantity_change" });
});

async function loadTools() {
  if (!toolGrid) return;
  try {
    const res = await fetch("/api/tools");
    tools = await res.json();
    toolGrid.innerHTML = Object.entries(tools).map(([key, tool]) => `
      <div class="page-panel">
        <strong>${escapeHtml(tool.name || key)}</strong>
        <p>${escapeHtml(tool.version ? `${tool.version} · ` : "")}${escapeHtml(tool.type || "")} · Risk Level ${tool.risk_level ?? "-"}</p>
        <p>${tool.enabled ? "Enabled" : "Disabled / Future"}</p>
        <div class="inline-actions">
          ${tool.url ? `<a class="action primary" href="${escapeAttr(tool.url)}" target="_blank" rel="noreferrer">Open</a>` : ""}
          ${tool.local_url ? `<a class="action secondary" href="${escapeAttr(tool.local_url)}" target="_blank" rel="noreferrer">Local</a>` : ""}
        </div>
      </div>
    `).join("");
  } catch (error) {
    toolGrid.innerHTML = `<div class="page-panel">Could not load tool registry.</div>`;
  }
}

async function loadJobs() {
  if (!jobList) return;
  try {
    const res = await fetch("/api/jobs");
    const data = await res.json();
    const jobs = data.jobs || [];
    jobList.innerHTML = jobs.length
      ? jobs.map(job => {
          const result = job.result || {};
          const progress = Math.max(0, Math.min(100, Number(job.progress || 0)));
          const statusClass = job.status === "completed" ? "status-working" : job.status === "failed" ? "status-error" : "status-offline";
          return `<div class="list-item">
            <strong>${escapeHtml(job.tool_name || job.tool_key || "Job")}</strong><br>
            <span class="${statusClass}">${escapeHtml(job.status || "queued")}</span> · ${escapeHtml(job.stage || "")} · ${progress}%<br>
            <div class="progress-bar mini"><span style="width:${progress}%"></span></div>
            <span class="muted-small">${escapeHtml(job.updated_at || job.created_at || "")}</span><br>
            ${result.download_url ? `<a href="${escapeAttr(result.download_url)}">Download output</a>` : ""}
          </div>`;
        }).join("")
      : `<div class="list-item">No background jobs yet.</div>`;
  } catch (error) {
    jobList.innerHTML = `<div class="list-item">Could not load background jobs.</div>`;
  }
}

async function loadOutputs(limit = null) {
  if (!outputList) return;
  try {
    const res = await fetch("/api/outputs");
    const data = await res.json();
    let outputs = data.outputs || [];
    if (limit) outputs = outputs.slice(0, limit);
    outputList.innerHTML = outputs.length
      ? outputs.map(file => `<div class="list-item"><strong>${escapeHtml(file.name)}</strong><br>${escapeHtml(file.relative_path)}<br>${escapeHtml(file.modified)}<br><a href="${escapeAttr(file.download_url)}">Download</a></div>`).join("")
      : `<div class="list-item">No generated outputs yet.</div>`;
  } catch (error) {
    outputList.innerHTML = `<div class="list-item">Could not load outputs.</div>`;
  }
}

async function loadHealth() {
  if (!healthGrid) return;
  try {
    const res = await fetch("/api/health");
    const data = await res.json();
    const checks = data.checks || {};
    healthGrid.innerHTML = Object.entries(checks).map(([key, check]) => {
      const cls = check.status === "working" ? "status-working" : check.status === "error" ? "status-error" : "status-offline";
      return `<div class="page-panel"><strong>${escapeHtml(key.replaceAll("_", " "))}</strong><p class="${cls}">${escapeHtml(check.status)}</p><p>${escapeHtml(check.url || check.path || check.detail || "")}</p></div>`;
    }).join("");
  } catch (error) {
    healthGrid.innerHTML = `<div class="page-panel">Could not load health check.</div>`;
  }
}



async function createSafetyBackup(reason = "Manual safety backup") {
  try {
    const res = await fetch("/api/backups/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason, include_jobs: true, include_outputs: false, include_inputs: false })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Backup failed");
    showToast("Safety backup created");
    renderResult("Safety backup created", "v2.10 Guard", `<div class="notice safe"><strong>${escapeHtml(data.backup_name)}</strong><br>${data.included_count || 0} config/job files saved. Private input/output files were not included.</div>`);
    await loadSafety();
  } catch (error) {
    renderResult("Backup failed", "No backup created", `<div class="notice warn">${escapeHtml(error.message || "Could not create backup")}</div>`);
  }
}

async function loadSafety() {
  try {
    const [summaryRes, backupsRes, approvalsRes] = await Promise.all([
      fetch("/api/safety/summary"),
      fetch("/api/backups"),
      fetch("/api/approvals")
    ]);
    const summary = await summaryRes.json();
    const backupsData = await backupsRes.json();
    const approvalsData = await approvalsRes.json();
    const backups = backupsData.backups || [];
    const approvals = approvalsData.approvals || [];

    if (safetySummary) {
      safetySummary.innerHTML = `
        <div class="notice safe"><strong>Safe mode:</strong> ${summary.safe_mode ? "On" : "Off"}<br>
        <strong>Stable tools modified:</strong> ${summary.stable_tools_modified ? "Yes" : "No"}<br>
        <strong>Backups:</strong> ${summary.backup_count || 0}<br>
        <strong>Latest backup:</strong> ${escapeHtml(summary.latest_backup?.backup_name || "None yet")}</div>
        <p class="muted-small">Restore, DNS/tunnel changes, core edits, cloud AI file sending, and Local AI auto-profile changes require approval.</p>
      `;
    }

    if (restoreBackupSelect) {
      restoreBackupSelect.innerHTML = backups.length
        ? backups.map(b => `<option value="${escapeAttr(b.backup_name)}">${escapeHtml(b.backup_name)}</option>`).join("")
        : `<option value="">No backups yet</option>`;
    }

    if (backupList) {
      backupList.innerHTML = backups.length ? backups.map(b => {
        const meta = b.metadata || {};
        const contains = Array.isArray(meta.contains) ? meta.contains.length : 0;
        return `<div class="list-item">
          <strong>${escapeHtml(b.backup_name)}</strong><br>
          ${escapeHtml(b.modified || "")} · ${Math.round((b.size_bytes || 0) / 1024)} KB<br>
          <span class="muted-small">Reason: ${escapeHtml(meta.reason || "")}</span><br>
          <span class="muted-small">Files included: ${contains}</span><br>
          <a href="${escapeAttr(b.download_url)}">Download backup</a>
        </div>`;
      }).join("") : `<div class="list-item">No backups yet. Create one before Local AI learning.</div>`;
    }

    if (approvalList) {
      approvalList.innerHTML = approvals.length ? approvals.map(a => {
        const cls = a.status === "approved" ? "status-working" : a.status === "rejected" ? "status-error" : "status-offline";
        return `<div class="list-item">
          <strong>${escapeHtml(a.action_key || "approval")}</strong> · <span class="${cls}">${escapeHtml(a.status || "pending")}</span><br>
          ID: ${escapeHtml(a.approval_id || "")} · Risk Level ${escapeHtml(a.risk_level ?? "-")}<br>
          ${escapeHtml(a.description || "")}<br>
          <span class="muted-small">${escapeHtml(a.created_at || "")}</span>
        </div>`;
      }).join("") : `<div class="list-item">No approval requests yet.</div>`;
    }
  } catch (error) {
    if (safetySummary) safetySummary.innerHTML = `<div class="notice warn">Could not load safety summary.</div>`;
  }
}


async function loadTermLibrary() {
  if (!termLibrarySummary) return;
  try {
    const res = await fetch("/api/term-library");
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not load term library");
    qsTermLibrary = data.library || {};
    const s = data.summary || {};
    termLibrarySummary.innerHTML = `
      <div class="notice safe"><strong>QS Term Library loaded</strong><br>
        ALL CAPS: ${escapeHtml(s.all_caps_terms || 0)} · Exact: ${escapeHtml(s.exact_terms || 0)} · Proper phrases: ${escapeHtml(s.proper_phrases || 0)} · Context lower: ${escapeHtml(s.contextual_lowercase_phrases || 0)}<br>
        Connectors: ${escapeHtml(s.heading_connector_words || 0)} · Units: ${escapeHtml(s.units || 0)} · Pending review: ${escapeHtml(s.unknown_pending_review || 0)} · Sources: ${escapeHtml(s.sources || 0)}
      </div>`;
  } catch (error) {
    termLibrarySummary.innerHTML = `<div class="notice warn">Could not load QS term library: ${escapeHtml(error.message || "error")}</div>`;
  }
}

async function scanUnknownTermsFromFeedback() {
  const text = feedbackTextInput?.value || "";
  if (!text.trim()) {
    showToast("Type feedback first");
    return;
  }
  try {
    const res = await fetch("/api/term-library/scan-feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Unknown scan failed");
    const terms = data.uncertain_terms || [];
    if (!terms.length) {
      unknownTermsBox.innerHTML = `<div class="notice safe"><strong>No uncertain terms found.</strong><br>Jarvis already has enough library/profile rules for the obvious technical terms in this feedback.</div>`;
      showToast("No unknown terms found");
      await loadTermLibrary();
      return;
    }
    unknownTermsBox.innerHTML = `<div class="notice warn"><strong>${terms.length} uncertain term(s) found.</strong><br>Choose one, teach Jarvis once, then save it to the QS term library.</div>` + terms.map(item => `
      <div class="list-item"><strong>${escapeHtml(item.term)}</strong><br>${escapeHtml(item.reason || "Unknown casing")}
        <div class="actions">
          <button class="action secondary" onclick="prepareTeachTerm('${escapeAttr(item.term)}','all_caps','${escapeAttr(String(item.term || '').toUpperCase())}')">ALL CAPS</button>
          <button class="action secondary" onclick="prepareTeachTerm('${escapeAttr(item.term)}','exact','${escapeAttr(item.term)}')">Exact</button>
          <button class="action secondary" onclick="prepareTeachTerm('${escapeAttr(item.term)}','lower_mid','${escapeAttr(String(item.term || '').toLowerCase())}')">lower in descriptions</button>
          <button class="action secondary" onclick="prepareTeachTerm('${escapeAttr(item.term)}','ignore','${escapeAttr(item.term)}')">Ignore</button>
        </div>
      </div>`).join("");
    showToast("Unknown term scan ready");
    await loadTermLibrary();
  } catch (error) {
    unknownTermsBox.innerHTML = `<div class="notice warn">Could not scan unknown terms: ${escapeHtml(error.message || "error")}</div>`;
  }
}

function prepareTeachTerm(term, action, value) {
  if (teachTermInput) teachTermInput.value = term || "";
  if (teachTermAction) teachTermAction.value = action || "exact";
  if (teachTermValue) teachTermValue.value = value || term || "";
  showToast(`Ready to save ${term}`);
}

async function saveTeachTermToLibrary() {
  const term = teachTermInput?.value?.trim() || "";
  if (!term) {
    showToast("Enter a term first");
    return;
  }
  const typed = window.prompt(`Save "${term}" to the QS Term Library?\n\nThis changes Jarvis local memory only. Type I APPROVE to continue.`) || "";
  if (typed.trim() !== "I APPROVE") {
    showToast("Approval cancelled");
    return;
  }
  try {
    const res = await fetch("/api/term-library/clarify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        term,
        action: teachTermAction?.value || "exact",
        value: teachTermValue?.value || term,
        typed_confirmation: "I APPROVE"
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not save term");
    await loadTermLibrary();
    await loadFormatterProfiles();
    unknownTermsBox.innerHTML = `<div class="notice safe"><strong>Term saved.</strong><br>${escapeHtml(term)} saved as ${escapeHtml(data.action)}. Backup: ${escapeHtml(data.backup_created || "created")}</div>`;
    renderResult("QS term learned", "Library updated · Backup created", unknownTermsBox.innerHTML);
    showToast("Term saved to library");
  } catch (error) {
    unknownTermsBox.innerHTML = `<div class="notice warn">Could not save term: ${escapeHtml(error.message || "error")}</div>`;
  }
}

async function loadLocalAIStatus() {
  if (!localAIStatus) return;
  try {
    const res = await fetch("/api/local-ai/status");
    const data = await res.json();
    const cls = data.status === "working" ? "status-working" : "status-offline";
    const models = Array.isArray(data.available_models) && data.available_models.length ? data.available_models.join(", ") : "No model list loaded";
    if (localAIModelInput && !localAIModelInput.value) localAIModelInput.value = data.default_model || "qwen2.5:3b";
    localAIStatus.innerHTML = `
      <div class="notice ${data.status === "working" ? "safe" : "warn"}">
        <strong>Status:</strong> <span class="${cls}">${escapeHtml(data.status || "unknown")}</span><br>
        <strong>Default model:</strong> ${escapeHtml(data.default_model || "qwen2.5:3b")}<br>
        <strong>Ollama:</strong> ${escapeHtml(data.ollama_url || "http://localhost:11434")}<br>
        <strong>Models:</strong> ${escapeHtml(models)}<br>
        <span class="muted-small">${escapeHtml(data.detail || "")}</span>
      </div>
    `;
  } catch (error) {
    localAIStatus.innerHTML = `<div class="notice warn">Could not read Local AI status.</div>`;
  }
}

async function analyzeWorkbookWithLocalAI(options = {}) {
  if (!uploadedFileRecord?.saved_name) {
    showToast("Attach an Excel workbook first");
    renderResult("Local AI needs a workbook", "No file attached", `<div class="notice warn">Attach a workbook first, then ask Local AI to review it.</div>`);
    return;
  }
  if (analyzeLocalAIBtn) {
    analyzeLocalAIBtn.disabled = true;
    analyzeLocalAIBtn.textContent = "Analyzing JSON...";
  }
  try {
    const payload = {
      input_file: uploadedFileRecord.saved_name,
      profile_key: activeFormatterProfile,
      model: localAIModelInput?.value || "",
      prompt: localAIPromptInput?.value || promptInput?.value || "Review this workbook for QS BOQ formatting.",
      max_rows: 140
    };
    const res = await fetch("/api/local-ai/analyze-formatter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Local AI review failed");
    renderLocalAIReview(data);
    showToast("Local AI review saved");
    return data;
  } catch (error) {
    const html = `<div class="notice warn"><strong>Local AI review failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (localAIResult) localAIResult.innerHTML = html;
    renderResult("Local AI review failed", "No workbook changed", html);
  } finally {
    if (analyzeLocalAIBtn) {
      analyzeLocalAIBtn.disabled = false;
      analyzeLocalAIBtn.textContent = "Analyze Only (JSON)";
    }
  }
}


async function analyzeAndRunFormatter() {
  if (!uploadedFileRecord?.saved_name) {
    showToast("Attach an Excel workbook first");
    renderResult("Jarvis needs a workbook", "No file attached", `<div class="notice warn">Attach a workbook first, then click Analyze + Create Excel.</div>`);
    return;
  }
  if (analyzeAndFormatBtn) {
    analyzeAndFormatBtn.disabled = true;
    analyzeAndFormatBtn.textContent = "Analyzing...";
  }
  try {
    const review = await analyzeWorkbookWithLocalAI({ silentButtonReset: true });
    if (analyzeAndFormatBtn) analyzeAndFormatBtn.textContent = "Starting formatter...";
    const jobPayload = {
      tool_key: "formatter",
      input_file: uploadedFileRecord.saved_name,
      output_prefix: "AI_Reviewed_Formatted",
      profile_key: activeFormatterProfile
    };
    const res = await fetch("/api/jobs/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(jobPayload)
    });
    const job = await res.json();
    if (!res.ok || !job.job_id) throw new Error(job.detail || "Could not start Formatter job");
    const reviewUrl = review?.download_url ? `<a class="action secondary" href="${escapeAttr(review.download_url)}">Download AI review JSON</a>` : "";
    renderJobResult(job, "Local AI reviewed workbook · Formatter job started");
    if (resultBody) {
      resultBody.innerHTML += `<div class="notice safe"><strong>v3.13 flow:</strong><br>Local AI review was saved first. Jarvis then started a safe background Formatter job to create the Excel output copy.</div><div class="actions">${reviewUrl}</div>`;
    }
    pollJob(job.job_id);
    showToast("AI reviewed + formatter job started");
  } catch (error) {
    renderResult("AI + Formatter flow failed", "No original file changed", `<div class="notice warn"><strong>Could not complete flow.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`);
    showToast(error.message || "AI + Formatter failed");
  } finally {
    if (analyzeAndFormatBtn) {
      analyzeAndFormatBtn.disabled = false;
      analyzeAndFormatBtn.textContent = "Analyze + Create Excel";
    }
    if (analyzeLocalAIBtn) {
      analyzeLocalAIBtn.disabled = false;
      analyzeLocalAIBtn.textContent = "Analyze Only (JSON)";
    }
  }
}

function renderLocalAIReview(data) {
  latestAIReview = data;
  const analysis = data.analysis || {};
  const warnings = Array.isArray(analysis.warnings) ? analysis.warnings : [];
  const notes = Array.isArray(analysis.row_classification_notes) ? analysis.row_classification_notes : [];
  const terms = Array.isArray(analysis.preserve_terms_to_add) ? analysis.preserve_terms_to_add : [];
  const sourceLabel = data.source || "local_ai";
  const html = `
    <div class="notice safe"><strong>${escapeHtml(analysis.workbook_type || "Workbook review")}</strong><br>
      Confidence: ${escapeHtml(analysis.confidence ?? "-")}% · Source: ${escapeHtml(sourceLabel)} · Model: ${escapeHtml(data.model || "")}
    </div>
    <div class="list-item"><strong>Recommendation</strong><br>${escapeHtml(analysis.reason || "Review complete.")}<br>
      <span class="muted-small">Recommended profile: ${escapeHtml(analysis.recommended_profile || data.profile_key || activeFormatterProfile)}</span>
    </div>
    ${notes.length ? `<div class="list-item"><strong>Row classification notes</strong><br>${notes.map(escapeHtml).join("<br>")}</div>` : ""}
    ${terms.length ? `<div class="list-item"><strong>Terms suggested to preserve</strong><br>${escapeHtml(terms.join(", "))}</div>` : ""}
    ${warnings.length ? `<div class="notice warn"><strong>Warnings</strong><br>${warnings.map(escapeHtml).join("<br>")}</div>` : ""}
    <div class="actions">
      ${data.download_url ? `<a class="action secondary" href="${escapeAttr(data.download_url)}">Download AI review JSON</a>` : ""}
      <button class="action primary" data-run-formatter="1">Create Excel Output</button>
      <button class="action secondary" data-apply-ai-suggestions="1">Apply AI Suggestions Safely</button>
      <button class="action secondary" onclick="showView('profiles'); loadFormatterProfiles();">Open Formatter Profiles</button>
    </div>
    <p class="muted-small">Privacy: ${escapeHtml(data.privacy || "Local-only review. No direct Excel edit.")}</p>
  `;
  if (localAIResult) localAIResult.innerHTML = html;
  renderResult("Local AI Formatter Brain", "JSON review saved · Excel output optional", html);
}


async function applyLatestAISuggestionsSafely() {
  const review = latestAIReview;
  const analysisFile = review?.relative_path || review?.analysis_file || "";
  if (!analysisFile) {
    showToast("Run a Local AI review first");
    renderResult("No AI review selected", "Nothing applied", `<div class="notice warn">Analyze a workbook first, then apply the suggestions.</div>`);
    return;
  }

  const typed = window.prompt("Apply Local AI suggestions to the active Formatter profile?\n\nThis changes profile memory only, not Excel files.\nType I APPROVE to continue.");
  if ((typed || "").trim() !== "I APPROVE") {
    showToast("Approval cancelled");
    renderResult("AI suggestion apply cancelled", "No profile changed", `<div class="notice warn">Typed approval was not provided. No profile memory changed.</div>`);
    return;
  }

  try {
    const requestRes = await fetch("/api/approvals/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action_key: "apply_ai_profile_suggestions",
        risk_level: 4,
        target: analysisFile,
        description: "Apply Local AI review suggestions to the active Formatter profile. This updates profile memory only."
      })
    });
    const approval = await requestRes.json();
    if (!requestRes.ok) throw new Error(approval.detail || "Could not request approval");

    const decisionRes = await fetch("/api/approvals/decision", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approval_id: approval.approval_id, decision: "approved", typed_confirmation: "I APPROVE" })
    });
    const decision = await decisionRes.json();
    if (!decisionRes.ok) throw new Error(decision.detail || "Could not approve request");

    const applyRes = await fetch("/api/local-ai/apply-review-suggestions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        analysis_file: analysisFile,
        approval_id: approval.approval_id,
        profile_key: activeFormatterProfile,
        display_name: formatterProfiles?.[activeFormatterProfile]?.display_name || "Default QS BOQ Format"
      })
    });
    const data = await applyRes.json();
    if (!applyRes.ok) throw new Error(data.detail || "Could not apply AI suggestions");

    await loadFormatterProfiles();
    await loadSafety();
    const added = data.added || {};
    const count = (added.protected_upper || []).length + Object.keys(added.protected_exact || {}).length + Object.keys(added.proper_phrases || {}).length + Object.keys(added.slash_words || {}).length;
    const warnings = Array.isArray(data.warnings) && data.warnings.length ? `<div class="notice warn"><strong>Warnings</strong><br>${data.warnings.map(escapeHtml).join("<br>")}</div>` : "";
    renderResult("AI suggestions applied safely", "Profile memory updated · Backup created", `
      <div class="notice safe"><strong>${escapeHtml(data.profile_name || data.profile_key)}</strong><br>${escapeHtml(data.message || "Profile updated.")}</div>
      <div class="list-item"><strong>Added/updated entries:</strong> ${count}<br>
        <span class="muted-small">Backup: ${escapeHtml(data.backup_created || "created")}</span><br>
        <span class="muted-small">Review: ${escapeHtml(data.review_file || analysisFile)}</span>
      </div>
      ${warnings}
      <div class="actions"><button class="action secondary" onclick="showView('profiles'); loadFormatterProfiles();">Review Formatter Profile</button></div>
    `);
    showToast("AI suggestions applied safely");
  } catch (error) {
    renderResult("AI suggestion apply failed", "No workbook changed", `<div class="notice warn"><strong>Could not apply suggestions.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`);
    showToast(error.message || "Apply failed");
  }
}


async function previewFeedbackRules() {
  const text = feedbackTextInput?.value?.trim() || "";
  if (!text) {
    showToast("Type feedback first");
    return;
  }
  try {
    const res = await fetch("/api/feedback/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedback_text: text, profile_key: activeFormatterProfile })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Feedback preview failed");
    renderFeedbackPreview(data);
    renderResult("Feedback rules preview", "No profile changed yet", renderFeedbackChangesHtml(data.changes || {}));
    showToast("Feedback preview ready");
    return data;
  } catch (error) {
    const html = `<div class="notice warn">${escapeHtml(error.message || "Could not preview feedback")}</div>`;
    if (feedbackPreview) feedbackPreview.innerHTML = html;
    renderResult("Feedback preview failed", "No profile changed", html);
  }
}

async function applyFeedbackRulesSafely() {
  const text = feedbackTextInput?.value?.trim() || "";
  if (!text) {
    showToast("Type feedback first");
    return;
  }
  const typed = window.prompt("Apply this feedback to the active Formatter profile?\n\nThis changes profile memory only, not Excel files.\nType I APPROVE to continue.") || "";
  if (typed.trim() !== "I APPROVE") {
    showToast("Approval cancelled");
    renderResult("Feedback apply cancelled", "No profile changed", `<div class="notice warn">Typed approval was not provided. No profile memory changed.</div>`);
    return;
  }
  try {
    const requestRes = await fetch("/api/approvals/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action_key: "apply_feedback_learning",
        risk_level: 4,
        target: activeFormatterProfile,
        description: "Apply user feedback corrections to the active Formatter profile memory."
      })
    });
    const approval = await requestRes.json();
    if (!requestRes.ok) throw new Error(approval.detail || "Could not request approval");
    const decisionRes = await fetch("/api/approvals/decision", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approval_id: approval.approval_id, decision: "approved", typed_confirmation: "I APPROVE" })
    });
    const decision = await decisionRes.json();
    if (!decisionRes.ok) throw new Error(decision.detail || "Could not approve feedback learning");
    const applyRes = await fetch("/api/feedback/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedback_text: text, approval_id: approval.approval_id, profile_key: activeFormatterProfile })
    });
    const data = await applyRes.json();
    if (!applyRes.ok) throw new Error(data.detail || "Could not apply feedback");
    await loadFormatterProfiles();
    await loadSafety();
    await loadOutputs();
    const html = `<div class="notice safe"><strong>Feedback learned safely.</strong><br>${escapeHtml(data.profile_name || data.profile_key)} updated. Backup: ${escapeHtml(data.backup_created || "created")}</div>${renderFeedbackChangesHtml(data.changes || {})}<div class="actions"><a class="action secondary" href="${escapeAttr(data.download_url || "#")}">Download feedback record</a><button class="action secondary" onclick="showView('profiles'); loadFormatterProfiles();">Open Formatter Profiles</button></div>`;
    if (feedbackPreview) feedbackPreview.innerHTML = html;
    renderResult("Feedback learned", "Profile memory updated · Backup created", html);
    showToast("Feedback applied safely");
  } catch (error) {
    const html = `<div class="notice warn"><strong>Feedback apply failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (feedbackPreview) feedbackPreview.innerHTML = html;
    renderResult("Feedback apply failed", "No workbook changed", html);
    showToast(error.message || "Feedback apply failed");
  }
}

function renderFeedbackPreview(data) {
  if (!feedbackPreview) return;
  feedbackPreview.innerHTML = `<div class="notice safe"><strong>Preview only</strong><br>Profile: ${escapeHtml(data.profile_name || data.profile_key)}. No profile changed yet.</div>${renderFeedbackChangesHtml(data.changes || {})}`;
}

function renderFeedbackChangesHtml(changes) {
  const upper = changes.protected_upper || [];
  const exact = changes.protected_exact || {};
  const phrases = changes.proper_phrases || {};
  const slash = changes.slash_words || {};
  const lowerMid = changes.lower_mid_phrases || [];
  const removeExact = changes.remove_protected_exact || [];
  const removeProper = changes.remove_proper_phrases || [];
  const rules = changes.format_rules || {};
  const overrides = changes.row_overrides || {};
  const tempOverrides = changes.temporary_row_overrides || {};
  const notes = changes.notes || [];
  const warnings = changes.warnings || [];
  const line = (label, value) => `<div class="list-item"><strong>${label}</strong><br>${value || "None"}</div>`;
  return `
    <div class="mini-grid">
      ${line("ALL CAPS terms", escapeHtml(Array.isArray(upper) ? upper.join(", ") : ""))}
      ${line("Exact terms to keep", escapeHtml(Object.entries(exact).map(([k,v]) => `${k} => ${v}`).join(", ")))}
      ${line("Proper phrases", escapeHtml(Object.entries(phrases).map(([k,v]) => `${k} => ${v}`).join(", ")))}
      ${line("Contextual lowercase phrases (description only)", escapeHtml(Array.isArray(lowerMid) ? lowerMid.join(", ") : ""))}
      ${line("Remove old exact/proper conflicts before saving", escapeHtml([...(Array.isArray(removeExact) ? removeExact : []), ...(Array.isArray(removeProper) ? removeProper : [])].join(", ")))}
      ${line("Slash words", escapeHtml(Object.entries(slash).map(([k,v]) => `${k} => ${v}`).join(", ")))}
      ${line("Format rules", escapeHtml(JSON.stringify(rules)))}
      ${line("Global row overrides", escapeHtml(JSON.stringify(overrides)))}
      ${line("Temporary row overrides", escapeHtml(JSON.stringify(tempOverrides)))}
    </div>
    ${notes.length ? `<div class="notice safe"><strong>Notes</strong><br>${notes.map(escapeHtml).join("<br>")}</div>` : ""}
    ${warnings.length ? `<div class="notice warn"><strong>Warnings</strong><br>${warnings.map(escapeHtml).join("<br>")}</div>` : ""}
  `;
}


function correctionContextPayload() {
  const attachedRaw = getAttachedWorkbookName();
  const sampleName = getSampleWorkbookName ? getSampleWorkbookName() : "";
  return {
    feedback_text: correctionTextInput?.value?.trim() || "",
    output_file: correctionOutputFileInput?.value?.trim() || "",
    raw_file: correctionRawFileInput?.value?.trim() || attachedRaw || "",
    sample_file: correctionSampleFileInput?.value?.trim() || sampleName || "",
    profile_key: activeFormatterProfile
  };
}

async function previewCorrectionLoop() {
  const payload = correctionContextPayload();
  if (!payload.feedback_text) {
    showToast("Type correction feedback first");
    return;
  }
  if (correctionPreview) correctionPreview.innerHTML = `<div class="notice safe">Analyzing correction...</div>`;
  try {
    const res = await fetch("/api/correction/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await readJsonOrThrow(res, "Correction preview failed");
    const html = renderCorrectionPreviewHtml(data);
    if (correctionPreview) correctionPreview.innerHTML = html;
    renderResult("Correction preview", "No memory changed yet", html);
    showToast("Correction preview ready");
  } catch (error) {
    const html = `<div class="notice warn"><strong>Correction preview failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (correctionPreview) correctionPreview.innerHTML = html;
    renderResult("Correction preview failed", "No memory changed", html);
  }
}

async function applyCorrectionLoop() {
  const payload = correctionContextPayload();
  if (!payload.feedback_text) {
    showToast("Type correction feedback first");
    return;
  }
  const typed = window.prompt("Apply this correction to Jarvis mistake memory and active Formatter profile?\n\nA safety backup will be created. Type I APPROVE to continue.") || "";
  if (typed.trim() !== "I APPROVE") {
    showToast("Approval cancelled");
    return;
  }
  const rerun = window.confirm("Rerun the formatter after saving correction memory?\n\nChoose OK to rerun using the attached/raw workbook, or Cancel to save memory only.");
  if (correctionPreview) correctionPreview.innerHTML = `<div class="notice safe">Applying correction memory...</div>`;
  try {
    const res = await fetch("/api/correction/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, typed_confirmation: typed, rerun_after_apply: rerun })
    });
    const data = await readJsonOrThrow(res, "Correction apply failed");
    const html = renderCorrectionAppliedHtml(data);
    if (correctionPreview) correctionPreview.innerHTML = html;
    renderResult("Correction memory saved", data.rerun?.performed ? "Formatter rerun created" : "Memory saved only", html);
    await loadFormatterProfiles();
    await loadSafety();
    await loadOutputs();
    showToast("Correction saved safely");
  } catch (error) {
    const html = `<div class="notice warn"><strong>Correction apply failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (correctionPreview) correctionPreview.innerHTML = html;
    renderResult("Correction apply failed", "No memory changed", html);
  }
}

function renderCorrectionPreviewHtml(data) {
  const cats = data.categories || [];
  const rules = data.proposed_mistake_memory_rules || [];
  const checks = data.regression_checks || [];
  return `
    <div class="notice safe"><strong>Correction preview only</strong><br>Profile: ${escapeHtml(data.profile_name || data.profile_key)}<br>Categories: ${escapeHtml(cats.join(", "))}</div>
    <div class="list wide-list">
      ${rules.map(r => `<div class="list-item"><strong>${escapeHtml(r.rule_key || "rule")}</strong><br>${escapeHtml(r.description || "")}<br><span class="muted-small">Scope: ${escapeHtml(r.scope || "")}</span></div>`).join("") || `<div class="list-item">No strategic mistake-memory rule detected yet. Jarvis will still save the feedback text if approved.</div>`}
    </div>
    ${renderFeedbackChangesHtml(data.profile_changes || {})}
    <div class="notice safe"><strong>Regression checks after apply</strong><br>${checks.map(escapeHtml).join("<br>")}</div>
  `;
}

function renderCorrectionAppliedHtml(data) {
  const entry = data.mistake_memory_entry || {};
  const rerun = data.rerun || {};
  return `
    <div class="notice safe"><strong>Correction memory saved.</strong><br>Entry: ${escapeHtml(entry.id || "saved")}<br>Backup: ${escapeHtml(data.backup_created || "created")}</div>
    ${rerun.performed ? `<div class="notice safe"><strong>Formatter rerun created.</strong><br>${escapeHtml(rerun.output_file || "")}</div>` : `<div class="notice warn"><strong>Formatter rerun:</strong> ${escapeHtml(rerun.reason || (rerun.requested ? "not performed" : "not requested"))}</div>`}
    <div class="actions">
      ${data.download_url ? `<a class="action secondary" href="${escapeAttr(data.download_url)}">Download correction record</a>` : ""}
      ${rerun.download_url ? `<a class="action primary" href="${escapeAttr(rerun.download_url)}">Download rerun Excel</a>` : ""}
    </div>
  `;
}

async function loadOutputSummary() {
  if (!outputSummary) return;
  try {
    const res = await fetch("/api/outputs/summary");
    const data = await res.json();
    outputSummary.textContent = `${data.visible_outputs || 0} visible output(s) · ${data.ai_review_json || 0} AI review JSON · ${data.job_records || 0} job record(s)`;
  } catch {
    outputSummary.textContent = "Could not load output summary";
  }
}

async function cleanupOutputs(cleanupType, keepLatest = 3) {
  try {
    const label = cleanupType.replaceAll("_", " ");
    const ok = window.confirm(`Archive ${label}?\n\nThis moves old Jarvis-generated files into Output Center/Archive. It does not delete files.`);
    if (!ok) return;
    const res = await fetch("/api/outputs/cleanup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cleanup_type: cleanupType, keep_latest: keepLatest })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Cleanup failed");
    showToast(`Archived ${data.moved_count || 0} file(s)`);
    renderResult("Output cleanup complete", "Archived, not deleted", `<div class="notice safe"><strong>${escapeHtml(data.cleanup_type)}</strong><br>Moved ${escapeHtml(data.moved_count || 0)} file(s) to ${escapeHtml(data.archive_folder || "Archive")}.</div>`);
    await loadOutputSummary();
    await loadJobs();
    await loadOutputs();
  } catch (error) {
    renderResult("Output cleanup failed", "No files deleted", `<div class="notice warn">${escapeHtml(error.message || "Cleanup failed")}</div>`);
  }
}

async function loadFormatterProfiles() {
  if (!profileSelect) return;
  try {
    const res = await fetch("/api/formatter/profiles");
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not load profiles");
    formatterProfiles = data.profiles || {};
    activeFormatterProfile = data.active_profile || "default_qs_boq";
    profileSelect.innerHTML = Object.entries(formatterProfiles).map(([key, profile]) =>
      `<option value="${escapeAttr(key)}" ${key === activeFormatterProfile ? "selected" : ""}>${escapeHtml(profile.display_name || key)}</option>`
    ).join("");
    fillProfileEditor(profileSelect.value || activeFormatterProfile, data.editor_text || {});
  } catch (error) {
    showToast(error.message || "Could not load profiles");
  }
}

function fillProfileEditor(key, editorTextStore = null) {
  const profile = formatterProfiles[key] || {};
  const casing = profile.casing || {};
  const editor = editorTextStore?.[key] || {
    protected_upper_text: Array.isArray(casing.protected_upper) ? casing.protected_upper.join("\n") : "",
    protected_exact_text: mapToLines(casing.protected_exact || {}),
    proper_phrases_text: mapToLines(casing.proper_phrases || {}),
    slash_words_text: mapToLines(casing.slash_words || {})
  };
  if (profileKeyInput) profileKeyInput.value = key || "default_qs_boq";
  if (profileNameInput) profileNameInput.value = profile.display_name || key || "Default QS BOQ Format";
  if (profileDescriptionInput) profileDescriptionInput.value = profile.description || "";
  if (protectedUpperText) protectedUpperText.value = editor.protected_upper_text || "";
  if (protectedExactText) protectedExactText.value = editor.protected_exact_text || "";
  if (properPhrasesText) properPhrasesText.value = editor.proper_phrases_text || "";
  if (slashWordsText) slashWordsText.value = editor.slash_words_text || "";
}

function mapToLines(obj) {
  return Object.entries(obj || {}).map(([k, v]) => `${k} => ${v}`).join("\n");
}

async function openTool(key) {
  if (!Object.keys(tools).length) {
    try {
      const res = await fetch("/api/tools");
      tools = await res.json();
    } catch {}
  }
  const tool = tools[key];
  if (tool?.url) window.open(tool.url, "_blank", "noreferrer");
  else showToast("Tool not available yet");
}


async function runFormatterSelfTest() {
  if (formatterSelfTestResult) formatterSelfTestResult.innerHTML = `<div class="notice safe">Running formatter regression self-test...</div>`;
  try {
    const res = await fetch("/api/self-test/formatter", { method: "POST" });
    const data = await readJsonOrThrow(res, "Self-test failed");
    const passed = (data.tests || []).filter(t => t.passed).length;
    const total = (data.tests || []).length;
    const rows = (data.tests || []).map(t => `<div class="list-item"><strong>${t.passed ? "PASS" : "FAIL"} · ${escapeHtml(t.name)}</strong><br><span class="muted-small">${escapeHtml(t.detail || "")}</span></div>`).join("");
    const statusClass = data.status === "passed" ? "safe" : "warn";
    const links = `
      ${data.output_download_url ? `<a href="${escapeAttr(data.output_download_url)}">Download self-test Excel</a>` : ""}
      ${data.report_download_url ? `<br><a href="${escapeAttr(data.report_download_url)}">Download self-test JSON report</a>` : ""}
    `;
    const html = `<div class="notice ${statusClass}"><strong>Status: ${escapeHtml(data.status)}</strong><br>${passed}/${total} checks passed.<br>${links}</div>${rows}`;
    if (formatterSelfTestResult) formatterSelfTestResult.innerHTML = html;
    renderResult("Formatter self-test complete", `${passed}/${total} checks passed`, html);
    await loadOutputs();
  } catch (error) {
    const html = `<div class="notice warn"><strong>Self-test failed.</strong><br>${escapeHtml(error.message || "Unknown error")}</div>`;
    if (formatterSelfTestResult) formatterSelfTestResult.innerHTML = html;
    renderResult("Self-test failed", "Needs patch", html);
  }
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttr(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}


async function readJsonOrThrow(res, fallbackMessage) {
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch (err) {
    const preview = (text || '').slice(0, 300);
    throw new Error(preview || fallbackMessage || `HTTP ${res.status}`);
  }
  if (!res.ok) {
    throw new Error(data.detail || data.error || data.message || fallbackMessage || `HTTP ${res.status}`);
  }
  return data;
}

function renderClientLayout(data) {
  const rec = data.recommended_layout || {};
  const sheets = data.sheet_layouts || [];
  const sheetHtml = sheets.map(layout => `
    <div class="list-item">
      <strong>${escapeHtml(layout.sheet || "Sheet")}</strong><br>
      Confidence: ${escapeHtml(layout.confidence || 0)}%<br>
      Description: <strong>${escapeHtml(layout.description_column || "auto")}</strong> · Row type: <strong>${escapeHtml(layout.row_type_column || "auto")}</strong> · Unit: <strong>${escapeHtml(layout.unit_column || "auto")}</strong><br>
      Formula columns protected: ${escapeHtml((layout.formula_columns || []).join(", ") || "none detected")}<br>
      <span class="muted-small">${escapeHtml((layout.reasons || []).join(" · "))}</span>
    </div>
  `).join("");
  const html = `
    <div class="notice safe"><strong>Average confidence:</strong> ${escapeHtml(data.average_confidence || 0)}%</div>
    <div class="list-item"><strong>Recommended layout</strong><br>
      Description: ${escapeHtml(rec.description_column || "auto")} · Row type: ${escapeHtml(rec.row_type_column || "auto")} · Unit: ${escapeHtml(rec.unit_column || "auto")}<br>
      Formula columns: ${escapeHtml((rec.formula_columns || []).join(", ") || "auto detect")}
    </div>
    <div class="list wide-list">${sheetHtml}</div>
    ${data.download_url ? `<div class="actions"><a class="action secondary" href="${escapeAttr(data.download_url)}">Download layout JSON</a></div>` : ""}
  `;
  if (clientLayoutResult) clientLayoutResult.innerHTML = html;
  renderResult("Client layout analyzed", "v3.18 Smart Column + Sample/Correction Safety", html);
}

function getAttachedWorkbookName() {
  return uploadedFileRecord?.saved_name || "";
}

function showClientLayoutInline(title, message, level = "warn") {
  const html = `<div class="notice ${level}"><strong>${escapeHtml(title)}</strong><br>${escapeHtml(message)}</div>`;
  if (clientLayoutResult) clientLayoutResult.innerHTML = html;
  return html;
}

analyzeClientLayoutBtn?.addEventListener("click", async () => {
  const inputFile = getAttachedWorkbookName();
  if (!inputFile) {
    const html = showClientLayoutInline("No workbook attached", "Attach a workbook first. The client layout analyzer uses the saved local copy in 01_Input_Files.");
    renderResult("Jarvis needs a workbook", "No file attached", html);
    return;
  }
  if (clientLayoutResult) clientLayoutResult.innerHTML = `<div class="notice safe"><strong>Analyzing layout...</strong><br>${escapeHtml(inputFile)}</div>`;
  try {
    const res = await fetch("/api/formatter/layout/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input_file: inputFile, profile_key: activeFormatterProfile })
    });
    const data = await readJsonOrThrow(res, "Client layout analysis failed");
    renderClientLayout(data);
    showToast("Client layout analyzed");
  } catch (error) {
    const html = showClientLayoutInline("Client layout analysis failed", error.message || "Could not analyze client layout");
    renderResult("Client layout analysis failed", "No profile changed", html);
  }
});

applyClientLayoutBtn?.addEventListener("click", async () => {
  const inputFile = getAttachedWorkbookName();
  if (!inputFile) {
    const html = showClientLayoutInline("No workbook attached", "Attach a workbook first. The client layout learner uses the saved local copy in 01_Input_Files.");
    renderResult("Jarvis needs a workbook", "No file attached", html);
    return;
  }
  const typed = window.prompt("Learn this workbook's column layout to the active Formatter profile?\n\nThis updates profile memory only and creates a safety backup.\nType I APPROVE to continue.");
  if ((typed || "").trim() !== "I APPROVE") {
    const html = showClientLayoutInline("Client layout learning cancelled", "Typed approval was not provided. No profile memory changed.");
    renderResult("Client layout learning cancelled", "No profile changed", html);
    return;
  }
  if (clientLayoutResult) clientLayoutResult.innerHTML = `<div class="notice safe"><strong>Learning layout...</strong><br>${escapeHtml(inputFile)}</div>`;
  try {
    const res = await fetch("/api/formatter/layout/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input_file: inputFile, profile_key: activeFormatterProfile, typed_confirmation: typed })
    });
    const data = await readJsonOrThrow(res, "Client layout learning failed");
    renderClientLayout(data.analysis || {});
    renderResult("Client layout learned safely", "Profile memory updated · Backup created", `<div class="notice safe"><strong>${escapeHtml(data.profile_name || data.profile_key)}</strong><br>Backup: ${escapeHtml(data.backup_created || "created")}<br>${escapeHtml(data.message || "Client layout learned.")}</div>`);
    loadFormatterProfiles();
  } catch (error) {
    const html = showClientLayoutInline("Client layout learning failed", error.message || "Could not learn client layout");
    renderResult("Client layout learning failed", "No profile changed", html);
  }
});


function renderSampleFormatAnalysis(data) {
  const sug = data.suggested_profile_updates || {};
  const rawRec = data.raw_layout?.recommended_layout || {};
  const sampleRec = data.sample_layout?.recommended_layout || {};
  const sig = data.sample_style_signature || {};
  const html = `
    <div class="notice safe"><strong>Sample analysis ready</strong><br>Raw: ${escapeHtml(data.raw_file || "")}<br>Sample: ${escapeHtml(data.sample_file || "")}</div>
    <div class="mini-grid">
      <div class="list-item"><strong>Raw layout</strong><br>Description: ${escapeHtml(rawRec.description_column || "auto")} · Row type: ${escapeHtml(rawRec.row_type_column || "auto")} · Unit: ${escapeHtml(rawRec.unit_column || "auto")}<br>Formula columns: ${escapeHtml((rawRec.formula_columns || []).join(", ") || "auto")}</div>
      <div class="list-item"><strong>Sample layout</strong><br>Description: ${escapeHtml(sampleRec.description_column || "auto")} · Row type: ${escapeHtml(sampleRec.row_type_column || "auto")} · Unit: ${escapeHtml(sampleRec.unit_column || "auto")}<br>Formula columns: ${escapeHtml((sampleRec.formula_columns || []).join(", ") || "auto")}</div>
      <div class="list-item"><strong>Learned hints</strong><br>Item rows below heading italic: ${sug.item_rows_below_heading_italic ? "Yes" : "No / uncertain"}<br>Sample rows: ${escapeHtml(sig.total_rows_sampled || 0)} · Italic child ratio: ${escapeHtml(sig.italic_child_row_ratio || 0)}</div>
    </div>
    ${data.download_url ? `<div class="actions"><a class="action secondary" href="${escapeAttr(data.download_url)}">Download sample analysis JSON</a></div>` : ""}
  `;
  if (sampleFormatResult) sampleFormatResult.innerHTML = html;
  renderResult("Sample format analyzed", "v3.17 Style Signature Learner", html);
}

function getSampleWorkbookName() {
  return sampleFileRecord?.saved_name || "";
}

async function analyzeSampleFormat() {
  const rawFile = getAttachedWorkbookName();
  const sampleFile = getSampleWorkbookName();
  if (!rawFile) {
    const html = `<div class="notice warn"><strong>No raw workbook attached.</strong><br>Use the main Attach button first.</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
    renderResult("Jarvis needs raw workbook", "No file attached", html);
    return;
  }
  if (!sampleFile) {
    const html = `<div class="notice warn"><strong>No sample workbook attached.</strong><br>Attach a correctly formatted sample workbook.</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
    renderResult("Jarvis needs sample workbook", "No sample attached", html);
    return;
  }
  if (sampleFormatResult) sampleFormatResult.innerHTML = `<div class="notice safe"><strong>Analyzing raw + sample...</strong><br>${escapeHtml(rawFile)}<br>${escapeHtml(sampleFile)}</div>`;
  try {
    const res = await fetch("/api/formatter/sample/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ raw_file: rawFile, sample_file: sampleFile, profile_key: activeFormatterProfile })
    });
    const data = await readJsonOrThrow(res, "Sample format analysis failed");
    renderSampleFormatAnalysis(data);
    showToast("Sample format analyzed");
    return data;
  } catch (error) {
    const html = `<div class="notice warn"><strong>Sample format analysis failed.</strong><br>${escapeHtml(error.message || "Could not analyze sample")}</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
    renderResult("Sample analysis failed", "No profile changed", html);
  }
}

async function learnSampleFormat() {
  const rawFile = getAttachedWorkbookName();
  const sampleFile = getSampleWorkbookName();
  if (!rawFile || !sampleFile) {
    showToast("Attach raw and sample workbooks first");
    await analyzeSampleFormat();
    return;
  }
  const typed = window.prompt("Learn this sample format to the active Formatter profile?\n\nThis updates profile memory only and creates a safety backup.\nType I APPROVE to continue.") || "";
  if (typed.trim() !== "I APPROVE") {
    const html = `<div class="notice warn">Sample learning cancelled. No profile memory changed.</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
    return;
  }
  if (sampleFormatResult) sampleFormatResult.innerHTML = `<div class="notice safe"><strong>Learning sample format...</strong><br>${escapeHtml(sampleFile)}</div>`;
  try {
    const res = await fetch("/api/formatter/sample/learn", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ raw_file: rawFile, sample_file: sampleFile, profile_key: activeFormatterProfile, typed_confirmation: typed })
    });
    const data = await readJsonOrThrow(res, "Sample format learning failed");
    await loadFormatterProfiles();
    await loadSafety();
    renderSampleFormatAnalysis(data.analysis || {});
    renderResult("Sample format learned safely", "Profile memory updated · Backup created", `<div class="notice safe"><strong>${escapeHtml(data.profile_name || data.profile_key)}</strong><br>${escapeHtml(data.message || "Sample learned.")}<br>Backup: ${escapeHtml(data.backup_created || "created")}</div>`);
    showToast("Sample format learned");
  } catch (error) {
    const html = `<div class="notice warn"><strong>Sample format learning failed.</strong><br>${escapeHtml(error.message || "Could not learn sample")}</div>`;
    if (sampleFormatResult) sampleFormatResult.innerHTML = html;
    renderResult("Sample learning failed", "No profile changed", html);
  }
}

analyzeSampleFormatBtn?.addEventListener("click", analyzeSampleFormat);
learnSampleFormatBtn?.addEventListener("click", learnSampleFormat);
builderPreviewBtn?.addEventListener("click", event => previewBuilderOutput(event.currentTarget));
builderLoadLevelsBtn?.addEventListener("click", loadBuilderLevelZoneSetup);
builderZoneComboSelect?.addEventListener("change", () => applyZoneCombo(builderZoneComboSelect.value));
builderApplyComboBtn?.addEventListener("click", () => applyZoneCombo(builderZoneComboSelect?.value || builderActiveComboId));
builderSaveComboBtn?.addEventListener("click", saveCurrentZoneComboToMemory);
builderDeleteComboBtn?.addEventListener("click", deleteCurrentZoneComboFromMemory);
builderAddLevelBtn?.addEventListener("click", addBuilderLevelRow);
builderAddZoneBtn?.addEventListener("click", addBuilderZoneRow);
builderImportStandardZonesBtn?.addEventListener("click", importStandardZonesForSelectedCategory);
builderResetLevelsBtn?.addEventListener("click", resetBuilderLevelRows);
builderSaveLevelsBtn?.addEventListener("click", saveBuilderLevelZoneSetup);

renderSearch(recent);
loadTools();
renderBuilderTradeProfiles(DEFAULT_BUILDER_TRADE_PROFILES_UI, "walls_partitions");
loadBuilderLevelZoneSetup();
loadFormatterProfiles();
loadSafety();


// v4.5.1.15 — conversation 404 recovery guard, real recents, and setup preview.
let currentConversationId = (() => { try { return localStorage.getItem("jarvis_current_conversation_id") || ""; } catch { return ""; } })();
let currentConversationProject = "";
let conversationSidebarCache = [];
let conversationRefreshSeq = 0;
let conversationSidebarRefreshTimer45120 = null;
// v4.5.1.21 — one conversation shell + one ordered event pipe.
// Without this, fast user/assistant appends could both see an empty currentConversationId,
// create multiple chats, and make Recents fluctuate or miss the real New Chat.
let conversationEnsurePromise45121 = null;
let conversationEventQueue45121 = Promise.resolve();
let conversationCommitSeq45121 = 0;
// Build 1 stability: one sidebar refresh at a time, with a small idle throttle.
// This stops refresh/event races from creating GET storms while still allowing
// explicit opens/resumes to force a current view refresh.
let conversationSidebarRefreshInFlight45122B1 = null;
let conversationSidebarLastStarted45122B1 = 0;
let conversationSidebarPendingActiveId45122B1 = "";

function scheduleConversationSidebarRefresh45120(activeId = currentConversationId, delay = 180) {
  clearTimeout(conversationSidebarRefreshTimer45120);
  conversationSidebarRefreshTimer45120 = window.setTimeout(() => refreshConversationSidebar(activeId), Math.max(80, delay));
}


function conversationFilenameList(messages = []) {
  const names = [];
  (messages || []).forEach(m => (m.attachments || []).forEach(a => {
    const n = a.filename || a.saved_name || a.name;
    if (n && !names.includes(n)) names.push(n);
  }));
  return names;
}

function conversationLooksEmpty(c = {}) {
  const title = String(c.title || "").trim().toLowerCase();
  return !Number(c.message_count || 0) && !c.has_unfinished_task && !(Array.isArray(c.attachments) && c.attachments.length) && ["", "new chat", "recovered chat", "conversation"].includes(title);
}

function conversationHasMeaningfulContent(c = {}) {
  if (c.has_meaningful_content === true) return true;
  if (c.has_unfinished_task) return true;
  if (Array.isArray(c.attachments) && c.attachments.length) return true;
  const msgs = Array.isArray(c.messages) ? c.messages : [];
  // Build 1: match backend v4.5.1.22 behavior. A short real user message
  // like “Hi” must keep New Chat/Recents/resume/export tied to the same chat.
  return msgs.some(m => m && m.role === "user" && String(m.text || "").trim());
}

function compactConversationMessagesForUi(messages = []) {
  const cleaned = [];
  let lastAssistantKey = "";
  (Array.isArray(messages) ? messages : []).forEach(m => {
    if (!m) return;
    const role = m.role === "assistant" ? "assistant" : "user";
    const attachments = Array.isArray(m.attachments) ? m.attachments : [];
    const key = role === "assistant" && !attachments.length ? `${role}|${String(m.text || "").trim()}|${String(m.meta || "").trim()}` : "";
    if (key && key === lastAssistantKey) return;
    lastAssistantKey = key || "";
    cleaned.push(m);
  });
  return cleaned.slice(-80);
}

function stableConversationRows(rows = []) {
  const byId = new Map();
  (rows || []).forEach(c => {
    if (!c || !c.id || conversationLooksEmpty(c)) return;
    const prev = byId.get(c.id);
    if (!prev || String(c.updated_at || "") >= String(prev.updated_at || "")) byId.set(c.id, c);
  });
  return Array.from(byId.values()).sort((a, b) => String(b.updated_at || b.created_at || "").localeCompare(String(a.updated_at || a.created_at || "")));
}

async function createConversation(project = "") {
  const res = await fetch("/api/conversations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ project: project || "", title: "New chat" })
  });
  if (!res.ok) throw new Error("Could not create conversation");
  const data = await res.json();
  currentConversationId = data?.conversation?.id || "";
  currentConversationProject = data?.conversation?.project || project || currentConversationProject || "";
  try { localStorage.setItem("jarvis_current_conversation_id", currentConversationId); } catch {}
  scheduleConversationSidebarRefresh45120(currentConversationId, 220);
  return currentConversationId;
}

async function conversationExists(conversationId) {
  if (!conversationId) return false;
  try {
    const res = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}`, { cache: "no-store" });
    return res.ok;
  } catch { return false; }
}

async function ensureConversation(project = "", options = {}) {
  const allowCreate = options.allowCreate !== false;
  if (currentConversationId) {
    const ok = await conversationExists(currentConversationId);
    if (ok) return currentConversationId;
    try { localStorage.removeItem("jarvis_current_conversation_id"); } catch {}
    currentConversationId = "";
  }
  if (!allowCreate) return "";
  if (conversationEnsurePromise45121) return await conversationEnsurePromise45121;
  conversationEnsurePromise45121 = (async () => {
    try {
      if (currentConversationId) return currentConversationId;
      return await createConversation(project || currentConversationProject || "");
    } finally {
      conversationEnsurePromise45121 = null;
    }
  })();
  return await conversationEnsurePromise45121;
}

async function commitConversationShell45121(project = "") {
  try {
    const cid = await ensureConversation(project || currentConversationProject || "", { allowCreate: true });
    if (cid) {
      try { localStorage.setItem("jarvis_current_conversation_id", cid); } catch {}
      scheduleConversationSidebarRefresh45120(cid, 260);
    }
    return cid || "";
  } catch {
    return "";
  }
}

async function postConversationEventOnce(cid, payload) {
  return await fetch(`/api/conversations/${encodeURIComponent(cid)}/event`, {
    method: "POST",
    cache: "no-store",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
}

async function persistConversationEventInner45121(role, text, options = {}) {
  try {
    if (options.persistConversation === false || options.noConversationPersist === true) return;
    const attachments = Array.isArray(options.attachments) ? options.attachments : [];
    const activeTask = activeConversationTask || null;
    const roleClean = String(role || "").toLowerCase();
    const allowCreate = roleClean === "user" || attachments.length > 0 || !!activeTask || !!currentConversationProject;
    let cid = await ensureConversation(currentConversationProject || "", { allowCreate });
    if (!cid) return;
    const fallbackId = `evt_${Date.now()}_${++conversationCommitSeq45121}_${Math.random().toString(36).slice(2, 8)}`;
    const payload = {
      role,
      text: String(text || ""),
      meta: String(options.meta || ""),
      attachments,
      active_task: activeTask,
      pending_clarification_type: pendingClarification?.type || "",
      event_id: String(options.event_id || options.message_id || options.id || fallbackId),
      message_id: String(options.message_id || options.id || fallbackId),
      project: currentConversationProject || "",
      source: "jarvis_ui"
    };
    let res = await postConversationEventOnce(cid, payload);
    if (res.status === 404) {
      try { localStorage.removeItem("jarvis_current_conversation_id"); } catch {}
      currentConversationId = "";
      if (!allowCreate) return;
      cid = await createConversation(currentConversationProject || "");
      res = await postConversationEventOnce(cid, payload);
    }
    if (res.ok) {
      const data = await res.json();
      if (data?.conversation?.id) {
        currentConversationId = data.conversation.id;
        try { localStorage.setItem("jarvis_current_conversation_id", currentConversationId); } catch {}
      }
      if (data?.conversation?.project) currentConversationProject = data.conversation.project;
      if (data?.conversation?.title) scheduleConversationSidebarRefresh45120(data.conversation.id, 220);
    }
  } catch (err) {
    // Conversation persistence must never interrupt the tool workflow.
  }
}

async function persistConversationEvent(role, text, options = {}) {
  conversationEventQueue45121 = conversationEventQueue45121
    .catch(() => {})
    .then(() => persistConversationEventInner45121(role, text, options));
  return conversationEventQueue45121;
}

const legacyLogVisibleChatEvent4514 = logVisibleChatEvent;
async function logVisibleChatEvent(role, text, options = {}) {
  // v4.5.1.22: canonical conversation storage is /api/conversations/{id}/event.
  // The older /api/chat/event trace is kept only for explicit diagnostics to avoid double POST spam.
  if (options.legacyTrace === true) {
    try { await legacyLogVisibleChatEvent4514(role, text, options); } catch {}
  }
  if (options.persistConversation === false || options.noConversationPersist === true) return;
  await persistConversationEvent(role, text, options);
}

function sidebarIconFolder() {
  return `<svg class="ui-icon folder-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M3.8 6.8h6l1.7 2h8.7v8.8a2 2 0 0 1-2 2H5.8a2 2 0 0 1-2-2Z"/><path d="M3.8 9h16.4"/></svg>`;
}
function sidebarDots() {
  return `<svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/></svg>`;
}

function renderConversationSidebar(data = {}) {
  const recents = stableConversationRows(Array.isArray(data.conversations) ? data.conversations : []);
  conversationSidebarCache = recents;
  const projectList = document.getElementById("projectList");
  const recentList = document.getElementById("recentConversationList");
  if (recentList) {
    if (!recents.length) {
      recentList.innerHTML = `<div class="sidebar-empty">No recent conversations yet.</div>`;
    } else {
      recentList.innerHTML = recents.slice(0, 12).map(c => `
        <div class="recent-chat-row${c.id === currentConversationId ? " active" : ""}${c.has_unfinished_task ? " has-unfinished" : ""}" data-conversation-row="${escapeAttr(c.id)}">
          <button class="recent-item" type="button" data-open-conversation="${escapeAttr(c.id)}"><span class="recent-title">${escapeHtml(c.title || "New chat")}</span></button>
          <span class="recent-item-more" data-recent-menu="${escapeAttr(c.title || "Conversation")}" data-conversation-menu="${escapeAttr(c.id)}" role="button" tabindex="0" aria-label="Recent chat options">${sidebarDots()}</span>
        </div>`).join("");
    }
  }
  if (projectList) {
    const projects = {};
    recents.forEach(c => { if (c.project) (projects[c.project] ||= []).push(c); });
    const names = Object.keys(projects);
    if (!names.length) {
      projectList.innerHTML = `<div class="sidebar-empty">No project conversations yet.</div>`;
    } else {
      projectList.innerHTML = names.map((name, idx) => {
        const expanded = idx === 0 || projects[name].some(c => c.id === currentConversationId);
        return `<div class="project-folder${expanded ? " expanded" : ""}" data-project="${escapeAttr(name)}">
          <button class="project-folder-head" data-project-open="${escapeAttr(name)}" type="button"><span class="folder-toggle" aria-hidden="true"><svg class="ui-icon chevron-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${expanded ? "m6 9 6 6 6-6" : "m9 18 6-6-6-6"}"/></svg></span>${sidebarIconFolder()}<span>${escapeHtml(name)}</span><span class="project-item-more" data-project-menu="${escapeAttr(name)}" role="button" tabindex="0" aria-label="Project options">${sidebarDots()}</span></button>
          <div class="project-conversations${expanded ? "" : " collapsed"}">${projects[name].slice(0,5).map(c => `<button class="project-conversation${c.id === currentConversationId ? " active" : ""}${c.has_unfinished_task ? " has-unfinished" : ""}" data-open-conversation="${escapeAttr(c.id)}" type="button"><span class="project-conversation-title">${escapeHtml(c.title || "New chat")}</span></button>`).join("")}</div>
        </div>`;
      }).join("");
    }
  }
}

async function refreshConversationSidebar(activeId = currentConversationId, options = {}) {
  const force = options.force === true;
  const requestedActiveId = activeId || currentConversationId || "";
  const now = Date.now();
  if (conversationSidebarRefreshInFlight45122B1) {
    if (requestedActiveId) conversationSidebarPendingActiveId45122B1 = requestedActiveId;
    return conversationSidebarRefreshInFlight45122B1;
  }
  if (!force && now - conversationSidebarLastStarted45122B1 < 180) {
    if (requestedActiveId) conversationSidebarPendingActiveId45122B1 = requestedActiveId;
    clearTimeout(conversationSidebarRefreshTimer45120);
    conversationSidebarRefreshTimer45120 = window.setTimeout(() => refreshConversationSidebar(conversationSidebarPendingActiveId45122B1 || currentConversationId, { force: true }), 220);
    return;
  }
  conversationSidebarLastStarted45122B1 = now;
  const seq = ++conversationRefreshSeq;
  conversationSidebarRefreshInFlight45122B1 = (async () => {
    try {
      const res = await fetch("/api/conversations?limit=80", { cache: "no-store" });
      if (!res.ok) throw new Error("Could not load conversations");
      const data = await res.json();
      if (seq !== conversationRefreshSeq) return; // ignore stale, out-of-order sidebar paints
      const finalActiveId = conversationSidebarPendingActiveId45122B1 || requestedActiveId;
      conversationSidebarPendingActiveId45122B1 = "";
      if (finalActiveId) currentConversationId = finalActiveId;
      renderConversationSidebar(data);
    } catch (err) {
      if (seq !== conversationRefreshSeq) return;
      const recentList = document.getElementById("recentConversationList");
      if (recentList) recentList.innerHTML = `<div class="sidebar-empty">Conversation storage unavailable.</div>`;
    } finally {
      conversationSidebarRefreshInFlight45122B1 = null;
    }
  })();
  return conversationSidebarRefreshInFlight45122B1;
}

function restoreConversationMessages(conv) {
  chatMessages = compactConversationMessagesForUi(conv.messages || []).map(m => ({
    id: m.id || `restored_${Date.now()}_${Math.random().toString(36).slice(2)}`,
    role: m.role === "assistant" ? "assistant" : "user",
    text: String(m.text || ""),
    html: "",
    kind: "chat",
    meta: String(m.meta || ""),
    at: (m.timestamp || "").slice(11,16) || "",
    attachments: Array.isArray(m.attachments) ? m.attachments : []
  })).slice(-80);
  activeConversationTask = conv.active_task || null;
  const restoredExportUrl451242B = activeConversationTask?.last_export_job?.result?.download_url || activeConversationTask?.export_result?.download_url || "";
  if (restoredExportUrl451242B && ["export_ready", "done", "completed"].includes(String(activeConversationTask?.status || ""))) {
    lastOutputDownloadUrl = restoredExportUrl451242B;
  }
  if (activeConversationTask?.plan) lastBuilderCommandPlan = activeConversationTask.plan;
  else if (conv.project_context?.last_builder_plan) lastBuilderCommandPlan = conv.project_context.last_builder_plan;
  if (activeConversationTask?.pending) pendingClarification = activeConversationTask.pending;
  if (activeConversationTask?.workbook && !uploadedFileRecord) {
    uploadedFileRecord = activeConversationTask.workbook;
    uploadedFileRecords = [activeConversationTask.workbook];
  }
  currentConversationProject = conv.project || conv.project_context?.project_name || "";
  renderChatThread();
  markChatStarted();
  homeStack?.classList.add("chat-started");
  welcomeHero?.setAttribute("aria-hidden", "true");
  quickActionRow?.setAttribute("aria-hidden", "true");
  if (activeConversationTask && activeConversationTask.status && !["cancelled"].includes(String(activeConversationTask.status))) {
    if (activeConversationTask.plan) {
      const wbName = activeConversationTask.workbook?.filename || activeConversationTask.workbook?.saved_name || "workbook";
      let recoveryActions = `${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Approve & Preview", "data-approve-builder-preview='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`;
      if (activeConversationTask.status === "preview_ready" && activeConversationTask.preview) {
        recoveryActions = `${compactAction("Open Preview", "data-open-preview-drawer='1'")}${compactAction("Export Excel", "data-run-builder='1'")}${compactAction("Review setup", "data-review-builder-setup='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`;
      } else if (["export_ready", "done", "completed"].includes(String(activeConversationTask.status))) {
        const downloadAction = lastOutputDownloadUrl ? `<a class="inline-action primary" href="${escapeAttr(lastOutputDownloadUrl)}">Download output</a>` : "";
        recoveryActions = `${downloadAction}${compactAction("Open Output Center", "onclick=\"showView('outputs'); loadJobs(); loadOutputs();\"")}${activeConversationTask.preview ? compactAction("Open Preview", "data-open-preview-drawer='1'") : ""}${compactAction("View details", "data-review-builder-setup='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`;
      }
      if (activeConversationTask.preview && !latestBuilderPreviewData) latestBuilderPreviewData = activeConversationTask.preview;
      const restoredLine = ["export_ready", "done", "completed"].includes(String(activeConversationTask.status))
        ? `Restored Builder output${activeConversationTask.workbook ? ` with ${wbName}` : ""}.`
        : `Restored Builder setup${activeConversationTask.workbook ? ` with ${wbName}` : ""}.`;
      appendAssistantConversation([restoredLine], recoveryActions, { meta: "recovery", persistConversation: false });
    } else {
      appendAssistantConversation(["I found an unfinished task in this conversation. You can continue from here or start a new command."], `${compactAction("Resume task", "data-continue-previous-task='1'")}${compactAction("Start new command", "data-start-new-command='1'")}`, { meta: "recovery", persistConversation: false });
    }
  }
}

async function openSavedConversation(conversationId, options = {}) {
  try {
    const res = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}`);
    if (!res.ok) throw new Error("Conversation not found");
    const data = await res.json();
    const conv = data.conversation || {};
    if (options.autoRestore && !conversationHasMeaningfulContent(conv)) {
      currentConversationId = "";
      try { localStorage.removeItem("jarvis_current_conversation_id"); } catch {}
      await refreshConversationSidebar("");
      return;
    }
    currentConversationId = conv.id || conversationId;
    try { localStorage.setItem("jarvis_current_conversation_id", currentConversationId); } catch {}
    resetActiveConversationState();
    restoreConversationMessages(conv);
    showView("home");
    await refreshConversationSidebar(currentConversationId, { force: true });
    if (!options.silent) showToast(`Opened ${conv.title || "conversation"}`);
  } catch (err) {
    if (!options.silent) showToast(err.message || "Could not open conversation");
    if (options.autoRestore) { try { localStorage.removeItem("jarvis_current_conversation_id"); } catch {}; currentConversationId = ""; }
  }
}

const legacyStartNewChat4514 = startNewChat;
async function startNewChat(options = {}) {
  chatMessages = [];
  resetActiveConversationState();
  resultCard?.classList.remove("show");
  if (resultBody) resultBody.innerHTML = "";
  if (promptInput) { promptInput.value = ""; autoResizeComposer(); promptInput.placeholder = "Message Jarvis..."; }
  homeStack?.classList.remove("chat-started");
  welcomeHero?.removeAttribute("aria-hidden");
  quickActionRow?.removeAttribute("aria-hidden");
  renderChatThread();
  showView("home");
  currentConversationId = "";
  currentConversationProject = options.project || "";
  conversationEnsurePromise45121 = null;
  try { localStorage.removeItem("jarvis_current_conversation_id"); } catch {}
  if (options.project) setActiveProjectFolder(options.project);
  showToast(options.project ? `New chat in ${options.project}` : "New chat");
}

async function startProjectChat(projectName, label = "") {
  await startNewChat({ project: projectName });
  if (promptInput) promptInput.placeholder = projectName ? `Message ${projectName}...` : "Message Jarvis...";
}

async function renameConversation(conversationId) {
  const conv = conversationSidebarCache.find(c => c.id === conversationId);
  const title = window.prompt("Rename chat", conv?.title || "New chat");
  if (!title) return;
  try {
    await fetch(`/api/conversations/${encodeURIComponent(conversationId)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) });
    await refreshConversationSidebar(conversationId);
  } catch { showToast("Rename failed"); }
}

async function archiveConversation(conversationId) {
  try {
    await fetch(`/api/conversations/${encodeURIComponent(conversationId)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ archived: true }) });
    if (conversationId === currentConversationId) await startNewChat({});
    await refreshConversationSidebar();
  } catch { showToast("Archive failed"); }
}

// Override conversation export so Share exports the current opened chat, not unrelated old logs.
async function downloadChatExport(kind = "conversation") {
  try {
    const cid = currentConversationId ? `&conversation_id=${encodeURIComponent(currentConversationId)}` : "";
    const res = await fetch(`/api/chat/export?kind=${encodeURIComponent(kind)}${cid}`);
    if (!res.ok) throw new Error("Could not export conversation");
    const blob = await res.blob();
    const cd = res.headers.get("content-disposition") || "";
    const match = cd.match(/filename="?([^";]+)"?/i);
    const filename = match ? match[1] : `Jarvis_${kind}_${new Date().toISOString().slice(0,19).replace(/[:T]/g, "-")}.md`;
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    showToast(kind === "project_context" ? "Project context exported" : "Conversation exported");
  } catch (error) { showToast(error.message || "Export failed"); }
}

document.addEventListener("click", async (event) => {
  const openBtn = event.target.closest("[data-open-conversation]");
  if (openBtn) { event.preventDefault(); event.stopPropagation(); await openSavedConversation(openBtn.dataset.openConversation); return; }
  const projectHead = event.target.closest("#projectList [data-project-open]");
  if (projectHead && !event.target.closest("[data-project-menu]")) { event.preventDefault(); toggleProjectFolder(projectHead.dataset.projectOpen || ""); return; }
  const cMenu = event.target.closest("[data-conversation-menu]");
  if (cMenu) { event.preventDefault(); event.stopPropagation(); showSidebarContextMenu(event, "recent", cMenu.dataset.recentMenu || "Conversation"); sidebarContextTarget = { type: "conversation", label: cMenu.dataset.recentMenu || "Conversation", conversationId: cMenu.dataset.conversationMenu }; return; }
});

// Extend existing sidebar context actions for real conversations.
document.addEventListener("click", async (event) => {
  const contextAction = event.target.closest("#sidebarContextMenu [data-context-action]");
  if (!contextAction || !sidebarContextTarget?.conversationId) return;
  const action = contextAction.dataset.contextAction || "";
  const cid = sidebarContextTarget.conversationId;
  if (action === "open") { await openSavedConversation(cid); return; }
  if (action === "rename") { await renameConversation(cid); return; }
  if (action === "archive") { await archiveConversation(cid); return; }
  if (action === "delete") { await archiveConversation(cid); return; }
});

window.addEventListener("DOMContentLoaded", async () => {
  conversationInitialRefreshDone45122 = true;
  await refreshConversationSidebar(currentConversationId, { force: true });
  if (currentConversationId) {
    try { await openSavedConversation(currentConversationId, { autoRestore: true, silent: true }); } catch { currentConversationId = ""; }
  }
});
// Also run after script load in case DOMContentLoaded already fired. Sidebar-only refresh must not repaint chat.
setTimeout(() => { if (!conversationInitialRefreshDone45122) refreshConversationSidebar(currentConversationId, { force: true }); }, 400);

# Jarvis v4.5.1.25 Change Report

## Version
v4.5.1.25 — Framework Scaffold + Doors/Windows Source-Preserve Guard

## Base
v4.5.1.24.2F — Conversation Transcript Hygiene + Review Route Suppression

## Scope approved
- Create a safe framework scaffold beside the current runtime.
- Add a guarded Doors/Windows source-preserve count workflow.
- Add active short confirmations for `Use Count`, `Use XGETCOUNT`, `Use XGETNUMBER`, and `Unit no`-style replies.
- Keep the stable Builder formula/export engine protected.

## Files changed
- `app.py`
- `static/assets/app.js`
- `static/index.html`
- `legacy/app_legacy_v4_5_1_24_2F.py`
- `jarvis/**` scaffold files
- `data/**` scaffold folders
- `config/tool_registry.json`
- `config/trade_profiles.json`
- `docs/CURRENT_FRAMEWORK.md`
- `docs/PATCH_RULES.md`
- `docs/MIGRATION_PLAN.md`
- `docs/KNOWN_ISSUES.md`
- `START_JARVIS_v4_5_1_25.bat`
- `START_JARVIS_v4_5_1_25_SIMPLE_NO_VENV.bat`

## Runtime changes
### Doors/Windows source-preserve guard
A new narrow source-preserve count path activates only when all of these are true:

- Trade/profile is `doors`, `windows`, or `doors_windows`.
- Function is `XGETCOUNT` or `XGETNUMBER`.
- Zone token mode is `preserve_source`.
- Source workbook contains CostX source zone tokens.

When active, Jarvis builds preview/export rows directly from source formulas and groups them by the source ZC3 level token. This prevents cross-joining source rows with stale workspace/default Builder levels.

### Active short confirmation parser
The active Builder plan now treats these as active setup confirmations instead of Local AI/general fallback:

- `Use Count`
- `Use XGETCOUNT`
- `Use XGETNUMBER`
- `Unit no`, `Unit m2`, `Unit m3`, `Unit m`, `Unit t`, etc.

### Classification warning severity
For simple Doors/Windows count exports, missing ZC5/ZC7 classification is now informational unless the user explicitly requests classification/split behavior.

### Framework scaffold
Created future migration folders and stubs while keeping `app.py` as the active runtime.

## Protected / not touched
- Builder formula/export engine core
- CostX formula string builder core
- Formula Integrity Guard core logic
- Mezz alias guard
- Multiline Zone parser
- Wall Types rebuild flow
- Structural Steel rebuild flow
- Formatter
- QA Checker
- Output Center engine

## Rollback
Use `legacy/app_legacy_v4_5_1_24_2F.py` as the source reference for the accepted 2F base. Full rollback is also available by reinstalling the accepted 2F ZIP.

"""BuilderRunSnapshot scaffold.

Future migration target: Preview/export should consume this object only. v25 keeps
existing app.py runtime and documents the target contract.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BuilderRunSnapshot:
    snapshot_id: str
    conversation_id: str
    workbook_ref: dict[str, Any]
    trade_profile: str
    function: str
    unit: str
    custom_quantity: str | None = None
    zone_mode: str = "preserve_source"
    dynamic_zones: list[dict[str, Any]] = field(default_factory=list)
    heading_assignments: list[dict[str, Any]] = field(default_factory=list)
    levels: list[str] = field(default_factory=list)
    aliases: dict[str, Any] = field(default_factory=dict)
    approved_by_user: bool = False

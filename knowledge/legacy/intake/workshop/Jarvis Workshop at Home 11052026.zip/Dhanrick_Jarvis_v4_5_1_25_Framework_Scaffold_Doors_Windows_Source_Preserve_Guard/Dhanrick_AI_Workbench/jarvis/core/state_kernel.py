"""State kernel scaffold for future Jarvis migration.

Runtime note: v4.5.1.25 still runs through app.py. This module is a safe
scaffold only so future patches can migrate state without rewriting the working
runtime in one jump.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConversationState:
    conversation_id: str
    project_id: str | None = None
    active_task_id: str | None = None
    active_workbook_id: str | None = None
    pending_clarification: dict[str, Any] | None = None
    latest_preview_id: str | None = None
    latest_export_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

"""Active task schema scaffold for future State Kernel migration."""

from dataclasses import dataclass, field
from typing import Any, Literal


TaskStatus = Literal["collecting", "needs_clarification", "needs_review", "plan_ready", "preview_ready", "export_ready", "failed", "cancelled"]


@dataclass
class ActiveTask:
    task_id: str
    conversation_id: str
    tool: str
    status: TaskStatus = "collecting"
    workbook: dict[str, Any] | None = None
    plan: dict[str, Any] = field(default_factory=dict)
    pending_clarification: dict[str, Any] | None = None
    preview_result: dict[str, Any] | None = None
    export_result: dict[str, Any] | None = None

"""Router scaffold for future migration.

Runtime remains app.py in v4.5.1.25. Future router order should be:
1. duplicate guard
2. pending clarification
3. active task action
4. active task edit
5. attachment reply
6. new command
7. general chat
"""

"""Doors/Windows source-preserve guard design notes.

The live implementation remains in app.py for v4.5.1.25. This file marks the
future extraction point for the guarded count-row generator.
"""

SOURCE_PRESERVE_COUNT_CONDITIONS = {
    "profiles": ["doors", "windows", "doors_windows"],
    "functions": ["XGETCOUNT", "XGETNUMBER"],
    "zone_token_mode": "preserve_source",
}

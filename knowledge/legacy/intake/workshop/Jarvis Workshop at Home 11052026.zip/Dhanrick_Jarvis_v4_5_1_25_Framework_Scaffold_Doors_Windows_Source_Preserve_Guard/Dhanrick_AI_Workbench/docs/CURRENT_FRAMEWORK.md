# Current Framework

Version: v4.5.1.25

Runtime remains `app.py`. The new `jarvis/`, `data/`, `config/`, `tests/`, and
`docs/` folders are scaffold/adapters only. Do not migrate working logic until a
separate approved state-kernel phase.

# Patch Rules

- Base: v4.5.1.24.2F accepted stable candidate.
- Protect Builder formula/export engine.
- Prefer narrow guards over broad rewrites.
- Preview/export must stay approval-based.
- Doors/Windows source-preserve logic activates only for count functions with existing source tokens.

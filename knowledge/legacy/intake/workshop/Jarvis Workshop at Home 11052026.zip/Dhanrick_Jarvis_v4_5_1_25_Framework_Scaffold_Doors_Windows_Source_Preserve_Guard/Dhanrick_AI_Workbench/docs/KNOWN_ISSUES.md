# Known Issues

Resolved in v25: Doors/Windows source-preserve count preview/export should no
longer cross-join source formulas with stale workspace levels.

Deferred: transcript entries for button actions such as Approve & Preview.

# Migration Plan

1. v4.5.1.25: scaffold + Doors/Windows source-preserve guard.
2. v4.5.1.26: State Kernel shadow mode.
3. v4.5.1.27: Router migration with fallback.
4. v4.5.1.28: Parser extraction + tests.
5. v4.5.1.29: BuilderRunSnapshot enforcement.

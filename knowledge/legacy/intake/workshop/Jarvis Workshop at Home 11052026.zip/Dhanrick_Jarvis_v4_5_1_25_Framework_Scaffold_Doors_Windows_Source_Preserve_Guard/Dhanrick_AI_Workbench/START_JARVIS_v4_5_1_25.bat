@echo off
cd /d %~dp0
echo Starting Jarvis v4.5.1.25...
python app.py
pause

# Jarvis v4.5.1.25 Test Report

## Version
v4.5.1.25 — Framework Scaffold + Doors/Windows Source-Preserve Guard

## Base
v4.5.1.24.2F — Conversation Transcript Hygiene + Review Route Suppression

## Static validation
- `python3 -m py_compile app.py` — PASS
- `node --check static/assets/app.js` — PASS
- Import `app.py` and read `APP_VERSION` — PASS

## Targeted source-preserve Doors/Windows test
Input used during local validation only: `Windows Test.xlsx`.

Run context:
- Trade: Doors / Windows
- Function: XGETCOUNT
- Unit: no
- Zone token mode: preserve_source

Expected:
- Preview safe to export.
- Output groups only source levels GF and L1.
- No invented L2/L3/L4 rows.
- 12 source-derived formula rows.
- XGETCOUNT/no only.

Actual:
- Preview status: safe_to_export = true — PASS
- Preview rows: 12 — PASS
- Groups: GF, L1 — PASS
- Export formulas: 12 — PASS
- GF formulas: 11 — PASS
- L1 formulas: 1 — PASS
- L2/L3/L4 formulas: 0 — PASS
- Formula Integrity Guard: PASS

## Active short confirmation tests
- `Use Count` against active Builder plan — PASS
- `Unit no` against active Builder plan — PASS
- `Use XGETNUMBER` against active Builder plan — PASS

## Cleanup after test
Test input and generated validation output were removed before packaging.

## Remaining required user regression tests
1. Doors/Windows source-preserve flow using `Windows Test.xlsx`.
2. Existing Wall Types / Structural Steel Mezz alias flow.
3. Reverse Mezz alias flow.
4. Multiline Zone 1 / Zone 2 parser flow.
5. Low-confidence unclear command safety gate.
6. Refresh/recovery.

## Risk notes
The new row-generation behavior is guarded to count-based Doors/Windows source-preserve only. Existing Wall Types/Structural Steel rebuild paths should not activate the new source-preserve count path.

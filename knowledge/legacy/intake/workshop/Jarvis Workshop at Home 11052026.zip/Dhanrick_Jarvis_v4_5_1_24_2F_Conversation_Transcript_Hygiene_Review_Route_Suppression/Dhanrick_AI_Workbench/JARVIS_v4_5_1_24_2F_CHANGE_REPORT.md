# Jarvis v4.5.1.24.2F Change Report

## Version
v4.5.1.24.2F — Conversation Transcript Hygiene + Review Route Suppression

## Base
v4.5.1.24.2E — Export Chat Confirmation + Support Log Message Isolation

## Files changed
- `static/assets/app.js`
- `static/index.html`
- `app.py`
- `START_JARVIS_v4_5_1_24_2F.bat`
- `START_JARVIS_v4_5_1_24_2F_SIMPLE_NO_VENV.bat`
- `JARVIS_v4_5_1_24_2F_CHANGE_REPORT.md`
- `JARVIS_v4_5_1_24_2F_TEST_REPORT.md`

## Fixes
1. `appendAssistantConversation()` now forwards `persistConversation` / `noConversationPersist` flags to `appendChatMessage()`.
   - UI-only review/support/status messages can stay out of canonical conversation exports.

2. Backend conversation compaction now filters support-log utility status rows such as:
   - `Support log ready.`
   - `Support log ready to export.`
   - `Support log exported.`

3. Backend debug/conversation export now uses compacted/filtered transcript rows, including fallback recent chat trace.

4. Review-route fallback now suppresses the duplicate Builder plan card.
   - `Review`, `Reviw`, `Revie`, `review setup`, `show setup`, and similar review actions open the read-only setup review without adding the extra `Builder setup ready.` message.

5. Cache key updated to `v4.5.1.24.2F-transcript-hygiene-review-route` for both CSS and JS references.

6. Frontend build marker added:
   - `JARVIS_FRONTEND_VERSION_451242F`

## Not touched
- Builder formula/export engine
- CostX formula generation
- Workbook export structure
- Formula Integrity Guard core logic
- Zone parser logic
- Formatter
- QA Checker
- Output Center engine

## Rollback
Use v4.5.1.24.2E if this cleanup causes UI issues. No Builder output logic was changed.

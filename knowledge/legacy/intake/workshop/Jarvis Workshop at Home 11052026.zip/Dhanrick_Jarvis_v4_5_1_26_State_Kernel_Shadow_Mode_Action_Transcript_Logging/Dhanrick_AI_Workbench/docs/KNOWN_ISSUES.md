# Known Issues

Resolved in v25: Doors/Windows source-preserve count preview/export should no
longer cross-join source formulas with stale workspace levels.

Deferred: transcript entries for button actions such as Approve & Preview.


## v4.5.1.26 status
- Button actions are now recorded as visible transcript rows for major workflow actions.
- State Kernel shadow snapshots are diagnostic only and are not the source of truth yet.
- Future migration should compare shadow state against current app.py runtime before replacing any active state logic.

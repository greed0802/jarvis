# Jarvis Project Context

Generated: 2026-05-11T12:27:46
App version: v4.5.1.26 State Kernel Shadow Mode + Action Transcript Logging

Conversation ID: chat_20260511_122724_9c861e30
Title: User Action Open Preview Build
Project: 

## Current Task / Router Summary

```json
{
  "app_version": "v4.5.1.26 State Kernel Shadow Mode + Action Transcript Logging",
  "generated_at": "2026-05-11T12:27:46",
  "counts": {
    "route_requests": 36,
    "file_uploads": 2,
    "builder_or_job_events": 6,
    "visible_chat_messages": 4
  },
  "last_visible_user_message": "User action: Export",
  "last_visible_assistant_message": "Output ready. Your BOQ base sheet has been exported.",
  "last_prompt": "Review",
  "last_action": "ask_first_plan",
  "last_intent": "builder_action_router",
  "last_confidence": 96,
  "last_builder_plan_summary": {
    "trade": "Walls / Partitions",
    "function": "XGETWALLAREA",
    "custom_quantity": "",
    "unit": "m2",
    "zone_mode": "rebuild",
    "has_file_at_route_time": true,
    "requires_review_before_preview": false
  },
  "last_project_hierarchy_summary": {
    "enabled": false,
    "rows": [
      {
        "title": "Levels / Zone 3",
        "zone_index": 3,
        "head": "formula rows",
        "label": "Levels",
        "mode": "levels",
        "values": [
          "GF",
          "L1",
          "L2",
          "L3",
          "L4",
          "L5",
          "L6",
          "L7",
          "L8",
          "L9",
          "L10",
          "L11",
          "L11 Mezzanine"
        ]
      }
    ],
    "levels": [
      "GF",
      "L1",
      "L2",
      "L3",
      "L4",
      "L5",
      "L6",
      "L7",
      "L8",
      "L9",
      "L10",
      "L11",
      "L11 Mezzanine"
    ],
    "dynamic_zones": [
      {
        "zone_index": 1,
        "values": [
          "Old",
          "New"
        ],
        "role": "zone_1",
        "source": "chained_zone_sentence"
      },
      {
        "zone_index": 2,
        "values": [
          "External",
          "Internal"
        ],
        "role": "location",
        "source": "chained_zone_sentence"
      }
    ],
    "hierarchy_description": "Zone 1 (Zone 1) = Head2; Zone 2 (Location / Split) = Head3; Detected dimension/type = Head4; Levels = formula rows (Zone 3)"
  },
  "latest_uploads": [
    "Test.xlsx",
    "Steel test.xlsx"
  ],
  "active_workbook": {
    "filename": "Steel test.xlsx",
    "saved_name": "20260511_122519_Steel test.xlsx",
    "is_workbook": true
  },
  "active_task_status": "export_ready"
}
```

## Visible Conversation

### Assistant · 2026-05-11T12:27:25
Preview ready

### User · 2026-05-11T12:27:26
User action: Open Preview

### User · 2026-05-11T12:27:35
User action: Export

### Assistant · 2026-05-11T12:27:37
Output ready. Your BOQ base sheet has been exported.

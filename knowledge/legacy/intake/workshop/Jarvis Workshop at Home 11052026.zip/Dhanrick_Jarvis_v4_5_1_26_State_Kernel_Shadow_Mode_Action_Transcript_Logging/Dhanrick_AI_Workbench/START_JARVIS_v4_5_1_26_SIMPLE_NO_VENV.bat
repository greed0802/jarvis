@echo off
cd /d %~dp0
echo Starting Jarvis v4.5.1.26 simple mode...
python app.py
pause

# Jarvis v4.5.1.26.2 Change Report

## Version
Jarvis v4.5.1.26.2 — Zone Parser Stopword + Multiline Active Edit Router Fix

## Base used
- Started from accepted v4.5.1.25 Framework Scaffold + Doors/Windows Source-Preserve Guard.
- Carried forward confirmed-safe v4.5.1.26 State Kernel shadow/action transcript features only.
- Carried forward confirmed-safe v4.5.1.26.1 action transcript binding, replace clarification resolution, multiline edit support, and source-preserve report-label cleanup only.
- v4.5.1.26.1 was not treated as the stable base.

## Files changed
- `app.py`
- `static/index.html`
- `static/assets/app.js` carried forward from v26.1 action-binding work; no new v26.2 frontend logic was added.
- `jarvis/core/state_kernel.py` carried forward from v26 shadow mode.
- `docs/KNOWN_ISSUES.md`
- `START_JARVIS_v4_5_1_26_2.bat`
- `START_JARVIS_v4_5_1_26_2_SIMPLE_NO_VENV.bat`
- `JARVIS_v4_5_1_26_2_CHANGE_REPORT.md`
- `JARVIS_v4_5_1_26_2_TEST_REPORT.md`

## Exact functions changed in app.py
- `APP_VERSION`
- Added `_truncate_zone_value_instruction_tail()`
- `_parse_chained_zone_value_phrases()`
- `parse_dynamic_zone_values_from_prompt()`
- `is_active_builder_plan_amendment()`
- Added `_is_builder_combined_count_or_unit_confirmation()`
- `_is_builder_count_or_unit_confirmation()`
- `_apply_builder_count_or_unit_confirmation_to_plan()`
- `_resolve_replace_target_unclear_confirmation()`
- `api_route()` builder-plan response message surfacing

## Fixes

### 1. Zone parser stopword / instruction boundary fix
Input:

```text
Zone 1: Old and New
Zone 2: External and Internal
Use Head 2 for Zone 1 and Head 3 for Zone 2
```

Expected output is now:

```text
Zone 1: Old, New
Zone 2: External, Internal
```

The parser now stops before newline instruction boundaries including:

```text
Use Head
Start at Head
Levels
Preview
Review
```

It does not globally strip the word `Use`, so valid values like `Mixed Use` remain possible.

### 2. Multiline active Builder edit router fix
`is_active_builder_plan_amendment()` now passes the raw prompt into `_is_builder_count_or_unit_confirmation()` so this message stays in Builder context:

```text
Use Count
Unit no
```

Expected result:

```text
Function = XGETCOUNT
Unit = no
No Local AI fallback
```

Added narrow active-context same-line support for:

```text
use count unit no
use xgetcount unit no
use steel surface area unit m2
```

### 3. Replace clarification reply improvement
For:

```text
Change Zone 1: Old to Toad
Confirm replace Zone 1: Old with Toad
```

Expected result:

```text
Zone 1: Toad, New
Reply: Replaced Zone 1: Old with Toad.
```

## What was not touched
- Builder formula/export engine core
- CostX formula generation
- Formula Integrity Guard core logic
- Doors/Windows source-preserve row generation
- Wall/Steel output logic
- Mezz alias guard
- Output Center
- Formatter
- QA Checker
- Major UI redesign

## Rollback notes
Rollback to the accepted v4.5.1.25 ZIP if v26.2 introduces any unexpected Builder output issue. v26.1 is still not promoted as a stable base until v26.2 passes real-user regression.

from __future__ import annotations

import json
import os
import re
import socket
import threading
import uuid
import zipfile
import shutil
import urllib.error
import urllib.request
import traceback
from copy import copy
from itertools import product
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar
from typing import Any, Dict, List, Optional, Tuple

import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent
SETTINGS_DIR = ROOT / "05_Settings"
INPUT_DIR = ROOT / "01_Input_Files"
OUTPUT_DIR = ROOT / "02_Output_Files"
BUILDER_OUTPUT_DIR = OUTPUT_DIR / "Builder"
JOBS_DIR = ROOT / "03_Jobs"
BACKUP_DIR = ROOT / "08_Backups"
LOG_DIR = ROOT / "logs"
STATIC_DIR = ROOT / "static"

QA_TEST_PACK_DIR = SETTINGS_DIR / "qa_test_packs"
DATA_DIR = ROOT / "data"
STATE_SHADOW_DIR = DATA_DIR / "state_shadow"

for folder in [INPUT_DIR, OUTPUT_DIR, BUILDER_OUTPUT_DIR, JOBS_DIR, BACKUP_DIR, LOG_DIR, SETTINGS_DIR, QA_TEST_PACK_DIR, DATA_DIR, STATE_SHADOW_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

APP_VERSION = "v4.5.1.26.2 Zone Parser Stopword + Multiline Active Edit Router Fix"
MISTAKE_MEMORY_FILE = SETTINGS_DIR / "mistake_memory.json"
BUILDER_LEVEL_ZONE_FILE = SETTINGS_DIR / "builder_level_zone_setup.json"
BUILDER_TRADE_PROFILE_FILE = SETTINGS_DIR / "builder_trade_profiles.json"

app = FastAPI(title="Dhanrick Jarvis", version=APP_VERSION)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


class RouteRequest(BaseModel):
    prompt: str
    mode: str = "Ask First"
    has_file: bool = False
    pending_clarification: Optional[Dict[str, Any]] = None
    active_builder_plan: Optional[Dict[str, Any]] = None


class ChatTraceRequest(BaseModel):
    role: str = "user"
    text: str = ""
    event_id: str = ""
    message_id: str = ""
    meta: str = ""
    attachments: Optional[List[Dict[str, Any]]] = None
    active_task: Optional[Dict[str, Any]] = None
    pending_clarification_type: str = ""
    route_prompt: str = ""
    source: str = "ui"
    ui_action: str = ""
    client_action_id: str = ""


class ConversationCreateRequest(BaseModel):
    project: str = ""
    title: str = ""


class ConversationEventRequest(BaseModel):
    role: str = "user"
    text: str = ""
    event_id: str = ""
    message_id: str = ""
    project: str = ""
    meta: str = ""
    attachments: Optional[List[Dict[str, Any]]] = None
    active_task: Optional[Dict[str, Any]] = None
    pending_clarification_type: str = ""
    source: str = "ui"
    ui_action: str = ""
    client_action_id: str = ""


class ConversationPatchRequest(BaseModel):
    title: Optional[str] = None
    project: Optional[str] = None
    archived: Optional[bool] = None
    active_task: Optional[Dict[str, Any]] = None


class FormatterRunRequest(BaseModel):
    input_file: str
    output_prefix: Optional[str] = None
    profile_key: Optional[str] = None


class BuilderRunRequest(BaseModel):
    input_file: str
    output_prefix: Optional[str] = None
    builder_levels: Optional[List[Dict[str, Any]]] = None
    current_work_setup: Optional[Dict[str, Any]] = None
    active_categories: Optional[List[Dict[str, Any]]] = None
    zone_library: Optional[List[Dict[str, Any]]] = None
    zone_combos: Optional[List[Dict[str, Any]]] = None
    active_combo_id: Optional[str] = None
    zone_token_mode: Optional[str] = None
    builder_run_snapshot: Optional[Dict[str, Any]] = None
    ui_action: str = ""
    client_action_id: str = ""
    conversation_id: str = ""
    active_task_status_before: str = ""


class BuilderLevelZoneSaveRequest(BaseModel):
    levels: List[Dict[str, Any]]
    preset_name: str = "Active"
    zone_library: Optional[List[Dict[str, Any]]] = None
    active_categories: Optional[List[Dict[str, Any]]] = None
    zone_combos: Optional[List[Dict[str, Any]]] = None
    active_combo_id: Optional[str] = None
    current_work_setup: Optional[Dict[str, Any]] = None
    trade_profiles: Optional[List[Dict[str, Any]]] = None


class BuilderCurrentWorkSaveRequest(BaseModel):
    current_work_setup: Dict[str, Any]
    active_combo_id: Optional[str] = None
    active_categories: Optional[List[Dict[str, Any]]] = None


class ToolJobStartRequest(BaseModel):
    tool_key: str
    input_file: Optional[str] = None
    prompt: str = ""
    mode: str = "Ask First"
    output_prefix: Optional[str] = None
    profile_key: Optional[str] = None
    builder_levels: Optional[List[Dict[str, Any]]] = None
    current_work_setup: Optional[Dict[str, Any]] = None
    active_categories: Optional[List[Dict[str, Any]]] = None
    zone_library: Optional[List[Dict[str, Any]]] = None
    zone_combos: Optional[List[Dict[str, Any]]] = None
    active_combo_id: Optional[str] = None
    zone_token_mode: Optional[str] = None
    builder_run_snapshot: Optional[Dict[str, Any]] = None
    ui_action: str = ""
    client_action_id: str = ""
    conversation_id: str = ""
    active_task_status_before: str = ""


class FormatterProfileSaveRequest(BaseModel):
    profile_key: str
    display_name: str = ""
    description: str = ""
    protected_upper_text: str = ""
    protected_exact_text: str = ""
    proper_phrases_text: str = ""
    slash_words_text: str = ""
    set_active: bool = True


class FormatterProfileActiveRequest(BaseModel):
    profile_key: str

class LocalAIAnalyzeRequest(BaseModel):
    input_file: str
    profile_key: Optional[str] = None
    model: Optional[str] = None
    prompt: str = ""
    max_rows: int = 140


class LocalAIProfileDraftRequest(BaseModel):
    input_file: str
    profile_key: Optional[str] = None
    model: Optional[str] = None
    prompt: str = ""
    max_rows: int = 140


class LocalAIProfileApplyRequest(BaseModel):
    analysis_file: str
    approval_id: str
    profile_key: str = "ai_learned_qs_format"
    display_name: str = "AI Learned QS Format"


class FeedbackPreviewRequest(BaseModel):
    feedback_text: str
    profile_key: Optional[str] = None


class FeedbackApplyRequest(BaseModel):
    feedback_text: str
    approval_id: str
    profile_key: Optional[str] = None


class TermLibraryScanRequest(BaseModel):
    text: str = ""


class TermLibraryClarifyRequest(BaseModel):
    term: str
    action: str = "exact"
    value: str = ""
    note: str = ""
    typed_confirmation: str = ""

class ClientLayoutAnalyzeRequest(BaseModel):
    input_file: str
    profile_key: Optional[str] = None
    max_rows: int = 250


class ClientLayoutApplyRequest(BaseModel):
    input_file: str
    profile_key: Optional[str] = None
    typed_confirmation: str = ""
    max_rows: int = 250


class SampleFormatAnalyzeRequest(BaseModel):
    raw_file: str
    sample_file: str
    profile_key: Optional[str] = None
    max_rows: int = 250


class SampleFormatLearnRequest(BaseModel):
    raw_file: str
    sample_file: str
    profile_key: Optional[str] = None
    typed_confirmation: str = ""
    max_rows: int = 250



class CorrectionPreviewRequest(BaseModel):
    feedback_text: str
    output_file: Optional[str] = None
    raw_file: Optional[str] = None
    sample_file: Optional[str] = None
    profile_key: Optional[str] = None


class CorrectionApplyRequest(BaseModel):
    feedback_text: str
    output_file: Optional[str] = None
    raw_file: Optional[str] = None
    sample_file: Optional[str] = None
    profile_key: Optional[str] = None
    typed_confirmation: str = ""
    rerun_after_apply: bool = False


class OutputCleanupRequest(BaseModel):
    cleanup_type: str = "archive_old_outputs"
    keep_latest: int = 3


class BugStatusUpdateRequest(BaseModel):
    status: str = "pending"
    note: str = ""


class SafeLogCleanupRequest(BaseModel):
    action: str = "preview"
    keep_latest_debug_reports: int = 5
    keep_latest_event_lines: int = 1500


class QALabRunRequest(BaseModel):
    test_pack: str = "smoke"
    include_recent_logs: bool = True


class QATestPackImportRequest(BaseModel):
    pack_text: str
    pack_name: Optional[str] = None
    run_after_import: bool = False


class QAGeneratedTestPackRequest(BaseModel):
    category: str = "mixed"
    count: int = 25
    provider: str = "local_builtin"
    model: Optional[str] = None
    save_pack: bool = True


class QAImportedRunRequest(BaseModel):
    pack_file: str
    include_recent_logs: bool = True



class BackupCreateRequest(BaseModel):
    reason: str = "Manual safety backup"
    include_jobs: bool = True
    include_outputs: bool = False
    include_inputs: bool = False


class ApprovalRequestCreate(BaseModel):
    action_key: str
    description: str = ""
    risk_level: int = 4
    target: str = ""


class ApprovalDecisionRequest(BaseModel):
    approval_id: str
    decision: str
    typed_confirmation: str = ""


class BackupRestoreRequest(BaseModel):
    backup_file: str
    target_file: str = "formatter_profiles.json"
    approval_id: str


JOB_LOCK = threading.Lock()
JOB_EXECUTOR = ThreadPoolExecutor(max_workers=2)
JOBS: Dict[str, Dict[str, Any]] = {}
FORMATTER_PROFILE_CONTEXT: ContextVar[Optional[Dict[str, Any]]] = ContextVar("formatter_profile", default=None)
BOQ_CASE_CONTEXT: ContextVar[Optional[Dict[str, Any]]] = ContextVar("boq_case_dictionary", default=None)

LOCAL_AI_EXPORT_DIR = OUTPUT_DIR / "AI_Exports"
LOCAL_AI_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
DEBUG_REPORT_DIR = OUTPUT_DIR / "Jarvis_Debug_Reports"
DEBUG_REPORT_DIR.mkdir(parents=True, exist_ok=True)
CHAT_TRANSCRIPT_FILE = LOG_DIR / "jarvis_visible_chat.jsonl"
CONVERSATIONS_FILE = LOG_DIR / "jarvis_conversations.json"
QA_REPORT_DIR = OUTPUT_DIR / "Jarvis_QA_Reports"
QA_REPORT_DIR.mkdir(parents=True, exist_ok=True)
BUG_STATUS_FILE = SETTINGS_DIR / "bug_status_register.json"
LOG_ARCHIVE_DIR = LOG_DIR / "Archive"
LOG_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)



def read_json(name: str, default: Any) -> Any:
    path = SETTINGS_DIR / name
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"error": f"Could not read {name}: {exc}"}


def write_log(event: str, payload: Dict[str, Any]) -> None:
    line = json.dumps({
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "event": event,
        "payload": payload,
    }, ensure_ascii=False)
    with (LOG_DIR / "jarvis_events.jsonl").open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def read_recent_events(limit: int = 300) -> List[Dict[str, Any]]:
    log_path = LOG_DIR / "jarvis_events.jsonl"
    if not log_path.exists():
        return []
    try:
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-max(1, limit):]
    except Exception:
        return []
    events: List[Dict[str, Any]] = []
    for line in lines:
        try:
            events.append(json.loads(line))
        except Exception:
            events.append({"timestamp": "", "event": "unreadable_log_line", "payload": {"raw": line[:1000]}})
    return events


def read_recent_chat_trace(limit: int = 120) -> List[Dict[str, Any]]:
    if not CHAT_TRANSCRIPT_FILE.exists():
        return []
    try:
        lines = CHAT_TRANSCRIPT_FILE.read_text(encoding="utf-8", errors="replace").splitlines()[-max(1, limit):]
    except Exception:
        return []
    rows: List[Dict[str, Any]] = []
    for line in lines:
        try:
            rows.append(json.loads(line))
        except Exception:
            rows.append({"timestamp": "", "role": "system", "text": line[:1000], "unreadable": True})
    return rows


def _shadow_sanitize(value: Any, depth: int = 0) -> Any:
    """Small JSON-safe sanitizer for v4.5.1.26 shadow-state snapshots.

    Shadow mode is diagnostic only. It records enough metadata to replay state
    decisions without storing workbook contents or large payloads.
    """
    if depth > 5:
        return "[max_depth]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:1200]
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for k, v in list(value.items())[:80]:
            key = str(k)[:120]
            if key.lower() in {"html", "preview_rows"}:
                continue
            out[key] = _shadow_sanitize(v, depth + 1)
        return out
    if isinstance(value, (list, tuple)):
        return [_shadow_sanitize(v, depth + 1) for v in list(value)[:80]]
    return str(value)[:1200]


def write_state_shadow_snapshot(kind: str, conversation_id: str = "", payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Write a diagnostic-only State Kernel shadow snapshot.

    v4.5.1.26 does not make this the source of truth. It mirrors current app.py
    runtime state so future migrations can compare actual behavior safely.
    """
    try:
        kind_clean = re.sub(r"[^a-z0-9_\-]+", "_", str(kind or "state").lower()).strip("_")[:80] or "state"
        conv_clean = re.sub(r"[^A-Za-z0-9_\-]+", "_", str(conversation_id or "global")).strip("_")[:100] or "global"
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        folder = STATE_SHADOW_DIR / kind_clean
        folder.mkdir(parents=True, exist_ok=True)
        snapshot = {
            "app_version": APP_VERSION,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "kind": kind_clean,
            "conversation_id": conversation_id or "",
            "shadow_mode": True,
            "source_of_truth": "app.py runtime",
            "payload": _shadow_sanitize(payload or {}),
        }
        path = folder / f"{stamp}_{conv_clean}.json"
        path.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        latest = STATE_SHADOW_DIR / "latest_state_shadow_snapshot.json"
        latest.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        return {"ok": True, "path": str(path), "kind": kind_clean, "conversation_id": conversation_id or ""}
    except Exception as exc:
        # Never block runtime work because of shadow logging.
        try:
            write_log("state_shadow_snapshot_failed", {"kind": str(kind), "conversation_id": str(conversation_id), "error": str(exc)})
        except Exception:
            pass
        return {"ok": False, "error": str(exc)}


def latest_state_shadow_payload(limit: int = 12) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    try:
        for path in sorted(STATE_SHADOW_DIR.rglob("*.json"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True):
            if path.name == "latest_state_shadow_snapshot.json":
                continue
            try:
                rows.append(json.loads(path.read_text(encoding="utf-8", errors="replace")))
            except Exception:
                rows.append({"file": path.name, "load_error": True})
            if len(rows) >= max(1, min(int(limit or 12), 50)):
                break
    except Exception as exc:
        return {"app_version": APP_VERSION, "error": str(exc), "items": []}
    latest = {}
    latest_path = STATE_SHADOW_DIR / "latest_state_shadow_snapshot.json"
    if latest_path.exists():
        try:
            latest = json.loads(latest_path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            latest = {"load_error": True}
    return {"app_version": APP_VERSION, "generated_at": datetime.now().isoformat(timespec="seconds"), "latest": latest, "items": rows}


def write_visible_chat_event(payload: Dict[str, Any]) -> None:
    safe = dict(payload or {})
    # Keep the transcript useful but safe: filenames/chips are allowed; workbook contents are not logged.
    safe["text"] = str(safe.get("text") or "")[:1500]
    attachments = safe.get("attachments") if isinstance(safe.get("attachments"), list) else []
    safe["attachments"] = [
        {
            "filename": str((a or {}).get("filename") or (a or {}).get("saved_name") or (a or {}).get("name") or "")[:240],
            "file_type": str((a or {}).get("file_type") or (a or {}).get("type") or "")[:80],
            "is_workbook": bool((a or {}).get("is_workbook")),
        }
        for a in attachments[:6] if isinstance(a, dict)
    ]
    if not safe["attachments"] and _conversation_is_utility_status_message(str(safe.get("role") or ""), str(safe.get("text") or ""), str(safe.get("meta") or "")):
        return
    line = json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), **safe}, ensure_ascii=False, default=str)
    with CHAT_TRANSCRIPT_FILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")
    if str(safe.get("meta") or "") in {"ui_action", "export", "preview"} or str(safe.get("source") or "") == "jarvis_ui_action":
        write_state_shadow_snapshot("visible_chat_event", str(safe.get("conversation_id") or ""), safe)


@app.post("/api/chat/event")
def api_chat_event(req: ChatTraceRequest) -> Dict[str, Any]:
    payload = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    write_visible_chat_event(payload)
    return {"ok": True}


# v4.5.1.14 conversation/session store -------------------------------------------------
def _conversation_store_read() -> Dict[str, Any]:
    if not CONVERSATIONS_FILE.exists():
        return {"version": 1, "conversations": []}
    try:
        data = json.loads(CONVERSATIONS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"version": 1, "conversations": []}
        data.setdefault("conversations", [])
        return _conversation_compact_store(data)
    except Exception:
        return {"version": 1, "conversations": []}


def _conversation_store_write(data: Dict[str, Any]) -> None:
    safe = _conversation_compact_store(data if isinstance(data, dict) else {"version": 1, "conversations": []})
    safe.setdefault("version", 1)
    safe.setdefault("conversations", [])
    tmp = CONVERSATIONS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(safe, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    tmp.replace(CONVERSATIONS_FILE)


def _conversation_clean_attachments(attachments: Any) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not isinstance(attachments, list):
        return rows
    for a in attachments[:8]:
        if not isinstance(a, dict):
            continue
        rows.append({
            "filename": str(a.get("filename") or a.get("saved_name") or a.get("name") or "")[:240],
            "saved_name": str(a.get("saved_name") or a.get("filename") or a.get("name") or "")[:240],
            "file_type": str(a.get("file_type") or a.get("type") or "")[:80],
            "is_workbook": bool(a.get("is_workbook") or str(a.get("filename") or a.get("saved_name") or "").lower().endswith((".xlsx", ".xlsm", ".xls"))),
        })
    return rows



def _conversation_clean_project_name(value: str) -> str:
    name = re.sub(r"\s+", " ", str(value or "")).strip(" \t\r\n:=-–—,.;")
    name = re.sub(r"\b(?:please|pls|thanks|thank you|workbook|excel|file|attach|attached|when ready)\b.*$", "", name, flags=re.I).strip(" \t\r\n:=-–—,.;")
    # Keep short project codes such as SNSW G25, but avoid capturing full sentences.
    words = name.split()
    if len(words) > 8:
        name = " ".join(words[:8]).strip()
    return name[:120]


def _conversation_extract_project_name(text: str) -> str:
    """Small project-memory extractor for conversation storage.

    This intentionally captures only explicit project naming patterns so Jarvis
    does not guess project names from normal questions. Examples it should catch:
    - "Create me a BOQ for SNSW project"
    - "Project name: SNWS G25"
    - "Project is SNWS G25"
    """
    raw = str(text or "").strip()
    if not raw:
        return ""
    low = raw.lower().strip()
    if re.search(r"\b(what|which|where|who|how)\b.*\bproject\b", low) or low.endswith("?"):
        return ""
    patterns = [
        r"^\s*project\s*(?:name|title|no\.?|number)?\s*[:=\-–—]\s*(.+?)\s*$",
        r"^\s*(?:project\s+is|project\s+name\s+is|project\s+title\s+is)\s+(.+?)\s*$",
        r"\bfor\s+([A-Za-z0-9][A-Za-z0-9 &._/\-]{1,80}?)\s+project\b",
        r"\bproject\s*(?:name|title)?\s+(?:as|to)\s+([A-Za-z0-9][A-Za-z0-9 &._/\-]{1,80})\b",
    ]
    for pat in patterns:
        m = re.search(pat, raw, flags=re.I)
        if m:
            return _conversation_clean_project_name(m.group(1))
    return ""


def _conversation_project_question(text: str) -> bool:
    t = _router_text(text)
    return bool(re.search(r"\b(what|which)\b.*\bproject\b|\bproject\b.*\b(are we|current|saved)\b", t))


def _conversation_remember_project_detail(conv: Dict[str, Any], msg: Dict[str, Any], detected_project: str = "") -> None:
    role = str(msg.get("role") or "").lower()
    if role != "user":
        return
    text = str(msg.get("text") or "").strip()
    if not text:
        return
    now = str(msg.get("timestamp") or datetime.now().isoformat(timespec="seconds"))
    ctx = conv.setdefault("project_context", {})
    if detected_project:
        ctx["project_name"] = detected_project
        ctx["last_project_name_source"] = text[:240]
        ctx["updated_at"] = now
    # v4.5.1.21: project/task memory should keep useful project details once
    # a project name or active task exists. This lets Resume recall details such
    # as Old/New zones, Internal/External, levels, and later workbook notes.
    active_task = conv.get("active_task") if isinstance(conv.get("active_task"), dict) else {}
    if conv.get("project") or detected_project or active_task:
        details = ctx.setdefault("recent_user_details", [])
        entry = {"timestamp": now, "text": text[:500]}
        if not details or details[-1].get("text") != entry["text"]:
            details.append(entry)
        ctx["recent_user_details"] = details[-60:]

def _conversation_has_active_task(conv: Dict[str, Any]) -> bool:
    task = conv.get("active_task") if isinstance(conv, dict) else None
    if not isinstance(task, dict) or not task:
        return False
    return str(task.get("status") or "").strip().lower() not in {"", "done", "cancelled", "completed"}


def _conversation_is_utility_status_message(role: str, text: str, meta: str = "") -> bool:
    """Return true for UI utility/status rows that should not pollute exports.

    v4.5.1.24.2F keeps normal user/assistant conversation useful by
    filtering support-log status rows and read-only review toast rows from
    debug/conversation exports. This does not remove real user commands.
    """
    role_l = str(role or "").strip().lower()
    if role_l not in {"assistant", "system"}:
        return False
    txt = re.sub(r"\s+", " ", str(text or "").strip()).lower().rstrip(".! ")
    meta_l = str(meta or "").strip().lower()
    support_statuses = {
        "support log ready",
        "support log ready to export",
        "support log exported",
        "debug log ready",
        "debug report ready",
    }
    if txt in support_statuses or (meta_l in {"support", "debug"} and "support log" in txt):
        return True
    review_statuses = {
        "review opened this is read-only use approve & preview when you’re ready, or edit in chat to change the setup",
        "review opened this is read-only use approve & preview when you're ready, or edit in chat to change the setup",
    }
    if txt in review_statuses or (meta_l == "review" and txt.startswith("review opened")):
        return True
    return False


def _conversation_compact_messages(messages: Any) -> List[Dict[str, Any]]:
    """Collapse accidental repeated assistant/status rows while preserving real user input.

    v4.5.1.20 fixes old recovered/debug chats that could contain hundreds of
    identical assistant rows such as "Support log ready.". User rows are not
    globally deduped because a user can intentionally repeat a command; only
    consecutive assistant/status duplicates with no attachments are collapsed.
    """
    rows = messages if isinstance(messages, list) else []
    cleaned: List[Dict[str, Any]] = []
    last_assistant_key = None
    duplicate_count = 0
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        role = str(raw.get("role") or "").strip().lower()
        text = str(raw.get("text") or "").strip()
        meta = str(raw.get("meta") or "").strip().lower()
        attachments = raw.get("attachments") if isinstance(raw.get("attachments"), list) else []
        if not attachments and _conversation_is_utility_status_message(role, text, meta):
            continue
        key = (role, text, meta, bool(attachments), str(raw.get("pending_clarification_type") or ""))
        if role in {"assistant", "system"} and not attachments and key == last_assistant_key:
            duplicate_count += 1
            if cleaned:
                cleaned[-1]["duplicate_count"] = int(cleaned[-1].get("duplicate_count") or 1) + 1
            continue
        duplicate_count = 0
        if role in {"assistant", "system"} and not attachments:
            last_assistant_key = key
        else:
            last_assistant_key = None
        cleaned.append(raw)
    return cleaned[-300:]


def _conversation_has_content(conv: Dict[str, Any]) -> bool:
    if not isinstance(conv, dict):
        return False
    messages = _conversation_compact_messages(conv.get("messages"))
    # v4.5.1.22: any real user text should keep the conversation visible.
    # Earlier builds hid greeting-only/new chats, which made Recents look empty
    # and prevented New Chat from being recorded after refresh. Assistant-only
    # helper/debug loops still stay hidden unless there is an active task/file.
    if any(isinstance(m, dict) and (m or {}).get("role") == "user" and str((m or {}).get("text") or "").strip() for m in messages):
        return True
    user_text = " ".join(str((m or {}).get("text") or "") for m in messages if isinstance(m, dict) and (m or {}).get("role") == "user")
    if _conversation_meaningful_text(user_text):
        return True
    if conv.get("attachments"):
        return True
    if _conversation_has_active_task(conv):
        return True
    return False


def _conversation_compact_store(data: Dict[str, Any]) -> Dict[str, Any]:
    """Dedupe malformed conversation rows without deleting real chat content.

    v4.5.1.16 keeps Recents stable by ensuring one row per conversation id.
    If duplicate ids exist, the most recently updated shell wins while messages and
    attachments are merged by id/name. Empty New Chat placeholders are hidden from
    the sidebar, but not aggressively deleted from disk.
    """
    safe = data if isinstance(data, dict) else {"version": 1, "conversations": []}
    safe.setdefault("version", 1)
    rows = safe.get("conversations") if isinstance(safe.get("conversations"), list) else []
    by_id: Dict[str, Dict[str, Any]] = {}
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        cid = str(raw.get("id") or "").strip()
        if not cid:
            continue
        raw["messages"] = _conversation_compact_messages(raw.get("messages"))
        if cid not in by_id:
            by_id[cid] = raw
            continue
        current = by_id[cid]
        # Use latest shell metadata, but preserve all unique messages/attachments.
        latest, older = (raw, current) if str(raw.get("updated_at") or "") >= str(current.get("updated_at") or "") else (current, raw)
        msg_seen = set()
        merged_msgs = []
        for m in (older.get("messages") or []) + (latest.get("messages") or []):
            if not isinstance(m, dict):
                continue
            mid = str(m.get("id") or f"{m.get('timestamp')}|{m.get('role')}|{m.get('text')}")
            if mid in msg_seen:
                continue
            msg_seen.add(mid)
            merged_msgs.append(m)
        att_seen = set()
        merged_att = []
        for a in (older.get("attachments") or []) + (latest.get("attachments") or []):
            if not isinstance(a, dict):
                continue
            key = str(a.get("saved_name") or a.get("filename") or a.get("name") or "")
            if key in att_seen:
                continue
            att_seen.add(key)
            merged_att.append(a)
        latest["messages"] = _conversation_compact_messages(merged_msgs)
        latest["attachments"] = merged_att[-40:]
        # Build 1 stability: keep dedupe ids when duplicate conversation shells are compacted.
        # Otherwise a stale shell merge can forget recent client event ids and allow
        # retry/double-click events to be saved again after the next store write.
        merged_ids = []
        seen_ids = set()
        for eid in (older.get("event_ids") or []) + (latest.get("event_ids") or []):
            val = str(eid or "").strip()
            if val and val not in seen_ids:
                seen_ids.add(val)
                merged_ids.append(val)
        latest["event_ids"] = merged_ids[-500:]
        by_id[cid] = latest
    safe["conversations"] = list(by_id.values())
    return safe


def _conversation_meaningful_text(text: str) -> bool:
    t = _router_text(text)
    return bool(t) and t not in {"hi", "hello", "hey", "jarvis", "good day", "good morning", "good evening", "good night", "thanks", "thank you"}


def _conversation_title_from_context(conv: Dict[str, Any]) -> Dict[str, str]:
    messages = conv.get("messages") if isinstance(conv.get("messages"), list) else []
    user_text = " ".join(str(m.get("text") or "") for m in messages if (m or {}).get("role") == "user")
    active_task = conv.get("active_task") if isinstance(conv.get("active_task"), dict) else {}
    task_txt = " ".join(str(v) for v in [active_task.get("type"), active_task.get("prompt"), active_task.get("original_prompt")] if v)
    t = _router_text(typo_normalize_prompt(user_text + " " + task_txt))
    if not _conversation_meaningful_text(t):
        return {"title": conv.get("title") or "New chat", "status": "temporary"}
    if re.search(r"\bwindow|windows\b", t) and ("boq" in t or "base sheet" in t):
        return {"title": "Window BOQ setup", "status": "final"}
    if re.search(r"\bdoor|doors\b", t) and ("boq" in t or "base sheet" in t):
        return {"title": "Door BOQ setup", "status": "final"}
    if re.search(r"\bsteel|metalwork\b", t) and ("boq" in t or "base sheet" in t):
        return {"title": "Steel base sheet setup", "status": "final"}
    if re.search(r"\bcompare|comparison|discrep", t):
        return {"title": "BOQ comparison check", "status": "final"}
    if re.search(r"\bformat|formatter|style\b", t):
        return {"title": "QS workbook formatting", "status": "final"}
    if re.search(r"\bpanic|qa lab|release gate\b", t):
        return {"title": "QA Lab run", "status": "final"}
    if re.search(r"\bhealth\b", t):
        return {"title": "Jarvis health check", "status": "final"}
    if re.search(r"\bdebug report|support log\b", t):
        return {"title": "Jarvis support log", "status": "final"}
    if "boq" in t or "base sheet" in t:
        return {"title": "BOQ setup", "status": "temporary" if len(messages) < 3 else "final"}
    words = [w for w in re.sub(r"[^a-z0-9\s]", " ", t).split() if w][:5]
    if words:
        return {"title": " ".join(words).title(), "status": "temporary"}
    return {"title": conv.get("title") or "New chat", "status": "temporary"}


def _conversation_touch_title(conv: Dict[str, Any]) -> None:
    if conv.get("title_status") == "manual" or conv.get("title_locked"):
        return
    if conv.get("title_status") == "final":
        conv["title_locked"] = True
        return
    generated = _conversation_title_from_context(conv)
    title = str(generated.get("title") or "").strip()
    if not title:
        return
    status = generated.get("status") or "temporary"
    current_title = str(conv.get("title") or "").strip().lower()
    placeholder = current_title in {"", "new chat", "recovered chat", "conversation"}
    meaningful = _conversation_meaningful_text(" ".join(str(m.get("text") or "") for m in (conv.get("messages") or []) if isinstance(m, dict) and m.get("role") == "user"))
    if not meaningful:
        # v4.5.1.22: keep greeting/new chats visible with a stable temporary title,
        # but do not lock/rename them until a meaningful task appears.
        if placeholder:
            conv["title"] = title or "New chat"
            conv["title_status"] = "temporary"
        return
    # v4.5.1.16: lock the first meaningful auto-title so Recents stop changing
    # from "Jarvis help me" -> "Jarvis help me hi" -> etc. Manual rename still works.
    if placeholder or conv.get("title_status") in {"", None, "temporary"}:
        conv["title"] = title
        conv["title_status"] = "final" if status == "final" else "auto_locked"
        conv["title_locked"] = True
        conv["auto_rename_used"] = True
    return


def _conversation_public(conv: Dict[str, Any], include_messages: bool = False) -> Dict[str, Any]:
    compact_messages = _conversation_compact_messages(conv.get("messages"))
    has_unfinished = _conversation_has_active_task(conv)
    out = {
        "id": conv.get("id"),
        "title": conv.get("title") or "New chat",
        "title_status": conv.get("title_status") or "temporary",
        "project": conv.get("project") or "",
        "project_context": conv.get("project_context") or {},
        "created_at": conv.get("created_at") or "",
        "updated_at": conv.get("updated_at") or "",
        "archived": bool(conv.get("archived")),
        "active_task": conv.get("active_task") or None,
        "has_unfinished_task": has_unfinished,
        "has_meaningful_content": _conversation_has_content({**conv, "messages": compact_messages}),
        "is_debug_only": (not _conversation_has_content({**conv, "messages": compact_messages}) and bool(compact_messages)),
        "attachments": conv.get("attachments") or [],
        "message_count": len(compact_messages),
    }
    if include_messages:
        out["messages"] = compact_messages
    return out


@app.post("/api/conversations")
def api_conversation_create(req: ConversationCreateRequest) -> Dict[str, Any]:
    data = _conversation_store_read()
    now = datetime.now().isoformat(timespec="seconds")
    cid = f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    conv = {
        "id": cid,
        "title": str(req.title or "New chat")[:120],
        "title_status": "temporary",
        "auto_rename_used": False,
        "title_locked": False,
        "project": str(req.project or "")[:120],
        "created_at": now,
        "updated_at": now,
        "archived": False,
        "messages": [],
        "attachments": [],
        "active_task": None,
        "outputs": [],
    }
    data["conversations"].append(conv)
    _conversation_store_write(data)
    write_log("conversation_created", {"conversation_id": cid, "project": conv["project"]})
    return {"conversation": _conversation_public(conv, include_messages=True)}


@app.get("/api/conversations")
def api_conversations(limit: int = 60, include_archived: bool = False) -> Dict[str, Any]:
    data = _conversation_store_read()
    rows = [c for c in data.get("conversations", []) if (include_archived or not c.get("archived")) and _conversation_has_content(c)]
    rows.sort(key=lambda c: str(c.get("updated_at") or c.get("created_at") or ""), reverse=True)
    public = [_conversation_public(c, include_messages=False) for c in rows[:max(1, min(limit, 200))]]
    projects: Dict[str, List[Dict[str, Any]]] = {}
    for c in public:
        project = c.get("project") or ""
        if project:
            projects.setdefault(project, []).append(c)
    return {"version": APP_VERSION, "conversations": public, "projects": projects}


@app.get("/api/conversations/{conversation_id}")
def api_conversation_get(conversation_id: str) -> Dict[str, Any]:
    data = _conversation_store_read()
    for conv in data.get("conversations", []):
        if conv.get("id") == conversation_id:
            return {"conversation": _conversation_public(conv, include_messages=True)}
    raise HTTPException(status_code=404, detail="Conversation not found")


@app.post("/api/conversations/{conversation_id}/event")
def api_conversation_event(conversation_id: str, req: ConversationEventRequest) -> Dict[str, Any]:
    data = _conversation_store_read()
    now = datetime.now().isoformat(timespec="seconds")
    payload = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    attachments = _conversation_clean_attachments(payload.get("attachments"))
    role_clean = str(payload.get("role") or "user").strip().lower()
    active_task_payload = payload.get("active_task") if isinstance(payload.get("active_task"), dict) else None
    event_id = str(payload.get("event_id") or payload.get("message_id") or "").strip()[:160]
    detected_project = _conversation_extract_project_name(str(payload.get("text") or ""))
    explicit_project = _conversation_clean_project_name(str(payload.get("project") or ""))
    conv = next((c for c in data.get("conversations", []) if c.get("id") == conversation_id), None)
    if not conv:
        # v4.5.1.20: do not create hidden recovered chats from assistant-only helper
        # statuses such as repeated support-log notices. User/file/task events may
        # still recover a minimal conversation so real work is not lost.
        if role_clean != "user" and not attachments and not active_task_payload:
            write_log("conversation_missing_event_ignored", {"conversation_id": conversation_id, "role": role_clean, "meta": str(payload.get("meta") or "")[:120]})
            return {"ignored": True, "reason": "assistant_only_missing_conversation", "conversation": {"id": conversation_id, "has_meaningful_content": False, "message_count": 0}, "message": None}
        conv = {
            "id": conversation_id,
            "title": "Recovered chat",
            "title_status": "temporary",
            "auto_rename_used": False,
            "project": "",
            "created_at": now,
            "updated_at": now,
            "archived": False,
            "messages": [],
            "attachments": [],
            "active_task": None,
            "outputs": [],
            "recovered_from_missing_id": True,
        }
        data.setdefault("conversations", []).append(conv)
        write_log("conversation_recovered_missing", {"conversation_id": conversation_id, "reason": "event_post_to_missing_conversation"})
    # v4.5.1.20: event idempotency guard. Browser retries, refresh races, or
    # duplicate click handlers must not create repeated saved messages.
    if event_id:
        seen_event_ids = set(str(x) for x in (conv.get("event_ids") if isinstance(conv.get("event_ids"), list) else []))
        if event_id in seen_event_ids:
            return {"ok": True, "deduped": True, "conversation": _conversation_public(conv, include_messages=False), "message": None}
    if explicit_project and (not conv.get("project") or explicit_project != conv.get("project")):
        conv["project"] = explicit_project
        conv.setdefault("project_context", {})["project_name"] = explicit_project
    if detected_project and (not conv.get("project") or re.match(r"^\s*project\s*(name|title|no\.?|number)?\s*[:=\-–—]", str(payload.get("text") or ""), flags=re.I)):
        conv["project"] = detected_project
        conv.setdefault("project_context", {})["project_name"] = detected_project
    if isinstance(active_task_payload, dict) and conv.get("project"):
        active_task_payload.setdefault("project", conv.get("project"))
        active_task_payload.setdefault("project_name", conv.get("project"))
    if conv.get("project") and isinstance(conv.get("active_task"), dict):
        conv["active_task"]["project"] = conv.get("project")
        conv["active_task"]["project_name"] = conv.get("project")
    # v4.5.1.22: safety dedupe for repeated click handlers that reuse different
    # event ids but send the exact same visible assistant/user message.
    text_fingerprint = str(payload.get("text") or "").strip()[:4000]
    meta_fingerprint = str(payload.get("meta") or "").strip()[:160]
    if not attachments and text_fingerprint:
        for prev in reversed(conv.get("messages") or []):
            if not isinstance(prev, dict):
                continue
            if str(prev.get("role") or "").strip().lower() != role_clean:
                break
            if str(prev.get("text") or "").strip() == text_fingerprint and str(prev.get("meta") or "").strip() == meta_fingerprint:
                if event_id:
                    ids = conv.setdefault("event_ids", [])
                    if event_id not in ids:
                        ids.append(event_id)
                    conv["event_ids"] = ids[-500:]
                    _conversation_store_write(data)
                return {"ok": True, "deduped": True, "reason": "same_visible_message", "conversation": _conversation_public(conv, include_messages=False), "message": None}
            break
    msg = {
        "id": event_id or f"msg_{uuid.uuid4().hex[:10]}",
        "timestamp": now,
        "role": str(payload.get("role") or "user")[:40],
        "text": str(payload.get("text") or "")[:4000],
        "meta": str(payload.get("meta") or "")[:160],
        "attachments": attachments,
        "pending_clarification_type": str(payload.get("pending_clarification_type") or "")[:120],
        "source": str(payload.get("source") or "ui")[:80],
    }
    conv.setdefault("messages", []).append(msg)
    conv["messages"] = conv.get("messages", [])[-300:]
    if isinstance(active_task_payload, dict) and active_task_payload:
        conv["active_task"] = active_task_payload
    _conversation_remember_project_detail(conv, msg, detected_project or explicit_project)
    if event_id:
        ids = conv.setdefault("event_ids", [])
        if event_id not in ids:
            ids.append(event_id)
        conv["event_ids"] = ids[-500:]
    for a in attachments:
        if a and a not in conv.setdefault("attachments", []):
            conv.setdefault("attachments", []).append(a)
    conv["updated_at"] = now
    _conversation_touch_title(conv)
    _conversation_store_write(data)
    write_state_shadow_snapshot("conversation_event", conversation_id, {
        "role": msg.get("role"),
        "text": msg.get("text"),
        "meta": msg.get("meta"),
        "source": msg.get("source"),
        "ui_action": str(payload.get("ui_action") or ""),
        "client_action_id": str(payload.get("client_action_id") or ""),
        "active_task": conv.get("active_task"),
        "attachments": attachments,
    })
    return {"conversation": _conversation_public(conv, include_messages=False), "message": msg}


@app.patch("/api/conversations/{conversation_id}")
def api_conversation_patch(conversation_id: str, req: ConversationPatchRequest) -> Dict[str, Any]:
    data = _conversation_store_read()
    conv = next((c for c in data.get("conversations", []) if c.get("id") == conversation_id), None)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    if req.title is not None:
        conv["title"] = str(req.title or "New chat")[:120]
        conv["title_status"] = "manual"
        conv["title_locked"] = True
    if req.project is not None:
        conv["project"] = str(req.project or "")[:120]
        if conv["project"]:
            conv.setdefault("project_context", {})["project_name"] = conv["project"]
            conv.setdefault("project_context", {})["updated_at"] = datetime.now().isoformat(timespec="seconds")
    if req.archived is not None:
        conv["archived"] = bool(req.archived)
    if req.active_task is not None:
        conv["active_task"] = req.active_task
    conv["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _conversation_store_write(data)
    write_state_shadow_snapshot("conversation_patch", conversation_id, {
        "active_task": conv.get("active_task"),
        "project": conv.get("project"),
        "title": conv.get("title"),
        "archived": conv.get("archived"),
    })
    return {"conversation": _conversation_public(conv, include_messages=True)}


# v4.5.1.16 bug register + archive-first log cleanup ----------------------------------
BUG_STATUS_VALUES = {"fixed", "not_fixed", "pending", "needs_retest", "reopened", "ignored"}
ACTIVE_BUG_STATUSES = {"not_fixed", "pending", "needs_retest", "reopened"}


def _slug_status(value: str) -> str:
    raw = str(value or "pending").strip().lower().replace(" ", "_").replace("-", "_")
    aliases = {"notfixed": "not_fixed", "not_fixed": "not_fixed", "needsretest": "needs_retest", "retest": "needs_retest", "na": "ignored", "n_a": "ignored"}
    raw = aliases.get(raw, raw)
    return raw if raw in BUG_STATUS_VALUES else "pending"


def _default_bug_rows() -> List[Dict[str, Any]]:
    now = datetime.now().isoformat(timespec="seconds")
    return [
        {
            "id": "BUG-UI-RECENTS-002",
            "title": "Recent conversations keep changing, duplicating, or renaming",
            "status": "pending",
            "area": "Conversation Store / Sidebar UI",
            "severity": "high",
            "version_found": "v4.5.1.15",
            "version_target": "v4.5.1.21",
            "needs_retest": True,
            "archived": False,
            "notes": "Lock auto-title after the first meaningful title, dedupe recents, and prevent stale refresh responses from repainting the sidebar.",
            "created_at": now,
            "updated_at": now,
            "history": [{"timestamp": now, "status": "pending", "note": "Seeded from user screenshot/report."}],
        },
        {
            "id": "BUG-LOGS-OLD-002",
            "title": "Old debug/support logs still appear mixed with current issues",
            "status": "pending",
            "area": "Logs / QA / Support",
            "severity": "medium",
            "version_found": "v4.5.1.15",
            "version_target": "v4.5.1.21",
            "needs_retest": True,
            "archived": False,
            "notes": "Add archive-first cleanup with latest-log protection and restore metadata.",
            "created_at": now,
            "updated_at": now,
            "history": [{"timestamp": now, "status": "pending", "note": "Seeded from user request for safe cleanup."}],
        },
        {
            "id": "BUG-QA-FILTER-001",
            "title": "Need bug filters for Fixed / Not fixed / Pending / Needs retest",
            "status": "pending",
            "area": "QA Lab / Bug Register",
            "severity": "medium",
            "version_found": "v4.5.1.15",
            "version_target": "v4.5.1.21",
            "needs_retest": True,
            "archived": False,
            "notes": "Default filter should show current active bugs only, with Fixed/Archived available on demand.",
            "created_at": now,
            "updated_at": now,
            "history": [{"timestamp": now, "status": "pending", "note": "Seeded from user request for filters."}],
        },
        {
            "id": "BUG-UI-SIDEBAR-001",
            "title": "Sidebar collapse/rail alignment and white style cleanup",
            "status": "needs_retest",
            "area": "UI",
            "severity": "medium",
            "version_found": "v4.5.1.x",
            "version_target": "v4.5.1.21",
            "needs_retest": True,
            "archived": False,
            "notes": "Tracked so it stays visible until manually retested.",
            "created_at": now,
            "updated_at": now,
            "history": [{"timestamp": now, "status": "needs_retest", "note": "Carried forward from previous UI cleanup list."}],
        },
    ]


def _bug_register_read() -> Dict[str, Any]:
    if BUG_STATUS_FILE.exists():
        try:
            data = json.loads(BUG_STATUS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("bugs", [])
            else:
                data = {"version": 1, "bugs": []}
        except Exception:
            data = {"version": 1, "bugs": []}
    else:
        data = {"version": 1, "bugs": []}
    existing = {str((b or {}).get("id") or "") for b in data.get("bugs", []) if isinstance(b, dict)}
    changed = False
    for bug in _default_bug_rows():
        if bug["id"] not in existing:
            data.setdefault("bugs", []).append(bug)
            changed = True
    # Keep active carried-forward bugs visible in the Current version filter after a patch.
    now = datetime.now().isoformat(timespec="seconds")
    for bug in data.get("bugs", []):
        if not isinstance(bug, dict):
            continue
        if _slug_status(str(bug.get("status") or "pending")) in ACTIVE_BUG_STATUSES and str(bug.get("version_target") or "") == "v4.5.1.16":
            bug["version_target"] = "v4.5.1.21"
            bug["updated_at"] = now
            bug.setdefault("history", []).append({"timestamp": now, "status": bug.get("status") or "pending", "note": "Carried forward to v4.5.1.21 retest filter."})
            changed = True
    if changed or not BUG_STATUS_FILE.exists():
        _bug_register_write(data)
    return data


def _bug_register_write(data: Dict[str, Any]) -> None:
    safe = data if isinstance(data, dict) else {"version": 1, "bugs": []}
    safe.setdefault("version", 1)
    safe.setdefault("bugs", [])
    tmp = BUG_STATUS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(safe, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    tmp.replace(BUG_STATUS_FILE)


def _bug_filter_rows(rows: List[Dict[str, Any]], status: str, scope: str, include_archived: bool) -> List[Dict[str, Any]]:
    status_key = str(status or "active").strip().lower().replace(" ", "_").replace("-", "_")
    scope_key = str(scope or "current").strip().lower().replace(" ", "_").replace("-", "_")
    out = []
    for bug in rows:
        if not isinstance(bug, dict):
            continue
        b_status = _slug_status(str(bug.get("status") or "pending"))
        archived = bool(bug.get("archived"))
        if archived and not include_archived and status_key != "archived":
            continue
        if status_key == "active" and b_status not in ACTIVE_BUG_STATUSES:
            continue
        elif status_key == "archived" and not archived:
            continue
        elif status_key in BUG_STATUS_VALUES and b_status != status_key:
            continue
        elif status_key not in {"all", "active", "archived"} and status_key not in BUG_STATUS_VALUES:
            continue
        target = str(bug.get("version_target") or "")
        found = str(bug.get("version_found") or "")
        if scope_key == "current" and "v4.5.1.21" not in (target + " " + found):
            continue
        if scope_key == "old" and "v4.5.1.21" in (target + " " + found):
            continue
        out.append({**bug, "status": b_status})
    out.sort(key=lambda b: (str(b.get("status") or ""), str(b.get("severity") or ""), str(b.get("updated_at") or "")), reverse=True)
    return out


def _bug_summary(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    summary = {"all": 0, "active": 0, "fixed": 0, "not_fixed": 0, "pending": 0, "needs_retest": 0, "reopened": 0, "ignored": 0, "archived": 0}
    for bug in rows:
        if not isinstance(bug, dict):
            continue
        st = _slug_status(str(bug.get("status") or "pending"))
        summary["all"] += 1
        summary[st] = summary.get(st, 0) + 1
        if st in ACTIVE_BUG_STATUSES:
            summary["active"] += 1
        if bug.get("archived"):
            summary["archived"] += 1
    return summary


def _write_bug_status_report(filtered: List[Dict[str, Any]], summary: Dict[str, int], status: str, scope: str) -> Dict[str, Any]:
    DEBUG_REPORT_DIR.mkdir(parents=True, exist_ok=True)
    json_path = DEBUG_REPORT_DIR / "bug_status_report.json"
    md_path = DEBUG_REPORT_DIR / "bug_status_report.md"
    payload = {"generated_at": datetime.now().isoformat(timespec="seconds"), "app_version": APP_VERSION, "filter": {"status": status, "scope": scope}, "summary": summary, "bugs": filtered}
    json_path.write_text(_safe_json_file_payload(payload), encoding="utf-8")
    lines = ["# Jarvis Bug Status Report", "", f"Generated: {payload['generated_at']}", f"App version: {APP_VERSION}", "", "## Summary", ""]
    lines += [f"- {k}: {v}" for k, v in summary.items()]
    lines += ["", "## Filtered bugs", ""]
    if not filtered:
        lines.append("No bugs match this filter.")
    for bug in filtered:
        lines += [f"### {bug.get('id')} — {bug.get('title')}", f"- Status: {bug.get('status')}", f"- Severity: {bug.get('severity')}", f"- Area: {bug.get('area')}", f"- Target: {bug.get('version_target')}", f"- Notes: {bug.get('notes') or ''}", ""]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return {"json": clean_download_url(str(json_path.relative_to(OUTPUT_DIR)).replace("\\", "/")), "md": clean_download_url(str(md_path.relative_to(OUTPUT_DIR)).replace("\\", "/"))}


def _file_info(path: Path) -> Dict[str, Any]:
    return {
        "path": str(path),
        "name": path.name,
        "relative_root": str(path.relative_to(ROOT)).replace("\\", "/") if ROOT in path.parents or path == ROOT else path.name,
        "size_bytes": path.stat().st_size if path.exists() else 0,
        "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds") if path.exists() else "",
    }


def _safe_log_cleanup_candidates(keep_latest_debug_reports: int) -> List[Path]:
    keep = max(0, min(int(keep_latest_debug_reports or 0), 50))
    candidates: List[Path] = []
    scoped_patterns = [
        (DEBUG_REPORT_DIR, "Jarvis_Debug_Report_*.zip"),
        (QA_REPORT_DIR, "Jarvis_Debug_Replay_Analysis_*.zip"),
        (QA_REPORT_DIR, "Jarvis_QA_Report_*.zip"),
        (OUTPUT_DIR / "Jarvis_QA_Coverage_Reports", "Jarvis_QA_Coverage_Map_*.zip"),
        (OUTPUT_DIR / "Jarvis_QA_Release_Gate_Reports", "Jarvis_Stable_Release_Gate_*.zip"),
        (OUTPUT_DIR / "AI_Exports", "Jarvis_conversation_*.md"),
    ]
    for folder, pattern in scoped_patterns:
        if not folder.exists():
            continue
        rows = sorted([p for p in folder.glob(pattern) if p.is_file()], key=lambda p: p.stat().st_mtime, reverse=True)
        candidates.extend(rows[keep:])
    # Keep current generated reports and cleanup reports visible; they are small and useful for troubleshooting.
    return [p for p in candidates if p.exists() and p.is_file()]


def _rotate_jsonl_for_cleanup(path: Path, keep_lines: int, archive_root: Path, action: str) -> Dict[str, Any]:
    info = {"file": str(path.relative_to(ROOT)).replace("\\", "/"), "exists": path.exists(), "total_lines": 0, "archive_lines": 0, "kept_lines": 0, "archived_to": ""}
    if not path.exists() or not path.is_file():
        return info
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    keep = max(100, min(int(keep_lines or 1500), 20000))
    old, kept = lines[:-keep], lines[-keep:]
    info.update({"total_lines": len(lines), "archive_lines": len(old), "kept_lines": len(kept)})
    if old and action == "archive":
        target = archive_root / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("\n".join(old) + "\n", encoding="utf-8")
        path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
        info["archived_to"] = str(target.relative_to(ROOT)).replace("\\", "/")
    return info


def _write_safe_log_cleanup_report(payload: Dict[str, Any]) -> Dict[str, str]:
    DEBUG_REPORT_DIR.mkdir(parents=True, exist_ok=True)
    json_path = DEBUG_REPORT_DIR / "safe_log_cleanup_report.json"
    md_path = DEBUG_REPORT_DIR / "safe_log_cleanup_report.md"
    json_path.write_text(_safe_json_file_payload(payload), encoding="utf-8")
    lines = ["# Jarvis Safe Log Cleanup Report", "", f"Generated: {payload.get('generated_at')}", f"Action: {payload.get('action')}", f"Status: {payload.get('status')}", "", "## Summary", ""]
    summary = payload.get("summary") or {}
    for k, v in summary.items():
        lines.append(f"- {k}: {v}")
    lines += ["", "## Protected", "", "- Conversation store was not deleted.", "- Current bug register was not deleted.", "- Latest debug/replay reports are preserved.", "- Archived files can be restored from the manifest where available.", ""]
    moved = payload.get("moved") or []
    if moved:
        lines += ["## Archived files", ""]
        for row in moved[:200]:
            lines.append(f"- {row.get('from')} → {row.get('to')}")
    jsonl = payload.get("jsonl_rotation") or []
    if jsonl:
        lines += ["", "## Event/chat log rotation", ""]
        for row in jsonl:
            lines.append(f"- {row.get('file')}: archived {row.get('archive_lines', 0)} line(s), kept {row.get('kept_lines', 0)} line(s)")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return {"json": clean_download_url(str(json_path.relative_to(OUTPUT_DIR)).replace("\\", "/")), "md": clean_download_url(str(md_path.relative_to(OUTPUT_DIR)).replace("\\", "/"))}


def safe_log_cleanup(action: str = "preview", keep_latest_debug_reports: int = 5, keep_latest_event_lines: int = 1500) -> Dict[str, Any]:
    action = str(action or "preview").strip().lower()
    if action not in {"preview", "archive", "restore_latest"}:
        raise HTTPException(status_code=400, detail="Unknown cleanup action.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    unresolved = _bug_filter_rows(_bug_register_read().get("bugs", []), "active", "all", False)
    archive_root = LOG_ARCHIVE_DIR / "Old_Debug_Logs" / stamp
    candidates = _safe_log_cleanup_candidates(keep_latest_debug_reports)
    moved: List[Dict[str, str]] = []
    restored: List[Dict[str, str]] = []
    jsonl_rotation: List[Dict[str, Any]] = []

    if action == "restore_latest":
        roots = sorted([p for p in (LOG_ARCHIVE_DIR / "Old_Debug_Logs").glob("*") if p.is_dir()], key=lambda p: p.stat().st_mtime, reverse=True)
        if roots:
            manifest_path = roots[0] / "manifest.json"
            manifest = {}
            if manifest_path.exists():
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                except Exception:
                    manifest = {}
            for row in manifest.get("moved", []):
                src = ROOT / str(row.get("to") or "")
                dest = ROOT / str(row.get("from") or "")
                if src.exists() and src.is_file():
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    if dest.exists():
                        dest = dest.with_name(dest.stem + "_restored_" + stamp + dest.suffix)
                    shutil.move(str(src), str(dest))
                    restored.append({"from": str(src.relative_to(ROOT)).replace("\\", "/"), "to": str(dest.relative_to(ROOT)).replace("\\", "/")})
            for row in manifest.get("jsonl_rotation", []):
                archived_to = row.get("archived_to")
                file_rel = row.get("file")
                if archived_to and file_rel:
                    src = ROOT / str(archived_to)
                    dest = ROOT / str(file_rel)
                    if src.exists():
                        old = src.read_text(encoding="utf-8", errors="replace")
                        cur = dest.read_text(encoding="utf-8", errors="replace") if dest.exists() else ""
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_text(old + cur, encoding="utf-8")
                        restored.append({"from": str(src.relative_to(ROOT)).replace("\\", "/"), "to": str(dest.relative_to(ROOT)).replace("\\", "/")})
    else:
        if action == "archive":
            archive_root.mkdir(parents=True, exist_ok=True)
        for path in candidates:
            info = _file_info(path)
            if action == "archive":
                target = archive_root / path.relative_to(ROOT)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(path), str(target))
                moved.append({"from": info["relative_root"], "to": str(target.relative_to(ROOT)).replace("\\", "/")})
        for path in [LOG_DIR / "jarvis_events.jsonl", LOG_DIR / "jarvis_visible_chat.jsonl"]:
            jsonl_rotation.append(_rotate_jsonl_for_cleanup(path, keep_latest_event_lines, archive_root, action))
        if action == "archive":
            manifest = {"generated_at": datetime.now().isoformat(timespec="seconds"), "app_version": APP_VERSION, "moved": moved, "jsonl_rotation": jsonl_rotation}
            (archive_root / "manifest.json").write_text(_safe_json_file_payload(manifest), encoding="utf-8")

    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "app_version": APP_VERSION,
        "action": action,
        "status": "ok",
        "unresolved_bugs_protected": [b.get("id") for b in unresolved],
        "candidates": [_file_info(p) for p in candidates],
        "moved": moved,
        "restored": restored,
        "jsonl_rotation": jsonl_rotation,
        "summary": {
            "candidate_files": len(candidates),
            "moved_files": len(moved),
            "restored_files": len(restored),
            "unresolved_bugs": len(unresolved),
            "event_lines_to_archive": sum(int((r or {}).get("archive_lines") or 0) for r in jsonl_rotation),
        },
    }
    payload["reports"] = _write_safe_log_cleanup_report(payload)
    write_log("safe_log_cleanup", {"action": action, "summary": payload["summary"]})
    return payload


@app.get("/api/bugs/status")
def api_bug_status(status: str = "active", scope: str = "current", include_archived: bool = False) -> Dict[str, Any]:
    data = _bug_register_read()
    rows = data.get("bugs", []) if isinstance(data.get("bugs"), list) else []
    filtered = _bug_filter_rows(rows, status, scope, include_archived)
    summary = _bug_summary(rows)
    reports = _write_bug_status_report(filtered, summary, status, scope)
    return {
        "app_version": APP_VERSION,
        "status_options": ["active", "all", "fixed", "not_fixed", "pending", "needs_retest", "reopened", "ignored", "archived"],
        "scope_options": ["current", "all", "old"],
        "summary": summary,
        "bugs": filtered,
        "reports": reports,
    }


@app.post("/api/bugs/{bug_id}/status")
def api_bug_status_update(bug_id: str, req: BugStatusUpdateRequest) -> Dict[str, Any]:
    data = _bug_register_read()
    now = datetime.now().isoformat(timespec="seconds")
    status = _slug_status(req.status)
    for bug in data.get("bugs", []):
        if str((bug or {}).get("id") or "") == bug_id:
            bug["status"] = status
            bug["needs_retest"] = status in {"pending", "needs_retest", "reopened", "not_fixed"}
            bug["updated_at"] = now
            bug.setdefault("history", []).append({"timestamp": now, "status": status, "note": str(req.note or "")[:1000]})
            _bug_register_write(data)
            write_log("bug_status_updated", {"bug_id": bug_id, "status": status})
            return {"status": "ok", "bug": bug}
    raise HTTPException(status_code=404, detail="Bug not found")


@app.post("/api/logs/safe-cleanup")
def api_logs_safe_cleanup(req: SafeLogCleanupRequest) -> Dict[str, Any]:
    return safe_log_cleanup(req.action, req.keep_latest_debug_reports, req.keep_latest_event_lines)


def _safe_json_file_payload(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str)


def _dynamic_hierarchy_summary(project: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Return dynamic Zone/Head labels for reports/replay without old fixed head3 wording."""
    if not isinstance(project, dict) or not project:
        return {}
    zones = project.get("dynamic_zones") or []
    zone_lookup: Dict[int, List[str]] = {}
    for zone in zones:
        try:
            idx = int((zone or {}).get("index") or (zone or {}).get("zone_index") or 0)
        except Exception:
            continue
        if not idx:
            continue
        zone_lookup[idx] = [str(v) for v in ((zone or {}).get("values") or [])]
    rows: List[Dict[str, Any]] = []
    for h in project.get("hierarchy") or []:
        if not isinstance(h, dict):
            continue
        try:
            zone_idx = int(h.get("zone_index") or 0)
        except Exception:
            zone_idx = 0
        head = str(h.get("head") or h.get("row_type") or "").strip()
        label = str(h.get("label") or "").strip()
        mode = str(h.get("mode") or "").strip()
        values = zone_lookup.get(zone_idx, []) if zone_idx else []
        if zone_idx:
            title = f"Zone {zone_idx}"
            if head:
                title += f" / {head}"
            if label:
                title += f": {label}"
        elif mode == "detected_type" or "detected" in label.lower():
            title = f"Detected dimension/type{(' / ' + head) if head else ''}"
        else:
            title = label or head or "Hierarchy row"
        rows.append({
            "title": title,
            "zone_index": zone_idx or None,
            "head": head or None,
            "label": label or None,
            "mode": mode or None,
            "values": values,
        })
    levels = [str(v) for v in (project.get("level_values") or [])]
    level_zone = project.get("level_zone_index") or project.get("levels_zone_index")
    if levels:
        rows.append({
            "title": f"Levels / Zone {level_zone}" if level_zone else "Levels",
            "zone_index": level_zone,
            "head": "formula rows",
            "label": "Levels",
            "mode": "levels",
            "values": levels,
        })
    return {
        "enabled": project.get("enabled"),
        "rows": rows,
        "levels": levels,
        "dynamic_zones": zones,
        "hierarchy_description": project.get("hierarchy_description"),
    }

def build_workflow_health_snapshot(events: List[Dict[str, Any]], conversation: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Compact no-workbook-content snapshot for checking Jarvis continuity.

    This records what Jarvis believed it was doing, not private workbook data.
    It helps verify command understanding, clarification continuity, attachment
    resume opportunities, and whether the router preserved run-only knowledge.
    """
    route_events = [e for e in events if e.get("event") == "route_request"]
    upload_events = [e for e in events if e.get("event") == "file_upload"]
    builder_events = [e for e in events if str(e.get("event") or "").startswith("builder") or e.get("event") == "job_created"]
    chat_trace = _conversation_compact_messages((conversation or {}).get("messages") or []) if isinstance(conversation, dict) else read_recent_chat_trace(120)
    active_task = (conversation or {}).get("active_task") if isinstance(conversation, dict) else None
    last_route = route_events[-1].get("payload", {}) if route_events else {}
    last_plan = ((last_route.get("route") or {}).get("builder_command_plan") or {}) if isinstance(last_route, dict) else {}
    if isinstance(active_task, dict) and isinstance(active_task.get("plan"), dict):
        last_plan = active_task.get("plan") or last_plan
    project = last_plan.get("project_zone_hierarchy") if isinstance(last_plan, dict) else None
    active_workbook = (active_task or {}).get("workbook") if isinstance(active_task, dict) else None
    builder_event_count = len(builder_events)
    if isinstance(last_plan, dict) and last_plan:
        builder_event_count = max(builder_event_count, 1)
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "counts": {
            "route_requests": len(route_events),
            "file_uploads": len(upload_events),
            "builder_or_job_events": builder_event_count,
            "visible_chat_messages": len(chat_trace),
        },
        "last_visible_user_message": next((m.get("text") for m in reversed(chat_trace) if m.get("role") == "user"), ""),
        "last_visible_assistant_message": next((m.get("text") for m in reversed(chat_trace) if m.get("role") == "assistant"), ""),
        "last_prompt": last_route.get("prompt") if isinstance(last_route, dict) else "",
        "last_action": last_route.get("action") if isinstance(last_route, dict) else "",
        "last_intent": ((last_route.get("route") or {}).get("intent") if isinstance(last_route, dict) else ""),
        "last_confidence": ((last_route.get("route") or {}).get("confidence") if isinstance(last_route, dict) else None),
        "last_builder_plan_summary": {
            "trade": last_plan.get("trade_profile_name"),
            "function": last_plan.get("default_function"),
            "custom_quantity": last_plan.get("custom_quantity"),
            "unit": last_plan.get("unit"),
            "zone_mode": last_plan.get("zone_mode"),
            "has_file_at_route_time": last_plan.get("has_file"),
            "requires_review_before_preview": last_plan.get("requires_review_before_preview"),
        } if isinstance(last_plan, dict) and last_plan else {},
        "last_project_hierarchy_summary": _dynamic_hierarchy_summary(project) if isinstance(project, dict) else {},
        "latest_uploads": [((e.get("payload") or {}).get("filename")) for e in upload_events[-5:]],
        "active_workbook": {
            "filename": (active_workbook or {}).get("filename") or (active_workbook or {}).get("saved_name"),
            "saved_name": (active_workbook or {}).get("saved_name"),
            "is_workbook": bool((active_workbook or {}).get("is_workbook")),
        } if isinstance(active_workbook, dict) else {},
        "active_task_status": (active_task or {}).get("status") if isinstance(active_task, dict) else "",
    }


def summarize_activity_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """Return a clean Activity Log row. No private chain-of-thought; only auditable app state."""
    name = str(event.get("event") or "event")
    payload = event.get("payload") or {}
    when = str(event.get("timestamp") or "")
    category = "System"
    title = name.replace("_", " ").title()
    body = ""
    meta: Dict[str, Any] = {}
    status = "info"
    if name == "route_request":
        route = payload.get("route") or {}
        plan = route.get("builder_command_plan") or {}
        context = payload.get("context_snapshot") or route.get("context_snapshot") or {}
        category = "Router"
        title = f"Route: {route.get('intent') or context.get('intent') or 'unknown'}"
        body = str(payload.get("prompt") or "")[:220]
        meta = {
            "action": payload.get("action"),
            "tool": route.get("tool_key"),
            "confidence": route.get("confidence"),
            "active_builder_plan": context.get("active_builder_plan"),
            "has_file": context.get("has_file"),
        }
        if plan:
            category = "Builder"
            title = "Builder plan updated"
            meta.update({
                "trade": plan.get("trade_profile_name"),
                "function": plan.get("default_function"),
                "custom_quantity": plan.get("custom_quantity"),
                "unit": plan.get("unit"),
                "zone_mode": plan.get("zone_mode"),
            })
        if route.get("clarification"):
            title = "Clarification requested"
            body = str((route.get("clarification") or {}).get("question") or body)[:260]
            status = "warn"
    elif name == "file_upload":
        category = "Attachment"
        title = "Workbook/file attached"
        body = str(payload.get("filename") or payload.get("saved_name") or "file")
        meta = {"size": payload.get("size_bytes"), "type": payload.get("file_type")}
    elif name in {"job_created", "builder_run", "builder_preview", "builder_export"} or name.startswith("builder"):
        category = "Builder"
        title = name.replace("_", " ").title()
        body = str(payload.get("output") or payload.get("message") or payload.get("job_id") or "")[:240]
        meta = {k: payload.get(k) for k in ["job_id", "tool_key", "output", "status"] if k in payload}
    elif name == "debug_report_exported":
        category = "Support Log"
        title = "Support log exported"
        body = str(payload.get("report") or "")
        meta = {"events": payload.get("events"), "errors": payload.get("errors")}
    elif "error" in name.lower() or "failed" in name.lower():
        category = "Error"
        status = "error"
        body = json.dumps(payload, ensure_ascii=False, default=str)[:260]
    else:
        body = json.dumps(payload, ensure_ascii=False, default=str)[:260]
    return {"time": when, "event": name, "category": category, "title": title, "body": body, "meta": meta, "status": status}


@app.get("/api/activity/recent")
def api_activity_recent(limit: int = 80, scope: str = "current"):
    limit = max(10, min(int(limit or 80), 200))
    source_limit = max(limit, 400)
    events = read_recent_events(source_limit)
    if str(scope or "current").lower() in {"current", "session", "task"}:
        # Keep the drawer focused on the current user-visible session. Historical QA/fuzz
        # events are still available via scope=all and in support logs.
        filtered = []
        allowed = {"route_request", "file_upload", "debug_report_exported", "builder_run", "builder_preview", "builder_export", "job_created", "input_normalized"}
        for e in events:
            name = str(e.get("event") or "")
            payload = e.get("payload") if isinstance(e.get("payload"), dict) else {}
            if name in allowed or name.startswith("builder"):
                filtered.append(e)
        events_for_rows = filtered[-limit:] if filtered else events[-limit:]
    elif str(scope).lower() in {"errors", "error"}:
        events_for_rows = [e for e in events if "error" in str(e.get("event") or "").lower() or "failed" in str(e.get("event") or "").lower()][-limit:]
    else:
        events_for_rows = events[-limit:]
    rows = [summarize_activity_event(e) for e in events_for_rows]
    rows = list(reversed(rows))
    return {"version": APP_VERSION, "generated_at": datetime.now().isoformat(timespec="seconds"), "scope": scope, "workflow": build_workflow_health_snapshot(events), "items": rows}


def build_debug_report_zip(conversation_id: str = "") -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = DEBUG_REPORT_DIR / f"Jarvis_Debug_Report_{stamp}.zip"
    events = read_recent_events(400)
    selected_conv = None
    if conversation_id:
        store = _conversation_store_read()
        selected_conv = next((c for c in store.get("conversations", []) if c.get("id") == conversation_id), None)
    route_events = [e for e in events if str(e.get("event") or "").startswith("route") or e.get("event") in {"builder_run", "builder_error", "builder_preview", "file_upload", "job_created", "job_persist_error"}]
    workflow_snapshot = build_workflow_health_snapshot(events, selected_conv)
    visible_chat = _conversation_compact_messages((selected_conv or {}).get("messages") or []) if isinstance(selected_conv, dict) else _conversation_compact_messages(read_recent_chat_trace(160))
    errors = [e for e in events if "error" in str(e.get("event") or "").lower() or "failed" in str(e.get("event") or "").lower()]
    inputs = []
    for item in sorted(INPUT_DIR.glob("*"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)[:80]:
        if item.is_file():
            try:
                stat = item.stat()
                inputs.append({
                    "name": item.name,
                    "size_bytes": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                    "suffix": item.suffix.lower(),
                })
            except Exception:
                pass
    outputs = []
    for item in sorted(OUTPUT_DIR.rglob("*"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)[:120]:
        if item.is_file():
            try:
                stat = item.stat()
                outputs.append({
                    "relative_path": str(item.relative_to(OUTPUT_DIR)).replace("\\", "/"),
                    "size_bytes": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                    "suffix": item.suffix.lower(),
                })
            except Exception:
                pass
    summary = f"""# Jarvis Debug Report

Generated: {datetime.now().isoformat(timespec='seconds')}
App version: {APP_VERSION}

## What this is for
Upload this ZIP when you want Jarvis behavior checked. It helps review what Jarvis understood, what route it chose, what file was attached, and whether a preview/export guard behaved correctly.

## Included
- `visible_chat_transcript.jsonl` — user-visible chat transcript and file chips
- `visible_chat_transcript.md` — readable visible user/Jarvis messages
- `jarvis_events_recent.jsonl` — recent event log lines
- `latest_router_events.json` — compact router/Builder/file events
- `workflow_health_snapshot.json` — compact command continuity / parser summary
- `attachment_manifest.json` — current Input Files list
- `output_manifest.json` — recent Output Files list
- `errors.log` — recent error/failed events only
- `app_manifest.json` — version and folder metadata

## Privacy note
This report lists filenames, visible chat text, route prompts, and local Jarvis metadata. It does not intentionally include workbook contents.
"""
    state_shadow = latest_state_shadow_payload(16)
    app_manifest = {
        "app_version": APP_VERSION,
        "root": str(ROOT),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "input_count_sampled": len(inputs),
        "output_count_sampled": len(outputs),
        "event_count_sampled": len(events),
        "visible_chat_count_sampled": len(visible_chat),
        "conversation_id": conversation_id or "",
        "active_task": (selected_conv or {}).get("active_task") if isinstance(selected_conv, dict) else None,
        "state_shadow_latest_kind": ((state_shadow.get("latest") or {}).get("kind") if isinstance(state_shadow, dict) else ""),
    }
    visible_md_lines = ["# Visible Chat Transcript", "", "Generated: " + datetime.now().isoformat(timespec="seconds"), ""]
    for row in visible_chat[-80:]:
        att = row.get("attachments") or []
        att_txt = (" · attachments: " + ", ".join([str((a or {}).get("filename") or "file") for a in att])) if att else ""
        visible_md_lines.append(f"## {row.get('role','message')} · {row.get('timestamp','')}{att_txt}")
        visible_md_lines.append(str(row.get("text") or "").strip() or "[no text]")
        visible_md_lines.append("")
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("latest_session_summary.md", summary)
        zf.writestr("visible_chat_transcript.jsonl", "\n".join(_safe_json_file_payload(e) for e in visible_chat))
        zf.writestr("visible_chat_transcript.md", "\n".join(visible_md_lines))
        zf.writestr("jarvis_events_recent.jsonl", "\n".join(_safe_json_file_payload(e) for e in events))
        zf.writestr("latest_router_events.json", _safe_json_file_payload(route_events[-120:]))
        zf.writestr("workflow_health_snapshot.json", _safe_json_file_payload(workflow_snapshot))
        zf.writestr("state_shadow_snapshot.json", _safe_json_file_payload(state_shadow))
        zf.writestr("attachment_manifest.json", _safe_json_file_payload(inputs))
        zf.writestr("output_manifest.json", _safe_json_file_payload(outputs))
        zf.writestr("errors.log", "\n".join(_safe_json_file_payload(e) for e in errors) or "No recent error events found.")
        zf.writestr("app_manifest.json", _safe_json_file_payload(app_manifest))
    write_log("debug_report_exported", {"report": out.name, "events": len(events), "errors": len(errors)})
    return out



def write_json(name: str, payload: Any) -> None:
    path = SETTINGS_DIR / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _unique_list(values: List[Any]) -> List[str]:
    seen = set()
    result: List[str] = []
    for value in values or []:
        item = str(value).strip()
        if not item:
            continue
        key = item.lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def default_qs_term_library() -> Dict[str, Any]:
    """Curated starter QS / construction term library.

    This is not "all internet words". It is a practical seed library for
    Dhanrick's Australian QS/BOQ formatting workflow, gathered from public
    construction/NCC/product glossary sources and then stored locally so Jarvis
    can ask before guessing unknown terms.
    """
    return {
        "version": "v3.13-qs-term-library",
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "description": "Local QS term/casing library. Jarvis checks this before guessing casing, and asks when terms are uncertain.",
        "sources": [
            {"name": "NCC Glossary", "url": "https://ncc.abcb.gov.au/editions/ncc-2022/adopted/volume-three/1-definitions/glossary", "notes": "Definitions including fire-resistance level (FRL), fire-resisting construction, structural adequacy, storey."},
            {"name": "National Dictionary of Building & Plumbing Terms", "url": "https://www.constructiondictionary.com.au/", "notes": "Australian building/plumbing terms including FRL."},
            {"name": "Construction Tuts quantity surveying abbreviations", "url": "https://constructiontuts.com/abbreviations-used-quantity-surveying/", "notes": "QS abbreviation seed terms such as FFL, RL, CL, GFA, DPC, PC, SMM."},
            {"name": "Studco CH-Stud product page", "url": "https://studcosystems.com.au/products/walls/shaftwall/ch-stud/", "notes": "CH-Stud, J-Track, shaftwall and BMT terminology."},
            {"name": "Gyprock Fyrchek product data", "url": "https://www.gyprock.com.au/", "notes": "Gyprock, Fyrchek, fire rated plasterboard, acoustic grade board, non-combustible usage context."},
            {"name": "Rondo Shaftwall public product information", "url": "https://www.rondo.com.au/", "notes": "Rondo, shaftwall, CH Stud, E Stud, J Runner, DT Runner."}
        ],
        "all_caps_terms": [
            "FRL", "NCC", "BCA", "AS", "AS/NZS", "NATSPEC", "ESD", "HVAC", "BIM",
            "BOQ", "BQ", "RFI", "RFQ", "RFT", "NTS", "TBC", "TBA", "TBD", "UNO", "NB",
            "FFL", "RL", "GL", "CL", "SSL", "FCL", "AHD", "GFA", "NLA", "FECA", "GPO",
            "DPC", "DPM", "PCA", "PC", "PS", "SMM", "WIP", "DDA", "BAL", "NRC", "STC", "Rw",
            "MDF", "FC", "CPD", "PIR", "EPS", "SFS", "PFC", "RHS", "SHS", "CHS", "UB", "UC", "EA", "UA", "MS", "HDG", "PVDF", "PPE", "CSR", "USG", "MRI"
        ],
        "exact_terms": {
            "rw": "Rw", "r'w": "R'w", "r’w": "R’w", "dnt,w": "DnT,w", "dntw": "DnT,w",
            "ext/dry": "Ext/Dry", "ext/wet": "Ext/Wet", "ext/void": "Ext/Void",
            "dry/dry": "Dry/Dry", "dry/wet": "Dry/Wet", "dry/void": "Dry/Void",
            "wet/wet": "Wet/Wet", "wet/void": "Wet/Void",
            "fyrchek": "Fyrchek", "fyrchek mr": "Fyrchek MR", "gyprock": "Gyprock", "aquachek": "AquaChek", "villaboard": "Villaboard",
            "rondo": "Rondo", "studco": "Studco", "speedpanel": "Speedpanel", "speed panel": "Speed Panel", "autex": "Autex", "earthwool": "Earthwool",
            "e-stud": "E-stud", "e-studs": "E-studs", "e stud": "E Stud", "e studs": "E Studs",
            "c-h stud": "C-H Stud", "c-h studs": "C-H Studs", "ch-stud": "CH-Stud", "ch-studs": "CH-Studs", "ch stud": "C-H Stud", "ch studs": "C-H Studs",
            "j-track": "J-Track", "j-tracks": "J-Tracks", "j-runner": "J-Runner", "j-runners": "J-Runners", "dt runner": "DT Runner", "dt runners": "DT Runners",
            "deflection track": "Deflection Track", "deflection head track": "Deflection Head Track"
        },
        "proper_phrases": {
            "acoustic rating": "Acoustic Rating", "thermal rating": "Thermal Rating", "fire rating": "Fire Rating",
            "fire resistance level": "Fire Resistance Level", "structural adequacy": "Structural Adequacy", "fire integrity": "Fire Integrity",
            "passive fire protection": "Passive Fire Protection", "essential services": "Essential Services", "fire stopping": "Fire Stopping",
            "smoke walls": "Smoke Walls", "shaftwall": "Shaftwall", "party wall": "Party Wall", "intertenancy wall": "Intertenancy Wall"
        },
        "contextual_lowercase_phrases": [
            "fire rated", "fire-rated", "non combustible", "non-combustible", "external", "internal",
            "load bearing", "load-bearing", "moisture resistant", "water resistant"
        ],
        "heading_connector_words": [
            "a", "an", "and", "as", "at", "but", "by", "for", "from", "if", "in", "into", "nor", "of", "on", "or", "per", "the", "to", "via", "vs", "with", "without", "within", "onto", "over", "under", "up", "off"
        ],
        "units": [
            "mm", "m", "m2", "m3", "m²", "m³", "kg", "kg/m3", "kg/m³", "t", "tonne", "No.", "No", "item", "items", "set", "pair", "hr", "day", "week", "kN", "MPa", "BMT"
        ],
        "slash_words": {"ext": "Ext", "int": "Int", "dry": "Dry", "wet": "Wet", "void": "Void", "external": "External", "internal": "Internal"},
        "letter_based_nouns": {
            "stud": "stud", "studs": "studs", "track": "track", "tracks": "tracks", "runner": "runner", "runners": "runners",
            "channel": "channel", "channels": "channels", "section": "section", "sections": "sections", "purlin": "purlin", "purlins": "purlins",
            "batten": "batten", "battens": "battens", "angle": "angle", "angles": "angles", "rail": "rail", "rails": "rails", "plate": "plate", "plates": "plates"
        },
        "unknown_pending_review": [],
        "ignored_terms": []
    }


def merge_qs_term_library(defaults: Dict[str, Any], loaded: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(loaded, dict):
        return defaults
    merged = dict(defaults)
    list_keys = ["all_caps_terms", "contextual_lowercase_phrases", "heading_connector_words", "units", "ignored_terms"]
    for key in list_keys:
        merged[key] = _unique_list(list(defaults.get(key, [])) + list(loaded.get(key, []) if isinstance(loaded.get(key), list) else []))
    # Keep pending-review records as dictionaries, not strings.
    pending_records = []
    seen_pending = set()
    for item in (loaded.get("unknown_pending_review", []) if isinstance(loaded.get("unknown_pending_review"), list) else []):
        if isinstance(item, dict):
            term_key = str(item.get("term", "")).strip().lower()
            if term_key and term_key not in seen_pending:
                seen_pending.add(term_key)
                pending_records.append(item)
    merged["unknown_pending_review"] = pending_records
    for key in ["exact_terms", "proper_phrases", "slash_words", "letter_based_nouns"]:
        base_map = dict(defaults.get(key, {}) if isinstance(defaults.get(key), dict) else {})
        extra = loaded.get(key, {}) if isinstance(loaded.get(key), dict) else {}
        base_map.update({str(k).lower(): str(v) for k, v in extra.items() if str(k).strip()})
        merged[key] = base_map
    # Keep user/source metadata but don't duplicate too aggressively.
    if isinstance(loaded.get("sources"), list):
        merged["sources"] = loaded["sources"] or defaults.get("sources", [])
    merged["version"] = loaded.get("version") or defaults.get("version")
    merged["updated_at"] = loaded.get("updated_at") or datetime.now().isoformat(timespec="seconds")
    merged["description"] = loaded.get("description") or defaults.get("description")
    return merged


@lru_cache(maxsize=1)
def load_qs_term_library() -> Dict[str, Any]:
    defaults = default_qs_term_library()
    path = SETTINGS_DIR / "qs_term_library.json"
    if not path.exists():
        write_json("qs_term_library.json", defaults)
        return defaults
    loaded = read_json("qs_term_library.json", {})
    merged = merge_qs_term_library(defaults, loaded)
    write_json("qs_term_library.json", merged)
    return merged


def save_qs_term_library(library: Dict[str, Any]) -> Dict[str, Any]:
    try:
        load_qs_term_library.cache_clear()
    except Exception:
        pass
    library = merge_qs_term_library(default_qs_term_library(), library if isinstance(library, dict) else {})
    library["updated_at"] = datetime.now().isoformat(timespec="seconds")
    write_json("qs_term_library.json", library)
    return library


def qs_library_summary(library: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "all_caps_terms": len(library.get("all_caps_terms", []) or []),
        "exact_terms": len(library.get("exact_terms", {}) or {}),
        "proper_phrases": len(library.get("proper_phrases", {}) or {}),
        "contextual_lowercase_phrases": len(library.get("contextual_lowercase_phrases", []) or []),
        "heading_connector_words": len(library.get("heading_connector_words", []) or []),
        "units": len(library.get("units", []) or []),
        "unknown_pending_review": len(library.get("unknown_pending_review", []) or []),
        "sources": len(library.get("sources", []) or []),
    }

def read_json_path(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


APPROVALS_FILE = BACKUP_DIR / "approval_requests.json"
ALLOWED_RESTORE_FILES = {
    "formatter_profiles.json",
    "boq_case_dictionary.json",
    "settings.json",
    "tool_registry.json",
    "router_rules.json",
    "permission_rules.json",
    "model_profiles.json",
}
SAFETY_BACKUP_SETTINGS_FILES = [
    "settings.json",
    "tool_registry.json",
    "router_rules.json",
    "permission_rules.json",
    "model_profiles.json",
    "formatter_profiles.json",
    "boq_case_dictionary.json",
    "qs_term_library.json",
]


def load_approvals() -> Dict[str, Any]:
    data = read_json_path(APPROVALS_FILE, {"approvals": []})
    if not isinstance(data, dict):
        data = {"approvals": []}
    if not isinstance(data.get("approvals"), list):
        data["approvals"] = []
    return data


def save_approvals(data: Dict[str, Any]) -> None:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    APPROVALS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def get_approval(approval_id: str) -> Optional[Dict[str, Any]]:
    data = load_approvals()
    for item in data.get("approvals", []):
        if item.get("approval_id") == approval_id:
            return item
    return None


def approval_is_valid(approval_id: str, action_key: str) -> bool:
    item = get_approval(approval_id)
    return bool(item and item.get("action_key") == action_key and item.get("status") == "approved")


def create_safety_backup(reason: str = "Manual safety backup", include_jobs: bool = True, include_outputs: bool = False, include_inputs: bool = False) -> Dict[str, Any]:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_reason = re.sub(r"[^A-Za-z0-9_-]+", "_", reason or "safety_backup").strip("_")[:48] or "safety_backup"
    zip_name = f"{stamp}_Jarvis_v3_18_{safe_reason}.zip"
    zip_path = BACKUP_DIR / zip_name
    included: List[str] = []

    def add_file_to_zip(zf: zipfile.ZipFile, path: Path, arcname: str) -> None:
        if path.exists() and path.is_file():
            zf.write(path, arcname)
            included.append(arcname)

    metadata = {
        "created_at": now_iso(),
        "jarvis_version": APP_VERSION,
        "reason": reason,
        "contains": [],
        "restore_rule": "Restore requires approval. Private input/output files are excluded unless explicitly selected.",
        "stable_tools_modified": False,
        "ui_action": req.ui_action,
        "client_action_id": req.client_action_id,
        "conversation_id": req.conversation_id,
        "active_task_status_before": req.active_task_status_before,
    }

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in SAFETY_BACKUP_SETTINGS_FILES:
            add_file_to_zip(zf, SETTINGS_DIR / name, f"05_Settings/{name}")
        prompt_dir = ROOT / "06_Prompts"
        if prompt_dir.exists():
            for path in prompt_dir.rglob("*"):
                if path.is_file():
                    add_file_to_zip(zf, path, str(path.relative_to(ROOT)).replace("\\", "/"))
        if include_jobs and JOBS_DIR.exists():
            for path in JOBS_DIR.glob("*.json"):
                add_file_to_zip(zf, path, f"03_Jobs/{path.name}")
        if include_outputs and OUTPUT_DIR.exists():
            for path in OUTPUT_DIR.rglob("*"):
                if path.is_file():
                    add_file_to_zip(zf, path, str(path.relative_to(ROOT)).replace("\\", "/"))
        if include_inputs and INPUT_DIR.exists():
            for path in INPUT_DIR.rglob("*"):
                if path.is_file():
                    add_file_to_zip(zf, path, str(path.relative_to(ROOT)).replace("\\", "/"))
        metadata["contains"] = included
        zf.writestr("BACKUP_METADATA.json", json.dumps(metadata, indent=2, ensure_ascii=False))

    payload = {
        "status": "ok",
        "backup_name": zip_name,
        "relative_path": zip_name,
        "path": str(zip_path),
        "size_bytes": zip_path.stat().st_size,
        "created_at": metadata["created_at"],
        "reason": reason,
        "included_count": len(included),
        "private_files_included": bool(include_outputs or include_inputs),
        "download_url": f"/api/backups/download/{zip_name}",
    }
    write_log("safety_backup_created", payload)
    return payload


def list_safety_backups() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for path in BACKUP_DIR.glob("*.zip"):
        info = {
            "backup_name": path.name,
            "size_bytes": path.stat().st_size,
            "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
            "download_url": f"/api/backups/download/{path.name}",
            "metadata": {},
        }
        try:
            with zipfile.ZipFile(path, "r") as zf:
                if "BACKUP_METADATA.json" in zf.namelist():
                    info["metadata"] = json.loads(zf.read("BACKUP_METADATA.json").decode("utf-8"))
        except Exception as exc:
            info["metadata"] = {"warning": str(exc)}
        rows.append(info)
    return sorted(rows, key=lambda x: x.get("modified", ""), reverse=True)[:100]


def restore_settings_file_from_backup(backup_file: str, target_file: str, approval_id: str) -> Dict[str, Any]:
    target_name = Path(target_file).name
    if target_name not in ALLOWED_RESTORE_FILES:
        raise HTTPException(status_code=400, detail="This file is not allowed for restore.")
    if not approval_is_valid(approval_id, "backup_restore"):
        raise HTTPException(status_code=403, detail="Approved backup_restore permission is required before restore.")
    backup_path = safe_child(BACKUP_DIR, backup_file)
    if not backup_path.exists() or backup_path.suffix.lower() != ".zip":
        raise HTTPException(status_code=404, detail="Backup file not found.")

    # Create a just-before-restore backup for rollback.
    pre = create_safety_backup(f"before_restore_{target_name}", include_jobs=True, include_outputs=False, include_inputs=False)
    source_arc = f"05_Settings/{target_name}"
    with zipfile.ZipFile(backup_path, "r") as zf:
        if source_arc not in zf.namelist():
            raise HTTPException(status_code=404, detail=f"{target_name} was not found inside this backup.")
        data = zf.read(source_arc)
    # Validate JSON before writing it into settings.
    try:
        json.loads(data.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Backup file is not valid JSON: {exc}") from exc
    target_path = SETTINGS_DIR / target_name
    target_path.write_bytes(data)
    payload = {
        "status": "restored",
        "target_file": target_name,
        "backup_file": backup_path.name,
        "pre_restore_backup": pre.get("backup_name"),
        "restored_at": now_iso(),
    }
    write_log("settings_restore_completed", payload)
    return payload


def default_formatter_profiles() -> Dict[str, Any]:
    """Default profile store for Jarvis v3.0.

    v2.10 makes formatter behavior profile-based so the next Local AI stage has
    a proper memory/profile target instead of rewriting Python code each time.
    """
    legacy_dict = read_json("boq_case_dictionary.json", {})
    protected_upper = legacy_dict.get("protected_upper") if isinstance(legacy_dict, dict) else None
    protected_exact = legacy_dict.get("protected_exact") if isinstance(legacy_dict, dict) else None
    proper_phrases = legacy_dict.get("proper_phrases") if isinstance(legacy_dict, dict) else None
    slash_words = legacy_dict.get("slash_words") if isinstance(legacy_dict, dict) else None

    base_casing = {
        "protected_upper": protected_upper if isinstance(protected_upper, list) else [
            "FRL", "ESD", "NCC", "BCA", "AS", "NZS", "NATSPEC", "MDF", "FC", "CPD", "PIR", "EPS", "SFS",
            "PFC", "RHS", "SHS", "CHS", "UB", "UC", "EA", "UA", "MS", "HDG", "PVDF", "PPE", "PCA", "DDA",
            "BAL", "NRC", "STC", "WIP", "BOQ", "RFI", "NB", "DB", "DBA", "COS", "UNO", "FFL", "GIB", "CSR", "USG"
        ],
        "protected_exact": protected_exact if isinstance(protected_exact, dict) else {
            "rw": "Rw", "r'w": "R'w", "r’w": "R’w", "dnt,w": "DnT,w", "dntw": "DnT,w",
            "fyrchek": "Fyrchek", "gyprock": "Gyprock", "villaboard": "Villaboard", "aquachek": "AquaChek",
            "acoustigard": "Acoustigard", "earthwool": "Earthwool", "rondo": "Rondo", "autex": "Autex"
        },
        "proper_phrases": proper_phrases if isinstance(proper_phrases, dict) else {
            "acoustic rating": "Acoustic Rating", "thermal rating": "Thermal Rating", "fire rating": "Fire Rating",
            "fire resistance level": "Fire Resistance Level", "impact rating": "Impact Rating",
            "sound insulation rating": "Sound Insulation Rating", "non combustible": "Non Combustible",
            "non-combustible": "Non-Combustible", "moisture resistant": "Moisture Resistant",
            "water resistant": "Water Resistant", "acoustically rated": "Acoustically Rated",
            "thermal rated": "Thermal Rated", "external wall": "External Wall", "internal wall": "Internal Wall"
        },
        "slash_words": slash_words if isinstance(slash_words, dict) else {
            "ext": "Ext", "int": "Int", "dry": "Dry", "wet": "Wet", "void": "Void", "external": "External",
            "internal": "Internal", "ex": "Ex", "in": "In"
        },
        "lower_mid_phrases": [
            "non combustible",
            "non-combustible",
            "fire rated",
            "fire-rated",
        ],
        "letter_based_terms": {
            "stud": "stud", "studs": "studs", "track": "track", "tracks": "tracks",
            "channel": "channel", "channels": "channels", "section": "section", "sections": "sections",
            "purlin": "purlin", "purlins": "purlins", "batten": "batten", "battens": "battens",
            "angle": "angle", "angles": "angles", "rail": "rail", "rails": "rails", "plate": "plate", "plates": "plates"
        },
    }

    default_rules = {
        "head1": {"case": "upper", "bold": True, "underline": True},
        "head2": {"case": "smart_title", "bold": True, "underline": True},
        "head3": {"case": "smart_title", "bold": True, "underline": False},
        "head4": {"case": "smart_qs_sentence", "bold": False, "underline": True},
        "item_rows": {"italic": True, "case": "smart_qs_sentence", "below_any_heading": True},
        "level_rows": {"italic": True, "preserve_text": True},
        "freeze_panes": "clear",
        "autofilter": "clear",
        "column_b_width": 50,
        "font": "Calibri",
        "font_size": 11,
        "layout_detection": {
            "mode": "auto",
            "description_column": "auto",
            "row_type_column": "auto",
            "unit_column": "auto",
            "formula_columns": "auto_protect",
            "client_format_learning": True,
        },
    }

    return {
        "active_profile": "default_qs_boq",
        "profiles": {
            "default_qs_boq": {
                "display_name": "Default QS BOQ Format",
                "description": "Dhanrick default BOQ format learned from Formatter v6: Head1-Head4 hierarchy, italic child items, smart QS sentence case, preserved CostX/wall tags and ratings.",
                "version": "v3.5",
                "format_rules": default_rules,
                "casing": base_casing,
            },
            "costx_wall_type": {
                "display_name": "CostX Wall Type Format",
                "description": "Profile for wall/partition descriptions and CostX tags such as Ext/Dry, Dry/Wet, S6c_F2, FRL, Rw, Acoustic Rating and Thermal Rating.",
                "version": "v3.5",
                "format_rules": default_rules,
                "casing": {
                    **base_casing,
                    "proper_phrases": {
                        **base_casing.get("proper_phrases", {}),
                        "wall lining": "Wall Lining",
                        "plasterboard lining": "Plasterboard Lining",
                        "steel studs": "Steel Studs",
                        "insulation": "Insulation",
                    },
                },
            },
            "builder_base_sheet": {
                "display_name": "Builder Base Sheet Format",
                "description": "Reserved profile for future Builder connector outputs. Keeps CostX formulas, zones and level rows conservative.",
                "version": "v3.5",
                "format_rules": {**default_rules, "item_rows": {"italic": True, "case": "preserve", "below_any_heading": True}},
                "casing": base_casing,
            },
        },
    }


def normalize_contextual_casing_profile(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Keep contextual lower-case rules authoritative.

    Older profiles may save phrases such as fire rated as exact/proper
    title-case phrases. That conflicts with Dhanrick's QS rule: description
    text should use lower-case fire rated / non combustible mid-sentence,
    while headings and rating labels may still be title case.
    """
    if not isinstance(profile, dict):
        return profile
    casing = profile.setdefault("casing", {})
    if not isinstance(casing, dict):
        profile["casing"] = casing = {}
    lower_mid = casing.setdefault("lower_mid_phrases", [])
    if not isinstance(lower_mid, list):
        lower_mid = []
        casing["lower_mid_phrases"] = lower_mid
    existing = {str(x).lower() for x in lower_mid}
    for phrase in ["non combustible", "non-combustible", "fire rated", "fire-rated", "external", "internal"]:
        if phrase not in existing:
            lower_mid.append(phrase)
            existing.add(phrase)
    conflict_keys = set()
    for phrase in lower_mid:
        p = str(phrase).strip().lower()
        if not p:
            continue
        conflict_keys.update([p, p.replace("-", " "), p.replace(" ", "-")])
    for bucket in ["protected_exact", "proper_phrases"]:
        mapping = casing.setdefault(bucket, {})
        if isinstance(mapping, dict):
            for key in list(mapping.keys()):
                key_l = str(key).strip().lower()
                if key_l in conflict_keys:
                    mapping.pop(key, None)
                    continue
                # If a single contextual word such as external/internal is learned,
                # remove longer proper phrases such as external wall/internal wall.
                # Otherwise mid-sentence descriptions can become "external Wall".
                for phrase in lower_mid:
                    phrase_l = str(phrase).strip().lower()
                    if phrase_l in {"external", "internal", "fire rated", "fire-rated", "non combustible", "non-combustible"} and key_l.startswith(phrase_l + " "):
                        mapping.pop(key, None)
                        break
    return profile


def normalize_formatter_profile_store(store: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(store, dict) and isinstance(store.get("profiles"), dict):
        for profile in store["profiles"].values():
            normalize_contextual_casing_profile(profile)
    return store


def load_formatter_profiles() -> Dict[str, Any]:
    defaults = default_formatter_profiles()
    path = SETTINGS_DIR / "formatter_profiles.json"
    if not path.exists():
        defaults = normalize_formatter_profile_store(defaults)
        write_json("formatter_profiles.json", defaults)
        return defaults
    loaded = read_json("formatter_profiles.json", {})
    if not isinstance(loaded, dict) or loaded.get("error"):
        return defaults
    if not isinstance(loaded.get("profiles"), dict):
        loaded["profiles"] = {}
    # Ensure new defaults are available even if user has an older profile file.
    for key, profile in defaults["profiles"].items():
        loaded["profiles"].setdefault(key, profile)
    if loaded.get("active_profile") not in loaded["profiles"]:
        loaded["active_profile"] = defaults["active_profile"]
    loaded = normalize_formatter_profile_store(loaded)
    write_json("formatter_profiles.json", loaded)
    return loaded


def save_formatter_profiles(store: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(store.get("profiles"), dict):
        store["profiles"] = {}
    if store.get("active_profile") not in store["profiles"] and store["profiles"]:
        store["active_profile"] = next(iter(store["profiles"].keys()))
    store = normalize_formatter_profile_store(store)
    write_json("formatter_profiles.json", store)
    return store


def normalise_profile_key(name: str) -> str:
    key = re.sub(r"[^a-zA-Z0-9_\-]+", "_", (name or "").strip().lower()).strip("_")
    return key or "custom_profile"


def parse_lines_text(text_value: str) -> List[str]:
    raw = re.split(r"[\n,]+", text_value or "")
    return [item.strip() for item in raw if item.strip()]


def parse_map_text(text_value: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for line in (text_value or "").splitlines():
        line = line.strip()
        if not line:
            continue
        if "=>" in line:
            key, value = line.split("=>", 1)
        elif "=" in line:
            key, value = line.split("=", 1)
        elif ":" in line:
            key, value = line.split(":", 1)
        else:
            key, value = line, line
        key = key.strip().lower()
        value = value.strip()
        if key:
            result[key] = value
    return result


def profile_to_editor_text(profile: Dict[str, Any]) -> Dict[str, str]:
    casing = profile.get("casing", {}) if isinstance(profile, dict) else {}
    protected_upper = casing.get("protected_upper", []) if isinstance(casing, dict) else []
    protected_exact = casing.get("protected_exact", {}) if isinstance(casing, dict) else {}
    proper_phrases = casing.get("proper_phrases", {}) if isinstance(casing, dict) else {}
    slash_words = casing.get("slash_words", {}) if isinstance(casing, dict) else {}
    return {
        "protected_upper_text": "\n".join(str(x) for x in protected_upper),
        "protected_exact_text": "\n".join(f"{k} => {v}" for k, v in protected_exact.items()),
        "proper_phrases_text": "\n".join(f"{k} => {v}" for k, v in proper_phrases.items()),
        "slash_words_text": "\n".join(f"{k} => {v}" for k, v in slash_words.items()),
    }


def resolve_formatter_profile(profile_key: Optional[str] = None) -> Dict[str, Any]:
    store = load_formatter_profiles()
    key = normalise_profile_key(profile_key or store.get("active_profile") or "default_qs_boq")
    profile = store.get("profiles", {}).get(key)
    if not profile:
        key = normalise_profile_key(store.get("active_profile") or "default_qs_boq")
        profile = store.get("profiles", {}).get(key) or default_formatter_profiles()["profiles"]["default_qs_boq"]
    resolved = dict(profile)
    resolved["profile_key"] = key
    return resolved


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")

def timestamp_name(label: str, original_name: str = "") -> str:
    """Return a safe timestamped filename stem for JSON/output exports.

    This is intentionally local and dependency-free because several endpoints
    need a safe name but older builds only used inline stamp logic.
    """
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_label = re.sub(r"[^A-Za-z0-9_-]+", "_", label or "Jarvis_Output").strip("_") or "Jarvis_Output"
    stem = Path(original_name or "workbook").stem
    safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "_", stem).strip("_") or "workbook"
    return f"{stamp}_{safe_label}_{safe_stem}"



def job_path(job_id: str) -> Path:
    return JOBS_DIR / f"{job_id}.json"


def persist_job(job: Dict[str, Any]) -> None:
    try:
        job_path(str(job["job_id"])).write_text(json.dumps(job, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as exc:
        write_log("job_persist_error", {"job_id": job.get("job_id"), "error": str(exc)})


def update_job(job_id: str, **fields: Any) -> Dict[str, Any]:
    with JOB_LOCK:
        job = JOBS.get(job_id) or load_job_from_disk(job_id) or {"job_id": job_id}
        job.update(fields)
        job["updated_at"] = now_iso()
        JOBS[job_id] = job
        persist_job(job)
        return dict(job)


def load_job_from_disk(job_id: str) -> Optional[Dict[str, Any]]:
    path = job_path(job_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def list_known_jobs() -> List[Dict[str, Any]]:
    jobs: Dict[str, Dict[str, Any]] = {}
    for path in JOBS_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("job_id"):
                jobs[str(data["job_id"])] = data
        except Exception:
            continue
    with JOB_LOCK:
        jobs.update({job_id: dict(job) for job_id, job in JOBS.items()})
    return sorted(jobs.values(), key=lambda x: x.get("updated_at") or x.get("created_at") or "", reverse=True)[:100]


def port_open(host: str, port: int, timeout: float = 0.35) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def safe_child(base: Path, name_or_path: str) -> Path:
    """Return a resolved path only if it stays inside base.

    This preserves safe relative subfolders such as Formatter/output.xlsx,
    but blocks absolute/path-traversal attempts.
    """
    candidate = Path(name_or_path)
    if candidate.is_absolute():
        resolved = candidate.resolve()
    else:
        resolved = (base / candidate).resolve()
    base_resolved = base.resolve()
    if base_resolved not in [resolved, *resolved.parents]:
        raise HTTPException(status_code=400, detail="Unsafe file path rejected.")
    return resolved


def classify_prompt(prompt: str, has_file: bool = False) -> Dict[str, Any]:
    registry = read_json("tool_registry.json", {})
    rules = read_json("router_rules.json", {}).get("rules", [])
    prompt_l = prompt.lower()

    best: Optional[Dict[str, Any]] = None
    for rule in rules:
        hits = [kw for kw in rule.get("keywords", []) if kw.lower() in prompt_l]
        if hits:
            score = min(99, 66 + len(hits) * 11)
            # Exact phrase boosts for the commands in the v1 checklist.
            if any(phrase in prompt_l for phrase in ["format my workbook", "build costx base sheet", "open my cloud storage", "write boq description", "compare boq"]):
                score = min(99, score + 9)
            if not best or score > best["confidence"]:
                tool_key = rule.get("tool", "local_ai")
                tool = registry.get(tool_key, {})
                needs_file = bool(rule.get("needs_file", False))
                best = {
                    "intent": rule.get("intent", "general"),
                    "tool_key": tool_key,
                    "tool": tool,
                    "confidence": score,
                    "matched_keywords": hits,
                    "needs_file": needs_file,
                    "missing": "Attach the required file first." if needs_file and not has_file else "",
                    "requires_approval": bool(rule.get("requires_approval", False)) or int(tool.get("risk_level", 1)) >= 4,
                }

    return best or {
        "intent": "general_ai",
        "tool_key": "local_ai",
        "tool": registry.get("local_ai", {}),
        "confidence": 58,
        "matched_keywords": [],
        "needs_file": False,
        "missing": "",
        "requires_approval": False,
    }


def _router_text(prompt: str) -> str:
    return re.sub(r"\s+", " ", str(prompt or "").strip().lower())


def _has_any(text: str, words: List[str]) -> bool:
    return any(word in text for word in words)


def builder_plan_from_current_default(prompt: str, has_file: bool = False, reason: str = "Using current Workspace default Builder setup.") -> Dict[str, Any]:
    """Build a router plan from the saved Workspace setup without changing the Builder engine."""
    level_setup = load_builder_level_zone_setup()
    current = sanitize_current_work_setup(level_setup.get("current_work_setup") or {})
    setup = dict(current)
    setup["notes"] = "Created by Jarvis v4.4.4.20 Stable Release Gate. Preview first before export."
    item_code_config = detect_item_code_intent(prompt)
    extra_reasons: List[str] = []
    if item_code_config:
        setup["item_code_config"] = item_code_config
        extra_reasons.append("Flexible BOQ item coding requested; Column A will use " + builder_item_code_summary(item_code_config) + ".")
    confidence = 78 if has_file else 74
    return {
        "tool": "builder",
        "tool_label": "Build base sheet",
        "version": "v4.4.4.20",
        "trade_profile_id": setup["trade_profile_id"],
        "trade_profile_name": trade_profile_display_name_for_router(setup["trade_profile_id"]),
        "function_mode": setup["costx_function_mode"],
        "default_function": setup["default_costx_function"],
        "custom_quantity": setup["custom_quantity_name"] if setup.get("default_costx_function") == "XGETCUSTOM" else "",
        "unit": setup["custom_quantity_unit"] if setup.get("default_costx_function") == "XGETCUSTOM" and setup.get("custom_quantity_unit") else setup["expected_unit"],
        "zone_mode": setup["zone_token_mode"],
        "confidence": confidence,
        "risk": "low",
        "has_file": has_file,
        "next_action": "approve_and_preview",
        "requires_review_before_preview": False,
        "uses_current_workspace_default": True,
        "reasons": [reason, "Preview still runs before export using the stable v4.3.9.2 Builder engine."] + extra_reasons,
        "matched_keywords": ["default", "current setup"],
        "current_work_setup": setup,
    }


def make_clarification(kind: str, question: str, prompt: str, options: List[Dict[str, str]], extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {
        "type": kind,
        "question": question,
        "original_prompt": str(prompt or ""),
        "options": options,
        "context": extra or {},
    }


def tool_choice_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "tool_choice",
        "I detected a BOQ-related command. Which workflow do you want Jarvis to prepare?",
        prompt,
        [
            {"label": "Build base sheet", "reply": "Build base sheet using current default setup"},
            {"label": "Compare BOQ", "reply": "Compare BOQ against measured quantities"},
            {"label": "Format workbook", "reply": "Format workbook using default QS BOQ format"},
            {"label": "Write BOQ description", "reply": "Write BOQ descriptions"},
        ],
    )



def is_simple_greeting_command(prompt: str) -> bool:
    """v4.5.1.13: friendly local greeting/status/chitchat should not route to Local AI."""
    return jarvis_conversation_reply(prompt) is not None


def jarvis_conversation_reply(prompt: str) -> Optional[str]:
    text = _router_text(prompt)
    cleaned = re.sub(r"[^a-z0-9\s]", "", text).strip()
    if not cleaned:
        return None
    # Identity / wake words
    without_name = re.sub(r"\bjarvis\b", "", cleaned).strip()
    if cleaned in {"jarvis", "hey jarvis", "hi jarvis", "hello jarvis"}:
        return "Yes Dhanrick — I’m here."
    if cleaned in {"you are jarvis", "youre jarvis", "you are my assistant", "youre my assistant", "you are my jarvis"}:
        return "Yes — I’m Jarvis, your local QS/workflow assistant."
    if without_name in {"help", "help me", "please help", "assist me"}:
        return "Of course — tell me what you want to build, check, compare, format, or write."
    # Greetings
    greeting_words = {"h", "hi", "hello", "hey", "good morning", "good afternoon", "good evening", "good day", "goodday", "yo", "sup", "kumusta", "kamusta"}
    if cleaned in greeting_words or without_name in greeting_words or (len(cleaned.split()) <= 4 and any(without_name.startswith(w) for w in ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "good day", "kumusta", "kamusta"])):
        return "Hi Dhanrick — I’m ready. Tell me what you want to build, check, compare, or write."
    # Thanks / sign-off / small talk
    if re.fullmatch(r"(?:thank you|thanks|thank u|ty|salamat|much appreciated)[!. ]*", cleaned, flags=re.I):
        return "You’re welcome."
    if cleaned in {"good night", "goodnight", "night", "later", "see you", "see you later"} or without_name in {"good night", "goodnight", "night", "later", "see you", "see you later"}:
        return "No problem, Dhanrick. We can continue when you’re ready."
    if cleaned in {"how are you", "how are you doing", "are you there", "you there"} or without_name in {"how are you", "how are you doing", "are you there", "you there"}:
        return "I’m good — ready to help with Jarvis or QS work."
    return None


def typo_normalize_prompt(prompt: str) -> str:
    """Small typo map for common Jarvis command words. Conservative: does not rewrite QS terms/formulas."""
    text = str(prompt or "")
    replacements = {
        r"\bcreat\b": "create", r"\bcreaet\b": "create", r"\bcrreate\b": "create",
        r"\bbuilld\b": "build", r"\bbuil\b": "build", r"\bbuld\b": "build",
        r"\bbasee\b": "base", r"\battch\b": "attach", r"\batach\b": "attach", r"\battachement\b": "attachment",
        r"\baprove\b": "approve", r"\baproved\b": "approved", r"\bdowload\b": "download", r"\bdwnload\b": "download",
        r"\bformatt\b": "format", r"\bformating\b": "formatting", r"\bcomapre\b": "compare", r"\bcompair\b": "compare",
        r"\bzonning\b": "zoning", r"\bmezanine\b": "mezzanine", r"\bexterna\b": "external", r"\binterna\b": "internal",
    }
    for pat, repl in replacements.items():
        text = re.sub(pat, repl, text, flags=re.I)
    return text


def is_health_command(prompt: str) -> bool:
    text = _router_text(typo_normalize_prompt(prompt))
    return bool(re.search(r"\b(?:jarvis\s+)?(?:check\s+)?health(?:\s+check)?\b|\bsystem\s+health\b", text))


def is_panic_test_command(prompt: str) -> bool:
    text = _router_text(typo_normalize_prompt(prompt))
    return bool(re.search(r"\b(?:jarvis\s+)?(?:do\s+|run\s+)?(?:a\s+)?panic\s+test\b|\bregression\s+test\b", text))


def is_debug_report_command(prompt: str) -> bool:
    text = _router_text(typo_normalize_prompt(prompt))
    return bool(re.search(r"\b(?:jarvis\s+)?(?:create|export|make|generate)\s+(?:a\s+)?(?:debug\s+report|support\s+log)\b|\bexport\s+support\s+log\b", text))


def is_fresh_boq_builder_request(prompt: str, has_file: bool = False) -> bool:
    text = _router_text(typo_normalize_prompt(prompt))
    if not text:
        return False
    starter = bool(re.search(r"\b(?:create|build|make|prepare|generate)\b", text))
    boq = "boq" in text or "base sheet" in text
    trade = bool(re.search(r"\b(?:door|doors|window|windows|wall|walls|partition|steel|metalwork|concrete|reo|joinery|finish|finishes)\b", text))
    setup = bool(re.search(r"\b(?:zone|zoning|level|levels|head1|head2|head3|head4|basement|mezzanine|old|new|internal|external)\b", text))
    return starter and (boq or (has_file and (trade or setup))) and (trade or setup or "base sheet" in text)


def is_ambiguous_base_boq_command(prompt: str) -> bool:
    """v4.5.1.8: vague BOQ/base sheet requests should clarify workflow instead of forcing Compare/Builder."""
    text = _router_text(prompt)
    if _has_any(text, ["current default setup", "default setup", "use current setup", "using current"]):
        return False
    clear_compare = _has_any(text, ["compare", "discrep", "against", "measured", "to find"])
    clear_format = _has_any(text, ["format", "formatter", "style"])
    clear_writer = _has_any(text, ["description", "write", "rewrite"])
    clear_trade = _has_any(text, ["door", "window", "wall", "partition", "steel", "metalwork", "concrete", "reinforcement", "rebar", "joinery"])
    if clear_compare or clear_format or clear_writer or clear_trade:
        return False
    if _has_any(text, ["base sheet", "build base", "boq base", "base boq"]):
        return True
    if "boq" not in text:
        return False
    vague_create = _has_any(text, ["create", "make", "prepare", "generate", "build"])
    base_mentioned = _has_any(text, ["base boq", "base sheet", "boq base", "base"])
    return vague_create and base_mentioned


def base_boq_ambiguity_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "base_boq_workflow_choice",
        "Do you want Jarvis to build a new BOQ base sheet, compare an existing BOQ, or write BOQ descriptions?",
        prompt,
        [
            {"label": "Build base sheet", "reply": "Build BOQ base sheet using current default setup"},
            {"label": "Compare BOQ", "reply": "Compare BOQ base sheet against measured sheet"},
            {"label": "Write BOQ description", "reply": "Write BOQ descriptions"},
            {"label": "Format workbook", "reply": "Format workbook using default QS BOQ format"},
        ],
        {"reason": "Vague base BOQ request; Jarvis should ask instead of guessing."},
    )

def builder_trade_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "builder_trade_choice",
        "Which Builder setup should I use?",
        prompt,
        [
            {"label": "Current Workspace default", "reply": "Use current Workspace default setup"},
            {"label": "Metalwork / Structural Steel", "reply": "Use Metalwork Structural Steel"},
            {"label": "Walls / Partitions", "reply": "Use Walls Partitions and preserve detected formulas"},
            {"label": "Doors / Windows", "reply": "Use Doors Windows count"},
            {"label": "Preserve detected formulas", "reply": "Use preserve detected formulas"},
        ],
    )


def steel_quantity_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "steel_quantity_choice",
        "Which steel custom quantity should I use?",
        prompt,
        [
            {"label": "Slope Length / m", "reply": "Use Slope Length"},
            {"label": "Steel Surface Area / m2", "reply": "Use Steel Surface Area"},
            {"label": "Weight / t", "reply": "Use Weight"},
            {"label": "RAKING CUTTING / m", "reply": "Use RAKING CUTTING"},
            {"label": "Current Workspace default", "reply": "Use current Workspace default setup"},
        ],
    )



# Jarvis v4.4.4.15.2 — Panic Conflict Guard + Tool Router Priority helpers.
def is_support_log_command(prompt: str) -> bool:
    text = _router_text(prompt)
    return bool(re.search(r"\b(export|create|download|prepare)\s+(?:the\s+)?(?:support|debug)\s+log\b|\b(?:support|debug)\s+log\s+(?:export|report)\b", text, flags=re.I))


def is_attachment_setup_builder_intent(prompt: str, has_file: bool = False) -> bool:
    """v4.5.1.11: bridge workbook + setup instructions into Builder context.

    If an Excel/workbook is already attached and the user gives setup language
    such as zones, levels, heads, hierarchy, formulas, or CostX instructions,
    Jarvis should not fall back to Local AI/general routing. It should create
    or clarify a Builder setup.
    """
    if not has_file:
        return False
    text = _router_text(prompt)
    if not text:
        return False
    if is_support_log_command(text) or is_boq_writer_command(text) or is_compare_boq_command(text):
        return False
    if _has_any(text, ["format workbook", "formatting only", "compare boq", "write boq description"]):
        return False
    # Clear Builder/base-sheet commands are already handled by the normal Builder router.
    # This bridge is only for attachment + setup notes such as "Please see attach, Zone 2...".
    if _has_any(text, ["base sheet", "boq base", "builder", "build", "create", "make", "prepare"]):
        return False
    setup_markers = [
        "zone", "zc", "level", "levels", "head", "head1", "head2", "head3", "head4",
        "hierarchy", "stage", "milestone", "internal", "external", "old", "new",
        "formula", "detected", "preserve", "xget", "costx", "dimension", "setup",
        "mezzanine", "basement", "gf", "lgf", "roof", "please see attach", "see attach"
    ]
    return any(marker in text for marker in setup_markers)


def is_boq_writer_command(prompt: str) -> bool:
    text = _router_text(prompt)
    # BOQ description writing is not Builder, even when the description mentions doors/windows/walls.
    return bool(re.search(r"\b(write|draft|create|compose|prepare|make)\s+(?:a\s+)?(?:boq\s+)?description\b|\bboq\s+description\b|\bitem\s+description\b", text, flags=re.I))


def _split_command_values(chunk: str) -> List[str]:
    chunk = re.split(r"\b(?:use|levels?|with\s+levels?|detected\s+(?:type|dimension)|door\s+counts?|wall\s+area|unit\s+|xget|format|compare|write\s+boq|boq\s+description|remove|omit|exclude|delete|take\s+away|but|do\s+not|don't)\b", str(chunk or ""), maxsplit=1, flags=re.I)[0]
    values: List[str] = []
    implied = ""
    for part in re.split(r",|\band\b|/|&", chunk, flags=re.I):
        clean = _clean_zone_value(part)
        if not clean:
            continue
        if re.match(r"^stage\s+\d+[a-z]?$", clean, flags=re.I):
            implied = "Stage"
        elif re.match(r"^milestone\s+\d+[a-z]?$", clean, flags=re.I):
            implied = "Milestone"
        elif implied and re.match(r"^\d+[a-z]?$", clean, flags=re.I):
            clean = f"{implied} {clean}"
        values.append(clean)
    return _dedupe_keep_order(values)


def _value_group_signature(values: List[str]) -> str:
    low = " ".join(str(v).lower() for v in values)
    if re.search(r"\bstage\s*\d+|\bstage\b|\bmilestone\b", low):
        return "stage/milestone"
    if "internal" in low or "external" in low:
        return "internal/external"
    if re.search(r"\bbuilding\b|\btower\b", low):
        return "building/tower"
    if re.search(r"\bpackage\b", low):
        return "package"
    if re.search(r"\bwing\b|\beast\b|\bwest\b", low):
        return "wing/location"
    if re.search(r"\bl\d+\b|\bb\d+\b|\bgf\b|\broof\b", low):
        return "level"
    return "other"


def detect_zone_value_assignment_conflicts(prompt: str) -> List[str]:
    raw = str(prompt or "")
    assignments: Dict[int, List[List[str]]] = {}
    # Natural explicit forms: Zone 1 is A and B / Zone 1 is also C and D / Zone 4 has East and West.
    pattern = re.compile(r"\bzone\s*(\d+)\s*(?:is\s+also|also\s+is|is|are|=|:|has|have|with)\s+([^\.\n;]+)", flags=re.I)
    for idx_raw, chunk in pattern.findall(raw):
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        values = _split_command_values(chunk)
        if values:
            assignments.setdefault(idx, []).append(values)
    issues: List[str] = []
    for idx, groups in assignments.items():
        signatures: List[str] = []
        unique_groups: List[List[str]] = []
        for values in groups:
            sig = _value_group_signature(values)
            normalized = {str(v).strip().lower() for v in values}
            if not any(normalized == {str(x).strip().lower() for x in old} for old in unique_groups):
                unique_groups.append(values)
                signatures.append(sig)
        # Same zone with different semantic groups is unsafe.
        sigs = {sig for sig in signatures if sig != "other"}
        if len(unique_groups) > 1 and (len(sigs) > 1 or any("also" in raw.lower() for _ in [0])):
            shown = ["Zone %s = %s" % (idx, ", ".join(vals)) for vals in unique_groups]
            issues.append("Conflicting Zone %s value assignments: %s." % (idx, " / ".join(shown)))
    return issues


def detect_zone_head_assignment_conflicts(prompt: str) -> List[str]:
    raw = str(prompt or "")
    pairs = re.findall(r"\bzone\s*(\d+)\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as)?\s*head\s*([1-4])\b", raw, flags=re.I)
    by_zone: Dict[int, set] = {}
    issues: List[str] = []
    for z_raw, h_raw in pairs:
        try:
            z = int(z_raw); h = int(h_raw)
        except Exception:
            continue
        by_zone.setdefault(z, set()).add(h)
    for z, heads in by_zone.items():
        if len(heads) > 1:
            issues.append("Zone %s is assigned to multiple heading levels: %s." % (z, ", ".join("Head"+str(h) for h in sorted(heads))))
    return issues


def detect_function_unit_conflicts(prompt: str) -> List[str]:
    text = _router_text(prompt)
    issues: List[str] = []
    xcount = "xgetcount" in text or re.search(r"\bdoor\s+counts?\b|\bcounts?\s+only\b|\bnumber\b", text)
    xwall = "xgetwallarea" in text or re.search(r"\bwall\s+area\b|\busing\s+wall\s+area\b", text)
    has_no = bool(re.search(r"\bunit\s+no\b|\blowercase\s+no\b|\bno\.?\b", text))
    has_m2 = bool(re.search(r"\bunit\s+m2\b|\bm2\b|\bsquare\s+met", text))
    door_trade = bool(re.search(r"\bdoor\s+trade\b|\bdoors?\b|\bwindows?\b", text))
    if xcount and xwall:
        issues.append("Function conflict: XGETCOUNT/count and XGETWALLAREA/wall area were both requested.")
    if has_no and has_m2:
        issues.append("Unit conflict: both no and m2 were requested.")
    if door_trade and xwall and not xcount:
        issues.append("Trade/function conflict: Door Trade normally uses XGETCOUNT/no, but wall area was requested.")
    if door_trade and xwall and xcount:
        issues.append("Trade/function conflict: Door Trade count and wall area instructions conflict.")
    return _dedupe_keep_order(issues)


def _has_positive_destructive_for_token(text: str, token: str) -> bool:
    """Return True only for real destructive actions, not negated phrases.

    v4.4.4.15.3 precision fix:
    - "do not remove L3" is a keep/no-op instruction, not a conflict.
    - "remove L3 but do not remove L3" is a real conflict because it
      contains one positive destructive action plus one negated destructive.
    """
    token_re = re.escape(str(token or "").strip())
    if not token_re:
        return False
    pat = re.compile(r"\b(?:remove|exclude|omit|delete|take\s+away)\b[^\.\n;]*\b" + token_re + r"\b", flags=re.I)
    for m in pat.finditer(text):
        prior = text[max(0, m.start() - 24):m.start()]
        if re.search(r"(?:do\s+not|don't|dont|never)\s+$", prior, flags=re.I):
            continue
        return True
    return False


def detect_edit_instruction_conflicts(prompt: str) -> List[str]:
    text = _router_text(prompt)
    issues: List[str] = []
    for token in re.findall(r"\b(?:l\s*\d+|b\s*\d+|gf|roof|internal|external|stage\s*\d+[a-z]?|building\s+[a-z]|package\s+[a-z])\b", text, flags=re.I):
        clean = token.strip()
        t = re.escape(clean)
        destructive = _has_positive_destructive_for_token(text, clean)
        negated = bool(re.search(r"\b(?:do\s+not|don't|dont|never)\s+(?:remove|exclude|omit|delete|take\s+away)\b[^\.\n;]*\b" + t + r"\b", text, flags=re.I))
        keep = bool(re.search(r"\b(?:keep|retain)\b[^\.\n;]*\b" + t + r"\b", text, flags=re.I))
        if destructive and (negated or keep):
            issues.append("Edit conflict: remove/exclude and keep/do-not-remove both mention %s." % clean)
    return _dedupe_keep_order(issues)


def detect_mixed_task_conflicts(prompt: str, active_plan: Optional[Dict[str, Any]] = None) -> List[str]:
    text = _router_text(prompt)
    issues: List[str] = []
    wants_compare = bool(re.search(r"\bcompare\b|\bdiscrepanc", text))
    # "base sheet" can be the object of a Compare BOQ task. Treat it as Builder
    # only when paired with build/create/costx/zone/trade instructions.
    wants_builder = bool(
        re.search(r"\b(?:build|create|make|prepare)\b[^.\n;]{0,60}\bbase\s+sheet\b", text)
        or re.search(r"\bcostx\b|\bzone\s*\d+\b|\bdoor\s+trade\b|\bwall\s+types?\b", text)
    )
    wants_write = is_boq_writer_command(prompt)
    wants_support = is_support_log_command(prompt)
    edit_words = bool(re.search(r"\b(remove|exclude|omit|add|bring\s+back|restore|change|make\s+.+first|retain\s+only|keep\s+only)\b", text))
    if wants_compare and wants_builder:
        issues.append("Mixed task conflict: compare and build/base-sheet instructions are in the same command.")
    if wants_write and wants_builder:
        issues.append("Mixed task conflict: BOQ description writing and Builder/base-sheet instructions are in the same command.")
    if wants_support and (wants_builder or wants_compare or wants_write or edit_words):
        issues.append("Mixed task conflict: support-log export is mixed with another task.")
    if active_plan and wants_compare and edit_words:
        issues.append("Mixed task conflict: active Builder edit and Compare BOQ request are in the same sentence.")
    return _dedupe_keep_order(issues)


def detect_panic_conflicts(prompt: str, active_plan: Optional[Dict[str, Any]] = None) -> List[str]:
    issues: List[str] = []
    issues.extend(detect_zone_value_assignment_conflicts(prompt))
    issues.extend(detect_zone_head_assignment_conflicts(prompt))
    issues.extend(detect_function_unit_conflicts(prompt))
    issues.extend(detect_edit_instruction_conflicts(prompt))
    issues.extend(detect_mixed_task_conflicts(prompt, active_plan))
    return _dedupe_keep_order([i for i in issues if i])


def panic_conflict_clarification(prompt: str, issues: List[str], active_plan: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    listed = "\n".join("- " + str(i) for i in issues[:8])
    question = "Jarvis found conflicting instructions and will not run Builder until you clarify.\n" + listed
    options = [
        {"label": "I will clarify", "reply": "I will clarify the instruction"},
        {"label": "Start new command", "reply": "new command: "},
        {"label": "Cancel", "reply": "Cancel"},
    ]
    return make_clarification("panic_conflict_guard", question, prompt, options, {"issues": issues, "active_plan": active_plan or {}})

def steel_quantity_conflict_clarification(prompt: str, quantities: Optional[List[Dict[str, str]]] = None) -> Dict[str, Any]:
    found = ", ".join([q.get("label", "") for q in (quantities or []) if q.get("label")]) or "multiple steel quantities"
    return make_clarification(
        "steel_quantity_choice",
        f"I detected more than one steel custom quantity ({found}). Which one should Jarvis use for this run?",
        prompt,
        [
            {"label": "Slope Length / m", "reply": "Use Slope Length"},
            {"label": "Steel Surface Area / m2", "reply": "Use Steel Surface Area"},
            {"label": "Weight / t", "reply": "Use Weight"},
            {"label": "RAKING CUTTING / m", "reply": "Use RAKING CUTTING"},
            {"label": "Current Workspace default", "reply": "Use current Workspace default setup"},
        ],
        {"detected_quantities": quantities or []},
    )


def zone_mode_conflict_clarification(prompt: str, project_setup: Dict[str, Any]) -> Dict[str, Any]:
    return make_clarification(
        "zone_mode_conflict",
        "You gave new project zones/levels but also asked to preserve original CostX/source zones. Which zone mode should Jarvis use?",
        prompt,
        [
            {"label": "Rebuild run-only tokens", "reply": "Rebuild tokens using my project zones and levels"},
            {"label": "Preserve original CostX zones", "reply": "Preserve original CostX source zones"},
            {"label": "Edit / choose setup first", "reply": "Edit setup first"},
        ],
        {"project_setup": project_setup},
    )


def _zone_option_label(zone: Optional[Dict[str, Any]], fallback: str = "selected zone") -> str:
    if not isinstance(zone, dict):
        return fallback
    try:
        idx = int(zone.get("zone_index"))
    except Exception:
        return fallback
    vals = ", ".join([str(v) for v in (zone.get("values") or [])[:4]]) or f"Zone {idx}"
    role = _zone_role_label(zone.get("role"), idx) if "_zone_role_label" in globals() else str(zone.get("role") or "zone")
    return f"Zone {idx} ({role}: {vals})"


def hierarchy_options_clarification(prompt: str, project_setup: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    setup = project_setup or {}
    dyn = [z for z in (setup.get("dynamic_zones") or []) if isinstance(z, dict) and z.get("role") != "level"]
    primary = next((z for z in dyn if z.get("role") in {"milestone", "tower", "area"}), dyn[0] if dyn else None)
    combo = next((z for z in dyn if z is not primary), None)
    primary_label = _zone_option_label(primary, "main zone")
    combo_label = _zone_option_label(combo, "other zone")
    # v4.4.4.12: option cards should suggest a clean project hierarchy
    # starting at Head1/Head2 unless the user explicitly stated another start.
    first_head = setup.get("primary_head") if setup.get("explicit_start_head") else "Head1"
    first_head = first_head or setup.get("start_head") or "Head1"
    next_head = setup.get("dimension_head") if setup.get("explicit_start_head") else _next_head_label(first_head)
    next_head = next_head or _next_head_label(first_head)
    return make_clarification(
        "hierarchy_option_choice",
        "I detected more than one zone/group. Which BOQ heading layout should I use?",
        prompt,
        [
            {"label": f"A: {primary_label} = {first_head}; Type + {combo_label} = {next_head}; Levels as rows", "reply": "Use option A: primary zone as first head, detected type plus combo zone as next head, levels as rows"},
            {"label": f"B: {combo_label} = {first_head}; Type + {primary_label} = {next_head}; Levels as rows", "reply": "Use option B: combo zone as first head, detected type plus primary zone as next head, levels as rows"},
            {"label": f"C: Detected type = {first_head}; zones/levels as rows", "reply": "Use option C: detected type as first head, zones and levels as rows"},
            {"label": "Use current Workspace default", "reply": "Use current Workspace default setup"},
            {"label": "I will describe custom format", "reply": "I will describe a custom hierarchy"},
        ],
        {"project_setup": setup},
    )


def custom_hierarchy_format_clarification(prompt: str, project_setup: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    example = "Example: Zone 2 (Stage 1, Stage 2) as Head1; detected type + Zone 1 (External, Internal) as Head2; levels L1-L5 excluding L2 as formula rows."
    return make_clarification(
        "custom_hierarchy_format",
        "Okay — type the exact hierarchy format Jarvis should use. " + example,
        prompt,
        [
            {"label": "Use example format", "reply": "Zone 2 (Stage 1, Stage 2) as Head1; detected type plus Zone 1 (External, Internal) as Head2; levels L1 to L5 excluding L2 as formula rows"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
        {"project_setup": project_setup or {}},
    )


def format_conflict_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "format_conflict",
        "You mentioned formatting and also said not to format yet. Which workflow should Jarvis use?",
        prompt,
        [
            {"label": "Builder only, no formatting", "reply": "Run Builder only and do not format yet"},
            {"label": "Builder then Formatter later", "reply": "Run Builder first then prepare Formatter after"},
            {"label": "Format workbook only", "reply": "Format workbook only"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
    )


def trade_title_head1_clarification(prompt: str, project_setup: Dict[str, Any]) -> Dict[str, Any]:
    return make_clarification(
        "trade_title_head1_choice",
        "You asked for a trade title/code row and also asked the project zone to start as Head1. Should the trade title be a separate top row, or should the Stage/Zone rows be the first Head1 rows?",
        prompt,
        [
            {"label": "Trade title as separate top row", "reply": "Use trade title as separate top row"},
            {"label": "Stage/Zone rows first", "reply": "Do not use trade title row; stage rows are first"},
            {"label": "Edit / choose setup first", "reply": "Edit setup first"},
        ],
        {"project_setup": project_setup},
    )


def basement_range_clarification(prompt: str, start: str = "B2", end: str = "B5") -> Dict[str, Any]:
    typed_order = _expand_basement_range(start, end) or [start, end]
    reverse_order = list(reversed(typed_order))
    typed_label = ", ".join(typed_order)
    reverse_label = ", ".join(reverse_order)
    return make_clarification(
        "basement_range_choice",
        f"Basement ranges can be ordered differently by project. For {start} to {end}, which order should I use?",
        prompt,
        [
            {"label": typed_label, "reply": f"Use basement level list {typed_label}"},
            {"label": reverse_label, "reply": f"Use basement level list {reverse_label}"},
            {"label": "I will type the level list", "reply": "I will type the exact levels"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
        {"start": start, "end": end, "typed_order": typed_order, "reverse_order": reverse_order},
    )


def project_setup_clarification(prompt: str, project_setup: Dict[str, Any]) -> Dict[str, Any]:
    levels = ", ".join(project_setup.get("level_values") or []) or "not detected"
    primary_head = project_setup.get("primary_head") or project_setup.get("start_head") or "Head3"
    dimension_head = project_setup.get("dimension_head") or _next_head_label(primary_head)
    hierarchy_desc = project_setup.get("hierarchy_description") or f"{project_setup.get('head3_label') or 'Selected zone'} = {primary_head}; detected type/dimension = {dimension_head}; levels = rows."
    zone_lines = []
    for zone in project_setup.get("dynamic_zones") or []:
        try:
            idx = int(zone.get("zone_index"))
        except Exception:
            continue
        values = ", ".join(zone.get("values") or [])
        role = zone.get("role") or "zone"
        if values:
            zone_lines.append(f"Zone {idx} ({role}): {values}")
    summary_lines = dynamic_hierarchy_summary_lines(project_setup)
    if summary_lines:
        zone_lines.extend(summary_lines)
    zone_summary = "; ".join(_dedupe_keep_order(zone_lines)) or "No explicit dynamic zones detected"
    return make_clarification(
        "project_zone_hierarchy_confirm",
        f"I detected a run-only project hierarchy. {hierarchy_desc} Zones: {zone_summary}. Levels: {levels}. Use this setup for this run only?",
        prompt,
        [
            {"label": "Use run-only setup", "reply": "Use this run only setup"},
            {"label": "Edit / choose setup first", "reply": "Edit setup first"},
        ],
        {"project_setup": project_setup},
    )


def _clean_zone_value(value: str) -> str:
    text = re.sub(r"[\[\]\"\r\n;]+", " ", str(value or "")).strip()
    text = re.sub(r"\s+", " ", text)
    # Users often say "Zone 1 being Milestone 1, 2, 3b". Treat
    # these leading connector words as grammar, not as CostX zone values.
    text = re.sub(r"^(?:being|be|as|is|are|contains?|has|have|values?\s+(?:are|is)|include|includes|including|set\s+as|for|use|using)\s+", "", text, flags=re.I).strip()
    if text.lower() in {"in", "at", "to", "and", "or", "with", "within", "under"}:
        return ""
    text = re.sub(r"^milestone\s+(\d+[a-z]?)$", r"Milestone \1", text, flags=re.I)
    text = re.sub(r"^m\s*(\d+[a-z]?)$", r"Milestone \1", text, flags=re.I)
    return text


def _level_label(code: str) -> str:
    raw = str(code or "").strip()
    key = raw.lower().replace(" ", "")
    labels = {
        "b2": "B2", "b1": "B1", "lgf": "LGF", "lowerground": "LGF", "lowergroundfloor": "LGF",
        "gf": "GF", "ground": "GF", "groundfloor": "GF", "roof": "Roof",
    }
    if key in labels:
        return labels[key]
    m = re.match(r"^(?:l|level|lvl)\s*(\d+)$", raw, flags=re.I)
    if m:
        return f"L{int(m.group(1))}"
    m = re.match(r"^(?:l|level|lvl)\s*(\d+)\s*(mez|mezz|mezzanine)$", raw, flags=re.I)
    if m:
        return f"L{int(m.group(1))} Mezzanine"
    m = re.match(r"^(\d+)\s*(mez|mezz|mezzanine)$", raw, flags=re.I)
    if m:
        return f"L{int(m.group(1))} Mezzanine"
    return raw



def _level_label_for_project(code: str, project_setup: Optional[Dict[str, Any]] = None) -> str:
    """Return CostX token level label, respecting run-only aliases like Mezz."""
    label = _level_label(code)
    alias = str((project_setup or {}).get("mezzanine_token_alias") or "").strip()
    if alias and re.fullmatch(r"mez+z?", alias, flags=re.I):
        label = re.sub(r"\s+Mezzanine\b", f" {alias}", label, flags=re.I)
    return label


def _truncate_zone_value_instruction_tail(chunk: str) -> str:
    """Trim trailing workflow instructions from a zone-value chunk.

    v4.5.1.26.2: stop at instruction-line boundaries such as
    newline + "Use Head" without globally removing the word "Use" from
    valid values like "Mixed Use".
    """
    raw = str(chunk or "")
    if not raw:
        return ""
    return re.split(
        r"[\r\n]+\s*(?:use\s+head\b|start\s+at\s+head\b|levels?\b|preview\b|review\b)",
        raw,
        maxsplit=1,
        flags=re.I,
    )[0]


def _split_zone_value_parts_backend(chunk: str) -> List[str]:
    """Split natural zone values without losing paired values."""
    raw = str(chunk or "").strip(" ,-/")
    if not raw:
        return []
    compact = re.sub(r"[^a-z0-9]+", " ", raw.lower()).strip()
    pair_aliases = {
        "old new": ["Old", "New"],
        "new old": ["New", "Old"],
        "internal external": ["Internal", "External"],
        "external internal": ["External", "Internal"],
    }
    if compact in pair_aliases:
        return pair_aliases[compact]
    raw_parts = [part for part in re.split(r",|\band\b|/|&", raw, flags=re.I) if str(part).strip()]
    values: List[str] = []
    implied_prefix = ""
    for part in raw_parts:
        clean = _clean_zone_value(part)
        if not clean:
            continue
        if re.match(r"^stage\s+\d+[a-z]?$", clean, flags=re.I):
            implied_prefix = "Stage"
        elif re.match(r"^milestone\s+\d+[a-z]?$", clean, flags=re.I):
            implied_prefix = "Milestone"
        elif implied_prefix and re.match(r"^\d+[a-z]?$", clean, flags=re.I):
            clean = f"{implied_prefix} {clean}"
        c2 = re.sub(r"[^a-z0-9]+", " ", clean.lower()).strip()
        if c2 in pair_aliases:
            values.extend(pair_aliases[c2])
        else:
            values.append(clean)
    return _dedupe_keep_order(values)




def _canonical_level_sort_key(level: str):
    """Natural QS level order used only for normalized level lists.

    v4.4.4.15.2: when a user restores/adds a level to an active plan
    (for example "bring back L3"), Jarvis should reinsert it in natural
    building order instead of appending it at the end. This does not change
    CostX formula generation; it only cleans the run-context level list and
    visible diff summaries.
    """
    lv = _level_label(str(level or "")).lower().replace(" ", "")
    if re.match(r"^b\d+$", lv):
        # B5, B4, B3, B2, B1 order for basement stacks.
        return (0, -int(lv[1:]), 0, "")
    if lv == "lgf":
        return (1, 0, 0, "")
    if lv == "gf":
        return (2, 0, 0, "")
    m = re.match(r"^l(\d+)(mezzanine)?$", lv)
    if m:
        return (3, int(m.group(1)), 1 if m.group(2) else 0, "")
    if lv == "plant":
        return (4, 0, 0, "")
    if lv == "roof":
        return (5, 0, 0, "")
    return (6, 0, 0, lv)


def _canonical_level_sort(values: List[str], *, preserve_user_order: bool = False) -> List[str]:
    """Deduplicate and sort level labels in natural QS order.

    Use this for active-plan edit amendments only, not for rewriting raw user
    hierarchy instructions. If a future project preset explicitly locks a
    custom level order, pass preserve_user_order=True.
    """
    cleaned = _dedupe_keep_order([_level_label(v) for v in (values or []) if _level_label(v)])
    if preserve_user_order:
        return cleaned
    return sorted(cleaned, key=_canonical_level_sort_key)

def _expand_level_range(start: int, end: int) -> List[str]:
    step = 1 if end >= start else -1
    return [f"L{i}" for i in range(start, end + step, step)]


def _expand_basement_range(start_label: str, end_label: str) -> List[str]:
    """Expand only the stated basement range, preserving the typed direction.

    B2-B1 should return B2, B1 only. It must not invent B3/B4.
    B2-B5 returns B2, B3, B4, B5; reversing the arguments reverses the order.
    """
    sm = re.search(r"(\d+)", str(start_label or ""))
    em = re.search(r"(\d+)", str(end_label or ""))
    if not sm or not em:
        return []
    start = int(sm.group(1))
    end = int(em.group(1))
    step = 1 if end >= start else -1
    return [f"B{i}" for i in range(start, end + step, step)]


def _dedupe_keep_order(values: List[str]) -> List[str]:
    seen = set()
    out = []
    for value in values:
        clean = str(value or "").strip()
        key = clean.lower()
        if clean and key not in seen:
            out.append(clean)
            seen.add(key)
    return out


def _small_count_to_int(raw: str) -> Optional[int]:
    text = str(raw or "").strip().lower()
    words = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8}
    if text.isdigit():
        return int(text)
    return words.get(text)


def _add_dynamic_zone(zones: List[Dict[str, Any]], seen: set, idx: int, values: List[str], role: str, source: str = "command") -> None:
    if idx < 1 or idx > 8 or idx in seen:
        return
    cleaned = _dedupe_keep_order([_clean_zone_value(v) for v in values if _clean_zone_value(v)])
    if not cleaned:
        return
    zones.append({"zone_index": idx, "values": cleaned, "role": role, "source": source})
    seen.add(idx)



def _parse_preposition_zone_phrases(text: str, zones: List[Dict[str, Any]], seen: set) -> None:
    """Catch natural QS wording like 'Two Stage in Zone 2' and
    'External and Internal at Zone 1' before the generic Zone-N parser runs.

    v4.4.4.9: count/stage phrases are parsed before generic "Zone N with ..."
    value capture. This prevents "Two Stage in Zone 2 with External and
    Internal at Zone 1" from turning Zone 2 into External/Internal. It also
    supports custom hierarchy replies like "Zone 2 at Head1 ... two stage make
    it Stage 1 and Stage 1b".
    """
    raw = str(text or "")

    explicit_value_stop = re.compile(
        r"\b(?:as\s+head\s*[1-4]|in\s+head\s*[1-4]|at\s+head\s*[1-4]|to\s+head\s*[1-4]|head\s*[1-4]|levels?|with\s+levels?|from|start\s+at|do\s+not\s+format|not\s+format|no\s+format|exclud(?:e|ing)|except|detected\s+(?:type|dimension)|formula\s+rows?|rows?|remove|omit|exclude|delete|take\s+away|compare|discrepanc(?:y|ies)|write\s+boq|boq\s+description|export\s+support\s+log|support\s+log|but|do\s+not|don't)\b",
        flags=re.I,
    )

    def _values_from_chunk(chunk: str) -> List[str]:
        return _split_zone_value_parts_backend(chunk)

    def _add_explicit_values(idx: int, values_raw: str, source: str = "command") -> None:
        if idx in seen:
            return
        # Guard: if values immediately point to another zone, e.g.
        # "Zone 2 with External and Internal at Zone 1", those values belong
        # to the later Zone 1 phrase, not Zone 2.
        if re.search(r"\b(?:in|at|under|within)\s+zone\s*\d+\b", values_raw or "", flags=re.I):
            return
        chunk = re.split(r"\bzone\s*\d+\b|\bzc\s*\d+\b", values_raw or "", maxsplit=1, flags=re.I)[0]
        chunk = explicit_value_stop.split(chunk, maxsplit=1)[0].strip(" ,-/")
        values = _values_from_chunk(chunk)
        if values:
            _add_dynamic_zone(zones, seen, idx, values, infer_zone_role(idx, values, raw), source=source)

    # v4.5.1.22: natural pair wording:
    # "Zone 1 and Zone 3; Zone 1 contain Old and New while the other Internal External".
    pair_intro = re.search(r"\bzone\s*(\d+)\s*(?:and|&)\s*zone\s*(\d+)\b", raw, flags=re.I)
    pair_detail = re.search(r"\bzone\s*(\d+)\s+(?:contain|contains|containing|has|have)\s+(.+?)\s+(?:while|and)\s+(?:the\s+)?other(?:\s+(?:is|are|contain|contains|containing|has|have))?\s+([^.;\n]+)", raw, flags=re.I)
    if pair_intro and pair_detail:
        try:
            first_idx = int(pair_detail.group(1))
            a = int(pair_intro.group(1)); b = int(pair_intro.group(2))
            other_idx = b if first_idx == a else a
            first_values = _values_from_chunk(explicit_value_stop.split(pair_detail.group(2), maxsplit=1)[0])
            other_values = _values_from_chunk(explicit_value_stop.split(pair_detail.group(3), maxsplit=1)[0])
            if first_values and first_idx not in seen:
                _add_dynamic_zone(zones, seen, first_idx, first_values, infer_zone_role(first_idx, first_values, raw), source="natural_pair")
            if other_values and other_idx not in seen:
                _add_dynamic_zone(zones, seen, other_idx, other_values, infer_zone_role(other_idx, other_values, raw), source="natural_pair")
        except Exception:
            pass

    # v4.5.1.12: user natural wording such as
    # "2 Zones in 1 containing Old and New with 2 Zones in 2 contains Internal and External".
    for count_raw, idx_raw, values_raw in re.findall(
        r"\b(one|two|three|four|five|six|seven|eight|\d+)\s+zones?\s+(?:in|at|under|within)\s+(?:zone\s*)?(\d+)\s+contain(?:s|ing)?\s*,?\s+(.+?)(?=\s+with\s+(?:one|two|three|four|five|six|seven|eight|\d+)\s+zones?\s+(?:in|at|under|within)\s+(?:zone\s*)?\d+\b|\s+with\s+levels?\b|\s+levels?\b|[.;]|$)",
        raw,
        flags=re.I,
    ):
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if idx in seen:
            continue
        values = _values_from_chunk(explicit_value_stop.split(values_raw, maxsplit=1)[0])
        if values:
            _add_dynamic_zone(zones, seen, idx, values, infer_zone_role(idx, values, raw), source="natural_contains")

    # Custom follow-up: "Zone 2 at Head1 and Zone1 at Head2, also for two
    # stage make it Stage 1 and Stage 1b" => Zone 2 values Stage 1/Stage 1b.
    custom_stage = re.search(
        r"\b(?:two|2)\s+stages?\b.{0,80}?\b(?:make|name|call|set)\s+(?:it|them)?\s*((?:stage\s*)?\d+[a-z]?(?:\s*(?:,|and|&|/)\s*(?:stage\s*)?\d+[a-z]?)+)",
        raw,
        flags=re.I,
    )
    if custom_stage:
        target_idx = None
        head_zone = re.search(r"\bzone\s*(\d+)\s*(?:in|at|to|as|=)?\s*head\s*[1-4]\b", raw, flags=re.I)
        if head_zone:
            try:
                target_idx = int(head_zone.group(1))
            except Exception:
                target_idx = None
        if target_idx is None:
            two_zone = re.search(r"\b(?:two|2)\s+stages?\s+(?:in|at|under|within)\s+zone\s*(\d+)\b", raw, flags=re.I)
            if two_zone:
                try:
                    target_idx = int(two_zone.group(1))
                except Exception:
                    target_idx = None
        values = _values_from_chunk(custom_stage.group(1))
        if target_idx and values:
            _add_dynamic_zone(zones, seen, target_idx, values, "milestone", source="custom_override")

    # Explicit override: Zone 2 be Stage 1 and Stage 1b / Zone 5 = Internal, External.
    for idx_raw, values_raw in re.findall(r"\bzone\s*(\d+)\s*(?:be|being|is|are|=|:)\s+([^\.\n;]+)", raw, flags=re.I):
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        _add_explicit_values(idx, values_raw, source="custom_override")

    # Count phrases: two stages in Zone 2 / 2 stage at Zone 2 -> Stage 1, Stage 2.
    for count_raw, idx_raw in re.findall(r"\b(one|two|three|four|five|six|seven|eight|\d+)\s+stages?\s+(?:in|at|under|within)\s+zone\s*(\d+)\b", raw, flags=re.I):
        count = _small_count_to_int(count_raw) or 0
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if count > 0:
            _add_dynamic_zone(zones, seen, idx, [f"Stage {i}" for i in range(1, count + 1)], "milestone")

    # Zone 2 has two stages / Zone 2 with two stages -> Stage 1, Stage 2.
    for idx_raw, count_raw in re.findall(r"\bzone\s*(\d+)\s+(?:has|have|with|containing|including)\s+(one|two|three|four|five|six|seven|eight|\d+)\s+stages?\b", raw, flags=re.I):
        count = _small_count_to_int(count_raw) or 0
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if count > 0:
            _add_dynamic_zone(zones, seen, idx, [f"Stage {i}" for i in range(1, count + 1)], "milestone")

    # External and Internal at Zone 1 -> External, Internal.
    for values_raw, idx_raw in re.findall(r"\b((?:external|internal)(?:\s*(?:,|/|and|&)\s*(?:external|internal))*)\s+(?:in|at|under|within)\s+zone\s*(\d+)\b", raw, flags=re.I):
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if idx in seen:
            continue
        parts = [p for p in re.split(r",|/|\band\b|&", values_raw, flags=re.I) if str(p).strip()]
        _add_dynamic_zone(zones, seen, idx, [p.strip().title() for p in parts], "location")

    # Generic values after Zone N. Keep this after natural QS phrases so it
    # does not steal values from another zone.
    for idx_raw, values_raw in re.findall(r"\bzone\s*(\d+)\s*(?:with|be|being|is|are|=|:)\s+([^\.\n;]+)", raw, flags=re.I):
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        _add_explicit_values(idx, values_raw, source="command")

def _parse_chained_zone_value_phrases(text: str, zones: List[Dict[str, Any]], seen: set[int]) -> None:
    """Parse chained zone value sentences before the broad legacy parser.

    Handles: "Zone 2 contains Old and New while Zone 4 contains External and Internal".
    The older parser captured "contains" and "while" as values because it split
    values before splitting zone clauses.
    """
    raw = str(text or "")
    if not re.search(r"\b(?:zone|zc)\s*[1-8]\b", raw, flags=re.I):
        return
    pattern = re.compile(
        r"(?:^|[\r\n]+|\b(?:while|and)|[,;])\s*(?:zone|zc)\s*([1-8])\s*(?:contains?|contain|has|have|values?\s*(?:are|is)|being|be|is|are|=|:|-|with)?\s*(.*?)(?=(?:[\r\n]+\s*(?:zone|zc)\s*[1-8]\b|\b(?:while|and)\s*(?:zone|zc)\s*[1-8]\b|[,;]\s*(?:zone|zc)\s*[1-8]\b|[\r\n]+\s*(?:use\s+head\b|start\s+at\s+head\b|levels?\b|preview\b|review\b)|\b(?:at|as)?\s*head\s*[1-4]\b|\bhead\s*[1-4]\b|\blevels?\b|$))",
        flags=re.I | re.S,
    )
    for match in pattern.finditer(raw):
        try:
            idx = int(match.group(1))
        except Exception:
            continue
        if idx < 1 or idx > 8 or idx in seen:
            continue
        chunk = _truncate_zone_value_instruction_tail(str(match.group(2) or "")).strip(" ,;.-")
        # Ignore zone-slot selection without values: "Use Zone 2 and 4".
        if not chunk or re.fullmatch(r"(?:and|or|,|\s|\d)+", chunk, flags=re.I):
            continue
        chunk = re.sub(r"^(?:contains?|contain|has|have|values?\s*(?:are|is)|being|be|is|are|with)\s+", "", chunk, flags=re.I).strip(" ,;.-")
        values = _split_zone_value_parts_backend(chunk)
        values = [_clean_zone_value(v) for v in values if _clean_zone_value(v)]
        if not values:
            continue
        role = infer_zone_role(idx, values, raw)
        zones.append({"zone_index": idx, "values": _dedupe_keep_order(values), "role": role, "source": "chained_zone_sentence"})
        seen.add(idx)


def parse_zone_slot_selection_indices(prompt: str) -> List[int]:
    """Return zone indices from slot-only prompts such as 'Use Zone 2 and 4'."""
    raw = str(prompt or "")
    if not re.search(r"\b(?:use|using|with|select|selected|zone|zones|zc)\b", raw, flags=re.I):
        return []
    indices: List[int] = []
    for m in re.finditer(r"\b(?:zone|zc)\s*([1-8])\b", raw, flags=re.I):
        try:
            idx = int(m.group(1))
        except Exception:
            continue
        if idx not in indices:
            indices.append(idx)
        tail = raw[m.end(): m.end() + 40]
        for extra in re.findall(r"\b(?:and|or|,|&)\s*([1-8])\b", tail, flags=re.I):
            try:
                eidx = int(extra)
            except Exception:
                continue
            if 1 <= eidx <= 8 and eidx not in indices:
                indices.append(eidx)
    return indices


def is_zone_slot_only_update(prompt: str) -> bool:
    text = _router_text(prompt)
    if not parse_zone_slot_selection_indices(prompt):
        return False
    # Slot selection should not force a trade/default plan.
    trade_words = ["wall", "partition", "door", "window", "concrete", "reo", "reinforcement", "steel", "metalwork", "finish", "landscape", "civil"]
    return not _has_any(text, trade_words)


def _ensure_project_from_zone_slots(plan: Dict[str, Any], prompt: str) -> Optional[Dict[str, Any]]:
    indices = parse_zone_slot_selection_indices(prompt)
    if not indices:
        return None
    setup = plan.setdefault("current_work_setup", {})
    project = plan.get("project_zone_hierarchy") or setup.get("project_zone_hierarchy") or _empty_project_setup_for_active_reply(prompt)
    project["run_only"] = True
    project["expected_zone_indices"] = indices
    project["needs_hierarchy_choice"] = True
    project["confirmation_needed"] = True
    project.setdefault("dynamic_zones", [])
    for idx in indices:
        if not _find_dynamic_zone(project, int(idx)):
            project["dynamic_zones"].append({"zone_index": int(idx), "values": [], "role": f"zone_{idx}", "source": "selected_slot"})
    setup["project_zone_hierarchy"] = project
    setup["zone_token_mode"] = "rebuild" if isinstance(project, dict) and project else setup.get("zone_token_mode", "preserve_source")
    if isinstance(project, dict) and project:
        plan["project_zone_hierarchy"] = project
    plan["zone_mode"] = "rebuild_run_only"
    plan["builder_levels"] = plan.get("builder_levels") or build_project_builder_levels(project)
    return project


def parse_dynamic_zone_values_from_prompt(prompt: str) -> List[Dict[str, Any]]:
    """Parse explicit Zone N instructions without hard-coding zone meanings.

    v4.4.4.3 guards against a known weak case where un-parenthesized
    phrases such as "Zone 1 being Milestone 1,2,3b and Levels B2-B1..."
    allowed the zone parser to absorb level/exclusion text as fake zone values.
    """
    text = str(prompt or "")
    zones: List[Dict[str, Any]] = []
    seen: set[int] = set()
    _parse_chained_zone_value_phrases(text, zones, seen)
    _parse_preposition_zone_phrases(text, zones, seen)
    # Capture either parenthesized Zone N (...) values, or free text after Zone N
    # up to the next workflow/level delimiter. Keep the delimiter handling local
    # so project-specific zone roles remain dynamic.
    pattern = re.compile(
        r"(?:zone\s*(\d+)|zc\s*(\d+))\s*(?:being|be|is|are|as|=|:|-|with)?\s*(?:\(([^\)]*)\)|([^\.\n;]+))",
        flags=re.I,
    )
    stop_pattern = re.compile(
        r"\b(?:as\s+head\s*[1-4]|head\s*[1-4]|levels?|with\s+levels?|from|start\s+at|do\s+not\s+format|not\s+format|no\s+format|exclud(?:e|ing)|except|use\s+basement|builder|format(?:ter)?|detected\s+(?:type|dimension)|remove|omit|exclude|delete|take\s+away|compare|discrepanc(?:y|ies)|write\s+boq|boq\s+description|export\s+support\s+log|support\s+log|but|do\s+not|don't)\b",
        flags=re.I,
    )
    for match in pattern.finditer(text):
        idx_raw = match.group(1) or match.group(2)
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if idx < 1 or idx > 8 or idx in seen:
            continue
        raw_chunk = match.group(3) if match.group(3) is not None else match.group(4)
        if is_zone_slot_only_update(text):
            continue
        chunk = re.sub(r"^\s*(?:with|as|=|:|-|being|be|is|are|contains?|contain|has|have|values?\s*(?:are|is))+\s*", "", raw_chunk or "", flags=re.I).strip()
        chunk = _truncate_zone_value_instruction_tail(chunk).strip()
        # Critical: truncate the whole zone chunk before splitting commas/and.
        # Otherwise "3b and Levels B2-B1 and L1-L6" can produce fake zone
        # values like "L1 to L6 with" and "to exclude".
        # v4.4.4.8 also stops at the next Zone-N mention so phrases like
        # "Zone2 in Head2 and Zone1, Zone 2 be Stage 1..." do not turn
        # Zone1 into a fake value.
        chunk = re.split(r"\bzone\s*\d+\b|\bzc\s*\d+\b", chunk, maxsplit=1, flags=re.I)[0]
        if re.match(r"^\s*(?:in|to|at|as)?\s*head\s*[1-4]\b", chunk, flags=re.I):
            continue
        chunk = stop_pattern.split(chunk, maxsplit=1)[0].strip(" ,-/")
        values = _split_zone_value_parts_backend(chunk)
        if not values:
            continue
        role = infer_zone_role(idx, values, text)
        zones.append({"zone_index": idx, "values": values, "role": role, "source": "command"})
        seen.add(idx)

    # v4.5.1.23: second pass for inline chained zones such as
    # "Zone 1 Old/New, Zone 2 Internal/External, Levels L1 to L11".
    inline_pattern = re.compile(
        r"(?:zone\s*(\d+)|zc\s*(\d+))\s*(?:being|be|is|are|as|=|:|-|with)?\s*(.*?)(?=(?:[,;]?\s*(?:zone|zc)\s*\d+|\b(?:levels?|head|from|start\s+at|do\s+not\s+format|format(?:ter)?|compare|support\s+log)\b|$))",
        flags=re.I | re.S,
    )
    for match in inline_pattern.finditer(text):
        idx_raw = match.group(1) or match.group(2)
        try:
            idx = int(idx_raw)
        except Exception:
            continue
        if idx < 1 or idx > 8 or idx in seen:
            continue
        if is_zone_slot_only_update(text):
            continue
        chunk = re.sub(r"^\s*(?:with|as|=|:|-|being|be|is|are|contains?|contain|has|have|values?\s*(?:are|is))+\s*", "", match.group(3) or "", flags=re.I).strip(" ,-/")
        chunk = stop_pattern.split(chunk, maxsplit=1)[0].strip(" ,-/")
        values = _split_zone_value_parts_backend(chunk)
        if not values:
            continue
        role = infer_zone_role(idx, values, text)
        zones.append({"zone_index": idx, "values": values, "role": role, "source": "command_inline"})
        seen.add(idx)

    # v4.5.1.23: active Builder follow-up shorthand, e.g. "1: Stage 1, 2, 3b"
    # or multiline "4: Old and New". Only accept Zone indices 1-8 and stop at
    # the next numbered zone fragment / workflow delimiter so timestamps are not
    # treated as zones.
    bare_pattern = re.compile(r"(?:^|[\n;])\s*([1-8])\s*[:=]\s*([^\n;]+)", flags=re.I)
    for match in bare_pattern.finditer(text):
        try:
            idx = int(match.group(1))
        except Exception:
            continue
        if idx in seen:
            continue
        chunk = re.split(r"(?:^|[,\s])(?:[1-8])\s*[:=]|\b(?:levels?|head|format|compare|support\s+log)\b", match.group(2), maxsplit=1, flags=re.I)[0]
        values = _split_zone_value_parts_backend(chunk)
        if not values:
            continue
        # Expand shorthand after a Stage/Milestone value: "Stage 1, 2, 3b".
        expanded = []
        implied = ""
        for value in values:
            clean = _clean_zone_value(value)
            if re.match(r"^stage\s+\d+[a-z]?$", clean, flags=re.I):
                implied = "Stage"
            elif re.match(r"^milestone\s+\d+[a-z]?$", clean, flags=re.I):
                implied = "Milestone"
            elif implied and re.match(r"^\d+[a-z]?$", clean, flags=re.I):
                clean = f"{implied} {clean}"
            if clean:
                expanded.append(clean)
        values = _dedupe_keep_order(expanded)
        if not values:
            continue
        role = infer_zone_role(idx, values, text)
        zones.append({"zone_index": idx, "values": values, "role": role, "source": "active_reply"})
        seen.add(idx)
    return zones


def infer_zone_role(zone_index: int, values: List[str], prompt_text: str = "") -> str:
    joined = " ".join(values).lower()
    prompt_l = str(prompt_text or "").lower()
    if "internal" in joined or "external" in joined:
        return "location"
    if "milestone" in joined or "stage" in joined or "phase" in joined:
        return "milestone"
    if re.search(r"\b(?:b\d+|lgf|gf|roof|l\d+)\b", joined, flags=re.I):
        return "level"
    if any(word in joined or word in prompt_l for word in ["tower", "building", "block"]):
        return "tower"
    if any(word in joined or word in prompt_l for word in ["lot", "area"]):
        return "area"
    if any(word in joined or word in prompt_l for word in ["primary steel", "secondary steel", "raking", "member type"]):
        return "member_type"
    if any(word in joined or word in prompt_l for word in ["wall type", "door type", "finish type"]):
        return "type"
    return f"zone_{zone_index}"


def parse_zone1_values_from_prompt(prompt: str) -> List[str]:
    """Backward-compatible helper. v4.4.2.4 no longer treats Zone 1 as a hard-coded role."""
    for zone in parse_dynamic_zone_values_from_prompt(prompt):
        if zone.get("zone_index") == 1:
            vals = zone.get("values") or []
            out = []
            for value in vals:
                clean = _clean_zone_value(value)
                if re.match(r"^\d+[a-z]?$", clean, flags=re.I):
                    clean = f"Milestone {clean}"
                out.append(clean)
            return _dedupe_keep_order(out)
    return []


def _parse_level_exclusions(prompt: str) -> List[str]:
    text = str(prompt or "")
    excluded: List[str] = []
    # Supports: excluding L3/L4, exclude Level 3 and Level 7, except L2.
    # v4.5.1.12: also treat "remove L5" as an exclusion only inside a full
    # Builder setup sentence containing BOQ/base/levels. For active edit commands
    # like "remove L4 and add Roof", parse_levels_from_prompt must still return
    # L4 so the active amendment resolver can remove it.
    patterns = [r"\b(?:exclud(?:e|ing)|except)\s+([^\.\n]+)"]
    if re.search(r"\b(?:boq|base\s+sheet|levels?)\b", text, flags=re.I):
        patterns.append(r"\b(?:remove|omit|delete|take\s+away)\s+([^\.\n]+)")
    for pattern in patterns:
        for chunk in re.findall(pattern, text, flags=re.I):
            # Clarification replies append internal markers such as
            # "use basement level list B2, B1". Do not treat those appended
            # chosen basement levels as exclusions.
            chunk = re.split(r"\buse\s+basement\b", chunk, maxsplit=1, flags=re.I)[0]
            for rng_start, rng_end in re.findall(r"\b(?:L|Level|Lvl)\s*(\d+)\s*(?:-|–|—|to)\s*(?:L|Level|Lvl)?\s*(\d+)\b", chunk, flags=re.I):
                excluded.extend(_expand_level_range(int(rng_start), int(rng_end)))
            for token in re.findall(r"\b(?:B\s*\d+|LGF|lower ground floor|lower ground|GF|ground floor|roof|(?:L|Level|Lvl)\s*\d+(?:\s*(?:mez|mezz|mezzanine))?)\b", chunk, flags=re.I):
                excluded.append(_level_label(token))
    return _dedupe_keep_order(excluded)


def _selected_basement_order_from_prompt(prompt: str) -> List[str]:
    text = str(prompt or "")
    orders: List[List[str]] = []
    for chunk in re.findall(r"\buse\s+basement\s+level\s+list\s+([^\.\n]+)", text, flags=re.I):
        vals = [_level_label(tok) for tok in re.findall(r"\bB\s*\d+\b", chunk, flags=re.I)]
        if vals:
            orders.append(vals)
    for start, end in re.findall(r"\buse\s+basement\s+range\s+(?:ascending|typed\s+order)\s+B\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", text, flags=re.I):
        orders.append(_expand_basement_range(f"B{start}", f"B{end}"))
    for start, end in re.findall(r"\buse\s+basement\s+range\s+(?:descending|reverse\s+order)\s+B\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", text, flags=re.I):
        orders.append(_expand_basement_range(f"B{end}", f"B{start}"))
    return orders[-1] if orders else []

def _has_basement_range_needing_clarification(prompt: str) -> Optional[tuple[str, str]]:
    m = re.search(r"\bB\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", str(prompt or ""), flags=re.I)
    if not m:
        return None
    start = int(m.group(1)); end = int(m.group(2))
    # v4.5.1.12: high-to-low basement ranges such as B5 to B1 are clear typed order.
    # Keep clarification only for low-to-high ranges, where the user might mean either typed or descending order.
    if start >= end:
        return None
    return (f"B{start}", f"B{end}")


def parse_levels_from_prompt(prompt: str) -> List[str]:
    text = str(prompt or "")
    levels: List[str] = []
    selected_basement_order = _selected_basement_order_from_prompt(text)
    lower = text.lower()
    # v4.5.1.22: "Level 11 and Level 5 having Mezzanine" / "L11 and L5 with Mezz".
    for chunk in re.findall(r"((?:(?:L|Level|Lvl)\s*\d+\s*(?:,|and|&)?\s*)+)\s+(?:having|has|with)\s+(?:a\s+)?(?:mez|mezz|mezzanine)\b", text, flags=re.I):
        for num in re.findall(r"(?:L|Level|Lvl)\s*(\d+)", chunk, flags=re.I):
            levels.append(f"L{int(num)} Mezzanine")
    # Level ranges such as L1-L10, L1 to L10, GF to L10, and natural language "Levels 1-11".
    # v4.5.1.11: previous parser handled "Level 1 to 11" but missed plural "Levels 1-11".
    for start, end in re.findall(r"\blevels?\s*(\d+)\s*(?:-|–|—|to)\s*(\d+)\b", text, flags=re.I):
        levels.extend(_expand_level_range(int(start), int(end)))
    for end in re.findall(r"\bGF\s*(?:-|–|—|to)\s*(?:(?:L|Level|Lvl)\s*)?(\d+)\b", text, flags=re.I):
        levels.append("GF")
        levels.extend(_expand_level_range(1, int(end)))
    for end in re.findall(r"\bground\s+floor\s*(?:-|–|—|to|up\s+to)\s*(?:(?:level|lvl|L)\s*)?(\d+)\b", text, flags=re.I):
        levels.append("GF")
        levels.extend(_expand_level_range(1, int(end)))
    for end in re.findall(r"\b(?:LGF|lower ground floor|lower ground)\s*(?:-|–|—|to)\s*L\s*(\d+)\b", text, flags=re.I):
        levels.append("LGF")
        levels.append("GF")
        levels.extend(_expand_level_range(1, int(end)))
    # Supports L1-L5, Level 1 to 5, Level 1 to Level 5, and L1 to Level 5.
    for start, end in re.findall(r"\b(?:L|Level|Lvl)\s*(\d+)\s*(?:-|–|—|to)\s*(?:(?:L|Level|Lvl)\s*)?(\d+)\b", text, flags=re.I):
        levels.extend(_expand_level_range(int(start), int(end)))
    # B-level ranges such as B5 to B1 are treated as explicit typed order.
    for start, end in re.findall(r"\bB\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", text, flags=re.I):
        levels.extend(_expand_basement_range(f"B{start}", f"B{end}"))
    # Basement ranges are usually clarified when written as B2-B5/B5-B2.
    # Natural language like "Basement 5 to 1" is treated as explicit typed order.
    for start, end in re.findall(r"\bbasement\s*(\d+)\s*(?:-|–|—|to)\s*(?:basement\s*)?(\d+)\b", text, flags=re.I):
        levels.extend(_expand_basement_range(f"B{start}", f"B{end}"))
    # Selected order must be preserved exactly (for example B2, B1 or B1, B2).
    if selected_basement_order:
        levels.extend(selected_basement_order)
    for start, end in re.findall(r"\buse\s+basement\s+range\s+(?:ascending|typed\s+order)\s+B\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", text, flags=re.I):
        levels.extend(_expand_basement_range(f"B{start}", f"B{end}"))
    for start, end in re.findall(r"\buse\s+basement\s+range\s+(?:descending|reverse\s+order)\s+B\s*(\d+)\s*(?:-|–|—|to)\s*B\s*(\d+)\b", text, flags=re.I):
        levels.extend(_expand_basement_range(f"B{end}", f"B{start}"))
    # Basements and named levels.
    for token in re.findall(r"\b(?:B\s*\d+|LGF|lower ground floor|lower ground|GF|ground floor|roof|plant)\b", text, flags=re.I):
        levels.append(_level_label(token))
    # Individual levels not already captured.
    for token in re.findall(r"\b(?:L|Level|Lvl)\s*\d+\b", text, flags=re.I):
        levels.append(_level_label(token))
    # Mezzanine references. Treat 'L5, L6, L7 Mezzanine' and 'L5-L7 Mezzanine' as L5/L6/L7 Mezzanine.
    if re.search(r"mezz|mezzanine", lower):
        for start, end in re.findall(r"\bL\s*(\d+)\s*(?:-|–|—|to)\s*L?\s*(\d+)\s*(?:mez|mezz|mezzanine)\b", text, flags=re.I):
            for num in range(int(start), int(end) + (1 if int(end) >= int(start) else -1), 1 if int(end) >= int(start) else -1):
                levels.append(f"L{num} Mezzanine")
        before_mezz = re.findall(r"((?:L\s*\d+\s*,?\s*)+)\s*(?:mez|mezz|mezzanine)", text, flags=re.I)
        for chunk in before_mezz:
            for num in re.findall(r"L\s*(\d+)", chunk, flags=re.I):
                levels.append(f"L{int(num)} Mezzanine")
        for num in re.findall(r"\b(?:L|Level|Lvl)\s*(\d+)\s*(?:mez|mezz|mezzanine)\b", text, flags=re.I):
            levels.append(f"L{int(num)} Mezzanine")
    excluded = set(x.lower() for x in _parse_level_exclusions(prompt))
    # Preferred ordering for common project levels.
    def order_key(level: str):
        lv = level.lower().replace(" ", "")
        if lv.startswith("b") and lv[1:].isdigit(): return (0, -int(lv[1:]), 0)
        if lv == "lgf": return (1, 0, 0)
        if lv == "gf": return (2, 0, 0)
        m = re.match(r"l(\d+)(mezzanine)?", lv)
        if m: return (3, int(m.group(1)), 1 if m.group(2) else 0)
        if lv == "plant": return (4, 0, 0)
        if lv == "roof": return (5, 0, 0)
        return (6, lv, 0)
    deduped = [lv for lv in _dedupe_keep_order(levels) if lv.lower() not in excluded]
    if selected_basement_order:
        selected_keys = {lv.lower() for lv in selected_basement_order}
        ordered_basements = [lv for lv in selected_basement_order if lv.lower() in {x.lower() for x in deduped}]
        rest = [lv for lv in deduped if lv.lower() not in selected_keys]
        return _dedupe_keep_order(ordered_basements + sorted(rest, key=order_key))
    return sorted(deduped, key=order_key)


def _zone_role_label(role: str, zone_index: int) -> str:
    labels = {
        "milestone": "Milestone / Stage",
        "location": "Location / Split",
        "level": "Level",
        "tower": "Tower / Building",
        "area": "Area / Lot",
        "member_type": "Member Type",
        "type": "Type",
    }
    return labels.get(role, f"Zone {zone_index}")


def _head_label_from_number(number: int) -> str:
    try:
        n = int(number)
    except Exception:
        n = 3
    n = max(1, min(4, n))
    return f"Head{n}"


def _head_number_from_label(label: Any, fallback: int = 3) -> int:
    m = re.search(r"head\s*([1-4])", str(label or ""), flags=re.I)
    return int(m.group(1)) if m else fallback


def _next_head_label(label: Any) -> str:
    n = _head_number_from_label(label, 3)
    return _head_label_from_number(min(4, n + 1))


def parse_explicit_hierarchy_head_from_prompt(prompt: str) -> Optional[int]:
    """Return user-stated first hierarchy Head level, e.g. 'as Head 1'.

    v4.4.4.6: this removes the hidden Head3/Head4 fallback. The parser only
    reacts to explicit hierarchy wording so random report references to Head rows
    do not silently change the Builder layout.
    """
    raw = str(prompt or "")
    patterns = [
        r"\bzone\s*\d+\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as)?\s*head\s*([1-4])\b",
        r"\bzone\s*\d+\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as)?\s*h\s*([1-4])\b",
        r"\b(?:as|set\s+as|use\s+as)\s+head\s*([1-4])\b",
        r"\bstart(?:ing)?\s+(?:at|from|with)?\s*head\s*([1-4])\b",
        r"\bbegin(?:ning)?\s+(?:at|from|with)?\s*head\s*([1-4])\b",
        r"\bfirst\s+(?:hierarchy\s+)?(?:zone|group|heading).*?head\s*([1-4])\b",
    ]
    for pat in patterns:
        m = re.search(pat, raw, flags=re.I)
        if m:
            return int(m.group(1))
    return None



# Jarvis v4.4.4.11 — Multi-zone hierarchy, routing priority and ambiguity guards.
def parse_zone_head_assignments(prompt: str) -> Dict[int, int]:
    """Return explicit zone-to-head assignments such as Zone 1 as Head1."""
    out: Dict[int, int] = {}
    raw = str(prompt or "")
    patterns = [
        (r"\bzone\s*(\d+)\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as|for)?\s*head\s*([1-4])\b", "zone_first"),
        (r"\bzone\s*(\d+)\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as|for)?\s*h\s*([1-4])\b", "zone_first"),
        (r"\bhead\s*([1-4])\s*(?:for|to|as|on)?\s*zone\s*(\d+)\b", "head_first"),
        (r"\bh\s*([1-4])\s*(?:for|to|as|on)?\s*zone\s*(\d+)\b", "head_first"),
    ]
    for pat, mode in patterns:
        for first_raw, second_raw in re.findall(pat, raw, flags=re.I):
            if mode == "head_first":
                head_raw, idx_raw = first_raw, second_raw
            else:
                idx_raw, head_raw = first_raw, second_raw
            try:
                idx = int(idx_raw); head = int(head_raw)
            except Exception:
                continue
            if 1 <= idx <= 8 and 1 <= head <= 4:
                out[idx] = head
    return out


def parse_other_zone_head_assignment(prompt: str) -> Optional[int]:
    raw = str(prompt or "")
    patterns = [
        r"\bhead\s*([1-4])\s*(?:for|to|as|on)?\s*(?:the\s+)?other\b",
        r"\b(?:the\s+)?other\s*(?:zone|one)?\s*(?:as|to|in|at|=)?\s*head\s*([1-4])\b",
    ]
    for pat in patterns:
        m = re.search(pat, raw, flags=re.I)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                return None
    return None


def parse_dimension_plus_zone_head_assignments(prompt: str) -> Dict[int, int]:
    """Return zones that are explicitly paired with detected type/dimension as a heading.

    Example: 'detected door type plus Zone 3 as Head3' means Zone 3 is not a
    standalone hierarchy zone; it is appended to the detected dimension/type at Head3.
    """
    out: Dict[int, int] = {}
    raw = str(prompt or "")
    pats = [
        r"\b(?:detected\s+)?(?:door\s+)?(?:type|dimension)\s*(?:/|and|plus|\+)\s*zone\s*(\d+).*?head\s*([1-4])\b",
        r"\bzone\s*(\d+)\s*(?:/|and|plus|\+)\s*(?:detected\s+)?(?:door\s+)?(?:type|dimension).*?head\s*([1-4])\b",
    ]
    for pat in pats:
        for idx_raw, head_raw in re.findall(pat, raw, flags=re.I):
            try:
                idx = int(idx_raw); head = int(head_raw)
            except Exception:
                continue
            if 1 <= idx <= 8 and 1 <= head <= 4:
                out[idx] = head
    return out


def _first_free_zone_index(used: List[int], preferred: int = 3) -> int:
    used_set = {int(x) for x in used if str(x).isdigit() or isinstance(x, int)}
    for idx in range(max(1, preferred), 9):
        if idx not in used_set:
            return idx
    for idx in range(1, 9):
        if idx not in used_set:
            return idx
    return preferred


def _project_uses_multizone_tree(project_setup: Optional[Dict[str, Any]]) -> bool:
    return isinstance(project_setup, dict) and bool(project_setup.get("hierarchy_zones"))


def _hierarchy_zone_products(hierarchy_zones: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    value_lists: List[List[Dict[str, Any]]] = []
    for zone in hierarchy_zones or []:
        try:
            idx = int(zone.get("zone_index"))
        except Exception:
            continue
        head = str(zone.get("head") or "Head3")
        role = zone.get("role") or infer_zone_role(idx, zone.get("values") or [], "")
        vals = [_clean_zone_value(v) for v in (zone.get("values") or []) if _clean_zone_value(v)]
        if vals:
            value_lists.append([{"zone_index": idx, "value": v, "head": head, "role": role} for v in vals])
    if not value_lists:
        return [[]]
    return [list(prod) for prod in product(*value_lists)]


def is_compare_boq_command(prompt: str) -> bool:
    text = _router_text(prompt)
    text = re.sub(r"^new\s+command\s*:\s*", "", text, flags=re.I).strip()
    return bool(
        _has_any(text, ["compare", "comparison", "discrepancy", "discrepancies", "measured sheet", "to find", "base sheet against", "base boq", "boq compare"]) and
        not _has_any(text, ["build base", "base sheet with", "create a boq base", "costx base"])
    )


def is_ambiguous_reference_message(prompt: str) -> bool:
    text = _router_text(prompt)
    return bool(re.search(r"\b(the\s+)?other\s+one\b|\bthat\s+one\b|\bthis\s+one\b|\bformer\b|\blatter\b", text, flags=re.I))


def ambiguous_reference_clarification(prompt: str, active_plan: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    project = (active_plan or {}).get("project_zone_hierarchy") or ((active_plan or {}).get("current_work_setup") or {}).get("project_zone_hierarchy") or {}
    candidates: List[str] = []
    if isinstance(project, dict):
        # Prefer non-level project values for ambiguous "other one" choices. Levels
        # are included only after zone/group values so Jarvis does not hard-code or
        # over-focus on levels.
        for z in (project.get("dynamic_zones") or []):
            if not isinstance(z, dict) or z.get("role") == "level":
                continue
            for v in (z.get("values") or []):
                clean = _clean_zone_value(v)
                if clean:
                    candidates.append(clean)
        for v in project.get("level_values") or []:
            clean = _level_label(v)
            if clean:
                candidates.append(clean)
    candidates = _dedupe_keep_order(candidates)[:10]
    options: List[Dict[str, str]] = []
    removing = _is_remove_action(prompt)
    reorder = _is_reorder_action(prompt) or not removing
    if candidates:
        if removing:
            for val in candidates[:8]:
                options.append({"label": f"Remove {val}", "reply": f"Confirm remove {val}"})
            question = "I’m not sure what “that one” refers to. Which active plan value do you want to remove?"
        else:
            for val in candidates[:8]:
                options.append({"label": f"Make {val} first", "reply": f"Make {val} first in the active Builder plan"})
            question = "I’m not sure what “the other one” refers to. Which active plan value should move first?"
    else:
        question = "I’m not sure what “the other one” refers to. Are you referring to the current Builder plan, the previous command, or a new command?"
        options.append({"label": "Continue previous task", "reply": "Continue previous task"})
    options.extend([
        {"label": "Start new command", "reply": "new command: " + str(prompt or "")},
        {"label": "Cancel", "reply": "Cancel"},
    ])
    return make_clarification(
        "ambiguous_reference_guard",
        question,
        prompt,
        options,
        {"active_project_zone_hierarchy": project, "dynamic_candidates": candidates},
    )

def needs_ambiguous_zone_mapping_clarification(prompt: str) -> bool:
    text = _router_text(prompt)
    has_stage = bool(re.search(r"\bstage\s*\d+\b|\bstages?\b", text, flags=re.I))
    has_location = _has_any(text, ["internal", "external"])
    has_level = bool(parse_levels_from_prompt(prompt)) or _has_any(text, ["level", "levels"])
    has_zone_number = bool(re.search(r"\bzone\s*\d+\b|\bzc\s*\d+\b", text, flags=re.I))
    has_hierarchy = bool(parse_zone_head_assignments(prompt) or parse_dimension_plus_zone_head_assignments(prompt))
    return bool(has_stage and has_location and has_level and not has_zone_number and not has_hierarchy)


def ambiguous_zone_mapping_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "ambiguous_zone_mapping",
        "I detected Stage and Internal/External values, but I do not know their CostX zone numbers or heading order. Which zone mapping should I use?",
        prompt,
        [
            {"label": "Zone 2 = Stage; Zone 1 = Internal/External", "reply": "Use Zone 2 for Stage 1 and Stage 2; use Zone 1 for Internal and External; ask me for heading order if needed"},
            {"label": "Zone 1 = Stage; Zone 2 = Internal/External", "reply": "Use Zone 1 for Stage 1 and Stage 2; use Zone 2 for Internal and External; ask me for heading order if needed"},
            {"label": "I will describe custom mapping", "reply": "I will describe a custom hierarchy"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
    )

def detect_project_zone_hierarchy_intent(prompt: str) -> Optional[Dict[str, Any]]:
    """Detect run-only project hierarchy without hard-coding zone roles.

    v4.4.4.11 adds a multi-zone hierarchy tree. Examples:
    - Zone 2 as Head1; detected type + Zone 1 as Head2; levels as rows.
    - Zone 1 as Head1; Zone 2 as Head2; detected type + Zone 3 as Head3;
      levels move to the next free token index, usually Zone 4.
    """
    text = _router_text(prompt)
    dynamic_zones = parse_dynamic_zone_values_from_prompt(prompt)
    level_values = parse_levels_from_prompt(prompt)
    mezzanine_token_alias = "Mezz" if re.search(r"\buse\s+mezz\s+instead\s+of\s+mezzanine\b|\bmezz\s+instead\s+of\s+mezzanine\b", str(prompt or ""), flags=re.I) else ""
    if mezzanine_token_alias:
        level_values = [re.sub(r"\s+Mezzanine\b", " Mezz", str(v), flags=re.I) for v in level_values]
    explicit_start_head_number = parse_explicit_hierarchy_head_from_prompt(prompt)
    head_assignments = parse_zone_head_assignments(prompt)
    dimension_plus_assignments = parse_dimension_plus_zone_head_assignments(prompt)
    has_explicit_start_head = explicit_start_head_number is not None or bool(head_assignments)
    no_format = _has_any(text, ["do not format", "don't format", "no format", "base sheet only", "not format yet", "do not format yet"])
    based_on = "wall_types" if _has_any(text, ["wall type", "wall types", "based on wall"]) else "detected_dimensions"
    preserve_source_explicit = _has_any(text, ["preserve source zones", "keep source zones", "preserve detected zones", "keep detected zones"])

    if not (dynamic_zones or level_values or has_explicit_start_head or no_format):
        return None

    non_level_zones = [z for z in dynamic_zones if z.get("role") not in {"level"}]
    zone_by_idx: Dict[int, Dict[str, Any]] = {}
    for z in non_level_zones:
        try:
            zone_by_idx[int(z.get("zone_index"))] = z
        except Exception:
            continue

    # Explicit multi-zone hierarchy tree: zones assigned to heads become separate
    # heading rows unless the same zone is explicitly paired with detected type.
    hierarchy_zones: List[Dict[str, Any]] = []
    dimension_combo_zones: List[Dict[str, Any]] = []
    if head_assignments:
        for idx, head_num in sorted(head_assignments.items(), key=lambda item: item[1]):
            zone = zone_by_idx.get(idx)
            if not zone:
                continue
            if idx in dimension_plus_assignments:
                continue
            hierarchy_zones.append({
                "zone_index": idx,
                "role": zone.get("role"),
                "values": zone.get("values") or [],
                "head": _head_label_from_number(head_num),
            })
        for idx, head_num in sorted(dimension_plus_assignments.items(), key=lambda item: item[1]):
            zone = zone_by_idx.get(idx)
            if zone:
                dimension_combo_zones.append({"zone_index": idx, "role": zone.get("role"), "values": zone.get("values") or []})
        # Any non-level zones not explicitly assigned become dimension suffix zones
        # when at least one hierarchy zone is clear. This preserves older commands
        # like "Zone2 in Head2 and Zone1" where Zone1 belongs beside the detected type.
        assigned = {z.get("zone_index") for z in hierarchy_zones} | set(dimension_plus_assignments.keys())
        for zone in non_level_zones:
            try:
                idx = int(zone.get("zone_index"))
            except Exception:
                continue
            if idx not in assigned:
                dimension_combo_zones.append({"zone_index": idx, "role": zone.get("role"), "values": zone.get("values") or []})

    option_b = _has_any(text, ["use hierarchy option b", "use option b", "option b"])
    if not hierarchy_zones:
        default_primary_zone = next((z for z in non_level_zones if z.get("role") in {"milestone", "tower", "area"}), None)
        if option_b and len(non_level_zones) > 1:
            head3_zone = next((z for z in non_level_zones if z is not default_primary_zone), non_level_zones[0])
        else:
            head3_zone = default_primary_zone
        if not head3_zone and dynamic_zones and has_explicit_start_head:
            head3_zone = dynamic_zones[0]
        if head3_zone:
            start_head_number = explicit_start_head_number if explicit_start_head_number is not None else 3
            hierarchy_zones = [{
                "zone_index": int(head3_zone.get("zone_index")),
                "role": head3_zone.get("role"),
                "values": head3_zone.get("values") or [],
                "head": _head_label_from_number(start_head_number),
            }]
            dimension_combo_zones = [
                {"zone_index": int(z.get("zone_index")), "role": z.get("role"), "values": z.get("values") or []}
                for z in non_level_zones if z is not head3_zone
            ][:2]

    used_zone_indices = []
    for z in dynamic_zones:
        try:
            if z.get("role") != "level":
                used_zone_indices.append(int(z.get("zone_index")))
        except Exception:
            pass
    explicit_level_zone_index = None
    m_level_zone = re.search(r"\blevels?\s+(?:as|in|at|under|within)?\s*zone\s*(\d+)\b|\bzone\s*(\d+)\s*(?:is|are|=|:)\s*(?:levels?|l\d+|gf|roof)", str(prompt or ""), flags=re.I)
    if m_level_zone:
        try:
            explicit_level_zone_index = int(m_level_zone.group(1) or m_level_zone.group(2))
        except Exception:
            explicit_level_zone_index = None
    level_zone = next((z for z in dynamic_zones if z.get("role") == "level"), None)
    if explicit_level_zone_index:
        level_zone_index = explicit_level_zone_index
    elif level_zone:
        try:
            level_zone_index = int(level_zone.get("zone_index"))
        except Exception:
            level_zone_index = _first_free_zone_index(used_zone_indices, 3)
        if level_zone.get("values") and not level_values:
            level_values = [_level_label(v) for v in (level_zone.get("values") or [])]
    else:
        # Dynamic Level Zone Allocator: if Zone 3 is already used by another
        # combo such as Internal/External, levels must move to Zone 4.
        level_zone_index = _first_free_zone_index(used_zone_indices, 3)

    hierarchy_zones = [z for z in hierarchy_zones if z.get("values")]
    first_zone = hierarchy_zones[0] if hierarchy_zones else None
    head3_values = _dedupe_keep_order([_clean_zone_value(v) for v in ((first_zone or {}).get("values") or [])])
    primary_head = (first_zone or {}).get("head") or _head_label_from_number(explicit_start_head_number or 3)
    # Dimension head is explicit when paired with detected type; otherwise next after last hierarchy head.
    if dimension_plus_assignments:
        dimension_head = _head_label_from_number(min(dimension_plus_assignments.values()))
    elif hierarchy_zones:
        last_head_num = max(_head_number_from_label(z.get("head"), 3) for z in hierarchy_zones)
        dimension_head = _head_label_from_number(min(4, last_head_num + 1))
    else:
        dimension_head = _next_head_label(primary_head)

    enabled = bool(hierarchy_zones and level_values and not preserve_source_explicit)
    hierarchy_parts: List[str] = []
    for z in hierarchy_zones:
        hierarchy_parts.append(f"Zone {z.get('zone_index')} ({_zone_role_label(z.get('role'), z.get('zone_index'))}) = {z.get('head')}")
    if dimension_combo_zones:
        combo_names = ", ".join([f"Zone {z.get('zone_index')}" for z in dimension_combo_zones])
        hierarchy_parts.append(f"Detected dimension/type + {combo_names} = {dimension_head}")
    else:
        hierarchy_parts.append(f"Detected dimension/type = {dimension_head}")
    hierarchy_parts.append(f"Levels = formula rows (Zone {level_zone_index})")
    hierarchy_description = "; ".join(hierarchy_parts)
    head4_combo_label = " + ".join([f"Zone {z.get('zone_index')} ({_zone_role_label(z.get('role'), z.get('zone_index'))})" for z in dimension_combo_zones]) or "None"

    first_idx = int(first_zone.get("zone_index")) if first_zone else None
    return {
        "enabled": enabled,
        "run_only": True,
        "dynamic_zones": dynamic_zones,
        "hierarchy_zones": hierarchy_zones,
        "dimension_combo_zones": dimension_combo_zones,
        "zone1_values": head3_values if first_idx == 1 else [],
        "level_values": _dedupe_keep_order(level_values),
        "mezzanine_token_alias": mezzanine_token_alias,
        "start_head": primary_head,
        "primary_head": primary_head,
        "dimension_head": dimension_head,
        "explicit_start_head": bool(has_explicit_start_head),
        "head3_source": "dynamic_zone" if first_zone else "none",
        "head3_zone_index": first_idx,
        "head3_role": (first_zone or {}).get("role"),
        "head3_label": f"Zone {first_idx} ({_zone_role_label((first_zone or {}).get('role'), first_idx or 1)})" if first_zone else "Head3 zone",
        "head3_values": head3_values,
        "head4_source": "detected_dimension_plus_zones" if dimension_combo_zones else "detected_dimension",
        "head4_combo_zones": [{"zone_index": int(z.get("zone_index")), "role": z.get("role"), "values": z.get("values") or []} for z in dimension_combo_zones],
        "head4_combo_label": head4_combo_label,
        "levels_source": "parsed_command" if level_values else "workspace_default",
        "level_zone_index": level_zone_index,
        "based_on": based_on,
        "formatting": "builder_base_only" if no_format else "builder_base_only",
        "zone_token_mode": "preserve_source" if preserve_source_explicit else "rebuild_run_only",
        "confirmation_needed": bool((dynamic_zones or level_values) and not preserve_source_explicit and not has_explicit_start_head),
        "needs_hierarchy_choice": bool(dynamic_zones and not hierarchy_zones),
        "hierarchy_description": hierarchy_description,
        "hierarchy_summary_lines": dynamic_hierarchy_summary_lines({"hierarchy_zones": hierarchy_zones, "dimension_combo_zones": dimension_combo_zones, "head4_combo_zones": dimension_combo_zones, "dimension_head": dimension_head, "level_values": _dedupe_keep_order(level_values), "level_zone_index": level_zone_index}),
    }


def _combo_zone_products(combo_zones: List[Dict[str, Any]]) -> List[tuple[str, List[tuple[int, str]]]]:
    if not combo_zones:
        return [("", [])]
    value_lists: List[List[tuple[int, str]]] = []
    for zone in combo_zones:
        try:
            idx = int(zone.get("zone_index"))
        except Exception:
            continue
        vals = [_clean_zone_value(v) for v in (zone.get("values") or []) if _clean_zone_value(v)]
        if vals:
            value_lists.append([(idx, v) for v in vals])
    if not value_lists:
        return [("", [])]
    combos: List[tuple[str, List[tuple[int, str]]]] = []
    for prod_vals in product(*value_lists):
        parts = list(prod_vals)
        label = " - ".join(v for _, v in parts)
        combos.append((label, parts))
    return combos or [("", [])]


def build_project_builder_levels(project_setup: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Build run-only Builder level rows for dynamic project hierarchy.

    v4.4.4.11 supports a multi-zone hierarchy tree. Each Builder row carries:
    - token_parts: every active hierarchy/combo zone plus the level zone
    - hierarchy_path: the heading rows to write before the dimension heading
    - head4_suffix/dimension_suffix: zones paired with the detected dimension/type
    """
    levels = project_setup.get("level_values") or []
    try:
        level_zone_index = int(project_setup.get("level_zone_index") or 3)
    except Exception:
        level_zone_index = 3
    rows: List[Dict[str, Any]] = []

    hierarchy_zones = project_setup.get("hierarchy_zones") or []
    if hierarchy_zones:
        dimension_combo_zones = project_setup.get("dimension_combo_zones") or project_setup.get("head4_combo_zones") or []
        hierarchy_products = _hierarchy_zone_products(hierarchy_zones)
        combo_products = _combo_zone_products(dimension_combo_zones)
        first_zone_idx = None
        try:
            first_zone_idx = int(hierarchy_zones[0].get("zone_index")) if hierarchy_zones else None
        except Exception:
            first_zone_idx = None
        for path in hierarchy_products:
            for combo_label, combo_parts in combo_products:
                for level in levels:
                    level_code = _level_label_for_project(str(level), project_setup)
                    token_pairs: List[tuple[int, str]] = []
                    for node in path:
                        token_pairs.append((int(node.get("zone_index")), _clean_zone_value(node.get("value"))))
                    for idx, value in combo_parts:
                        token_pairs.append((idx, _clean_zone_value(value)))
                    token_pairs.append((level_zone_index, level_code))
                    token_bits = [f"{idx}|{value}" for idx, value in sorted(token_pairs, key=lambda pair: pair[0])]
                    primary_value = str(path[0].get("value")) if path else ""
                    rows.append({
                        "zone_index": first_zone_idx or 1,
                        "zone_name": primary_value,
                        "level_index": level_zone_index,
                        "level_code": level_code,
                        "description": level_code,
                        "token_parts": sanitize_costx_token_parts(";".join(token_bits)),
                        "head3_group": primary_value,
                        "head4_suffix": combo_label,
                        "dimension_suffix": combo_label,
                        "hierarchy_path": path,
                        "run_only": True,
                    })
        return rows

    # Backward-compatible one-primary-zone behavior.
    head3_values = project_setup.get("head3_values") or project_setup.get("zone1_values") or []
    try:
        head3_zone_index = int(project_setup.get("head3_zone_index") or 1)
    except Exception:
        head3_zone_index = 1
    combo_zones = project_setup.get("head4_combo_zones") or []
    combo_products = _combo_zone_products(combo_zones)
    for head3_value in head3_values:
        h3_clean = _clean_zone_value(str(head3_value))
        for combo_label, combo_parts in combo_products:
            for level in levels:
                level_code = _level_label_for_project(str(level), project_setup)
                token_pairs = [(head3_zone_index, h3_clean)]
                for idx, value in combo_parts:
                    token_pairs.append((idx, _clean_zone_value(value)))
                token_pairs.append((level_zone_index, level_code))
                token_bits = [f"{idx}|{value}" for idx, value in sorted(token_pairs, key=lambda pair: pair[0])]
                rows.append({
                    "zone_index": head3_zone_index,
                    "zone_name": h3_clean,
                    "level_index": level_zone_index,
                    "level_code": level_code,
                    "description": level_code,
                    "token_parts": sanitize_costx_token_parts(";".join(token_bits)),
                    "head3_group": h3_clean,
                    "head4_suffix": combo_label,
                    "run_only": True,
                })
    return rows


# Jarvis v4.4.4.10 — Dynamic Query Vision / Right Track Guard helpers.
def _deepcopy_json(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value))
    except Exception:
        return dict(value) if isinstance(value, dict) else value


def _has_active_builder_plan(plan: Any) -> bool:
    return isinstance(plan, dict) and bool(plan.get("current_work_setup") or plan.get("project_zone_hierarchy") or plan.get("builder_levels"))


def classify_current_query_intent(prompt: str, pending: Optional[Dict[str, Any]] = None, active_plan: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    text = _router_text(prompt)
    if not text:
        return {"intent": "empty", "confidence": 0, "reason": "No user text."}
    if text.startswith("new command:") or _has_any(text, ["start fresh", "cancel current", "new task"]):
        return {"intent": "new_command", "confidence": 96, "reason": "User explicitly requested a new command."}
    if isinstance(pending, dict) and pending.get("type"):
        return {"intent": "clarification_answer", "confidence": 92, "reason": f"Jarvis is waiting for {pending.get('type')}."}
    if _has_active_builder_plan(active_plan) and is_active_builder_plan_amendment(prompt):
        return {"intent": "active_plan_amendment", "confidence": 90, "reason": "Short add/remove/change wording detected while a Builder plan is active."}
    if _has_active_builder_plan(active_plan) and len(text.split()) <= 12 and _has_any(text, ["stage", "zone", "head", "level", "l1", "l2", "l3", "l4", "l5", "internal", "external", "concrete", "reo", "steel", "metalwork", "door", "window", "wall", "partition", "finish"]):
        return {"intent": "possible_active_plan_edit", "confidence": 72, "reason": "Short project/setup/trade phrase could be an edit to the active Builder plan."}
    if looks_like_fresh_command_backend(text):
        return {"intent": "new_command", "confidence": 82, "reason": "Command-style wording detected."}
    return {"intent": "general_or_new", "confidence": 58, "reason": "No active-plan evidence strong enough."}


def looks_like_fresh_command_backend(text: str) -> bool:
    text_l = _router_text(text)
    if text_l.startswith("new command:"):
        return True
    starters = ["create", "build", "make", "generate", "format", "compare", "write", "prepare", "run"]
    return len(text_l) > 18 and any(text_l.startswith(w + " ") for w in starters)


def is_active_builder_plan_amendment(prompt: str) -> bool:
    text = _router_text(prompt)
    if not text:
        return False
    # Explicit fresh commands must remain fresh commands even if they mention
    # Zone/Head syntax. Active-plan amendment priority only applies to follow-up
    # replies without the new-command reset.
    if text.startswith("new command:"):
        return False
    fresh_reorder_like = _is_reorder_action(text) if '_is_reorder_action' in globals() else bool(re.search(r"\b(?:make|put|move)\b.+\bfirst\b", text, flags=re.I))
    if looks_like_fresh_command_backend(text) and not fresh_reorder_like:
        return False
    # v4.5.1.9 context-priority guard: short hierarchy replies such as
    # "Zone 1 at Head2" or "start at Head2" are Builder amendments when a
    # Builder plan is active. They must not fall through to the generic
    # Formatter/Local AI router simply because they contain "Head2".
    try:
        if parse_zone_head_assignments(prompt) or parse_other_zone_head_assignment(prompt) or parse_explicit_hierarchy_head_from_prompt(prompt):
            return True
    except Exception:
        pass
    if is_zone_slot_only_update(prompt):
        return True
    if re.search(r"\b(?:use|change|switch|set|make)\b.*\b(?:instead|to|as)?\b.*\b(?:concrete|reo|reinforcement|door|doors|window|windows|wall|walls|partition|partitions|steel|metalwork|finish|finishes)\b", str(prompt or ""), flags=re.I):
        return True
    if re.search(r"\b(?:add|include|use|set)?\s*zone\s*\d+\s*[:=]", str(prompt or ""), flags=re.I):
        return True
    # v4.5.1.24 Bug-2 fix: "use zone 2 and zone 4" / "zone 2 and zone 4" zone selection commands.
    if re.search(r"\bzone\s*\d+\s+and\s+zone\s*\d+", text, flags=re.I):
        return True
    # v4.5.1.24.2C: Mezz/Mezzanine alias direction commands, including
    # "change Mezz to Mezzanine instead", are active Builder amendments.
    if _parse_mezzanine_alias_direction(prompt):
        return True
    if re.search(r"\bmezz(?:anine)?\b", text, flags=re.I) and re.search(r"\b(?:instead\s+of|instead|as|use|to|with|change|replace|rename)\b", text, flags=re.I):
        return True
    if re.search(r"\binstead\s+of\b", text, flags=re.I) and _has_any(text, ["mezzanine", "mezz", "level", "formula", "zone", "gf", "roof", "basement"]):
        return True
    if re.search(r"(?:^|[\n;])\s*[1-8]\s*[:=]\s*\S", str(prompt or ""), flags=re.I):
        return True
    if re.search(r"\bzone\s*\d+\b", text, flags=re.I) and re.search(r"\bstage\s*\d+", text, flags=re.I):
        return True
    if re.search(r"\b(?:base|based)\s+(?:on\s+)?(?:steel|metalwork|wall|walls|partition|door|doors|window|windows|concrete|reo|finish|finishes)\b", text, flags=re.I):
        return True
    # v4.5.1.10: formula-mode replies are active Builder amendments, not Local AI.
    if text in {"detected", "use detected", "detected formula", "detected formulas", "default formula", "default formula detected", "use detected formula as is"} or re.search(r"\b(?:use\s+)?(?:detected|preserve|keep)\s+(?:formula|formulas|function|functions)\b|\bdetected\s+formula\b|\bdefault\s+formula\s+detected\b", text, flags=re.I):
        return True
    # v4.5.1.25: short count/unit confirmations belong to the active Builder
    # task. Do not route "Use Count" / "Unit no" to Local AI when a plan exists.
    if _is_builder_count_or_unit_confirmation(prompt):
        return True
    # v4.5.1.10: basement order replies such as "B5 first" answer Builder level-order clarification.
    if re.search(r"\bb\d+\s+(?:first|last)\b|\b(?:first|last)\s+b\d+\b", text, flags=re.I):
        return True
    # Do not treat full fresh commands as amendments, except short reorder/edit
    # phrases such as "make External first" which previously routed to Local AI.
    reorder_like = _is_reorder_action(text) if '_is_reorder_action' in globals() else bool(re.search(r"\b(?:make|put|move)\b.+\bfirst\b", text, flags=re.I))
    if looks_like_fresh_command_backend(text) and not reorder_like:
        return False
    amendment_words = [
        "also", "remove", "exclude", "omit", "delete", "leave out", "take away", "do not include",
        "add", "include", "bring back", "add back", "restore", "change", "make", "update", "replace",
        "instead", "swap", "retain only", "only", "put", "move", "first", "last", "before", "after", "above", "below",
    ]
    target_words = [
        "l1", "l2", "l3", "l4", "l5", "l6", "l7", "l8", "l9", "l10", "b1", "b2", "b3", "b4", "b5", "level", "levels", "roof", "gf", "basement",
        "stage", "zone", "head", "internal", "external", "building", "tower", "package", "wing", "east", "west",
        "door", "doors", "window", "windows", "count", "counts", "no", "number",
        "formula", "formulas", "function", "functions", "detected", "default", "preserve",
        "current arrangement", "split", "latter", "former", "other one", "that one",
    ]
    return _has_any(text, amendment_words) and _has_any(text, target_words)


def _extract_stage_values(text: str) -> List[str]:
    vals = []
    for m in re.finditer(r"\bstage\s*(\d+[a-z]?)\b", str(text or ""), flags=re.I):
        vals.append("Stage " + m.group(1))
    return _dedupe_keep_order([v.replace("  ", " ").strip() for v in vals])


def _extract_location_values(text: str) -> List[str]:
    vals = []
    raw = _router_text(text)
    if re.search(r"\bexternal\b", raw, flags=re.I):
        vals.append("External")
    if re.search(r"\binternal\b", raw, flags=re.I):
        vals.append("Internal")
    return vals




def _is_detected_formula_mode_reply(text: str) -> bool:
    t = _router_text(text)
    return bool(t in {"detected", "use detected", "detected formula", "detected formulas", "default formula detected", "use detected formula as is", "keep detected"} or re.search(r"\b(?:use\s+)?(?:detected|preserve|keep)\s+(?:formula|formulas|function|functions)\b|\bdetected\s+formula\b|\bdefault\s+formula\s+detected\b|\bsame\s+(?:formula|function)s?\b", t, flags=re.I))


def _is_force_default_formula_reply(text: str) -> bool:
    t = _router_text(text)
    return bool(re.search(r"\bforce\s+default\b|\buse\s+default\s+(?:formula|function)\b|\bdefault\s+(?:function|formula)\s+only\b", t, flags=re.I))


def _builder_short_edit_lines(text: str) -> List[str]:
    """Return safe one-line Builder edit clauses from a short active reply.

    v4.5.1.26.1: users often send compact multi-line replies such as
    "Use Count\nUnit no". Split only on line/semicolon boundaries and keep this
    helper conservative so full commands still route normally.
    """
    raw = str(text or "").strip()
    if not raw:
        return []
    parts = [p.strip() for p in re.split(r"[\r\n;]+", raw) if p and p.strip()]
    return parts or [raw]


def _is_single_builder_count_or_unit_confirmation(text: str) -> bool:
    t = _router_text(text)
    if not t:
        return False
    if re.fullmatch(r"(?:use\s+)?(?:count|counts|xgetcount|xgetnumber|number)", t, flags=re.I):
        return True
    if re.fullmatch(r"(?:unit|use\s+unit|set\s+unit|use)\s+(?:no|m2|m3|m|t|kg|lm|nr)", t, flags=re.I):
        return True
    return False


def _is_builder_combined_count_or_unit_confirmation(text: str) -> bool:
    """Narrow same-line active Builder edit aliases.

    v4.5.1.26.2: this is intentionally small and is only called from active
    Builder context so general chat does not get pulled into Builder.
    """
    t = _router_text(text)
    allowed = {
        "use count unit no",
        "use xgetcount unit no",
        "use steel surface area unit m2",
    }
    return t in allowed


def _is_builder_count_or_unit_confirmation(text: str) -> bool:
    """v4.5.1.25/26.1/26.2 active Builder short-reply guard.

    These terse replies are common while a Builder plan is active and should
    confirm/amend the current setup instead of falling through to Local AI.
    v4.5.1.26.1 supports multiple safe short edits in one message.
    v4.5.1.26.2 also supports a few compact same-line aliases.
    """
    if _is_builder_combined_count_or_unit_confirmation(text):
        return True
    lines = _builder_short_edit_lines(text)
    if not lines:
        return False
    return all(_is_single_builder_count_or_unit_confirmation(line) for line in lines)


def _apply_single_builder_count_or_unit_confirmation_to_plan(plan: Dict[str, Any], text: str) -> List[str]:
    setup = plan.setdefault("current_work_setup", {})
    changes: List[str] = []
    t = _router_text(text)
    if re.fullmatch(r"(?:use\s+)?(?:count|counts|xgetcount|number)", t, flags=re.I):
        setup.update({
            "default_costx_function": "XGETCOUNT",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "no",
        })
        plan.update({"default_function": "XGETCOUNT", "function_mode": "force_default", "custom_quantity": "", "unit": "no"})
        changes.append("Confirmed XGETCOUNT with unit no for the active Builder plan.")
    elif re.fullmatch(r"(?:use\s+)?xgetnumber", t, flags=re.I):
        setup.update({
            "default_costx_function": "XGETNUMBER",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "no",
        })
        plan.update({"default_function": "XGETNUMBER", "function_mode": "force_default", "custom_quantity": "", "unit": "no"})
        changes.append("Confirmed XGETNUMBER with unit no for the active Builder plan.")
    m = re.fullmatch(r"(?:unit|use\s+unit|set\s+unit|use)\s+(no|m2|m3|m|t|kg|lm|nr)", t, flags=re.I)
    if m:
        unit = canonical_builder_unit(m.group(1))
        setup["expected_unit"] = unit
        if setup.get("default_costx_function") != "XGETCUSTOM":
            setup["custom_quantity_unit"] = ""
        plan["unit"] = unit
        changes.append(f"Confirmed active Builder unit as {unit}.")
    return changes


def _apply_builder_count_or_unit_confirmation_to_plan(plan: Dict[str, Any], prompt: str) -> List[str]:
    """Apply safe short count/unit confirmations to the active Builder setup."""
    changes: List[str] = []
    t = _router_text(prompt)
    if t in {"use count unit no", "use xgetcount unit no"}:
        changes.extend(_apply_single_builder_count_or_unit_confirmation_to_plan(plan, "use count"))
        changes.extend(_apply_single_builder_count_or_unit_confirmation_to_plan(plan, "unit no"))
        return _dedupe_keep_order(changes)
    if t == "use steel surface area unit m2":
        setup = plan.setdefault("current_work_setup", {})
        setup.update({
            "default_costx_function": "XGETCUSTOM",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "Steel Surface Area",
            "custom_quantity_unit": "m2",
            "expected_unit": "m2",
        })
        plan.update({"default_function": "XGETCUSTOM", "function_mode": "force_default", "custom_quantity": "Steel Surface Area", "unit": "m2"})
        return ["Confirmed XGETCUSTOM Steel Surface Area with unit m2 for the active Builder plan."]
    for line in _builder_short_edit_lines(prompt):
        changes.extend(_apply_single_builder_count_or_unit_confirmation_to_plan(plan, line))
    return _dedupe_keep_order(changes)


def _extract_basement_order_request(text: str) -> Optional[str]:
    t = _router_text(text)
    m = re.search(r"\b(b\d+)\s+(first|last)\b", t, flags=re.I) or re.search(r"\b(first|last)\s+(b\d+)\b", t, flags=re.I)
    if not m:
        return None
    parts = [g for g in m.groups() if g]
    b = next((p.upper() for p in parts if re.fullmatch(r"b\d+", p, flags=re.I)), None)
    pos = next((p.lower() for p in parts if p.lower() in {"first", "last"}), "first")
    return f"{b}:{pos}" if b else None

def _find_dynamic_zone(project_setup: Dict[str, Any], zone_index: int) -> Optional[Dict[str, Any]]:
    for zone in project_setup.get("dynamic_zones") or []:
        try:
            if int(zone.get("zone_index")) == int(zone_index):
                return zone
        except Exception:
            continue
    return None


def _set_dynamic_zone_values(project_setup: Dict[str, Any], zone_index: int, values: List[str], role: Optional[str] = None) -> None:
    clean = _dedupe_keep_order([_clean_zone_value(v) for v in values if _clean_zone_value(v)])
    zone = _find_dynamic_zone(project_setup, zone_index)
    if zone:
        zone["values"] = clean
        if role:
            zone["role"] = role
    else:
        project_setup.setdefault("dynamic_zones", []).append({"zone_index": int(zone_index), "values": clean, "role": role or infer_zone_role(zone_index, clean, ""), "source": "amendment"})


def _refresh_project_hierarchy_from_dynamic_zones(project_setup: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(project_setup, dict):
        return project_setup
    # v4.4.4.15: refresh both the old one-primary-zone fields and the newer
    # multi-zone hierarchy tree without collapsing the tree back to Head3/Head4.
    for z in project_setup.get("dynamic_zones") or []:
        if not isinstance(z, dict):
            continue
        try:
            idx = int(z.get("zone_index"))
        except Exception:
            continue
        vals = _dedupe_keep_order([_clean_zone_value(v) for v in z.get("values") or [] if _clean_zone_value(v)])
        for key in ["hierarchy_zones", "dimension_combo_zones", "head4_combo_zones"]:
            for hz in project_setup.get(key) or []:
                try:
                    if int(hz.get("zone_index")) == idx:
                        hz["values"] = vals
                        if z.get("role"):
                            hz["role"] = z.get("role")
                except Exception:
                    continue
    try:
        head3_idx = int(project_setup.get("head3_zone_index") or 1)
    except Exception:
        head3_idx = 1
    head3_zone = _find_dynamic_zone(project_setup, head3_idx)
    if head3_zone:
        project_setup["head3_values"] = _dedupe_keep_order([_clean_zone_value(v) for v in head3_zone.get("values") or []])
        project_setup["head3_label"] = f"Zone {head3_idx} ({_zone_role_label(head3_zone.get('role'), head3_idx)})"
        project_setup["head3_role"] = head3_zone.get("role")
    project_setup["level_values"] = _dedupe_keep_order([_level_label(v) for v in project_setup.get("level_values") or []])

    hierarchy_zones = project_setup.get("hierarchy_zones") or []
    if hierarchy_zones:
        parts: List[str] = []
        for hz in hierarchy_zones:
            parts.append(f"Zone {hz.get('zone_index')} ({_zone_role_label(hz.get('role'), hz.get('zone_index'))}) = {hz.get('head') or 'Head'}")
        combo = project_setup.get("dimension_combo_zones") or project_setup.get("head4_combo_zones") or []
        if combo:
            combo_names = ", ".join([f"Zone {z.get('zone_index')}" for z in combo])
            parts.append(f"Detected dimension/type + {combo_names} = {project_setup.get('dimension_head') or 'Head4'}")
        else:
            parts.append(f"Detected dimension/type = {project_setup.get('dimension_head') or 'Head4'}")
        parts.append(f"Levels = formula rows (Zone {project_setup.get('level_zone_index') or 3})")
        project_setup["hierarchy_description"] = "; ".join(parts)
    else:
        primary_head = project_setup.get("primary_head") or project_setup.get("start_head") or "Head3"
        project_setup["primary_head"] = primary_head
        project_setup["start_head"] = primary_head
        project_setup["dimension_head"] = project_setup.get("dimension_head") or _next_head_label(primary_head)
        combo_names = ", ".join([f"Zone {z.get('zone_index')}" for z in project_setup.get("head4_combo_zones") or []])
        parts = [f"Zone {head3_idx} ({_zone_role_label(project_setup.get('head3_role'), head3_idx)}) = {project_setup['primary_head']}"]
        parts.append((f"Detected dimension/type + {combo_names} = {project_setup['dimension_head']}" if combo_names else f"Detected dimension/type = {project_setup['dimension_head']}"))
        parts.append(f"Levels = formula rows (Zone {project_setup.get('level_zone_index') or 3})")
        project_setup["hierarchy_description"] = "; ".join(parts)
    project_setup["hierarchy_summary_lines"] = dynamic_hierarchy_summary_lines(project_setup)
    return project_setup

def _plan_zone_snapshot(project_setup: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(project_setup, dict):
        return {}
    return {
        "dynamic_zones": project_setup.get("dynamic_zones") or [],
        "primary_zone_index": project_setup.get("head3_zone_index"),
        "primary_head": project_setup.get("primary_head") or project_setup.get("start_head"),
        "dimension_head": project_setup.get("dimension_head"),
        "level_zone_index": project_setup.get("level_zone_index"),
        "levels": project_setup.get("level_values") or [],
    }


def build_dynamic_query_vision(prompt: str, plan: Optional[Dict[str, Any]], pending: Optional[Dict[str, Any]] = None, amendment_summary: Optional[List[str]] = None) -> Dict[str, Any]:
    setup = (plan or {}).get("current_work_setup") or {}
    project_setup = (plan or {}).get("project_zone_hierarchy") or setup.get("project_zone_hierarchy") or {}
    return {
        "intent": classify_current_query_intent(prompt, pending, plan),
        "task": (plan or {}).get("tool_label") or "Build base sheet",
        "trade": (plan or {}).get("trade_profile_name") or trade_profile_display_name_for_router(setup.get("trade_profile_id", "")),
        "function": (plan or {}).get("default_function") or setup.get("default_costx_function"),
        "unit": (plan or {}).get("unit") or setup.get("expected_unit"),
        "zone_mode": (plan or {}).get("zone_mode") or setup.get("zone_token_mode"),
        "zone_snapshot": _plan_zone_snapshot(project_setup),
        "amendment_summary": amendment_summary or [],
        "source_of_truth_order": ["current message", "pending clarification", "active Builder plan", "attached workbook", "project preset", "workspace default"],
    }


def validate_builder_plan_integrity(plan: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    warnings: List[str] = []
    setup = plan.get("current_work_setup") or {}
    fn = sanitize_costx_function(plan.get("default_function") or setup.get("default_costx_function") or "", "")
    unit = canonical_builder_unit(plan.get("unit") or setup.get("expected_unit") or setup.get("custom_quantity_unit") or "")
    if fn == "XGETCOUNT" and unit != "no":
        issues.append(f"Function/unit mismatch: XGETCOUNT should use unit no, not {unit or 'blank'}.")
    if fn == "XGETWALLAREA" and unit != "m2":
        warnings.append(f"XGETWALLAREA normally uses m2; found {unit or 'blank'}.")
    if fn == "XGETCUSTOM" and not sanitize_custom_quantity_name(setup.get("custom_quantity_name") or plan.get("custom_quantity") or ""):
        issues.append("XGETCUSTOM selected but no custom quantity is set.")
    project = plan.get("project_zone_hierarchy") or setup.get("project_zone_hierarchy") or {}
    if isinstance(project, dict) and project.get("enabled"):
        dynamic = project.get("dynamic_zones") or []
        if not project.get("head3_values"):
            issues.append("Project hierarchy has no primary zone values.")
        if not project.get("level_values"):
            issues.append("Project hierarchy has no level values.")
        # Prevent Stage/Internal-External crossing: primary zone values and combo values should not be the same role/value set unless user intentionally configured it.
        primary_idx = project.get("head3_zone_index")
        primary_vals = {str(v).lower() for v in project.get("head3_values") or []}
        combo_vals = set()
        for combo in project.get("head4_combo_zones") or []:
            combo_vals.update(str(v).lower() for v in combo.get("values") or [])
        overlap = sorted(primary_vals.intersection(combo_vals))
        if overlap:
            issues.append("Zone role conflict: primary zone and combo zone share values: " + ", ".join(overlap) + ".")
        if len([z for z in dynamic if isinstance(z, dict) and z.get("role") != "level"]) > 1 and not project.get("explicit_start_head") and not project.get("primary_head"):
            issues.append("Multiple zones detected without a clear heading order.")
    status = "PASS" if not issues else "BLOCKED"
    return {"status": status, "issues": issues, "warnings": warnings, "safe_to_preview": not issues, "safe_to_export": not issues}




# Jarvis v4.4.4.15 — Active Plan Edit Resolver helpers.
def _has_negated_destructive_action(text: str) -> bool:
    t = _router_text(text)
    return bool(re.search(r"\b(?:do\s+not|don't|dont|never)\s+(?:remove|exclude|omit|delete|take\s+away)\b", t, flags=re.I))


def _is_add_back_action(text: str) -> bool:
    t = _router_text(text)
    return bool(_has_any(t, ["bring back", "add back", "restore", "include again", "put back", "return"]) or re.search(r"\binclude\b", t, flags=re.I))


def _is_remove_action(text: str) -> bool:
    t = _router_text(text)
    if _has_negated_destructive_action(t):
        return False
    return bool(_has_any(t, ["remove", "exclude", "omit", "delete", "leave out", "take away", "do not include", "don't include", "dont include", "retain only", "only the", "only "]))


def _is_replace_action(text: str) -> bool:
    t = _router_text(text)
    return bool(re.search(r"\b(?:change|replace|rename|swap)\b.+?\b(?:to|with)\b", t, flags=re.I))


def _is_reorder_action(text: str) -> bool:
    t = _router_text(text)
    return bool(re.search(r"\b(?:make|put|place|move)\b.+?\b(?:first|last|before|after|above|below)\b", t, flags=re.I) or re.search(r"\b(?:first|last)\b", t, flags=re.I))


def _project_all_dynamic_zones(project: Dict[str, Any]) -> List[Dict[str, Any]]:
    zones: Dict[int, Dict[str, Any]] = {}
    for key in ["dynamic_zones", "hierarchy_zones", "dimension_combo_zones", "head4_combo_zones"]:
        for z in project.get(key) or []:
            if not isinstance(z, dict):
                continue
            try:
                idx = int(z.get("zone_index"))
            except Exception:
                continue
            if idx not in zones:
                zones[idx] = {"zone_index": idx, "role": z.get("role"), "values": list(z.get("values") or []), "head": z.get("head")}
            else:
                vals = list(zones[idx].get("values") or []) + list(z.get("values") or [])
                zones[idx]["values"] = _dedupe_keep_order([_clean_zone_value(v) for v in vals if _clean_zone_value(v)])
                if z.get("role"):
                    zones[idx]["role"] = z.get("role")
                if z.get("head"):
                    zones[idx]["head"] = z.get("head")
    return [zones[k] for k in sorted(zones)]


def _sync_project_zone_collections(project: Dict[str, Any], zone_index: int, values: List[str], role: Optional[str] = None) -> None:
    vals = _dedupe_keep_order([_clean_zone_value(v) for v in values if _clean_zone_value(v)])
    _set_dynamic_zone_values(project, zone_index, vals, role)
    for key in ["hierarchy_zones", "dimension_combo_zones", "head4_combo_zones"]:
        for z in project.get(key) or []:
            try:
                if int(z.get("zone_index")) == int(zone_index):
                    z["values"] = vals
                    if role:
                        z["role"] = role
            except Exception:
                continue
    try:
        if int(project.get("head3_zone_index") or -999) == int(zone_index):
            project["head3_values"] = vals
    except Exception:
        pass


def _find_zone_values_mentioned(project: Dict[str, Any], prompt: str) -> List[Dict[str, Any]]:
    raw = str(prompt or "")
    found: List[Dict[str, Any]] = []
    for zone in _project_all_dynamic_zones(project):
        try:
            idx = int(zone.get("zone_index"))
        except Exception:
            continue
        role = zone.get("role") or infer_zone_role(idx, zone.get("values") or [], raw)
        for val in zone.get("values") or []:
            clean = _clean_zone_value(val)
            if not clean:
                continue
            pattern = r"\b" + re.escape(clean).replace(r"\ ", r"\s+") + r"\b"
            if re.search(pattern, raw, flags=re.I):
                found.append({"type": "zone_value", "zone_index": idx, "role": role, "value": clean})
    # Stages/locations may be newly mentioned even if not exact-cased.
    return _dedupe_zone_value_hits(found)


def _dedupe_zone_value_hits(hits: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for h in hits:
        key = (h.get("type"), int(h.get("zone_index") or 0), str(h.get("value") or "").lower())
        if key not in seen:
            seen.add(key)
            out.append(h)
    return out




def _extract_levels_by_action(prompt: str) -> tuple[List[str], List[str]]:
    """Return (remove_levels, add_levels) using local clauses so
    'remove L4 and add Roof' does not remove Roof.
    """
    raw = str(prompt or "")
    remove_levels: List[str] = []
    add_levels: List[str] = []
    clauses = re.split(r"\band\b|;|\n", raw, flags=re.I)
    for clause in clauses:
        t = _router_text(clause)
        levels = [_level_label(v) for v in parse_levels_from_prompt(clause)]
        if not levels:
            continue
        if _has_negated_destructive_action(t):
            continue
        if _is_remove_action(t):
            remove_levels.extend(levels)
        elif _is_add_back_action(t) or _has_any(t, ["add", "include"]):
            add_levels.extend(levels)
        else:
            # If the whole prompt is a simple action, let the caller decide.
            pass
    return _dedupe_keep_order(remove_levels), _dedupe_keep_order(add_levels)

def _extract_replace_pair(prompt: str) -> Optional[tuple[str, str]]:
    raw = str(prompt or "")
    m = re.search(r"\b(?:change|replace|rename)\s+(.+?)\s+(?:to|with)\s+(.+?)(?:[\.;\n]|$)", raw, flags=re.I)
    if not m:
        return None
    old = _clean_zone_value(m.group(1))
    new = _clean_zone_value(m.group(2))
    # v4.5.1.24.2C: users often say "change Mezz to Mezzanine instead".
    # "instead" is instruction grammar, not part of the replacement value.
    new = re.sub(r"\s+instead\s*$", "", new, flags=re.I).strip()
    return (old, new) if old and new else None


def _parse_mezzanine_alias_direction(prompt: str) -> str:
    """Return set_mezz, clear_mezz, or empty for Mezz/Mezzanine alias edits."""
    raw = str(prompt or "")
    text = _router_text(raw)
    if not re.search(r"\bmezz(?:anine)?\b", raw, flags=re.I):
        return ""
    # Full-word Mezzanine requested instead of short Mezz.
    clear_patterns = [
        r"\b(?:change|replace|rename)\s+mezz\s+(?:to|with)\s+mezzanine(?:\s+instead)?\b",
        r"\buse\s+mezzanine\s+instead\s+of\s+mezz\b",
        r"\bmezzanine\s+instead\s+of\s+mezz\b",
    ]
    if any(re.search(p, text, flags=re.I) for p in clear_patterns):
        return "clear_mezz"
    # Short Mezz requested as the CostX/display token for Mezzanine.
    set_patterns = [
        r"\buse\s+mezz\s+(?:as\s+(?:code\s+for\s+)?)?mezzanine\b",
        r"\buse\s+mezz\s+instead\s+of\s+mezzanine\b",
        r"\bmezz\s+instead\s+of\s+mezzanine\b",
        r"\b(?:change|replace|rename)\s+mezzanine\s+(?:to|with)\s+mezz\b",
    ]
    if any(re.search(p, text, flags=re.I) for p in set_patterns):
        return "set_mezz"
    return ""


def _is_stage_like(value: str) -> bool:
    return bool(re.search(r"\bstage\s*\d+[a-z]?\b", str(value or ""), flags=re.I))


def _clarify_major_branch_delete(prompt: str, hit: Dict[str, Any]) -> Dict[str, Any]:
    val = hit.get("value") or "selected value"
    idx = hit.get("zone_index") or "?"
    return make_clarification(
        "confirm_branch_delete",
        f"This will remove {val} from Zone {idx} and remove that whole branch from the Builder output. Continue?",
        prompt,
        [
            {"label": f"Confirm remove {val}", "reply": f"Confirm remove {val}"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
        {"target": hit},
    )


def _active_plan_edit_no_plan_clarification(prompt: str) -> Dict[str, Any]:
    return make_clarification(
        "no_active_builder_plan_for_edit",
        "I do not have an active Builder plan to edit. Do you want to restore/use the previous Builder plan or start a new command?",
        prompt,
        [
            {"label": "Restore/use previous Builder plan", "reply": "Yes, restore/use the previous Builder plan"},
            {"label": "Start new Builder command", "reply": "new command: " + str(prompt or "")},
            {"label": "Cancel", "reply": "Cancel"},
        ],
        {"original_edit_prompt": str(prompt or "")},
    )


def _update_hierarchy_for_stages_above(project: Dict[str, Any]) -> Optional[str]:
    zones = _project_all_dynamic_zones(project)
    stage_zone = next((z for z in zones if (z.get("role") == "milestone" or any(_is_stage_like(v) for v in z.get("values") or []))), None)
    if not stage_zone:
        return None
    stage_idx = int(stage_zone.get("zone_index"))
    other_zones = [z for z in zones if int(z.get("zone_index")) != stage_idx and z.get("role") != "level"]
    hierarchy_zones = [{"zone_index": stage_idx, "role": stage_zone.get("role") or "milestone", "values": stage_zone.get("values") or [], "head": "Head1"}]
    # Put only one non-stage zone as Head2. More complex layouts should still be shown in summary if present.
    for i, z in enumerate(other_zones):
        head = _head_label_from_number(min(4, 2 + i))
        hierarchy_zones.append({"zone_index": int(z.get("zone_index")), "role": z.get("role"), "values": z.get("values") or [], "head": head})
    project["hierarchy_zones"] = hierarchy_zones
    project["dimension_combo_zones"] = []
    project["head4_combo_zones"] = []
    project["head3_zone_index"] = stage_idx
    project["primary_head"] = "Head1"
    project["start_head"] = "Head1"
    project["dimension_head"] = _head_label_from_number(min(4, 1 + len(hierarchy_zones)))
    project["head3_values"] = list(stage_zone.get("values") or [])
    return "Updated hierarchy so Stage values are above the other project zones."


def dynamic_hierarchy_summary_lines(project_setup: Dict[str, Any]) -> List[str]:
    if not isinstance(project_setup, dict):
        return []
    lines: List[str] = []
    for z in project_setup.get("hierarchy_zones") or []:
        vals = ", ".join([_clean_zone_value(v) for v in z.get("values") or [] if _clean_zone_value(v)])
        if vals:
            lines.append(f"Zone {z.get('zone_index')} / {z.get('head') or 'Head'}: {vals}")
    combo = project_setup.get("dimension_combo_zones") or project_setup.get("head4_combo_zones") or []
    if combo:
        dim_head = project_setup.get("dimension_head") or "next Head"
        for z in combo:
            vals = ", ".join([_clean_zone_value(v) for v in z.get("values") or [] if _clean_zone_value(v)])
            if vals:
                lines.append(f"Detected dimension/type + Zone {z.get('zone_index')} / {dim_head}: {vals}")
    elif project_setup.get("dimension_head"):
        lines.append(f"Detected dimension/type / {project_setup.get('dimension_head')}: source dimension/type names")
    if project_setup.get("level_values"):
        lines.append(f"Levels / Zone {project_setup.get('level_zone_index') or 3}: " + ", ".join(project_setup.get("level_values") or []))
    return lines


def _head_num_from_label(value: Any) -> int:
    m = re.search(r"head\s*([1-4])", str(value or ""), flags=re.I)
    return int(m.group(1)) if m else 3


def _apply_zone_head_assignment_to_project(project: Dict[str, Any], zone_index: int, head_num: int, source_text: str = "") -> str:
    """Apply Zone N = HeadX to the active project hierarchy without losing values."""
    idx = int(zone_index)
    head = _head_label_from_number(head_num)
    zone = _find_dynamic_zone(project, idx)
    values = list((zone or {}).get("values") or [])
    role = (zone or {}).get("role") or infer_zone_role(idx, values, source_text)
    if not values:
        for z in _project_all_dynamic_zones(project):
            try:
                if int(z.get("zone_index")) == idx:
                    values = list(z.get("values") or [])
                    role = z.get("role") or role
                    break
            except Exception:
                continue
    _sync_project_zone_collections(project, idx, values, role)
    # v4.5.1.22: once a zone is explicitly promoted to a hierarchy heading,
    # it must not also remain paired with detected dimension/type. Otherwise
    # the same zone can be written twice in CostX token parts, e.g.
    # [1|Old;3|Internal;3|Internal;4|L1].
    for combo_key in ("dimension_combo_zones", "head4_combo_zones"):
        cleaned_combo = []
        for combo_zone in project.get(combo_key) or []:
            if not isinstance(combo_zone, dict):
                continue
            try:
                if int(combo_zone.get("zone_index") or -1) == idx:
                    continue
            except Exception:
                pass
            cleaned_combo.append(dict(combo_zone))
        project[combo_key] = cleaned_combo
    hierarchy = [dict(z) for z in (project.get("hierarchy_zones") or []) if isinstance(z, dict)]
    found = False
    for hz in hierarchy:
        try:
            if int(hz.get("zone_index")) == idx:
                hz["head"] = head
                hz["values"] = values
                hz["role"] = role
                found = True
        except Exception:
            continue
    if not found:
        hierarchy.append({"zone_index": idx, "role": role, "values": values, "head": head})
    hierarchy.sort(key=lambda z: (_head_num_from_label(z.get("head")), int(z.get("zone_index") or 99)))
    project["hierarchy_zones"] = hierarchy
    project["primary_head"] = hierarchy[0].get("head") if hierarchy else head
    project["start_head"] = project["primary_head"]
    project["head3_zone_index"] = idx if head == "Head3" else project.get("head3_zone_index")
    if head == "Head3":
        project["head3_values"] = values
        project["head3_role"] = role
        project["head3_label"] = f"Zone {idx} ({_zone_role_label(role, idx)})"
    max_head = max([_head_num_from_label(z.get("head")) for z in hierarchy] + [head_num])
    project["dimension_head"] = _head_label_from_number(min(4, max_head + 1))
    project["confirmation_needed"] = False
    project["needs_hierarchy_choice"] = False
    return f"Set Zone {idx} as {head}."


def _apply_explicit_dynamic_zone_values_to_project(project: Dict[str, Any], prompt: str) -> List[str]:
    """Apply explicit short amendments like 'Add Zone 1: Stage 1, Stage 2'."""
    changes: List[str] = []
    for z in parse_dynamic_zone_values_from_prompt(prompt) or []:
        try:
            idx = int(z.get("zone_index"))
        except Exception:
            continue
        vals = [_clean_zone_value(v) for v in (z.get("values") or []) if _clean_zone_value(v)]
        if not vals:
            continue
        role = z.get("role") or infer_zone_role(idx, vals, prompt)
        _sync_project_zone_collections(project, idx, vals, role)
        changes.append(f"Set Zone {idx} values to {', '.join(vals)}.")
    return changes


def _apply_start_head_to_project(project: Dict[str, Any], head_num: int, prompt: str) -> str:
    """Apply 'start at Head2' to the first active non-level zone, preserving values."""
    head = _head_label_from_number(head_num)
    hierarchy = [z for z in (project.get("hierarchy_zones") or []) if isinstance(z, dict)]
    if hierarchy:
        # Shift the first hierarchy branch to the requested starting head and
        # keep later branches in sequence where practical.
        hierarchy.sort(key=lambda z: (_head_num_from_label(z.get("head")), int(z.get("zone_index") or 99)))
        first_idx = int(hierarchy[0].get("zone_index") or project.get("head3_zone_index") or 1)
        return _apply_zone_head_assignment_to_project(project, first_idx, head_num, prompt)
    zones = [z for z in _project_all_dynamic_zones(project) if z.get("role") != "level"]
    if zones:
        first_idx = int(zones[0].get("zone_index") or 1)
        return _apply_zone_head_assignment_to_project(project, first_idx, head_num, prompt)
    project["primary_head"] = head
    project["start_head"] = head
    project["dimension_head"] = _next_head_label(head)
    project["confirmation_needed"] = False
    project["needs_hierarchy_choice"] = False
    return f"Changed starting heading to {head}."

def _empty_project_setup_for_active_reply(prompt: str = "") -> Dict[str, Any]:
    """Small run-only project setup shell for v4.5.1.23 active slot replies.

    This lets Jarvis keep hierarchy/zone/level follow-ups attached to the
    current Builder plan without falling back to workspace wall defaults.
    """
    return {
        "enabled": False,
        "run_only": True,
        "dynamic_zones": [],
        "hierarchy_zones": [],
        "dimension_combo_zones": [],
        "zone1_values": [],
        "level_values": [],
        "mezzanine_token_alias": "",
        "start_head": "Head3",
        "primary_head": "Head3",
        "dimension_head": "Head4",
        "explicit_start_head": bool(parse_zone_head_assignments(prompt) or parse_explicit_hierarchy_head_from_prompt(prompt)),
        "head3_source": "none",
        "head3_zone_index": None,
        "head3_role": None,
        "head3_label": "Head3 zone",
        "head3_values": [],
        "head4_source": "detected_dimension",
        "head4_combo_zones": [],
        "head4_combo_label": "None",
        "levels_source": "parsed_command" if parse_levels_from_prompt(prompt) else "workspace_default",
        "level_zone_index": 3,
        "based_on": "active_builder_plan",
        "formatting": "builder_base_only",
        "zone_token_mode": "rebuild_run_only",
        "confirmation_needed": False,
        "needs_hierarchy_choice": False,
        "hierarchy_description": "Detected dimension/type = Head4; Levels = formula rows (Zone 3)",
        "hierarchy_summary_lines": [],
    }


def _active_reply_project_seed(prompt: str) -> Optional[Dict[str, Any]]:
    parsed = detect_project_zone_hierarchy_intent(prompt)
    has_slots = bool(parse_dynamic_zone_values_from_prompt(prompt) or parse_zone_head_assignments(prompt) or parse_levels_from_prompt(prompt) or parse_zone_slot_selection_indices(prompt))
    if isinstance(parsed, dict) and (parsed.get("dynamic_zones") or parsed.get("hierarchy_zones") or parsed.get("level_values") or parse_zone_head_assignments(prompt)):
        seed = _deepcopy_json(parsed)
    elif has_slots:
        seed = _empty_project_setup_for_active_reply(prompt)
    else:
        return None
    return seed


def _apply_steel_quantity_to_plan(plan: Dict[str, Any], prompt: str) -> List[str]:
    text = _router_text(prompt)
    mentions = detect_steel_quantity_mentions(text)
    chosen = choose_steel_quantity_from_mentions(text, mentions)
    if not chosen:
        return []
    setup = plan.setdefault("current_work_setup", {})
    setup.update({
        "trade_profile_id": "metalwork_structural_steel",
        "default_costx_function": "XGETCUSTOM",
        "costx_function_mode": "force_default",
        "custom_quantity_name": chosen.get("label") or "Weight",
        "custom_quantity_unit": chosen.get("unit") or "t",
        "expected_unit": chosen.get("unit") or "t",
    })
    plan.update({
        "trade_profile_id": "metalwork_structural_steel",
        "trade_profile_name": trade_profile_display_name_for_router("metalwork_structural_steel"),
        "default_function": "XGETCUSTOM",
        "function_mode": "force_default",
        "custom_quantity": chosen.get("label") or "Weight",
        "unit": chosen.get("unit") or "t",
    })
    return [f"Updated steel custom quantity to {chosen.get('label')} / {chosen.get('unit')}."]


def apply_active_builder_plan_amendment(active_plan: Dict[str, Any], prompt: str, has_file: bool = False) -> Optional[Dict[str, Any]]:
    # v4.5.1.24.2C: Mezz alias wording can appear inside a level sentence
    # (for example "GF to Level 11 with Level 11 Mezzanine use Mezz as Code")
    # or later as a directional edit ("Change Mezz to Mezzanine instead").
    # Record direction, but do not return early because the same prompt may also
    # need the level reducer below.
    mezz_alias_direction = _parse_mezzanine_alias_direction(prompt)
    mezz_alias_requested = bool(mezz_alias_direction == "set_mezz")
    # v4.5.1.24 Bug-2 supplement: normalise "use zone X and zone Y" into a form
    # that the zone parsers can already handle ("zone X: ..., zone Y: ...").
    # This synthetic rewrite only fires when no colon-based assignments exist.
    if (re.search(r"\bzone\s*\d+\s+and\s+zone\s*\d+", str(prompt or ""), flags=re.I)
            and not re.search(r"zone\s*\d+\s*[:=]", str(prompt or ""), flags=re.I)):
        # Extract all zone numbers from "use zone 2 and zone 4" style input.
        zone_nums = re.findall(r"zone\s*(\d+)", str(prompt or ""), flags=re.I)
        if zone_nums:
            # Build a synthetic prompt the parsers understand: "zone 2, zone 4"
            synthetic = "; ".join(f"use zone {z}" for z in zone_nums)
            prompt = synthetic
    """Apply same-query edits to the active Builder plan without resetting context.

    v4.4.4.15 strengthens this layer so known bugs do not regress:
    - bring back/restore/add back adds to existing levels instead of replacing
    - do not remove L3 keeps L3
    - remove Internal resolves Internal as an active zone value and asks confirmation
    - change Stage 2 to Stage 2b replaces instead of duplicating
    - make External first / put stages above others stays in Builder context
    """
    if not _has_active_builder_plan(active_plan):
        if is_active_builder_plan_amendment(prompt):
            return {"clarification": _active_plan_edit_no_plan_clarification(prompt), "confidence": 62, "risk": "review"}
        return None
    active_slot_reply = bool(is_active_builder_plan_amendment(prompt) or is_ambiguous_reference_message(prompt) or parse_dynamic_zone_values_from_prompt(prompt) or parse_zone_head_assignments(prompt) or parse_levels_from_prompt(prompt) or detect_steel_quantity_mentions(_router_text(prompt)) or _is_builder_count_or_unit_confirmation(prompt))
    if not active_slot_reply:
        return None

    text = _router_text(prompt)
    panic_issues = detect_panic_conflicts(prompt, active_plan)
    if panic_issues:
        return {"clarification": panic_conflict_clarification(prompt, panic_issues, active_plan), "confidence": 74, "risk": "blocked"}
    plan = _deepcopy_json(active_plan)
    setup = plan.setdefault("current_work_setup", {})
    project = plan.get("project_zone_hierarchy") or setup.get("project_zone_hierarchy")

    # v4.5.1.23: zone/head/level follow-ups can start the run-only slot model
    # even when the active Builder plan originally had only trade/function info.
    if not isinstance(project, dict):
        seed_project = _active_reply_project_seed(prompt)
        if seed_project:
            project = seed_project
            setup["project_zone_hierarchy"] = project
            plan["project_zone_hierarchy"] = project
        else:
            project = None

    # v4.5.1.10: some active-task replies amend only the Builder setup, not the
    # hierarchy. They must not fail just because the plan has no project hierarchy yet.
    if not isinstance(project, dict):
        setup_only_changes: List[str] = []
        setup_only_changes.extend(_apply_steel_quantity_to_plan(plan, prompt))
        if _is_detected_formula_mode_reply(prompt):
            setup["costx_function_mode"] = "preserve_detected"
            plan["function_mode"] = "preserve_detected"
            setup_only_changes.append("Kept detected/source CostX formulas as-is for the active Builder plan.")
        elif _is_force_default_formula_reply(prompt):
            setup["costx_function_mode"] = "force_default"
            plan["function_mode"] = "force_default"
            setup_only_changes.append("Set active Builder plan to use the default function for this run.")
        setup_only_changes.extend(_apply_builder_count_or_unit_confirmation_to_plan(plan, prompt))
        if _has_any(text, ["door", "doors", "window", "windows", "count", "counts"]):
            setup.update({"trade_profile_id": "doors_windows", "default_costx_function": "XGETCOUNT", "costx_function_mode": "force_default", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "no", "zone_token_mode": "preserve_source"})
            plan.update({"trade_profile_id": "doors_windows", "trade_profile_name": trade_profile_display_name_for_router("doors_windows"), "default_function": "XGETCOUNT", "function_mode": "force_default", "custom_quantity": "", "unit": "no"})
            setup_only_changes.append("Updated active Builder trade/profile to Doors / Windows.")
        elif _has_any(text, ["steel", "metalwork", "structural steel", "purlin", "girt", "beam", "column", "rafter"]):
            setup.update({"trade_profile_id": "metalwork_structural_steel", "default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": setup.get("custom_quantity_name") or "Steel Surface Area", "custom_quantity_unit": setup.get("custom_quantity_unit") or "m2", "expected_unit": setup.get("custom_quantity_unit") or "m2"})
            plan.update({"trade_profile_id": "metalwork_structural_steel", "trade_profile_name": trade_profile_display_name_for_router("metalwork_structural_steel"), "default_function": "XGETCUSTOM", "function_mode": "force_default", "custom_quantity": setup.get("custom_quantity_name") or "Steel Surface Area", "unit": setup.get("custom_quantity_unit") or "m2"})
            setup_only_changes.append("Updated active Builder trade/profile to Metalwork / Structural Steel.")
        elif _has_any(text, ["concrete", "reo", "reinforcement", "formwork", "formworks"]):
            setup.update({"trade_profile_id": "concrete_reo", "default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": "Formworks", "custom_quantity_unit": "m2", "expected_unit": "m2"})
            plan.update({"trade_profile_id": "concrete_reo", "trade_profile_name": trade_profile_display_name_for_router("concrete_reo"), "default_function": "XGETCUSTOM", "function_mode": "force_default", "custom_quantity": "Formworks", "unit": "m2"})
            setup_only_changes.append("Updated active Builder trade/profile to Concrete / Reo.")
        elif _has_any(text, ["wall", "walls", "partition", "partitions", "wall type", "wall types"]):
            setup.update({"trade_profile_id": "walls_partitions", "default_costx_function": "XGETWALLAREA", "costx_function_mode": "preserve_detected", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "m2"})
            plan.update({"trade_profile_id": "walls_partitions", "trade_profile_name": trade_profile_display_name_for_router("walls_partitions"), "default_function": "XGETWALLAREA", "function_mode": "preserve_detected", "custom_quantity": "", "unit": "m2"})
            setup_only_changes.append("Updated active Builder trade/profile to Walls / Partitions.")
        if setup_only_changes:
            plan["has_file"] = bool(has_file)
            plan["confidence"] = max(70, min(99, int(plan.get("confidence") or 86)))
            plan["risk"] = "low"
            plan["requires_review_before_preview"] = False
            plan["next_action"] = "approve_and_preview"
            plan.setdefault("reasons", [])
            plan["reasons"] = [r for r in plan.get("reasons", []) if "Confidence is below" not in str(r)]
            plan["reasons"].append("Active Builder plan amended safely: " + " ".join(setup_only_changes))
            plan["query_vision"] = build_dynamic_query_vision(prompt, plan, None, setup_only_changes)
            return plan
        return {"clarification": project_setup_clarification(prompt, {"enabled": False, "level_values": parse_levels_from_prompt(prompt)}), "confidence": 66, "risk": "review"}

    changes: List[str] = []
    selected_slot_project = _ensure_project_from_zone_slots(plan, prompt)
    if selected_slot_project:
        changes.append("Saved zone slots: " + ", ".join([f"Zone {i}" for i in selected_slot_project.get("expected_zone_indices") or []]) + ".")
    # v4.5.1.9: apply explicit short zone value amendments before generic
    # stage/location inference, e.g. "Add Zone 1: Stage 1, Stage 2".
    for change in _apply_explicit_dynamic_zone_values_to_project(project, prompt):
        if change not in changes:
            changes.append(change)
    # v4.5.1.9: active hierarchy replies must stay in Builder context.
    parsed_zone_heads = parse_zone_head_assignments(prompt) or {}
    for z_idx, h_num in parsed_zone_heads.items():
        change = _apply_zone_head_assignment_to_project(project, int(z_idx), int(h_num), prompt)
        if change not in changes:
            changes.append(change)
    other_head_num = parse_other_zone_head_assignment(prompt)
    if other_head_num:
        assigned = {int(k) for k in parsed_zone_heads.keys()}
        for z in _project_all_dynamic_zones(project):
            try:
                z_idx = int(z.get("zone_index") or 0)
            except Exception:
                continue
            if z.get("role") == "level" or z_idx in assigned:
                continue
            change = _apply_zone_head_assignment_to_project(project, z_idx, int(other_head_num), prompt)
            if change not in changes:
                changes.append(change)
    if not parsed_zone_heads and not other_head_num:
        start_num = parse_explicit_hierarchy_head_from_prompt(prompt)
        if start_num:
            change = _apply_start_head_to_project(project, int(start_num), prompt)
            if change not in changes:
                changes.append(change)

    # v4.5.1.10: active formula-mode replies update the current Builder plan.
    if _is_detected_formula_mode_reply(prompt):
        setup["costx_function_mode"] = "preserve_detected"
        plan["function_mode"] = "preserve_detected"
        changes.append("Kept detected/source CostX formulas as-is for the active Builder plan.")
    elif _is_force_default_formula_reply(prompt):
        setup["costx_function_mode"] = "force_default"
        plan["function_mode"] = "force_default"
        changes.append("Set active Builder plan to use the default function for this run.")

    before_levels = [_level_label(v) for v in (project.get("level_values") or [])]
    levels_in_prompt = [_level_label(v) for v in parse_levels_from_prompt(prompt)]
    confirming = _has_any(text, ["confirm", "continue", "yes", "approved", "approve", "proceed"])

    # Complicated edit sentence guard: do not guess on phrases like
    # "omit the latter stage and retain only the external split".
    if not confirming and (_has_any(text, ["latter stage", "former stage", "retain only", "only the external", "only external"])):
        stage_zone = next((z for z in _project_all_dynamic_zones(project) if (z.get("role") == "milestone" or any(_is_stage_like(v) for v in z.get("values") or []))), None)
        loc_zone = next((z for z in _project_all_dynamic_zones(project) if (z.get("role") == "location" or any(str(v).lower() in {"internal", "external"} for v in z.get("values") or []))), None)
        likely_stage = None
        if stage_zone and stage_zone.get("values"):
            likely_stage = list(stage_zone.get("values") or [])[-1] if "latter" in text else list(stage_zone.get("values") or [])[0]
        keep_loc = "External" if "external" in text else ("Internal" if "internal" in text else None)
        q = "I think this is a combined edit, but I need confirmation before changing branches. "
        bits = []
        if likely_stage:
            bits.append(f"remove {likely_stage}")
        if keep_loc:
            bits.append(f"keep only {keep_loc}")
        q += "Do you mean: " + (" and ".join(bits) if bits else "update the current arrangement") + "?"
        return {"clarification": make_clarification("complicated_edit_confirm", q, prompt, [{"label": "Confirm this edit", "reply": "Confirm: " + " and ".join(bits)}, {"label": "I will clarify", "reply": "I will clarify the edit"}, {"label": "Cancel", "reply": "Cancel"}], {"likely_stage": likely_stage, "keep_location": keep_loc, "active_plan": active_plan}), "confidence": 66, "risk": "review"}

    # Negation/antonym guard: do not remove L3 means keep L3.
    if _has_negated_destructive_action(text):
        kept = levels_in_prompt or [h.get("value") for h in _find_zone_values_mentioned(project, prompt)]
        kept = [str(v) for v in kept if v]
        if kept:
            changes.append("Negation guard: kept " + ", ".join(_dedupe_keep_order(kept)) + ".")
        else:
            changes.append("Negation guard: destructive edit ignored.")

    # v4.5.1.23: steel quantity replies such as "Use Weight" are amendments
    # to the active Builder setup.
    for _change in _apply_steel_quantity_to_plan(plan, prompt):
        changes.append(_change)
    for _change in _apply_builder_count_or_unit_confirmation_to_plan(plan, prompt):
        changes.append(_change)

    # v4.5.1.24.2A: trade/profile edits are amendments to the active Builder setup; preserve zones/levels.
    if _has_any(text, ["concrete", "reo", "reinforcement", "formwork", "formworks"]):
        setup.update({"trade_profile_id": "concrete_reo", "default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": "Formworks", "custom_quantity_unit": "m2", "expected_unit": "m2"})
        plan.update({"trade_profile_id": "concrete_reo", "trade_profile_name": trade_profile_display_name_for_router("concrete_reo"), "default_function": "XGETCUSTOM", "function_mode": "force_default", "custom_quantity": "Formworks", "unit": "m2"})
        changes.append("Updated active Builder trade/profile to Concrete / Reo while preserving project zones and levels.")

    # v4.5.1.22: trade/profile edits such as "change it to door count" are
    # amendments to the active Builder setup, not zone-value replacements.
    if _has_any(text, ["door", "doors", "window", "windows", "count", "counts"]):
        setup.update({"trade_profile_id": "doors_windows", "default_costx_function": "XGETCOUNT", "costx_function_mode": "force_default", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "no", "zone_token_mode": "preserve_source"})
        plan.update({"trade_profile_id": "doors_windows", "trade_profile_name": trade_profile_display_name_for_router("doors_windows"), "default_function": "XGETCOUNT", "function_mode": "force_default", "custom_quantity": "", "unit": "no"})
        changes.append("Updated active Builder trade/profile to Doors / Windows count.")

    if mezz_alias_direction == "clear_mezz":
        if project.get("mezzanine_token_alias"):
            project.pop("mezzanine_token_alias", None)
        changes.append("Mezzanine alias cleared; active Builder levels will use full Mezzanine wording.")
    elif (mezz_alias_requested or re.search(r"\buse\s+mezz\s+instead\s+of\s+mezzanine\b|\bmezz\s+instead\s+of\s+mezzanine\b|\buse\s+mezz\s+as\s+(?:code\s+for\s+)?mezzanine\b", str(prompt or ""), flags=re.I)):
        project["mezzanine_token_alias"] = "Mezz"
        if "Mezzanine token alias set to Mezz from user command." not in changes:
            changes.append("Mezzanine token alias set to Mezz from user command.")

    replace_pair = None if mezz_alias_direction else _extract_replace_pair(prompt)
    if replace_pair and not _has_any(text, ["door", "doors", "window", "windows", "count", "counts"]):
        old, new = replace_pair
        replaced = False
        # Levels replacement
        if _level_label(old) in before_levels or _level_label(new).lower().startswith("l") or _level_label(new) in {"GF", "Roof", "B1", "B2"}:
            old_lv = _level_label(old); new_lv = _level_label(new)
            if old_lv in before_levels:
                project["level_values"] = _canonical_level_sort([new_lv if str(v).lower() == old_lv.lower() else v for v in before_levels], preserve_user_order=bool(project.get("preserve_level_order")))
                changes.append(f"Replaced level {old_lv} with {new_lv}. Levels: {', '.join(project['level_values'])}.")
                replaced = True
        # Zone value replacement
        for hit in _find_zone_values_mentioned(project, old):
            idx = int(hit.get("zone_index"))
            zone = _find_dynamic_zone(project, idx)
            vals = list((zone or {}).get("values") or [])
            if vals:
                new_vals = [new if str(v).lower() == str(hit.get("value")).lower() else v for v in vals]
                _sync_project_zone_collections(project, idx, new_vals, (zone or {}).get("role") or hit.get("role"))
                changes.append(f"Replaced Zone {idx} value {hit.get('value')} with {new}.")
                replaced = True
        if not replaced:
            return {"clarification": make_clarification("replace_target_unclear", f"I found a replace instruction ({old} to {new}), but I’m not sure which active plan value to replace. Should I replace it or add it as a new value?", prompt, [{"label": f"Replace {old} with {new}", "reply": f"Confirm replace {old} with {new}"}, {"label": f"Add {new} as new value", "reply": f"add {new}"}, {"label": "Cancel", "reply": "Cancel"}], {"active_plan": active_plan}), "confidence": 64, "risk": "review"}

    removing = _is_remove_action(text)
    adding = _is_add_back_action(text) or (_has_any(text, ["add", "include"]) and not removing)
    reorder = _is_reorder_action(text)

    # Level add/remove, with restore/add-back preserving current list. Clause-aware
    # parsing prevents mixed requests like "remove L4 and add Roof" from deleting Roof.
    if levels_in_prompt and not _has_negated_destructive_action(text):
        remove_levels, add_levels = _extract_levels_by_action(prompt)
        if not remove_levels and not add_levels and _has_any(text, ["level", "levels", "consist", "from"]):
            project["level_values"] = _canonical_level_sort(levels_in_prompt, preserve_user_order=bool(project.get("preserve_level_order")))
            project["explicit_level_instruction"] = True
            changes.append("Set active Builder levels to: " + ", ".join(project["level_values"]) + ".")
        if not remove_levels and not add_levels:
            if removing:
                remove_levels = levels_in_prompt
            elif adding:
                add_levels = levels_in_prompt
        current_levels = list(before_levels)
        order_req = _extract_basement_order_request(prompt)
        if order_req and current_levels:
            req_level, req_pos = order_req.split(":", 1)
            if req_level in current_levels:
                remainder = [lv for lv in current_levels if lv != req_level]
                current_levels = ([req_level] + remainder) if req_pos == "first" else (remainder + [req_level])
                project["level_values"] = current_levels
                project["preserve_level_order"] = True
                changes.append(f"Moved {req_level} {req_pos} in the active Builder level order.")
        if remove_levels:
            remove_set = {lv.lower() for lv in remove_levels}
            current_levels = [lv for lv in current_levels if str(lv).lower() not in remove_set]
            current_levels = _canonical_level_sort(current_levels, preserve_user_order=bool(project.get("preserve_level_order")))
            project["level_values"] = current_levels
            project["explicit_level_instruction"] = True
            changes.append("Removed level(s): " + ", ".join(remove_levels) + f". Remaining: {', '.join(current_levels) or 'none'}.")
        if add_levels:
            current_levels = _canonical_level_sort(current_levels + add_levels, preserve_user_order=bool(project.get("preserve_level_order")))
            project["level_values"] = current_levels
            project["explicit_level_instruction"] = True
            changes.append("Added level(s): " + ", ".join(add_levels) + f". Levels: {', '.join(project['level_values'])}.")

    # Stage values can belong to any active milestone/stage zone, not always the old primary/head3 zone.
    stage_values = _extract_stage_values(prompt)
    stage_zone = next((z for z in _project_all_dynamic_zones(project) if (z.get("role") == "milestone" or any(_is_stage_like(v) for v in z.get("values") or []))), None)
    if stage_values and not replace_pair and not _has_negated_destructive_action(text):
        if not stage_zone:
            opts = []
            for z in _project_all_dynamic_zones(project):
                opts.append({"label": f"Add stage to Zone {z.get('zone_index')}", "reply": f"Add {' and '.join(stage_values)} to Zone {z.get('zone_index')}"})
            return {"clarification": make_clarification("stage_target_zone_unclear", "I found a Stage value, but the active plan does not currently have a Stage/Milestone zone. Which zone should receive this stage value?", prompt, opts[:6] + [{"label": "Cancel", "reply": "Cancel"}], {"active_plan": active_plan, "stage_values": stage_values}), "confidence": 66, "risk": "review"}
        target_idx = int((stage_zone or {}).get("zone_index") or project.get("head3_zone_index") or 2)
        zone = _find_dynamic_zone(project, target_idx)
        current_vals = list((zone or {}).get("values") or project.get("head3_values") or [])
        if removing:
            rem = {v.lower() for v in stage_values}
            new_vals = [v for v in current_vals if str(v).lower() not in rem]
            changes.append("Removed stage value(s): " + ", ".join(stage_values) + ".")
        elif adding:
            new_vals = _dedupe_keep_order(current_vals + stage_values)
            changes.append("Added stage value(s): " + ", ".join(stage_values) + ".")
        else:
            # Bare stage mention in an edit should be treated as reorder/clarification, not destructive replacement.
            new_vals = current_vals
        _sync_project_zone_collections(project, target_idx, new_vals, (zone or stage_zone or {}).get("role") or "milestone")

    # Location/other zone value add/remove using active target resolver.
    zone_hits = _find_zone_values_mentioned(project, prompt)
    non_level_hits = [h for h in zone_hits if h.get("type") == "zone_value"]
    if non_level_hits and not replace_pair and not _has_negated_destructive_action(text):
        if removing:
            # Major branch deletion asks confirmation unless user already confirmed.
            if not confirming:
                return {"clarification": _clarify_major_branch_delete(prompt, non_level_hits[0]), "confidence": 72, "risk": "review"}
            for hit in non_level_hits:
                idx = int(hit.get("zone_index"))
                zone = _find_dynamic_zone(project, idx)
                cur = list((zone or {}).get("values") or [])
                rem = str(hit.get("value") or "").lower()
                vals = [v for v in cur if str(v).lower() != rem]
                _sync_project_zone_collections(project, idx, vals, (zone or {}).get("role") or hit.get("role"))
                changes.append(f"Removed {hit.get('value')} from Zone {idx}.")
        elif adding:
            for hit in non_level_hits:
                idx = int(hit.get("zone_index"))
                zone = _find_dynamic_zone(project, idx)
                cur = list((zone or {}).get("values") or [])
                vals = _dedupe_keep_order(cur + [hit.get("value")])
                _sync_project_zone_collections(project, idx, vals, (zone or {}).get("role") or hit.get("role"))
                changes.append(f"Added {hit.get('value')} to Zone {idx}.")

    # Reorder: make External first, put Stage 2 before Stage 1, put stages above others.
    if reorder and not _has_negated_destructive_action(text):
        if re.search(r"\bstages?\b.+\babove\b|\babove\b.+\bstages?\b", text, flags=re.I):
            msg = _update_hierarchy_for_stages_above(project)
            if msg:
                changes.append(msg)
        for hit in non_level_hits:
            idx = int(hit.get("zone_index"))
            zone = _find_dynamic_zone(project, idx)
            cur = list((zone or {}).get("values") or [])
            val = hit.get("value")
            if cur and val:
                if _has_any(text, ["last", "after"]):
                    vals = [v for v in cur if str(v).lower() != str(val).lower()] + [val]
                    changes.append(f"Moved {val} last in Zone {idx}.")
                else:
                    vals = [val] + [v for v in cur if str(v).lower() != str(val).lower()]
                    changes.append(f"Moved {val} first in Zone {idx}.")
                _sync_project_zone_collections(project, idx, vals, (zone or {}).get("role") or hit.get("role"))
        # Reorder explicit stage if stage value mentioned but not exact hit yet.
        if stage_values and stage_zone:
            idx = int(stage_zone.get("zone_index"))
            zone = _find_dynamic_zone(project, idx)
            cur = list((zone or {}).get("values") or [])
            val = stage_values[0]
            if val in cur:
                vals = [val] + [v for v in cur if str(v).lower() != val.lower()]
                _sync_project_zone_collections(project, idx, vals, (zone or {}).get("role") or "milestone")
                changes.append(f"Moved {val} first in Zone {idx}.")

    # Heading changes are still supported.
    head_num = parse_explicit_hierarchy_head_from_prompt(prompt)
    zone_head_match = re.search(r"\bzone\s*(\d+)\s*(?:in|at|to|as|=|should\s+be|set\s+as|use\s+as)?\s*head\s*([1-4])\b", str(prompt or ""), flags=re.I)
    if zone_head_match:
        target_idx = int(zone_head_match.group(1)); head_num = int(zone_head_match.group(2))
        # If using hierarchy_zones, update the specific hierarchy row.
        found = False
        for hz in project.get("hierarchy_zones") or []:
            try:
                if int(hz.get("zone_index")) == target_idx:
                    hz["head"] = _head_label_from_number(head_num); found = True
            except Exception:
                pass
        if found:
            changes.append(f"Changed Zone {target_idx} to {_head_label_from_number(head_num)}.")
        else:
            project["head3_zone_index"] = target_idx
            project["primary_head"] = _head_label_from_number(head_num)
            project["start_head"] = project["primary_head"]
            project["dimension_head"] = _next_head_label(project["primary_head"])
            zone = _find_dynamic_zone(project, target_idx)
            if zone:
                project["head3_values"] = list(zone.get("values") or [])
            changes.append(f"Changed Zone {target_idx} to {project['primary_head']} and detected type/combo to {project['dimension_head']}.")
    elif head_num:
        project["primary_head"] = _head_label_from_number(head_num)
        project["start_head"] = project["primary_head"]
        project["dimension_head"] = _next_head_label(project["primary_head"])
        changes.append(f"Changed primary heading to {project['primary_head']}.")

    # Short trade/profile amendments such as "Base on Steel" should update the
    # active Builder context instead of falling to Local AI. Keep this light and
    # do not touch the locked formula/export engine.
    if _has_any(text, ["steel", "metalwork", "structural steel", "purlin", "girt", "beam", "column", "rafter"]):
        setup.update({"trade_profile_id": "metalwork_structural_steel", "default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": setup.get("custom_quantity_name") or "Steel Surface Area", "custom_quantity_unit": setup.get("custom_quantity_unit") or "m2", "expected_unit": setup.get("custom_quantity_unit") or "m2"})
        plan.update({"trade_profile_id": "metalwork_structural_steel", "trade_profile_name": trade_profile_display_name_for_router("metalwork_structural_steel"), "default_function": "XGETCUSTOM", "function_mode": "force_default", "custom_quantity": setup.get("custom_quantity_name") or "Steel Surface Area", "unit": setup.get("custom_quantity_unit") or "m2"})
        changes.append("Updated active Builder trade/profile to Metalwork / Structural Steel.")
    elif _has_any(text, ["wall", "walls", "partition", "partitions", "wall type", "wall types"]):
        setup.update({"trade_profile_id": "walls_partitions", "default_costx_function": "XGETWALLAREA", "costx_function_mode": "preserve_detected", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "m2"})
        plan.update({"trade_profile_id": "walls_partitions", "trade_profile_name": trade_profile_display_name_for_router("walls_partitions"), "default_function": "XGETWALLAREA", "function_mode": "preserve_detected", "custom_quantity": "", "unit": "m2"})
        changes.append("Updated active Builder trade/profile to Walls / Partitions.")
    elif _has_any(text, ["door", "doors", "window", "windows"]):
        setup.update({"trade_profile_id": "doors_windows", "default_costx_function": "XGETCOUNT", "costx_function_mode": "force_default", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "no", "zone_token_mode": "preserve_source"})
        plan.update({"trade_profile_id": "doors_windows", "trade_profile_name": trade_profile_display_name_for_router("doors_windows"), "default_function": "XGETCOUNT", "function_mode": "force_default", "custom_quantity": "", "unit": "no"})
        changes.append("Updated active Builder trade/profile to Doors / Windows.")

    if not changes:
        # Action-specific clarification beats generic fallback.
        if removing:
            options = []
            for z in _project_all_dynamic_zones(project):
                for v in z.get("values") or []:
                    options.append({"label": f"Remove {v}", "reply": f"Confirm remove {v}"})
            for lv in project.get("level_values") or []:
                options.append({"label": f"Remove {lv}", "reply": f"remove {lv}"})
            return {"clarification": make_clarification("remove_target_unclear", "Which active plan value do you want to remove?", prompt, options[:8] + [{"label": "Cancel", "reply": "Cancel"}], {"active_plan": active_plan}), "confidence": 64, "risk": "review"}
        if reorder:
            options = []
            for z in _project_all_dynamic_zones(project):
                vals = list(z.get("values") or [])
                for v in vals[1:]:
                    options.append({"label": f"Make {v} first", "reply": f"make {v} first"})
            return {"clarification": make_clarification("reorder_target_unclear", "Which active plan value should move first?", prompt, options[:8] + [{"label": "Cancel", "reply": "Cancel"}], {"active_plan": active_plan}), "confidence": 64, "risk": "review"}
        return {"clarification": make_clarification("active_plan_edit_unclear", "I can update the active Builder plan, but I’m not sure what to change. Do you want this as an edit to the current plan or a new command?", prompt, [{"label": "Update current Builder plan", "reply": "Update current Builder plan"}, {"label": "Start new command", "reply": "new command: " + str(prompt or "")}, {"label": "Cancel", "reply": "cancel"}], {"active_plan": active_plan}), "confidence": 62, "risk": "review"}

    project["level_values"] = _canonical_level_sort(project.get("level_values") or [], preserve_user_order=bool(project.get("preserve_level_order")))
    project = _refresh_project_hierarchy_from_dynamic_zones(project)
    project["hierarchy_summary_lines"] = dynamic_hierarchy_summary_lines(project)
    setup["project_zone_hierarchy"] = project
    # v4.5.1.25: Doors/Windows count follow-ups such as "Use Count" / "Unit no"
    # must not silently flip source-preserve workflows back to rebuild. Preserve
    # source tokens for count-based door/window plans unless the user explicitly
    # provided a project hierarchy/zone edit in this message.
    _dw_source_preserve = normalize_builder_trade_profile_id(setup.get("trade_profile_id")) in {"doors", "windows", "doors_windows"} and sanitize_costx_function(setup.get("default_costx_function") or "", "") in {"XGETCOUNT", "XGETNUMBER"} and _is_builder_count_or_unit_confirmation(prompt)
    if _dw_source_preserve:
        setup["zone_token_mode"] = "preserve_source"
        plan["zone_mode"] = "preserve_source"
    else:
        setup["zone_token_mode"] = "rebuild"
        plan["zone_mode"] = "rebuild"
    plan["project_zone_hierarchy"] = project
    plan["builder_levels"] = build_project_builder_levels(project)
    plan["has_file"] = bool(has_file)
    # v4.5.1.24.2A: once a concrete/door/wall/steel trade has been selected,
    # remove stale trade-choice clarification cards from the active plan.
    if setup.get("trade_profile_id"):
        plan.pop("clarification", None)
    plan["confidence"] = max(70, min(99, int(plan.get("confidence") or 86)))
    plan["risk"] = "low"
    plan["requires_review_before_preview"] = False
    plan["next_action"] = "approve_and_preview"
    plan.setdefault("reasons", [])
    plan["reasons"] = [r for r in plan.get("reasons", []) if "Confidence is below" not in str(r)]
    plan["reasons"].append("Active Builder plan amended safely: " + " ".join(changes))
    integrity = validate_builder_plan_integrity(plan)
    plan["query_vision"] = build_dynamic_query_vision(prompt, plan, None, changes)
    plan["self_assessment"] = integrity
    if integrity.get("issues"):
        plan["risk"] = "review"
        plan["requires_review_before_preview"] = True
        plan["next_action"] = "review_setup_first"
        plan["reasons"].append("Right Track Guard blocked direct preview: " + "; ".join(integrity.get("issues") or []))
    return plan

def validate_costx_formula_string(formula: str) -> List[str]:
    issues: List[str] = []
    f = str(formula or "")
    if not f.startswith("="):
        issues.append("Formula does not start with =.")
    for left, right, label in [('"', '"', 'quotes'), ('[', ']', 'square brackets'), ('(', ')', 'parentheses')]:
        if left == right:
            if f.count(left) % 2:
                issues.append(f"Unbalanced {label}.")
        else:
            if f.count(left) != f.count(right):
                issues.append(f"Unbalanced {label}.")
    fn = re.match(r"=\s*(XGET[A-Z0-9_]+)\s*\(", f, flags=re.I)
    if not fn:
        issues.append("Formula does not start with a valid XGET function call.")
    if "[" in f and "]" in f:
        token = f[f.find("[")+1:f.find("]")]
        seen_idx: set[int] = set()
        for part in token.split(";"):
            if part and not re.match(r"^\d+\|.+$", part.strip()):
                issues.append("Invalid CostX zone token part: " + part.strip())
                continue
            if "|" in part:
                left, _right = part.split("|", 1)
                try:
                    idx = int(left.strip())
                except Exception:
                    continue
                if idx in seen_idx:
                    issues.append(f"Duplicate CostX zone token index: {idx}.")
                seen_idx.add(idx)
    return issues


def validate_builder_preview_integrity(preview_rows: List[Dict[str, Any]], current_work: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    warnings: List[str] = []
    expected_fn = sanitize_costx_function(current_work.get("default_costx_function") or "", "")
    expected_unit = canonical_builder_unit(current_work.get("expected_unit") or "")
    project = current_work.get("project_zone_hierarchy") if isinstance(current_work.get("project_zone_hierarchy"), dict) else {}
    allowed_by_idx: Dict[int, set] = {}
    if project:
        for zone in project.get("dynamic_zones") or []:
            try:
                idx = int(zone.get("zone_index"))
            except Exception:
                continue
            vals = {str(v).lower() for v in zone.get("values") or []}
            if vals:
                allowed_by_idx[idx] = vals
        try:
            level_idx = int(project.get("level_zone_index") or 0)
        except Exception:
            level_idx = 0
        level_vals: set[str] = set()
        for v in project.get("level_values") or []:
            raw_v = str(v or "").strip()
            if not raw_v:
                continue
            # v4.5.1.24.2D: Formula Integrity Guard must accept both the
            # user-facing level label (L11 Mezzanine) and the CostX token alias
            # requested for this run (for example L11 Mezz). The Builder row
            # generator already uses _level_label_for_project(); the guard must
            # validate against the same alias-aware value to avoid blocking safe
            # exports after a run-only Mezz alias instruction.
            level_vals.add(raw_v.lower())
            level_vals.add(_level_label(raw_v).lower())
            level_vals.add(_level_label_for_project(raw_v, project).lower())
        if level_idx and level_vals:
            allowed_by_idx[level_idx] = level_vals
    for i, row in enumerate(preview_rows[:200], start=1):
        formula = row.get("formula") or ""
        for issue in validate_costx_formula_string(formula):
            issues.append(f"Row {i}: {issue}")
        fn = str(row.get("function") or "").upper()
        unit = canonical_builder_unit(row.get("unit") or "")
        if expected_fn == "XGETCOUNT" and (fn != "XGETCOUNT" or unit != "no"):
            issues.append(f"Row {i}: XGETCOUNT/no expected but found {fn}/{unit}.")
        m = re.search(r"\[([^\]]+)\]", str(formula))
        token_map: Dict[int, str] = {}
        if m:
            for part in m.group(1).split(";"):
                if "|" in part:
                    k, v = part.split("|", 1)
                    try:
                        idx = int(k.strip())
                    except Exception:
                        continue
                    if idx in token_map:
                        issues.append(f"Row {i}: duplicate token index {idx}.")
                    token_map[idx] = v.strip()
        if token_map and allowed_by_idx:
            for idx, allowed in allowed_by_idx.items():
                if idx in token_map and allowed and str(token_map.get(idx, "")).lower() not in allowed:
                    issues.append(f"Row {i}: zone token {idx}|{token_map.get(idx)} is not in active Zone {idx} values.")
    seen = set()
    deduped = []
    for issue in issues:
        if issue not in seen:
            deduped.append(issue); seen.add(issue)
    status = "PASS" if not deduped else "BLOCKED"
    return {"status": status, "issues": deduped[:20], "warnings": warnings, "safe_to_preview": not deduped, "safe_to_export": not deduped}




def _project_setup_context_prompt(project_setup: Optional[Dict[str, Any]]) -> str:
    """Return a compact, parseable context string for pending clarification carryover."""
    if not isinstance(project_setup, dict):
        return ""
    parts: List[str] = []
    for z in (project_setup.get("dynamic_zones") or []):
        if not isinstance(z, dict) or z.get("role") == "level":
            continue
        try:
            idx = int(z.get("zone_index"))
        except Exception:
            continue
        vals = _dedupe_keep_order([_clean_zone_value(v) for v in (z.get("values") or []) if _clean_zone_value(v)])
        if vals:
            parts.append(f"Zone {idx} be " + ", ".join(vals))
    levels = _dedupe_keep_order([_level_label(v) for v in (project_setup.get("level_values") or []) if _level_label(v)])
    if levels:
        parts.append("levels " + ", ".join(levels) + " as formula rows")
    return "; ".join(parts)


def _contextualize_short_hierarchy_reply(reply: str, project_setup: Optional[Dict[str, Any]] = None) -> str:
    """Interpret short hierarchy replies against the active/pending project setup.

    Example while Jarvis is waiting for a heading layout:
    "Zone 2 head1 and Zone 1 head2" means Zone 2 is the first heading and
    detected type + Zone 1 is the next heading for typical two-zone Builder
    hierarchy. This avoids losing the original Door Trade/XGETCOUNT context.
    """
    raw = str(reply or "").strip()
    if not raw:
        return raw
    if re.search(r"\bdetected\b|\btype\b|\bdimension\b", raw, flags=re.I):
        return raw
    assignments = parse_zone_head_assignments(raw)
    if not assignments:
        return raw
    dyn = [z for z in ((project_setup or {}).get("dynamic_zones") or []) if isinstance(z, dict) and z.get("role") != "level"]
    # v4.4.4.13: explicit zone-to-head wording means standalone zone headings.
    # Example: "Zone 2 head1 and Zone 1 head2" should produce:
    #   Zone 2 = Head1; Zone 1 = Head2; detected dimension/type = Head3.
    # Only pair a zone with detected dimension/type when the user explicitly says
    # "detected type plus Zone N" / "dimension + Zone N", or when a zone is
    # mentioned without its own Head assignment (older shorthand: "Zone2 Head2 and Zone1").
    if len(assignments) >= 2:
        ordered = sorted(assignments.items(), key=lambda item: (item[1], item[0]))
        return "; ".join([f"Zone {idx} as Head{head}" for idx, head in ordered])
    return raw


def _option_hierarchy_prompt(project_setup: Optional[Dict[str, Any]], option: str) -> str:
    """Build a parseable prompt for option A/B using real detected zones."""
    setup = project_setup or {}
    dyn = [z for z in (setup.get("dynamic_zones") or []) if isinstance(z, dict) and z.get("role") != "level"]
    primary = next((z for z in dyn if z.get("role") in {"milestone", "tower", "area"}), dyn[0] if dyn else None)
    combo = next((z for z in dyn if z is not primary), None)
    if str(option).lower() == "b" and combo:
        primary, combo = combo, primary
    parts: List[str] = []
    if primary:
        parts.append(f"Zone {int(primary.get('zone_index'))} as Head1")
    if combo:
        parts.append(f"detected type plus Zone {int(combo.get('zone_index'))} as Head2")
    context = _project_setup_context_prompt(setup)
    if context:
        parts.append(context)
    parts.append("use parsed project hierarchy")
    return "; ".join(parts)

def build_custom_hierarchy_override_prompt(original: str, custom_reply: str, project_setup: Optional[Dict[str, Any]] = None) -> str:
    """Compose a custom hierarchy clarification as an override, not an append.

    v4.4.4.8: Put the clarification reply first so revised zone values
    such as "Zone 2 be Stage 1 and Stage 1b" win over values detected
    in the original command such as "Two Stage in Zone 2". The original
    command is kept after it so trade/function/level/Zone-1 context remains
    available.
    """
    reply = _contextualize_short_hierarchy_reply(str(custom_reply or "").strip(), project_setup)
    context = _project_setup_context_prompt(project_setup)
    base = str(original or "").strip()
    pieces = [reply, context, base, "custom hierarchy override use parsed project hierarchy"]
    return "; ".join([p for p in pieces if str(p or "").strip()]).strip()



def _strip_zone_prefix_from_replace_value(value: str) -> Tuple[Optional[int], str]:
    raw = str(value or "").strip()
    m = re.match(r"^\s*zone\s*([1-8])\s*[:=\-–—]?\s*(.+?)\s*$", raw, flags=re.I)
    if m:
        try:
            return int(m.group(1)), str(m.group(2) or "").strip(" ,;.-")
        except Exception:
            return None, raw
    return None, raw


def _resolve_replace_target_unclear_confirmation(prompt: str, pending: Dict[str, Any], active_plan: Optional[Dict[str, Any]], has_file: bool = False) -> Optional[Dict[str, Any]]:
    """Resolve the v4.5.1.26.1 replace-target clarification directly.

    This is deliberately narrow: it applies only to an already-active Builder
    plan and only edits explicit zone/level values. It prevents loops such as
    "Confirm replace Zone 1: Old with Toad" re-asking the same question.
    """
    answer = _router_text(prompt)
    if not answer:
        return None
    if _has_any(answer, ["cancel", "stop", "never mind", "nevermind"]):
        return {"tool_choice_only": True, "tool_key": "local_ai", "tool_label": "Jarvis", "confidence": 80, "message": "Replacement cancelled. No Builder setup was changed."}
    base_plan = _deepcopy_json(active_plan or ((pending.get("context") or {}).get("active_plan") if isinstance(pending, dict) else {}) or {})
    if not _has_active_builder_plan(base_plan):
        return None
    original = str(pending.get("original_prompt") or "")
    pair = _extract_replace_pair(prompt) or _extract_replace_pair(original)
    if not pair:
        return None
    raw_old, raw_new = pair
    idx_hint, old_value = _strip_zone_prefix_from_replace_value(raw_old)
    _, new_value = _strip_zone_prefix_from_replace_value(raw_new)
    old_value = str(old_value or "").strip(" ,;.-")
    new_value = str(new_value or "").strip(" ,;.-")
    if not old_value or not new_value:
        return None
    plan = base_plan
    setup = plan.setdefault("current_work_setup", {})
    project = plan.get("project_zone_hierarchy") or setup.get("project_zone_hierarchy") or {}
    if not isinstance(project, dict):
        return None
    changes: List[str] = []
    want_add = bool(re.match(r"^\s*add\b", str(prompt or ""), flags=re.I)) or "add as new" in answer
    want_replace = bool(re.search(r"\b(?:confirm|replace|yes|use this|use it|ok|okay|proceed)\b", answer, flags=re.I))
    if not (want_add or want_replace):
        return None

    if want_add:
        target_idx = idx_hint
        if target_idx is None:
            hit = (_find_zone_values_mentioned(project, old_value) or [None])[0]
            target_idx = int(hit.get("zone_index")) if isinstance(hit, dict) and hit.get("zone_index") else None
        if target_idx is None:
            zones = _project_all_dynamic_zones(project)
            target_idx = int((zones[0] or {}).get("zone_index") or 1) if zones else 1
        zone = _find_dynamic_zone(project, int(target_idx))
        vals = list((zone or {}).get("values") or [])
        if new_value not in vals:
            vals.append(new_value)
        _sync_project_zone_collections(project, int(target_idx), _dedupe_keep_order(vals), (zone or {}).get("role") if zone else f"zone_{target_idx}")
        changes.append(f"Added {new_value} as a Zone {target_idx} value.")
    elif want_replace:
        replaced = False
        if idx_hint is not None:
            zone = _find_dynamic_zone(project, int(idx_hint))
            vals = list((zone or {}).get("values") or [])
            if vals:
                new_vals = [new_value if str(v).lower() == old_value.lower() else v for v in vals]
                if new_vals != vals:
                    _sync_project_zone_collections(project, int(idx_hint), _dedupe_keep_order(new_vals), (zone or {}).get("role") or f"zone_{idx_hint}")
                    changes.append(f"Replaced Zone {idx_hint}: {old_value} with {new_value}.")
                    replaced = True
        if not replaced:
            for hit in _find_zone_values_mentioned(project, old_value):
                idx = int(hit.get("zone_index"))
                zone = _find_dynamic_zone(project, idx)
                vals = list((zone or {}).get("values") or [])
                if vals:
                    new_vals = [new_value if str(v).lower() == str(hit.get("value")).lower() else v for v in vals]
                    _sync_project_zone_collections(project, idx, _dedupe_keep_order(new_vals), (zone or {}).get("role") or hit.get("role"))
                    changes.append(f"Replaced Zone {idx}: {hit.get('value')} with {new_value}.")
                    replaced = True
                    break
        if not replaced:
            old_lv = _level_label(old_value); new_lv = _level_label(new_value)
            levels = list(project.get("level_values") or [])
            if any(str(v).lower() == old_lv.lower() for v in levels):
                project["level_values"] = _canonical_level_sort([new_lv if str(v).lower() == old_lv.lower() else v for v in levels], preserve_user_order=bool(project.get("preserve_level_order")))
                changes.append(f"Replaced level {old_lv} with {new_lv}.")
                replaced = True
        if not replaced:
            return None

    project = _refresh_project_hierarchy_from_dynamic_zones(project)
    project["hierarchy_summary_lines"] = dynamic_hierarchy_summary_lines(project)
    setup["project_zone_hierarchy"] = project
    plan["project_zone_hierarchy"] = project
    plan["builder_levels"] = build_project_builder_levels(project)
    plan["has_file"] = bool(has_file)
    plan["confidence"] = max(70, min(99, int(plan.get("confidence") or 86)))
    plan["risk"] = "low"
    plan["requires_review_before_preview"] = False
    plan["next_action"] = "approve_and_preview"
    plan.setdefault("reasons", [])
    plan["reasons"] = [r for r in plan.get("reasons", []) if "replace instruction" not in str(r).lower()]
    replacement_message = " ".join(changes).strip() or "Replacement applied."
    plan["clarification_resolved_message"] = replacement_message
    plan["message_override"] = replacement_message
    plan["reasons"].append("Resolved replacement clarification: " + replacement_message)
    integrity = validate_builder_plan_integrity(plan)
    plan["self_assessment"] = integrity
    plan["query_vision"] = build_dynamic_query_vision(prompt, plan, None, changes)
    if integrity.get("issues"):
        plan["risk"] = "review"
        plan["requires_review_before_preview"] = True
        plan["next_action"] = "review_setup_first"
        plan["reasons"].append("Right Track Guard blocked direct preview: " + "; ".join(integrity.get("issues") or []))
    return plan

def resolve_pending_clarification(prompt: str, pending: Optional[Dict[str, Any]], has_file: bool = False, active_plan: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    if not isinstance(pending, dict):
        return None
    kind = str(pending.get("type") or "").strip()
    original = str(pending.get("original_prompt") or "")
    answer = _router_text(prompt)
    combined = f"{original} {prompt}".strip()
    # v4.4.3 state guard: if the same command is submitted while a
    # clarification is pending, keep the clarification open instead of
    # re-routing it as a fresh command. The UI also blocks this, but the
    # backend guard keeps routing deterministic for repeated requests.
    if original and answer == _router_text(original):
        return {"clarification": pending, "confidence": int(pending.get("confidence") or 60), "risk": "review"}

    if kind == "replace_target_unclear":
        resolved_replace = _resolve_replace_target_unclear_confirmation(prompt, pending, active_plan, has_file)
        if resolved_replace:
            return resolved_replace

    if kind == "no_active_builder_plan_for_edit":
        if _has_any(answer, ["yes", "restore", "use previous", "continue", "current", "previous", "ok", "okay", "proceed"]):
            if _has_active_builder_plan(active_plan):
                return apply_active_builder_plan_amendment(active_plan or {}, original, has_file)
            return {"clarification": _active_plan_edit_no_plan_clarification(original), "confidence": 62, "risk": "review"}
        if _has_any(answer, ["new", "start"]):
            return build_builder_command_plan(original, has_file, allow_clarification=True)
        if _has_any(answer, ["cancel", "stop"]):
            return {"tool_choice_only": True, "tool_key": "local_ai", "tool_label": "Jarvis", "confidence": 80, "message": "Active-plan edit cancelled. No setup was changed and no file was created."}

    if kind in {"tool_choice", "base_boq_workflow_choice"}:
        if _has_any(answer, ["build", "base sheet", "builder", "costx"]):
            if _has_any(answer, ["current", "default"]):
                return builder_plan_from_current_default(combined, has_file, "User clarified: build base sheet using current Workspace default setup.")
            return build_builder_command_plan(combined, has_file, allow_clarification=False) or builder_plan_from_current_default(combined, has_file, "User clarified: build base sheet; using current Workspace default setup.")
        if _has_any(answer, ["compare", "comparison", "discrepancy", "checkmate"]):
            return {"tool_choice_only": True, "tool_key": "qs_checkmate", "tool_label": "Compare BOQ", "confidence": 86, "message": "Jarvis will route this to Compare BOQ / QS CheckMate. Deep command control will be connected after Builder dialogue is stable."}
        if _has_any(answer, ["format", "formatter", "workbook"]):
            return {"tool_choice_only": True, "tool_key": "formatter", "tool_label": "Format workbook", "confidence": 86, "message": "Jarvis will route this to Formatter. Deep command control will be connected after Builder dialogue is stable."}
        if _has_any(answer, ["write", "description", "item description"]):
            return {"tool_choice_only": True, "tool_key": "boq_writer", "tool_label": "Write BOQ description", "confidence": 84, "message": "Jarvis will route this to BOQ Writer. Deep command control will be connected after Builder dialogue is stable."}

    if kind == "builder_trade_choice":
        if is_zone_slot_only_update(prompt):
            if _has_active_builder_plan(active_plan):
                amended = apply_active_builder_plan_amendment(active_plan or {}, prompt, has_file)
            else:
                amended = {
                    "action": "build_base_sheet",
                    "intent": "builder_slot_only_update",
                    "confidence": 78,
                    "risk": "review",
                    "has_file": bool(has_file),
                    "current_work_setup": {},
                    "requires_review_before_preview": True,
                    "next_action": "ask_trade_profile",
                    "reasons": ["Zone slots were saved without choosing a trade/profile default."],
                }
                _ensure_project_from_zone_slots(amended, prompt)
            amended["clarification"] = builder_trade_clarification(original or prompt)
            amended["confidence"] = max(70, int(amended.get("confidence") or 78))
            amended["risk"] = "review"
            amended["requires_review_before_preview"] = True
            return amended
        if _has_any(answer, ["current", "default"]):
            return builder_plan_from_current_default(combined, has_file, "User clarified: use current Workspace default Builder setup.")
        return build_builder_command_plan(combined, has_file, allow_clarification=False) or builder_plan_from_current_default(combined, has_file, "User clarified Builder setup; using current Workspace default because no exact trade was matched.")

    if kind == "steel_quantity_choice":
        if _has_any(answer, ["current", "default"]):
            return builder_plan_from_current_default(combined, has_file, "User clarified: use current Workspace default Builder setup.")
        return build_builder_command_plan(f"steel metalwork {answer}", has_file, allow_clarification=False)

    if kind == "project_zone_hierarchy_confirm":
        project_setup = (pending.get("context") or {}).get("project_setup") or {}
        # v4.5.1.9: when Jarvis is waiting for hierarchy confirmation,
        # hierarchy replies such as "Zone 1 at Head2" are answers to this
        # pending Builder task, not generic Formatter commands.
        if _has_active_builder_plan(active_plan) and is_active_builder_plan_amendment(prompt):
            amended = apply_active_builder_plan_amendment(active_plan or {}, prompt, has_file)
            if amended:
                return amended
        pending_conflicts = detect_panic_conflicts(original, None)
        if pending_conflicts:
            return {"clarification": panic_conflict_clarification(original, pending_conflicts), "confidence": 74, "risk": "blocked"}
        if _has_any(answer, ["cancel", "stop"]):
            return {"tool_choice_only": True, "tool_key": "local_ai", "tool_label": "Jarvis", "confidence": 80, "message": "Project hierarchy setup cancelled. No setup was changed and no file was created."}
        if _has_any(answer, ["edit", "choose", "review"]):
            return {"clarification": builder_trade_clarification(combined), "confidence": 62, "risk": "review"}
        if _has_any(answer, ["yes", "use", "run", "approve", "ok", "okay", "this"]):
            return build_builder_command_plan(combined + " use parsed project hierarchy", has_file, allow_clarification=False)

    if kind == "zone_mode_conflict":
        if _has_any(answer, ["preserve", "original", "source"]):
            return build_builder_command_plan(original + " preserve source zones", has_file, allow_clarification=False)
        if _has_any(answer, ["rebuild", "run only", "project zones", "my project"]):
            clean_original = re.sub(r"preserve source zones|keep source zones|original CostX zones|keep original CostX zones", "", original, flags=re.I)
            return build_builder_command_plan(clean_original + " use parsed project hierarchy", has_file, allow_clarification=False)
        if _has_any(answer, ["edit", "choose", "review"]):
            return {"clarification": builder_trade_clarification(combined), "confidence": 62, "risk": "review"}

    if kind == "trade_title_head1_choice":
        if _has_any(answer, ["separate", "top row", "trade title"]):
            return build_builder_command_plan(original + " trade title as separate top row use parsed project hierarchy", has_file, allow_clarification=False)
        if _has_any(answer, ["stage", "zone", "first", "no trade", "without"]):
            return build_builder_command_plan(original + " no trade title row stage rows are first use parsed project hierarchy", has_file, allow_clarification=False)
        if _has_any(answer, ["edit", "choose", "review"]):
            return {"clarification": builder_trade_clarification(combined), "confidence": 62, "risk": "review"}

    if kind == "ambiguous_zone_mapping":
        if _has_any(answer, ["cancel", "stop"]):
            return {"tool_choice_only": True, "tool_key": "local_ai", "tool_label": "Jarvis", "confidence": 80, "message": "Zone mapping cancelled. No setup was changed and no file was created."}
        if _has_any(answer, ["custom", "describe"]):
            return {"clarification": custom_hierarchy_format_clarification(original, {}), "confidence": 62, "risk": "review"}
        mapped_prompt = f"{original}; {prompt}; use parsed project hierarchy"
        mapped_setup = detect_project_zone_hierarchy_intent(mapped_prompt) or {}
        # If user supplied zone numbers/values but asked for heading order, preserve
        # the command context and ask a hierarchy question rather than building a weak plan.
        if mapped_setup and needs_hierarchy_options(mapped_prompt, mapped_setup):
            return {"clarification": hierarchy_options_clarification(mapped_prompt, mapped_setup), "confidence": 68, "risk": "review"}
        if mapped_setup and mapped_setup.get("enabled"):
            return build_builder_command_plan(mapped_prompt, has_file, allow_clarification=False)
        return {"clarification": hierarchy_options_clarification(mapped_prompt, mapped_setup), "confidence": 68, "risk": "review"}

    if kind == "hierarchy_option_choice":
        project_setup = (pending.get("context") or {}).get("project_setup") or {}
        # v4.5.1.23: while a hierarchy choice is pending, user may correct the
        # trade/function instead of choosing A/B/C, e.g. "change it to door count".
        # Preserve the parsed project zones/levels and only change the trade slots.
        if re.search(r"\b(?:door|doors|window|windows)\b", answer, flags=re.I) and re.search(r"\b(?:count|counts|no|number)\b", answer, flags=re.I):
            plan = build_builder_command_plan("Create Door BOQ base sheet using count", has_file, allow_clarification=False)
            if plan and project_setup:
                plan["project_zone_hierarchy"] = project_setup
                plan["builder_levels"] = build_project_builder_levels(project_setup) if project_setup.get("level_values") or project_setup.get("dynamic_zones") else []
                plan.setdefault("current_work_setup", {})["project_zone_hierarchy"] = project_setup
                plan.setdefault("current_work_setup", {})["zone_token_mode"] = "rebuild"
                plan["zone_mode"] = "rebuild_run_only"
                plan.setdefault("reasons", []).append("Pending hierarchy preserved while changing trade/function to door count.")
            return plan
        if re.search(r"\b(?:steel|structural\s+steel|metalwork)\b", answer, flags=re.I):
            mentions = detect_steel_quantity_mentions(prompt)
            chosen = choose_steel_quantity_from_mentions(mentions)
            if chosen:
                plan = build_builder_command_plan(f"structural steel {chosen.get('label')}", has_file, allow_clarification=False)
                if plan and project_setup:
                    plan["project_zone_hierarchy"] = project_setup
                    plan["builder_levels"] = build_project_builder_levels(project_setup) if project_setup.get("level_values") or project_setup.get("dynamic_zones") else []
                    plan.setdefault("current_work_setup", {})["project_zone_hierarchy"] = project_setup
                    plan.setdefault("current_work_setup", {})["zone_token_mode"] = "rebuild"
                    plan["zone_mode"] = "rebuild_run_only"
                    plan.setdefault("reasons", []).append("Pending hierarchy preserved while changing trade/function to structural steel.")
                return plan
        pending_conflicts = detect_panic_conflicts(original, None)
        if pending_conflicts:
            return {"clarification": panic_conflict_clarification(original, pending_conflicts), "confidence": 74, "risk": "blocked"}
        if _has_any(answer, ["current", "default"]):
            if project_setup and (project_setup.get("dynamic_zones") or project_setup.get("level_values")):
                return {"clarification": make_clarification("unsafe_workspace_default_guard", "This command already contains project-specific zone/level instructions. Using the current Workspace default could create duplicate or wrong CostX tokens. Choose a hierarchy option or describe the format instead.", original, [{"label": "I will describe custom format", "reply": "I will describe custom format"}, {"label": "Cancel", "reply": "Cancel"}], {"project_setup": project_setup}), "confidence": 70, "risk": "review"}
            return builder_plan_from_current_default(combined, has_file, "User clarified: use current Workspace default hierarchy/setup.")
        if parse_zone_head_assignments(prompt):
            return build_builder_command_plan(build_custom_hierarchy_override_prompt(original, prompt, project_setup), has_file, allow_clarification=False)
        if re.search(r"\boption\s*a\b|^use\s+a\b|primary\s+zone\s+as\s+first\s+head|type\s+plus\s+combo", answer, flags=re.I):
            return build_builder_command_plan(f"{original}; {_option_hierarchy_prompt(project_setup, 'a')}", has_file, allow_clarification=False)
        if _has_any(answer, ["run only", "run only setup", "use setup", "okay", "ok", "yes", "approve", "proceed"]):
            # v4.5.1.22: a short approval to a hierarchy-option card should not fall to Local AI.
            # Use safe Option A: first detected project zone as heading, other zone(s) combined with detected type.
            return build_builder_command_plan(f"{original}; {_option_hierarchy_prompt(project_setup, 'a')}", has_file, allow_clarification=False)
        if re.search(r"\boption\s*b\b|^use\s+b\b|combo\s+zone\s+as\s+first\s+head", answer, flags=re.I):
            return build_builder_command_plan(f"{original}; {_option_hierarchy_prompt(project_setup, 'b')}", has_file, allow_clarification=False)
        if _has_any(answer, ["option c", " use c", "detected type as first"]):
            return {"clarification": custom_hierarchy_format_clarification(original, project_setup), "confidence": 62, "risk": "review"}
        if _has_any(answer, ["custom", "describe"]):
            return {"clarification": custom_hierarchy_format_clarification(original, project_setup), "confidence": 62, "risk": "review"}

    if kind == "custom_hierarchy_format":
        project_setup = (pending.get("context") or {}).get("project_setup") or {}
        if _has_any(answer, ["cancel", "stop"]):
            return {"tool_choice_only": True, "tool_key": "local_ai", "tool_label": "Jarvis", "confidence": 80, "message": "Custom hierarchy setup cancelled. No setup was changed and no file was created."}
        # Require the follow-up to actually contain layout information. A short
        # acknowledgement should keep the card open instead of accidentally
        # running Builder.
        has_layout_words = _has_any(answer, ["zone", "head", "level", "levels", "stage", "external", "internal", "rows", "formula"])
        if not has_layout_words or len(answer) < 12:
            return {"clarification": custom_hierarchy_format_clarification(original, project_setup), "confidence": 62, "risk": "review"}
        return build_builder_command_plan(build_custom_hierarchy_override_prompt(original, prompt, project_setup), has_file, allow_clarification=False)

    if kind == "complicated_edit_confirm":
        context = pending.get("context") or {}
        active = context.get("active_plan") or {}
        likely_stage = context.get("likely_stage")
        keep_location = context.get("keep_location")
        if _has_any(answer, ["confirm", "yes", "proceed", "approve"]):
            parts = []
            if likely_stage:
                parts.append(f"remove {likely_stage}")
            if keep_location:
                # keep only External means remove the opposite branch.
                opposite = "Internal" if str(keep_location).lower() == "external" else "External"
                parts.append(f"confirm remove {opposite}")
            return apply_active_builder_plan_amendment(active, "; ".join(parts) or original, has_file) or {"clarification": pending, "confidence": 66, "risk": "review"}
        return {"clarification": make_clarification("complicated_edit_reclarify", "Please type the exact edit, for example: remove Stage 2b and keep only External.", original, [{"label": "Cancel", "reply": "Cancel"}], {"active_plan": active}), "confidence": 62, "risk": "review"}

    if kind == "level_zone_token_choice":
        context = pending.get("context") or {}
        project_setup = context.get("project_setup") or {}
        level_zone = None
        m = re.search(r"zone\s*(\d+)", answer, flags=re.I)
        if m:
            try:
                level_zone = int(m.group(1))
            except Exception:
                level_zone = None
        elif _has_any(answer, ["next free", "first option"]):
            level_zone = context.get("next_free")
        elif _has_any(answer, ["after highest", "second option"]):
            level_zone = context.get("after_highest")
        if level_zone:
            project_setup["level_zone_index"] = int(level_zone)
            project_setup["hierarchy_description"] = re.sub(r"Levels = formula rows \(Zone \d+\)", f"Levels = formula rows (Zone {int(level_zone)})", project_setup.get("hierarchy_description") or "")
            return build_builder_command_plan(original + f" levels as Zone {int(level_zone)} use parsed project hierarchy", has_file, allow_clarification=False)
        return {"clarification": skipped_zone_level_clarification(original, project_setup), "confidence": 70, "risk": "review"}

    if kind == "format_conflict":
        if _has_any(answer, ["builder only", "no format", "do not format"]):
            return build_builder_command_plan(original + " base sheet only do not format yet", has_file, allow_clarification=False)
        if _has_any(answer, ["formatter", "format workbook", "format only"]):
            return {"tool_choice_only": True, "tool_key": "formatter", "tool_label": "Format workbook", "confidence": 86, "message": "Jarvis will route this to Formatter. Deep command control will be connected after Builder dialogue is stable."}
        if _has_any(answer, ["then", "later", "after"]):
            return build_builder_command_plan(original + " builder only then formatter later", has_file, allow_clarification=False)

    if kind == "basement_range_choice":
        context = pending.get("context") or {}
        typed_order = context.get("typed_order") or []
        reverse_order = context.get("reverse_order") or []
        answer_levels = [_level_label(tok) for tok in re.findall(r"\bB\s*\d+\b", str(prompt or ""), flags=re.I)]
        chosen: List[str] = []
        if answer_levels:
            chosen = answer_levels
        elif _has_any(answer, ["ascending", "typed order", "first option"]):
            chosen = typed_order
        elif _has_any(answer, ["descending", "reverse", "second option"]):
            chosen = reverse_order
        if chosen:
            return build_builder_command_plan(original + " use basement level list " + ", ".join(chosen), has_file, allow_clarification=False)
        if _has_any(answer, ["type", "exact"]):
            return {"clarification": builder_trade_clarification(combined), "confidence": 62, "risk": "review"}

    return None



def detect_steel_quantity_mentions(text: str) -> List[Dict[str, str]]:
    """Return steel custom quantities mentioned in the command, preserving first occurrence.

    This catches conflicts such as "Weight and Steel Surface Area" and override wording
    such as "tonnage but use Steel Surface Area" without changing the Builder engine.
    """
    specs = [
        ("Weight", "t", [r"\bweight\b", r"\btonnage\b", r"\btonne\b", r"\btons\b"]),
        ("Steel Surface Area", "m2", [r"\bsteel\s+surface\b", r"\bsurface\s+area\b"]),
        ("RAKING CUTTING", "m", [r"\braking\s+cutting\b", r"\braking\b"]),
        ("Slope Length", "m", [r"\bslope\s+length\b", r"\blength\s+slope\b"]),
        ("Core Filling", "m3", [r"\bcore\s+filling\b", r"\bcorefill\b"]),
        ("Reinforcement by Ratio", "t", [r"\breinforcement\s+by\s+ratio\b"]),
        ("Formworks", "m2", [r"\bformworks?\b"]),
    ]
    found: List[Dict[str, str]] = []
    seen = set()
    for label, unit, patterns in specs:
        best = None
        for pat in patterns:
            m = re.search(pat, text, flags=re.I)
            if m and (best is None or m.start() < best):
                best = m.start()
        if best is not None and label.lower() not in seen:
            found.append({"label": label, "unit": unit, "position": str(best)})
            seen.add(label.lower())
    found.sort(key=lambda item: int(item.get("position", "0")))
    return found


def choose_steel_quantity_from_mentions(text: str, mentions: List[Dict[str, str]]) -> Optional[Dict[str, str]]:
    if not mentions:
        return None
    # "but use X" is an explicit override. Prefer the first quantity mentioned after this phrase.
    override_match = re.search(r"\bbut\s+use\b|\boverride\s+with\b|\binstead\s+use\b", text, flags=re.I)
    if override_match:
        tail = text[override_match.end():]
        tail_mentions = detect_steel_quantity_mentions(tail)
        if tail_mentions:
            return tail_mentions[0]
    if len(mentions) == 1:
        return mentions[0]
    return None


def has_format_conflict(text: str) -> bool:
    wants_format = _has_any(text, ["format it", "format workbook", "format this", "then format", "and format"])
    no_format = _has_any(text, ["do not format", "don't format", "no formatting", "no format", "not format yet", "do not format yet", "base sheet only"])
    return wants_format and no_format


def has_zone_mode_conflict(text: str, project_setup: Optional[Dict[str, Any]]) -> bool:
    if not project_setup:
        return False
    stated_project_structure = bool(project_setup.get("dynamic_zones") or project_setup.get("level_values"))
    preserve_source_explicit = _has_any(text, ["preserve source zones", "keep source zones", "original costx zones", "keep original costx zones", "original source zones", "preserve original costx zones"])
    return stated_project_structure and preserve_source_explicit


def needs_hierarchy_options(text: str, project_setup: Optional[Dict[str, Any]]) -> bool:
    if _has_any(text, ["arrange it nicely", "arranged nicely", "nice hierarchy", "hierarchy", "format option", "combo"]):
        return bool(_has_any(text, ["milestone", "internal", "external", "levels", "zone"]))
    if project_setup:
        non_level_zones = [z for z in (project_setup.get("dynamic_zones") or []) if isinstance(z, dict) and z.get("role") != "level"]
        explicit_head = bool(project_setup.get("explicit_start_head"))
        # v4.4.4.7: if the user provides two or more project zones but does not
        # state the first Head level, ask with concrete zone options instead of
        # silently locking into one hierarchy.
        if len(non_level_zones) > 1 and not explicit_head:
            return True
    return bool(project_setup and project_setup.get("needs_hierarchy_choice"))



def needs_skipped_zone_level_clarification(project_setup: Optional[Dict[str, Any]], prompt: str = "") -> bool:
    if not isinstance(project_setup, dict) or not project_setup.get("enabled"):
        return False
    # If the user explicitly specified a level Zone N, do not ask.
    if re.search(r"\blevels?\s+(?:as|in|at|under|within)?\s*zone\s*\d+\b|\bzone\s*\d+\s*(?:is|are|=|:)\s*(?:levels?|l\d+|gf|roof)", str(prompt or ""), flags=re.I):
        return False
    non_level_indices = []
    for z in project_setup.get("dynamic_zones") or []:
        if not isinstance(z, dict) or z.get("role") == "level":
            continue
        try:
            non_level_indices.append(int(z.get("zone_index")))
        except Exception:
            pass
    if not non_level_indices:
        return False
    # Ask only for clearly skipped/high custom zone maps such as Zone 5/7.
    return max(non_level_indices) >= 5 and bool(project_setup.get("level_values"))


def skipped_zone_level_clarification(prompt: str, project_setup: Dict[str, Any]) -> Dict[str, Any]:
    used = []
    for z in project_setup.get("dynamic_zones") or []:
        if not isinstance(z, dict) or z.get("role") == "level":
            continue
        try:
            used.append(int(z.get("zone_index")))
        except Exception:
            pass
    next_free = _first_free_zone_index(used, 3)
    after_highest = max(used or [2]) + 1
    return make_clarification(
        "level_zone_token_choice",
        f"Your command uses skipped CostX zone numbers ({', '.join('Zone '+str(i) for i in sorted(used))}). Which CostX zone token should levels use?",
        prompt,
        [
            {"label": f"Use next free Zone {next_free}", "reply": f"Use levels as Zone {next_free}"},
            {"label": f"Use next after highest Zone {after_highest}", "reply": f"Use levels as Zone {after_highest}"},
            {"label": "I will type the level zone", "reply": "I will type the level zone"},
            {"label": "Cancel", "reply": "Cancel"},
        ],
        {"project_setup": project_setup, "next_free": next_free, "after_highest": after_highest},
    )

def build_builder_command_plan(prompt: str, has_file: bool = False, allow_clarification: bool = True) -> Optional[Dict[str, Any]]:
    """v4.4.2.4 Builder Command Router with Dynamic Zone Role Parsing.

    This is intentionally a rule-based, local router. It does not modify the
    Builder formula engine. It only suggests a Builder run context that can be
    applied to the existing v4.3.9.2 preview/export flow after approval.
    """
    text = _router_text(prompt)
    if not text:
        return None
    if re.fullmatch(r"(?:b\d+\s+(?:first|last)|(?:first|last)\s+b\d+)", text, flags=re.I):
        return None
    # v4.4.4.7 continuity guard: this is a clarification-choice phrase,
    # not an approval to run Builder. If frontend state is lost, keep asking
    # for the custom hierarchy instead of routing stale context.
    if re.fullmatch(r"(?:i\s+will\s+describe\s+(?:a\s+)?custom\s+(?:hierarchy|format)|describe\s+custom\s+(?:hierarchy|format)|custom\s+(?:hierarchy|format))", text, flags=re.I):
        return {"clarification": custom_hierarchy_format_clarification(prompt), "confidence": 62, "risk": "review"}

    default_requested = _has_any(text, ["by default", "default setting", "default settings", "current setup", "current default", "current default setup", "current workspace", "workspace default", "use default", "using default"])
    boq_related = "boq" in text
    project_setup = detect_project_zone_hierarchy_intent(prompt)
    trade_or_setup_requested = _has_any(text, ["door", "doors", "window", "windows", "wall", "walls", "partition", "partitions", "steel", "metalwork", "concrete", "reo", "zone", "level", "levels", "head", "old", "new", "internal", "external"])
    base_sheet_requested = _has_any(text, ["base sheet", "builder", "costx", "dimension group", "dimension groups", "xget"]) or (boq_related and trade_or_setup_requested)

    pre_item_code_config = detect_item_code_intent(prompt)

    if allow_clarification:
        panic_issues = detect_panic_conflicts(prompt, None)
        if panic_issues:
            return {"clarification": panic_conflict_clarification(prompt, panic_issues), "confidence": 74, "risk": "blocked"}

    if allow_clarification and needs_skipped_zone_level_clarification(project_setup, prompt):
        return {"clarification": skipped_zone_level_clarification(prompt, project_setup or {}), "confidence": 70, "risk": "review"}

    if allow_clarification and needs_ambiguous_zone_mapping_clarification(prompt):
        return {"clarification": ambiguous_zone_mapping_clarification(prompt), "confidence": 64, "risk": "review"}

    if allow_clarification and has_format_conflict(text):
        return {"clarification": format_conflict_clarification(prompt), "confidence": 62, "risk": "review"}

    if allow_clarification and boq_related and not base_sheet_requested and not _has_any(text, ["compare", "format", "description", "write"]):
        return {"clarification": tool_choice_clarification(prompt), "confidence": 62, "risk": "review"}
    if default_requested and base_sheet_requested:
        return builder_plan_from_current_default(prompt, has_file, "Default setup requested; using current Workspace Builder setup instead of guessing a trade.")

    if allow_clarification:
        b_range = _has_basement_range_needing_clarification(prompt)
        if b_range:
            return {"clarification": basement_range_clarification(prompt, b_range[0], b_range[1]), "confidence": 72, "risk": "review"}

    if allow_clarification and has_zone_mode_conflict(text, project_setup):
        return {"clarification": zone_mode_conflict_clarification(prompt, project_setup or {}), "confidence": 72, "risk": "review"}

    if allow_clarification and needs_hierarchy_options(text, project_setup):
        return {"clarification": hierarchy_options_clarification(prompt, project_setup), "confidence": 68, "risk": "review"}

    if allow_clarification and pre_item_code_config and pre_item_code_config.get("trade_title_enabled") and project_setup and project_setup.get("enabled") and (project_setup.get("primary_head") or project_setup.get("start_head")) == "Head1" and _has_any(text, ["trade title", "from trade title", "section title", "trade heading"]):
        return {"clarification": trade_title_head1_clarification(prompt, project_setup), "confidence": 70, "risk": "review"}

    if allow_clarification and project_setup and project_setup.get("confirmation_needed") and not _has_any(text, ["use parsed project hierarchy", "run only setup"]):
        return {"clarification": project_setup_clarification(prompt, project_setup), "confidence": 72, "risk": "review"}

    steel_mentions = detect_steel_quantity_mentions(text)
    chosen_steel_quantity = choose_steel_quantity_from_mentions(text, steel_mentions)
    if allow_clarification and len(steel_mentions) > 1 and chosen_steel_quantity is None:
        return {"clarification": steel_quantity_conflict_clarification(prompt, steel_mentions), "confidence": 68, "risk": "review"}

    preserve_formula_requested = _has_any(text, ["preserve detected", "keep detected", "keep detected formulas", "preserve source formulas", "preserve formulas", "detected formulas", "keep source", "same functions", "mixed functions"])
    builder_words = ["build", "base sheet", "costx", "builder", "xget", "dimension group", "dimension groups", "boq base sheet"]
    looks_builder = any(word in text for word in builder_words) or preserve_formula_requested or bool(project_setup and (project_setup.get("dynamic_zones") or project_setup.get("head3_values") or project_setup.get("level_values")))
    trade_words = [
        "steel", "metalwork", "structural steel", "purlin", "girt", "beam", "column", "rafter",
        "door", "doors", "window", "windows", "wall", "walls", "partition", "partitions",
        "finish", "finishes", "floor finish", "ceiling finish", "joinery", "concrete", "reo", "reinforcement",
    ]
    if not looks_builder and not any(word in text for word in trade_words):
        return None

    setup: Dict[str, Any] = {
        "project_name": "Current Project",
        "trade_profile_id": "walls_partitions",
        "setup_name": "Command Router Plan",
        "formula_mode": "Compact",
        "default_costx_function": "XGETWALLAREA",
        "costx_function_mode": "preserve_detected",
        "custom_quantity_name": "",
        "custom_quantity_unit": "",
        "expected_unit": "m2",
        "zone_token_mode": "preserve_source",
        "notes": "Created by Jarvis v4.4.4.20 Stable Release Gate. Preview first before export.",
    }
    if project_setup and (project_setup.get("enabled") or project_setup.get("dynamic_zones") or project_setup.get("hierarchy_zones") or project_setup.get("level_values")):
        # v4.5.1.22: preserve partial run-only hierarchy in the active plan even
        # before levels are supplied, so follow-up replies amend the same plan.
        setup["project_zone_hierarchy"] = project_setup
        setup["zone_token_mode"] = "rebuild"
        setup["notes"] = "Created by Jarvis v4.4.4.20 Stable Release Gate. Run-only project setup; no Formatter pass."

    item_code_config = pre_item_code_config
    if item_code_config:
        setup["item_code_config"] = item_code_config

    reasons: List[str] = []
    if item_code_config:
        reasons.append("Flexible BOQ item coding requested; Column A will use " + builder_item_code_summary(item_code_config) + ". Item codes are output-only and do not affect CostX formulas or zone tokens.")
    matched: List[str] = []
    confidence = 64
    risk = "low"
    project_builder_levels: List[Dict[str, Any]] = build_project_builder_levels(project_setup) if project_setup and (project_setup.get("enabled") or project_setup.get("dynamic_zones") or project_setup.get("hierarchy_zones") or project_setup.get("level_values")) else []

    def hit(words: List[str]) -> bool:
        found = [w for w in words if w in text]
        matched.extend(found)
        return bool(found)

    # Trade selection
    wall_type_intent = bool(re.search(r"\bwall\s*types?\b|\bwall\s+type\b", str(prompt or ""), flags=re.I))
    if wall_type_intent:
        # v4.4.4.5 context lock: "Wall Types trade" must survive clarification replies
        # and must not fall back to a previously selected Steel/Metalwork workspace setup.
        setup.update({
            "trade_profile_id": "walls_partitions",
            "default_costx_function": "XGETWALLAREA",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "m2",
        })
        reasons.append("Wall Types trade detected; using Walls / Partitions with XGETWALLAREA / m2 for this run.")
        confidence += 16
    elif hit(["steel", "structural steel", "metalwork", "purlin", "girt", "beam", "column", "rafter"]):
        setup.update({
            "trade_profile_id": "metalwork_structural_steel",
            "default_costx_function": "XGETCUSTOM",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "Slope Length",
            "custom_quantity_unit": "m",
            "expected_unit": "m",
        })
        reasons.append("Steel/metalwork keywords detected; using Metalwork / Structural Steel with XGETCUSTOM.")
        confidence += 18
    elif hit(["door", "doors", "window", "windows", "count", "number"]):
        setup.update({
            "trade_profile_id": "doors_windows",
            "default_costx_function": "XGETCOUNT",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "no",
        })
        reasons.append("Door/window/count keywords detected; using XGETCOUNT with lowercase no.")
        confidence += 16
    elif hit(["wall", "walls", "partition", "partitions", "lining", "plasterboard"]):
        setup.update({
            "trade_profile_id": "walls_partitions",
            "default_costx_function": "XGETWALLAREA",
            "costx_function_mode": "preserve_detected",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "m2",
        })
        reasons.append("Walls/partitions keywords detected; preserving detected functions with XGETWALLAREA as default guidance.")
        confidence += 14
    elif hit(["finish", "finishes", "floor finish", "ceiling finish", "vinyl", "tile", "carpet"]):
        setup.update({
            "trade_profile_id": "finishes",
            "default_costx_function": "XGETAREA",
            "costx_function_mode": "preserve_detected",
            "custom_quantity_name": "",
            "custom_quantity_unit": "",
            "expected_unit": "m2",
        })
        reasons.append("Finishes keywords detected; preserving detected functions with XGETAREA as default guidance.")
        confidence += 12
    elif hit(["concrete", "reo", "reinforcement", "formwork", "formworks", "pt", "core filling"]):
        setup.update({
            "trade_profile_id": "concrete_reo",
            "default_costx_function": "XGETCUSTOM",
            "costx_function_mode": "force_default",
            "custom_quantity_name": "Formworks",
            "custom_quantity_unit": "m2",
            "expected_unit": "m2",
        })
        reasons.append("Concrete/reo keywords detected; using Concrete / Reo custom quantity guidance.")
        confidence += 12
    else:
        if allow_clarification and looks_builder:
            return {"clarification": builder_trade_clarification(prompt), "confidence": 52, "risk": "review"}
        reasons.append("Builder task detected, but trade is not explicit. Jarvis will ask you to review the setup before preview.")
        confidence -= 12

    # Function/custom quantity overrides
    if any(k in text for k in ["preserve detected", "keep detected", "keep detected formulas", "preserve source formulas", "preserving source", "preserve formulas", "detected formulas", "keep source", "same function", "same functions", "mixed function", "mixed functions"]):
        setup["costx_function_mode"] = "preserve_detected"
        reasons.append("Preserve detected mode requested.")
        confidence += 5
    if any(k in text for k in ["force", "force default"]):
        setup["costx_function_mode"] = "force_default"
        reasons.append("Force default mode requested.")
        confidence += 3

    selected_qty = chosen_steel_quantity
    if selected_qty:
        setup.update({"default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": selected_qty["label"], "custom_quantity_unit": selected_qty["unit"], "expected_unit": selected_qty["unit"]})
        reasons.append(f"Custom quantity override detected: {selected_qty['label']} / {selected_qty['unit']}.")
        if len(steel_mentions) > 1:
            reasons.append("Conflict guard: multiple steel custom quantities were mentioned; explicit override wording selected the final custom quantity for this run.")
        confidence += 10
    elif any(k in text for k in ["core filling", "corefill"]):
        setup.update({"default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": "Core Filling", "custom_quantity_unit": "m3", "expected_unit": "m3"})
        reasons.append("Custom quantity override detected: Core Filling / m3.")
        confidence += 8
    elif any(k in text for k in ["reinforcement by ratio"]):
        setup.update({"default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": "Reinforcement by Ratio", "custom_quantity_unit": "t", "expected_unit": "t"})
        reasons.append("Custom quantity override detected: Reinforcement by Ratio / t.")
        confidence += 8
    elif any(k in text for k in ["formwork", "formworks"]):
        setup.update({"default_costx_function": "XGETCUSTOM", "costx_function_mode": "force_default", "custom_quantity_name": "Formworks", "custom_quantity_unit": "m2", "expected_unit": "m2"})
        reasons.append("Custom quantity override detected: Formworks / m2.")
        confidence += 8

    if any(k in text for k in ["count", "number", "no.", " no "]):
        if setup["trade_profile_id"] in {"doors_windows", "doors", "windows"} or any(k in text for k in ["door", "window"]):
            setup.update({"default_costx_function": "XGETCOUNT", "costx_function_mode": "force_default", "custom_quantity_name": "", "custom_quantity_unit": "", "expected_unit": "no"})
            reasons.append("Count/number requested; using XGETCOUNT with lowercase no.")
            confidence += 6

    if project_setup and project_setup.get("enabled"):
        reasons.append("Project Zone Hierarchy detected: dynamic zone roles are used for this run. " + (project_setup.get("hierarchy_description") or "The selected dynamic zone becomes the requested Head level; detected dimension/type becomes the next Head level; parsed levels become item/formula rows."))
        reasons.append("Run-only setup: parsed zones/levels are used for this preview/export and should not overwrite stable Workspace defaults unless saved later as a Project Preset.")
        if project_setup.get("formatting") == "builder_base_only":
            reasons.append("No formatting requested; Jarvis will run Builder base output only and will not call Formatter.")
        excluded_levels = _parse_level_exclusions(prompt)
        # Compare exclusions against the range before exclusions are removed,
        # so valid exclusions such as L3 from L1-L6 are not reported as ignored.
        prompt_without_exclusions = re.sub(r"\b(?:exclud(?:e|ing)|except)\s+[^\.\n]+", "", str(prompt or ""), flags=re.I)
        raw_selected_levels = set(str(lv).lower() for lv in parse_levels_from_prompt(prompt_without_exclusions))
        ignored_exclusions = [lv for lv in excluded_levels if lv.lower() not in raw_selected_levels]
        if ignored_exclusions:
            reasons.append("Some excluded levels were outside the selected parsed range and were ignored: " + ", ".join(ignored_exclusions) + ".")
        confidence += 10

    explicit_steel_quantity = bool(steel_mentions) or _has_any(text, ["default", "current setup", "current workspace"])
    if allow_clarification and setup.get("trade_profile_id") == "metalwork_structural_steel" and not explicit_steel_quantity:
        return {"clarification": steel_quantity_clarification(prompt), "confidence": 68, "risk": "review"}

    confidence = max(35, min(99, confidence))
    requires_review_before_preview = confidence < 70
    next_action = "approve_and_preview"
    if requires_review_before_preview:
        risk = "review"
        next_action = "review_setup_first"
        if not any("not explicit" in reason.lower() for reason in reasons):
            reasons.append("Confidence is below 70%; Jarvis requires Workspace review before Preview.")

    plan = {
        "tool": "builder",
        "tool_label": "Build base sheet",
        "version": "v4.4.4.20",
        "trade_profile_id": setup["trade_profile_id"],
        "trade_profile_name": trade_profile_display_name_for_router(setup["trade_profile_id"]),
        "function_mode": setup["costx_function_mode"],
        "default_function": setup["default_costx_function"],
        "custom_quantity": setup["custom_quantity_name"] if setup.get("default_costx_function") == "XGETCUSTOM" else "",
        "unit": setup["custom_quantity_unit"] if setup.get("default_costx_function") == "XGETCUSTOM" and setup.get("custom_quantity_unit") else setup["expected_unit"],
        "zone_mode": setup["zone_token_mode"],
        "confidence": confidence,
        "risk": risk,
        "has_file": has_file,
        "next_action": next_action,
        "requires_review_before_preview": requires_review_before_preview,
        "reasons": reasons,
        "matched_keywords": sorted(set(matched)),
        "project_zone_hierarchy": project_setup if project_setup and project_setup.get("enabled") else None,
        "builder_levels": project_builder_levels,
        "current_work_setup": setup,
    }
    integrity = validate_builder_plan_integrity(plan)
    plan["query_vision"] = build_dynamic_query_vision(prompt, plan, None, [])
    plan["self_assessment"] = integrity
    if integrity.get("issues"):
        plan["risk"] = "review"
        plan["requires_review_before_preview"] = True
        plan["next_action"] = "review_setup_first"
        plan["reasons"].append("Right Track Guard blocked direct preview: " + "; ".join(integrity.get("issues") or []))
    return plan


def trade_profile_display_name_for_router(profile_id: str) -> str:
    names = {
        "walls_partitions": "Walls / Partitions",
        "doors_windows": "Doors / Windows",
        "metalwork_structural_steel": "Metalwork / Structural Steel",
        "concrete_reo": "Concrete / Reo",
        "finishes": "Finishes",
        "joinery": "Joinery",
    }
    return names.get(normalize_builder_trade_profile_id(profile_id, "walls_partitions"), profile_id)


def clean_download_url(relative_path: str) -> str:
    return f"/api/download/{relative_path.replace('\\\\', '/')}"


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/settings")
def api_settings() -> Dict[str, Any]:
    return read_json("settings.json", {})


@app.get("/api/tools")
def api_tools() -> Dict[str, Any]:
    return read_json("tool_registry.json", {})


@app.get("/api/health")
def api_health() -> Dict[str, Any]:
    checks = {
        "jarvis_backend": {"status": "working", "detail": f"FastAPI running · {APP_VERSION}"},
        "ollama": {"status": "working" if port_open("127.0.0.1", 11434) else "offline", "url": "http://localhost:11434"},
        "open_webui": {"status": "working" if port_open("127.0.0.1", 3000) else "offline", "url": "http://localhost:3000"},
        "qs_checkmate": {"status": "working" if port_open("127.0.0.1", 8501) else "offline", "url": "http://localhost:8501"},
        "formatter": {"status": "working" if port_open("127.0.0.1", 8502) else "offline", "url": "http://localhost:8502"},
        "builder": {"status": "working" if port_open("127.0.0.1", 8503) else "offline", "url": "http://localhost:8503"},
        "workspace_old": {"status": "working" if port_open("127.0.0.1", 8504) else "offline", "url": "http://localhost:8504"},
        "input_folder": {"status": "working" if INPUT_DIR.exists() else "offline", "path": str(INPUT_DIR)},
        "output_folder": {"status": "working" if OUTPUT_DIR.exists() else "offline", "path": str(OUTPUT_DIR)},
        "jobs_folder": {"status": "working" if JOBS_DIR.exists() else "offline", "path": str(JOBS_DIR)},
        "backup_folder": {"status": "working" if BACKUP_DIR.exists() else "offline", "path": str(BACKUP_DIR)},
        "settings_folder": {"status": "working" if SETTINGS_DIR.exists() else "offline", "path": str(SETTINGS_DIR)},
    }
    return {"timestamp": datetime.now().isoformat(timespec="seconds"), "checks": checks}




@app.get("/api/version")
def api_version() -> Dict[str, Any]:
    return {
        "version": APP_VERSION,
        "name": "Snapshot + Slot Memory + Export State Hotfix",
        "stable_base": "v4.5.1.24 PATCHED Router Clarification Bypass Fix",
        "detail": "Jarvis v4.5.1.24.2F keeps the 24.2D/2E Builder output fixes and adds conversation transcript hygiene, Review route suppression, and support-log status filtering while keeping Builder formula/export logic unchanged."
    }


@app.post("/api/route")
def api_route(req: RouteRequest) -> Dict[str, Any]:
    original_prompt_for_log = req.prompt
    normalized_prompt = typo_normalize_prompt(req.prompt)
    if normalized_prompt != req.prompt:
        write_log("input_normalized", {"original": req.prompt, "interpreted_as": normalized_prompt})
        req.prompt = normalized_prompt
    result = classify_prompt(req.prompt, req.has_file)
    registry = read_json("tool_registry.json", {})

    text_for_priority = _router_text(req.prompt)
    # v4.5.1.13: utility commands should not fall into general/local AI routing.
    if is_health_command(req.prompt):
        result.update({"intent": "health_check_router", "tool_key": "health", "tool": {"name": "Health Check"}, "confidence": 96, "matched_keywords": ["health"], "needs_file": False, "missing": "", "requires_approval": False, "message_override": "I’ll check Jarvis health now."})
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "health_check"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": "ask_first_plan", "message": result.get("message_override"), "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload
    if is_panic_test_command(req.prompt):
        result.update({"intent": "panic_test_router", "tool_key": "qa_lab", "tool": {"name": "QA Lab"}, "confidence": 96, "matched_keywords": ["panic test"], "needs_file": False, "missing": "", "requires_approval": True, "message_override": "I can run the Panic / Regression QA test from QA Lab."})
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "panic_test"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": "ask_first_plan", "message": result.get("message_override"), "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload
    if is_debug_report_command(req.prompt):
        result.update({"intent": "support_log_router", "tool_key": "support_log", "tool": {"name": "Support Log"}, "confidence": 98, "matched_keywords": ["debug report", "support log"], "needs_file": False, "missing": "", "requires_approval": False, "message_override": "I’ll create a compact support log for this conversation."})
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "support_log"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": "ask_first_plan", "message": result.get("message_override"), "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    # v4.4.4.18.2: panic/mixed-task conflicts must hard-stop before
    # normal route priority. Clean single-task support/BOQ/compare commands
    # still pass because detect_panic_conflicts returns no issues for them.
    pre_route_conflicts = detect_panic_conflicts(req.prompt, req.active_builder_plan if req.active_builder_plan else None)
    if pre_route_conflicts:
        clarification = panic_conflict_clarification(req.prompt, pre_route_conflicts, req.active_builder_plan)
        result.update({"intent": "clarification_needed", "tool_key": "jarvis_clarification", "tool": {"name": "Jarvis Clarification"}, "confidence": 74, "matched_keywords": [], "needs_file": False, "missing": "", "requires_approval": True, "clarification": clarification, "risk": "blocked"})
        action = "clarification_needed"
        message = "Jarvis found conflicting instructions and blocked Builder until you clarify."
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "panic_conflict_guard"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    # v4.5.1.2: local UI niceties. Keep these light-touch so greetings and
    # vague BOQ requests do not feel like routing errors in the ChatGPT-style UI.
    if is_simple_greeting_command(req.prompt):
        result.update({
            "intent": "greeting_router",
            "tool_key": "jarvis_chat",
            "tool": {"name": "Jarvis"},
            "confidence": 99,
            "matched_keywords": ["conversation"],
            "needs_file": False,
            "missing": "",
            "requires_approval": False,
            "message_override": jarvis_conversation_reply(req.prompt) or "Hi Dhanrick — I’m ready. Tell me what you want to build, check, compare, or write.",
        })
        action = "ask_first_plan"
        message = result.get("message_override")
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "greeting"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    # v4.5.1.23: hard guard short Builder action replies before generic/support routing.
    # Frontend handles these too, but backend must be deterministic after refresh/recovery.
    active_action_text = _router_text(req.prompt)
    if _has_active_builder_plan(req.active_builder_plan) and active_action_text in {"review", "reviw", "revie", "setup", "show setup", "review setup", "view setup", "check setup"}:
        amended_plan = _deepcopy_json(req.active_builder_plan or {})
        amended_plan["has_file"] = bool(req.has_file) or bool(amended_plan.get("has_file"))
        amended_plan["next_action"] = "review_setup"
        result.update({"intent": "builder_action_router", "tool_key": "builder", "tool": registry.get("builder", {"name": "Build base sheet"}), "confidence": 96, "matched_keywords": ["review"], "needs_file": True, "missing": "" if amended_plan.get("has_file") else "Attach the Excel workbook first.", "requires_approval": False, "builder_command_plan": amended_plan})
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": True, "query_intent": {"intent": "builder_review_action"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": "ask_first_plan", "message": "Active Builder setup restored for review.", "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload
    if _has_active_builder_plan(req.active_builder_plan) and active_action_text in {"approve", "approved", "ok", "okay", "ok approve", "yes", "proceed", "preview", "approve preview", "approve and preview", "run preview", "use setup", "use this setup", "use this run only setup", "run only", "this run only", "create", "build", "go", "make it", "do it", "run it", "go ahead"}:  # v4.5.1.24 Bug-4 fix: one-word build triggers
        amended_plan = _deepcopy_json(req.active_builder_plan or {})
        amended_plan["has_file"] = bool(req.has_file) or bool(amended_plan.get("has_file"))
        amended_plan["next_action"] = "approve_and_preview"
        result.update({"intent": "builder_action_router", "tool_key": "builder", "tool": registry.get("builder", {"name": "Build base sheet"}), "confidence": 96, "matched_keywords": ["approve"], "needs_file": True, "missing": "" if amended_plan.get("has_file") else "Attach the Excel workbook first.", "requires_approval": False, "builder_command_plan": amended_plan})
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": True, "query_intent": {"intent": "builder_approve_action"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": "ask_first_plan", "message": "Builder setup approved for preview.", "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    if req.has_file and _router_text(req.prompt) in {"attached file", "file attached", "attached workbook", "workbook attached"}:
        if _has_active_builder_plan(req.active_builder_plan):
            amended_plan = _deepcopy_json(req.active_builder_plan or {})
            amended_plan["has_file"] = True
            amended_plan["confidence"] = max(70, int(amended_plan.get("confidence") or 82))
            amended_plan["risk"] = "low"
            amended_plan["requires_review_before_preview"] = False
            amended_plan["next_action"] = "approve_and_preview"
            amended_plan.setdefault("reasons", []).append("Workbook received and merged into the active Builder task.")
            result.update({"intent": "builder_command_router", "tool_key": "builder", "tool": registry.get("builder", {"name": "Build base sheet"}), "confidence": amended_plan.get("confidence", 82), "matched_keywords": ["attached workbook"], "needs_file": True, "missing": "", "requires_approval": False, "builder_command_plan": amended_plan})
            action = "ask_first_plan"
            message = "Workbook received. I can now prepare the BOQ base sheet preview."
            context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "attachment_merged_active_builder_task"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
            result["context_snapshot"] = context_snapshot
            payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
            write_log("route_request", payload)
            return payload
        clarification = tool_choice_clarification(req.prompt)
        clarification["question"] = "I received the workbook. What do you want Jarvis to do with it?"
        result.update({"intent": "workbook_attachment_router", "tool_key": "jarvis_clarification", "tool": {"name": "Jarvis Clarification"}, "confidence": 86, "matched_keywords": ["attached workbook"], "needs_file": False, "missing": "", "requires_approval": True, "clarification": clarification, "risk": "review"})
        action = "clarification_needed"
        message = "Jarvis received a workbook and needs one workflow choice."
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "workbook_attachment"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    if is_ambiguous_base_boq_command(req.prompt) and not _has_active_builder_plan(req.active_builder_plan) and not (isinstance(req.pending_clarification, dict) and req.pending_clarification.get("type")):
        clarification = base_boq_ambiguity_clarification(req.prompt)
        result.update({"intent": "clarification_needed", "tool_key": "jarvis_clarification", "tool": {"name": "Jarvis Clarification"}, "confidence": 68, "matched_keywords": ["base boq"], "needs_file": False, "missing": "", "requires_approval": True, "clarification": clarification, "risk": "review"})
        action = "clarification_needed"
        message = "Jarvis needs one clarification before preparing the final plan."
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "base_boq_ambiguous"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    # v4.4.4.15.2 router priority: support-log and BOQ-description commands
    # must not be swallowed by Builder or general Local AI.
    if is_support_log_command(req.prompt):
        result.update({
            "intent": "support_log_router",
            "tool_key": "support_log",
            "tool": {"name": "Support Log Export"},
            "confidence": 96,
            "matched_keywords": ["support log"],
            "needs_file": False,
            "missing": "",
            "requires_approval": False,
            "message_override": "Jarvis will export the support/debug log and preserve the active plan.",
        })
        action = "ask_first_plan"
        message = result.get("message_override")
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "support_log"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    if is_boq_writer_command(req.prompt):
        result.update({
            "intent": "boq_writer_router",
            "tool_key": "boq_writer",
            "tool": {"name": "BOQ Writer / Local AI", "local_url": "http://localhost:3000", "url": "https://ai.dhanrickeviota.com"},
            "confidence": 90,
            "matched_keywords": ["boq description"],
            "needs_file": False,
            "missing": "",
            "requires_approval": True,
            "message_override": "Jarvis will route this to BOQ Writer / Local AI writing mode, not Builder.",
        })
        action = "ask_first_plan"
        message = result.get("message_override")
        context_snapshot = {"mode": req.mode, "has_file": bool(req.has_file), "pending_clarification": bool(req.pending_clarification), "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "", "active_builder_plan": bool(req.active_builder_plan), "query_intent": {"intent": "boq_writer"}, "tool_key": result.get("tool_key"), "intent": result.get("intent")}
        result["context_snapshot"] = context_snapshot
        payload = {"prompt": req.prompt, "mode": req.mode, "route": result, "action": action, "message": message, "context_snapshot": context_snapshot}
        write_log("route_request", payload)
        return payload

    query_intent = classify_current_query_intent(req.prompt, req.pending_clarification, req.active_builder_plan)
    ambiguous_reference = is_ambiguous_reference_message(req.prompt)
    resolved_pending = None if query_intent.get("intent") == "new_command" or ambiguous_reference else resolve_pending_clarification(req.prompt, req.pending_clarification, req.has_file, req.active_builder_plan)
    # v4.5.1.24 Bug-1 fix: if Jarvis is waiting for a clarification and the reply was
    # not matched by any resolver branch, keep the card open instead of falling to general_ai.
    if (resolved_pending is None
            and isinstance(req.pending_clarification, dict)
            and req.pending_clarification.get("type")
            and query_intent.get("intent") == "clarification_answer"):
        resolved_pending = {
            "clarification": req.pending_clarification,
            "confidence": int(req.pending_clarification.get("confidence") or 60),
            "risk": "review",
        }
    builder_plan = None
    # v4.5.1.11: attached workbook + setup words (zones/levels/head/formula)
    # is Builder context, not Local AI/general routing.
    if (not resolved_pending and builder_plan is None and not _has_active_builder_plan(req.active_builder_plan)
            and is_attachment_setup_builder_intent(req.prompt, req.has_file)):
        bridged_prompt = "Build base sheet from attached workbook; " + req.prompt + "; use parsed project hierarchy"
        builder_plan = build_builder_command_plan(bridged_prompt, req.has_file, allow_clarification=True)
        if builder_plan is None:
            builder_plan = builder_plan_from_current_default(bridged_prompt, req.has_file, "Workbook and setup instructions detected; using current Workspace Builder setup pending review.")

    if builder_plan is None and is_compare_boq_command(req.prompt):
        if ambiguous_reference:
            result.update({
                "intent": "clarification_needed",
                "tool_key": "jarvis_clarification",
                "tool": {"name": "Jarvis Clarification"},
                "confidence": 68,
                "matched_keywords": [],
                "needs_file": False,
                "missing": "",
                "requires_approval": True,
                "clarification": make_clarification("ambiguous_compare_reference", "Do you want to compare the current Builder output against another sheet, or start a new Compare BOQ task?", req.prompt, [{"label": "Start new Compare BOQ task", "reply": "new command: Compare BOQ base sheet against measured sheet and report discrepancies"}, {"label": "Use current Builder output", "reply": "Compare current Builder output"}, {"label": "Cancel", "reply": "Cancel"}], {"active_builder_plan": req.active_builder_plan or {}}),
                "risk": "review",
            })
            builder_plan = None
            resolved_pending = None
        else:
            result.update({
                "intent": "compare_boq_router",
            "tool_key": "qs_checkmate",
            "tool": registry.get("qs_checkmate", {"name": "Compare BOQ"}),
            "confidence": 92,
            "matched_keywords": ["compare", "discrepancy", "measured sheet"],
            "needs_file": True,
            "missing": "Attach the BOQ/workbook files first." if not req.has_file else "",
            "requires_approval": True,
            "message_override": "Jarvis will route this to Compare BOQ / QS CheckMate, not Builder.",
        })
        builder_plan = None
        resolved_pending = None
    elif ambiguous_reference:
        builder_plan = {"clarification": ambiguous_reference_clarification(req.prompt, req.active_builder_plan), "confidence": 60, "risk": "review"}
    elif not _has_active_builder_plan(req.active_builder_plan) and is_active_builder_plan_amendment(req.prompt) and not is_fresh_boq_builder_request(req.prompt, req.has_file):
        builder_plan = {"clarification": _active_plan_edit_no_plan_clarification(req.prompt), "confidence": 62, "risk": "review"}
    if not resolved_pending and query_intent.get("intent") in {"active_plan_amendment", "possible_active_plan_edit"}:
        builder_plan = apply_active_builder_plan_amendment(req.active_builder_plan or {}, req.prompt, req.has_file)
    if resolved_pending:
        if resolved_pending.get("tool_choice_only"):
            tool_key = resolved_pending.get("tool_key", "local_ai")
            result.update({
                "intent": "clarification_resolved",
                "tool_key": tool_key,
                "tool": registry.get(tool_key, {"name": resolved_pending.get("tool_label", "Tool")}),
                "confidence": resolved_pending.get("confidence", 80),
                "matched_keywords": [],
                "needs_file": tool_key in {"formatter", "qs_checkmate", "builder"},
                "missing": "Attach the required workbook first." if tool_key in {"formatter", "qs_checkmate", "builder"} and not req.has_file else "",
                "requires_approval": True,
                "clarification_resolved_message": resolved_pending.get("message", "Clarification received."),
            })
        else:
            builder_plan = resolved_pending
    elif builder_plan is None and not is_compare_boq_command(req.prompt):
        builder_plan = build_builder_command_plan(req.prompt, req.has_file)

    if builder_plan and builder_plan.get("clarification"):
        result.update({
            "intent": "clarification_needed",
            "tool_key": "jarvis_clarification",
            "tool": {"name": "Jarvis Clarification"},
            "confidence": builder_plan.get("confidence", 60),
            "matched_keywords": [],
            "needs_file": False,
            "missing": "",
            "requires_approval": True,
            "clarification": builder_plan.get("clarification"),
            "risk": "review",
        })
        builder_plan = None
    elif builder_plan:
        result.update({
            "intent": "builder_command_router",
            "tool_key": "builder",
            "tool": registry.get("builder", {"name": "Build base sheet"}),
            "confidence": builder_plan.get("confidence", result.get("confidence", 75)),
            "matched_keywords": builder_plan.get("matched_keywords", result.get("matched_keywords", [])),
            "needs_file": True,
            "missing": "Attach the workbook first, then approve Builder preview." if not req.has_file else "",
            "requires_approval": bool(builder_plan.get("requires_review_before_preview")),
            "builder_command_plan": builder_plan,
        })
        if builder_plan.get("clarification_resolved_message") or builder_plan.get("message_override"):
            result["clarification_resolved_message"] = builder_plan.get("clarification_resolved_message") or builder_plan.get("message_override")
    mode = req.mode

    if result.get("clarification"):
        action = "clarification_needed"
        message = "Jarvis needs one clarification before preparing the final plan."
    elif result.get("message_override"):
        action = "ask_first_plan"
        message = result.get("message_override")
    elif result.get("clarification_resolved_message"):
        action = "approval_required"
        message = result.get("clarification_resolved_message")
    elif result["missing"]:
        action = "need_more_info"
        message = result["missing"]
    elif result["requires_approval"]:
        action = "approval_required"
        message = "This action needs approval before running."
    elif mode == "Manual":
        action = "open_tool"
        message = f"Open {result['tool'].get('name', 'tool')} manually."
    elif mode == "AutoPilot":
        action = "autopilot_preview"
        message = "AutoPilot preview only. Jarvis will not modify stable tools without approval."
    else:
        action = "ask_first_plan"
        if result.get("tool_key") == "formatter" and req.has_file:
            message = "I can run the internal Formatter engine on a safe copy and save the result to Output Center."
        elif result.get("tool_key") == "builder" and req.has_file:
            if result.get("builder_command_plan", {}).get("requires_review_before_preview"):
                message = "I detected a Builder task, but the trade/profile is not clear. Review the setup in Workspace before preview."
            else:
                message = "I prepared a Builder command plan. Review the suggested setup, then approve preview before export."
        else:
            message = "I’m not sure what you want me to do yet. Tell me the task, or attach a workbook if this is for BOQ work."

    context_snapshot = {
        "mode": mode,
        "has_file": bool(req.has_file),
        "pending_clarification": bool(req.pending_clarification),
        "pending_type": (req.pending_clarification or {}).get("type") if isinstance(req.pending_clarification, dict) else "",
        "active_builder_plan": bool(req.active_builder_plan),
        "query_intent": query_intent,
        "tool_key": result.get("tool_key"),
        "intent": result.get("intent"),
    }
    result["context_snapshot"] = context_snapshot
    payload = {
        "prompt": req.prompt,
        "mode": mode,
        "route": result,
        "action": action,
        "message": message,
        "context_snapshot": context_snapshot,
    }
    write_log("route_request", payload)
    return payload


# ---------------------------------------------------------------------------
# v4.4.4.18.2 — Replay Classification Cleanup + Fuzz Generator Expansion
# Safe diagnostics only: no stable tool changes and no Builder formula/export
# engine rewrite. Replay is tuned to reduce false positives, classify safe clarifications correctly, and local fuzz generation honors requested test counts.
# ---------------------------------------------------------------------------

def _qa_status(pass_condition: bool, blocked_safe: bool = False) -> str:
    if pass_condition:
        return "PASS"
    if blocked_safe:
        return "BLOCKED_SAFE"
    return "FAIL"


def _qa_route(prompt: str, *, has_file: bool = True, active_plan: Optional[Dict[str, Any]] = None, pending: Optional[Dict[str, Any]] = None, mode: str = "Ask First") -> Dict[str, Any]:
    req = RouteRequest(prompt=prompt, mode=mode, has_file=has_file, active_builder_plan=active_plan, pending_clarification=pending)
    return api_route(req)


def _qa_route_obj(route_payload: Dict[str, Any]) -> Dict[str, Any]:
    return route_payload.get("route") or {}


def _qa_plan(route_payload: Dict[str, Any]) -> Dict[str, Any]:
    return (_qa_route_obj(route_payload).get("builder_command_plan") or {})


def _qa_project(plan: Dict[str, Any]) -> Dict[str, Any]:
    return (plan or {}).get("project_zone_hierarchy") or {}


def _qa_levels(plan: Dict[str, Any]) -> List[str]:
    project = _qa_project(plan)
    if isinstance(project.get("level_values"), list):
        return [str(x) for x in project.get("level_values")]
    rows = plan.get("builder_levels") or []
    out: List[str] = []
    for row in rows:
        desc = str((row or {}).get("description") or "")
        if desc and desc not in out:
            out.append(desc)
    return out


def _qa_zone_values(plan: Dict[str, Any], zone_index: int) -> List[str]:
    project = _qa_project(plan)
    for zone in project.get("dynamic_zones") or []:
        if int((zone or {}).get("index") or (zone or {}).get("zone_index") or 0) == int(zone_index):
            return [str(v) for v in (zone or {}).get("values") or []]
    return []


def _qa_add(results: List[Dict[str, Any]], test_id: str, name: str, expected: str, actual: str, status: str, evidence: Optional[Dict[str, Any]] = None) -> None:
    results.append({
        "id": test_id,
        "name": name,
        "expected": expected,
        "actual": actual,
        "status": status,
        "evidence": evidence or {},
    })


def _qa_final_boss_prompt() -> str:
    return (
        "new command: Create a Door Trade BOQ base sheet. Zone 1 is Building A and Building B. "
        "Zone 2 is Stage 1, Stage 1b, and Stage 2. Zone 3 is Internal and External. "
        "Use Zone 1 as Head1, Zone 2 as Head2, Zone 3 as Head3, detected door type as Head4, "
        "and levels Basement 2 to 1, GF, L1 to L8 excluding L3 and L5 as formula rows. "
        "Use door counts only. Do not format yet."
    )


def run_qa_lab_tests(test_pack: str = "smoke") -> Dict[str, Any]:
    pack = (test_pack or "smoke").strip().lower()
    results: List[Dict[str, Any]] = []

    # Router priority tests.
    route = _qa_route("Export support log", has_file=False)
    r = _qa_route_obj(route)
    _qa_add(results, "ROUTE-01", "Support Log route", "support_log_router", str(r.get("intent")), _qa_status(r.get("intent") == "support_log_router"), {"tool_key": r.get("tool_key")})

    route = _qa_route("Write a BOQ description for fire-rated doors.", has_file=False)
    r = _qa_route_obj(route)
    _qa_add(results, "ROUTE-02", "BOQ Writer route", "boq_writer_router", str(r.get("intent")), _qa_status(r.get("intent") == "boq_writer_router"), {"tool_key": r.get("tool_key")})

    route = _qa_route("Compare BOQ base sheet against measured sheet and report discrepancies.", has_file=True)
    r = _qa_route_obj(route)
    _qa_add(results, "ROUTE-03", "Compare route", "compare_boq_router", str(r.get("intent")), _qa_status(r.get("intent") == "compare_boq_router"), {"tool_key": r.get("tool_key")})

    # Core Builder plan test.
    route = _qa_route(_qa_final_boss_prompt(), has_file=True)
    r = _qa_route_obj(route)
    plan = _qa_plan(route)
    levels = _qa_levels(plan)
    zones_ok = _qa_zone_values(plan, 1) == ["Building A", "Building B"] and _qa_zone_values(plan, 2) == ["Stage 1", "Stage 1b", "Stage 2"] and _qa_zone_values(plan, 3) == ["Internal", "External"]
    plan_setup = plan.get("current_work_setup") or {}
    plan_func = str(plan.get("default_costx_function") or plan.get("costx_function") or plan_setup.get("default_costx_function") or "").upper()
    core_ok = bool(plan) and r.get("intent") == "builder_command_router" and plan.get("trade_profile_name") == "Doors / Windows" and plan_func == "XGETCOUNT" and zones_ok and levels == ["B2", "B1", "GF", "L1", "L2", "L4", "L6", "L7", "L8"]
    _qa_add(results, "BUILD-01", "Final boss Builder plan", "Door/XGETCOUNT/no with Zone 1/2/3 and levels on Zone 4", f"intent={r.get('intent')}; trade={plan.get('trade_profile_name')}; function={plan_func}; levels={levels}", _qa_status(core_ok), {"zones": _qa_project(plan).get("dynamic_zones", []), "hierarchy": _qa_project(plan).get("hierarchy", [])})

    # Active edit tests are only meaningful if Builder plan exists.
    if plan:
        edit_route = _qa_route("Also remove L4 and add Roof.", has_file=True, active_plan=plan)
        edit_plan = _qa_plan(edit_route)
        edit_levels = _qa_levels(edit_plan)
        ok = edit_levels == ["B2", "B1", "GF", "L1", "L2", "L6", "L7", "L8", "Roof"]
        _qa_add(results, "EDIT-01", "Remove L4 and add Roof", "B2,B1,GF,L1,L2,L6,L7,L8,Roof", ",".join(edit_levels), _qa_status(ok), {"intent": _qa_route_obj(edit_route).get("intent")})

        restore_route = _qa_route("bring back L3", has_file=True, active_plan=edit_plan or plan)
        restore_plan = _qa_plan(restore_route)
        restore_levels = _qa_levels(restore_plan)
        ok = restore_levels == ["B2", "B1", "GF", "L1", "L2", "L3", "L6", "L7", "L8", "Roof"]
        _qa_add(results, "EDIT-02", "Bring back L3 sorted", "B2,B1,GF,L1,L2,L3,L6,L7,L8,Roof", ",".join(restore_levels), _qa_status(ok), {"intent": _qa_route_obj(restore_route).get("intent")})

        keep_route = _qa_route("do not remove L3", has_file=True, active_plan=restore_plan or edit_plan or plan)
        keep_plan = _qa_plan(keep_route)
        keep_levels = _qa_levels(keep_plan)
        ok = "L3" in keep_levels and not (_qa_route_obj(keep_route).get("clarification") and "conflict" in json.dumps(_qa_route_obj(keep_route).get("clarification"), ensure_ascii=False).lower())
        _qa_add(results, "EDIT-03", "Negation keeps L3", "L3 remains; no false conflict", f"levels={keep_levels}; intent={_qa_route_obj(keep_route).get('intent')}", _qa_status(ok), {})

        conflict_route = _qa_route("remove L3 but do not remove L3", has_file=True, active_plan=restore_plan or edit_plan or plan)
        cr = _qa_route_obj(conflict_route)
        ctext = json.dumps(cr.get("clarification") or {}, ensure_ascii=False).lower()
        ok = cr.get("intent") == "clarification_needed" and "conflict" in ctext
        _qa_add(results, "EDIT-04", "True edit conflict blocks", "clarification_needed conflict", f"intent={cr.get('intent')}; clarification={ctext[:180]}", _qa_status(ok, blocked_safe=ok), {})

    # Panic conflict tests.
    panic_cases = [
        ("PANIC-01", "Duplicate Zone assignment", "new command: Create Door Trade base sheet. Zone 1 is Internal and External. Zone 1 is also Stage 1 and Stage 2. Use Zone 1 as Head1 and Zone 2 as Head2. Levels L1 to L3. Door counts only."),
        ("PANIC-02", "Same zone two headings", "new command: Create Door Trade base sheet. Zone 2 is Stage 1 and Stage 2. Use Zone 2 as Head1 and Zone 2 as Head2. Levels L1. Door counts only."),
        ("PANIC-03", "Function/unit conflict", "new command: Create Door Trade base sheet using wall area. Use XGETCOUNT and XGETWALLAREA. Unit no and m2. Levels L1 to L2."),
        ("PANIC-04", "Compare + Build mixed task", "new command: Compare BOQ base sheet against measured sheet, then build a Door Trade base sheet with Zone 2 as Stage 1 and Stage 2."),
    ]
    for tid, name, prompt in panic_cases:
        route = _qa_route(prompt, has_file=True)
        rr = _qa_route_obj(route)
        text = json.dumps(rr.get("clarification") or {}, ensure_ascii=False).lower()
        ok = rr.get("intent") == "clarification_needed" and any(word in text for word in ["conflict", "which", "clarify", "more than one"])
        _qa_add(results, tid, name, "blocked/clarification before Builder", f"intent={rr.get('intent')}; text={text[:180]}", _qa_status(ok, blocked_safe=ok), {})

    if pack in {"panic", "full", "regression"}:
        # Skipped zone should clarify level placement.
        route = _qa_route("new command: Create Door Trade base sheet. Zone 4 is East Wing and West Wing. Zone 7 is Package A and Package B. Use Zone 7 as Head1 and Zone 4 as Head2. Levels L1 to L9. Door counts only.", has_file=True)
        rr = _qa_route_obj(route)
        text = json.dumps(rr.get("clarification") or {}, ensure_ascii=False).lower()
        ok = rr.get("intent") == "clarification_needed" and ("level" in text and "zone" in text)
        _qa_add(results, "PANIC-05", "Skipped zone level placement", "ask level-zone clarification", f"intent={rr.get('intent')}; text={text[:180]}", _qa_status(ok, blocked_safe=ok), {})

    pass_count = sum(1 for x in results if x["status"] == "PASS")
    blocked_count = sum(1 for x in results if x["status"] == "BLOCKED_SAFE")
    fail_count = sum(1 for x in results if x["status"] == "FAIL")
    status = "PASS" if fail_count == 0 else "FAIL"
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "test_pack": pack,
        "status": status,
        "summary": {"total": len(results), "pass": pass_count, "blocked_safe": blocked_count, "fail": fail_count},
        "results": results,
    }


def write_qa_lab_report(report: Dict[str, Any]) -> Dict[str, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_pack_name = _qa_slug(str(report.get('test_pack') or 'smoke'), "qa_pack")
    base_name = f"Jarvis_QA_Report_{stamp}_{safe_pack_name}.zip"
    zip_path = QA_REPORT_DIR / base_name
    md_lines = [
        f"# Jarvis QA Lab Report — {report.get('test_pack')}\n",
        f"Version: {report.get('app_version')}\n",
        f"Generated: {report.get('generated_at')}\n",
        f"Status: {report.get('status')}\n",
        f"Summary: {report.get('summary')}\n",
        "\n## Results\n",
    ]
    for row in report.get("results") or []:
        md_lines.append(f"### {row.get('id')} — {row.get('name')}\n")
        md_lines.append(f"- Status: {row.get('status')}\n")
        md_lines.append(f"- Expected: {row.get('expected')}\n")
        md_lines.append(f"- Actual: {row.get('actual')}\n")
    latest_events = read_recent_events(180)
    workflow = build_workflow_health_snapshot(latest_events)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("qa_summary.json", _safe_json_file_payload(report))
        zf.writestr("qa_report.md", "\n".join(md_lines))
        zf.writestr("workflow_health_snapshot.json", _safe_json_file_payload(workflow))
        zf.writestr("latest_router_events.json", _safe_json_file_payload(latest_events[-120:]))
    return {
        "file": zip_path.name,
        "relative_path": str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/"),
        "download_url": clean_download_url(str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/")),
        "path": str(zip_path),
        "size_bytes": zip_path.stat().st_size,
    }



# v4.4.4.19 — QA Coverage Map
# Diagnostic/reporting only. Reads QA/replay reports and maps tested areas so stable confidence is evidence-based.
QA_COVERAGE_REPORT_DIR = OUTPUT_DIR / "Jarvis_QA_Coverage_Reports"
QA_COVERAGE_REPORT_DIR.mkdir(parents=True, exist_ok=True)

QA_COVERAGE_CATEGORIES = [
    {
        "key": "router_priority",
        "label": "Tool routing priority",
        "description": "Support Log, BOQ Writer, Compare, and Builder commands route to the correct tool instead of defaulting to Builder or Local AI.",
        "minimum": 5,
        "risk_if_weak": "Commands may be sent to the wrong tool.",
    },
    {
        "key": "builder_core",
        "label": "Builder core plan",
        "description": "Door Trade / XGETCOUNT / no, final-boss multi-zone plan, and normal Builder route behavior.",
        "minimum": 2,
        "risk_if_weak": "Builder setup could regress to wrong trade/function/unit.",
    },
    {
        "key": "zone_hierarchy",
        "label": "Zone + hierarchy logic",
        "description": "Zone values, Head levels, skipped zone logic, dynamic level token placement, and no duplicate token indexes.",
        "minimum": 6,
        "risk_if_weak": "Formula tokens and headings could mismatch.",
    },
    {
        "key": "formula_integrity",
        "label": "CostX formula integrity",
        "description": "Function/unit pairing, formula syntax risk, XGETCOUNT/no, XGETWALLAREA/m2, and conflict blocking.",
        "minimum": 4,
        "risk_if_weak": "Broken or wrong CostX formulas could be exported.",
    },
    {
        "key": "active_edits",
        "label": "Active-plan edits",
        "description": "remove/add/restore/reorder/replace level and zone edits while preserving the active Builder plan.",
        "minimum": 6,
        "risk_if_weak": "Follow-up edits may reset or route to Local AI.",
    },
    {
        "key": "negation_conflict",
        "label": "Negation + conflict guards",
        "description": "do not remove, remove-but-do-not-remove, duplicate zones, same zone two headings, mixed task conflicts.",
        "minimum": 8,
        "risk_if_weak": "Jarvis may apply the opposite of the user's instruction or guess through conflicts.",
    },
    {
        "key": "fuzz_generated",
        "label": "Generated/imported fuzz coverage",
        "description": "Local generated and imported AI-style packs cover variations beyond fixed Smoke/Panic tests.",
        "minimum": 50,
        "risk_if_weak": "QA may only prove known bugs, not variations.",
    },
    {
        "key": "debug_replay",
        "label": "Debug replay intelligence",
        "description": "Replay analysis runs on recent logs and classifies real issues without false critical failures.",
        "minimum": 1,
        "risk_if_weak": "Debug reports still need manual inspection.",
    },
    {
        "key": "reporting_outputs",
        "label": "QA/report exports",
        "description": "QA reports, replay reports, and coverage reports are created with downloadable ZIP outputs.",
        "minimum": 3,
        "risk_if_weak": "Testing evidence cannot be handed off cleanly.",
    },
]

def _coverage_empty_bucket(cat: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "key": cat["key"],
        "label": cat["label"],
        "description": cat["description"],
        "minimum": cat["minimum"],
        "risk_if_weak": cat["risk_if_weak"],
        "total": 0,
        "pass": 0,
        "blocked_safe": 0,
        "fail": 0,
        "needs_clarification": 0,
        "evidence": [],
        "coverage_percent": 0,
        "status": "NO_COVERAGE",
    }

def _qa_load_zip_json(path: Path, member_names: List[str]) -> Optional[Dict[str, Any]]:
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for name in member_names:
                if name in zf.namelist():
                    with zf.open(name) as fh:
                        return json.loads(fh.read().decode("utf-8", errors="replace"))
    except Exception:
        return None
    return None

def _qa_recent_report_files(limit: int = 60) -> List[Path]:
    files = list(QA_REPORT_DIR.glob("Jarvis_QA_Report_*.zip")) + list(QA_REPORT_DIR.glob("Jarvis_Debug_Replay_Analysis_*.zip"))
    files += list(QA_COVERAGE_REPORT_DIR.glob("Jarvis_QA_Coverage_Map_*.zip"))
    return sorted(files, key=lambda p: p.stat().st_mtime, reverse=True)[:max(1, limit)]

def _qa_category_keys_for_result(row: Dict[str, Any], report_name: str = "") -> List[str]:
    text = " ".join([
        str(row.get("id") or ""),
        str(row.get("name") or ""),
        str(row.get("category") or ""),
        str(row.get("expected") or ""),
        str(row.get("actual") or ""),
        json.dumps(row.get("evidence") or {}, ensure_ascii=False),
        report_name,
    ]).lower()
    keys = set()
    if any(w in text for w in ["route", "support log route", "boq writer", "compare route", "compare_boq_router", "support_log_router", "boq_writer_router"]):
        keys.add("router_priority")
    if any(w in text for w in ["final boss", "builder plan", "door/xgetcount", "builder_command_router", "doors / windows"]):
        keys.add("builder_core")
    if any(w in text for w in ["zone", "head", "hierarchy", "skipped", "duplicate zone", "token", "building a", "stage 1", "internal", "external"]):
        keys.add("zone_hierarchy")
    if any(w in text for w in ["formula", "xgetcount", "xgetwallarea", "xgetcustom", "unit", "m2", "no", "weight"]):
        keys.add("formula_integrity")
    if any(w in text for w in ["edit", "remove", "add roof", "bring back", "restore", "reorder", "replace", "external first", "stage 2b"]):
        keys.add("active_edits")
    if any(w in text for w in ["negation", "conflict", "do not remove", "same zone", "duplicate zone", "mixed task", "blocked", "blocked_safe"]):
        keys.add("negation_conflict")
    if any(w in text for w in ["imported", "generated", "fuzz", "ai-", "smart qa generated"]):
        keys.add("fuzz_generated")
    if any(w in text for w in ["qa report", "report zip", "download", "export", "workflow_health_snapshot"]):
        keys.add("reporting_outputs")
    return sorted(keys)

def _qa_add_coverage_evidence(bucket: Dict[str, Any], row: Dict[str, Any], report_file: str) -> None:
    status = str(row.get("status") or "").upper()
    bucket["total"] += 1
    if status == "FAIL":
        bucket["fail"] += 1
    elif status == "BLOCKED_SAFE":
        bucket["blocked_safe"] += 1
    elif status in {"NEEDS_CLARIFICATION", "CLARIFICATION"}:
        bucket["needs_clarification"] += 1
    else:
        bucket["pass"] += 1
    if len(bucket["evidence"]) < 12:
        bucket["evidence"].append({
            "report": report_file,
            "id": row.get("id"),
            "name": row.get("name"),
            "status": status or "PASS",
        })

def build_qa_coverage_map(report_limit: int = 60) -> Dict[str, Any]:
    """Build current-version QA coverage.

    v4.4.4.20 intentionally prioritizes fresh/current-version evidence so old
    known-failure reports do not make a fixed version look broken. Historical
    reports are still listed as sources when current-version, but older reports
    are not counted as active failures.
    """
    buckets = {cat["key"]: _coverage_empty_bucket(cat) for cat in QA_COVERAGE_CATEGORIES}
    source_reports: List[Dict[str, Any]] = []

    def ingest_qa_report(qa_report: Dict[str, Any], report_name: str) -> None:
        summary = qa_report.get("summary") or {}
        source_reports.append({"file": report_name, "type": "qa", "status": qa_report.get("status"), "summary": summary})
        _qa_add_coverage_evidence(buckets["reporting_outputs"], {"id": "REPORT", "name": report_name, "status": "PASS" if (summary.get("fail") or 0) == 0 else "FAIL"}, report_name)
        for row in qa_report.get("results") or []:
            keys = _qa_category_keys_for_result(row, report_name)
            if "imported" in report_name.lower() or "generated" in report_name.lower() or "fuzz" in report_name.lower():
                keys.append("fuzz_generated")
            for key in set(k for k in keys if k in buckets):
                _qa_add_coverage_evidence(buckets[key], row, report_name)

    def ingest_replay(replay_report: Dict[str, Any], report_name: str) -> None:
        summary = replay_report.get("summary") or {}
        issues = replay_report.get("issues") or []
        fail_count = int(summary.get("critical") or 0) + int(summary.get("high") or 0)
        source_reports.append({"file": report_name, "type": "replay", "status": replay_report.get("status"), "summary": summary})
        _qa_add_coverage_evidence(buckets["debug_replay"], {"id": "REPLAY", "name": report_name, "status": "PASS" if fail_count == 0 else "FAIL"}, report_name)
        _qa_add_coverage_evidence(buckets["reporting_outputs"], {"id": "REPLAY_REPORT", "name": report_name, "status": "PASS"}, report_name)
        for issue in issues:
            row = {"id": issue.get("type"), "name": issue.get("message"), "status": "FAIL" if issue.get("severity") in {"critical", "high"} else "PASS", "actual": issue.get("patch_area")}
            for key in set(_qa_category_keys_for_result(row, report_name)):
                if key in buckets:
                    _qa_add_coverage_evidence(buckets[key], row, report_name)

    # Fresh evidence from the current code path. These calls exercise the same
    # diagnostic harness but do not write Builder exports or patch files.
    try:
        ingest_qa_report(run_qa_lab_tests("smoke"), "CURRENT_SMOKE")
    except Exception as exc:
        _qa_add_coverage_evidence(buckets["reporting_outputs"], {"id": "CURRENT_SMOKE_ERROR", "name": str(exc), "status": "FAIL"}, "CURRENT_SMOKE")
    try:
        ingest_qa_report(run_qa_lab_tests("panic"), "CURRENT_PANIC")
    except Exception as exc:
        _qa_add_coverage_evidence(buckets["reporting_outputs"], {"id": "CURRENT_PANIC_ERROR", "name": str(exc), "status": "FAIL"}, "CURRENT_PANIC")
    try:
        generated_pack = generate_qa_test_pack(QAGeneratedTestPackRequest(provider="local_builtin", category="mixed", count=75, save_pack=False))
        ingest_qa_report(run_imported_qa_test_pack(generated_pack), "CURRENT_GENERATED_FUZZ_75")
    except Exception as exc:
        _qa_add_coverage_evidence(buckets["fuzz_generated"], {"id": "CURRENT_FUZZ_ERROR", "name": str(exc), "status": "FAIL"}, "CURRENT_GENERATED_FUZZ_75")
    try:
        # Analyze the recent event window but classify safe clarifications as pass.
        replay_report = analyze_debug_events(read_recent_events(220), source_name="coverage_recent_events")
        ingest_replay(replay_report, "CURRENT_REPLAY_WINDOW")
    except Exception as exc:
        _qa_add_coverage_evidence(buckets["debug_replay"], {"id": "CURRENT_REPLAY_ERROR", "name": str(exc), "status": "FAIL"}, "CURRENT_REPLAY_WINDOW")

    # Current-version saved reports can add evidence; older reports are listed
    # but not counted as current failures to avoid stale known-bug noise.
    for path in _qa_recent_report_files(report_limit):
        qa_report = _qa_load_zip_json(path, ["qa_summary.json"])
        replay_report = _qa_load_zip_json(path, ["debug_replay_analysis.json"])
        if qa_report:
            if str(qa_report.get("app_version") or "") == APP_VERSION:
                ingest_qa_report(qa_report, path.name)
            else:
                source_reports.append({"file": path.name, "type": "qa_older_version_ignored", "status": qa_report.get("status"), "summary": qa_report.get("summary")})
        if replay_report:
            if str(replay_report.get("app_version") or "") == APP_VERSION:
                ingest_replay(replay_report, path.name)
            else:
                source_reports.append({"file": path.name, "type": "replay_older_version_ignored", "status": replay_report.get("status"), "summary": replay_report.get("summary")})

    categories: List[Dict[str, Any]] = []
    weak_areas: List[Dict[str, Any]] = []
    for cat in QA_COVERAGE_CATEGORIES:
        bucket = buckets[cat["key"]]
        effective_ok = bucket["pass"] + bucket["blocked_safe"] + bucket["needs_clarification"]
        count_score = min(1.0, bucket["total"] / max(1, bucket["minimum"]))
        quality_score = 0.0 if bucket["total"] == 0 else max(0.0, (effective_ok - (bucket["fail"] * 2)) / max(1, bucket["total"]))
        coverage = int(round(100 * count_score * quality_score))
        bucket["coverage_percent"] = coverage
        if bucket["fail"] > 0:
            bucket["status"] = "NEEDS_REVIEW"
        elif coverage >= 90:
            bucket["status"] = "STRONG"
        elif coverage >= 60:
            bucket["status"] = "PARTIAL"
        elif bucket["total"] > 0:
            bucket["status"] = "LOW"
        else:
            bucket["status"] = "NO_COVERAGE"
        if bucket["status"] in {"NEEDS_REVIEW", "LOW", "NO_COVERAGE"}:
            weak_areas.append({"key": bucket["key"], "label": bucket["label"], "status": bucket["status"], "coverage_percent": coverage, "risk": bucket["risk_if_weak"]})
        categories.append(bucket)

    critical_failures = sum(b["fail"] for b in buckets.values())
    strong_count = sum(1 for b in categories if b["status"] == "STRONG")
    avg_coverage = int(round(sum(b["coverage_percent"] for b in categories) / max(1, len(categories))))
    stable_candidate = critical_failures == 0 and avg_coverage >= 75 and strong_count >= 6
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": "PASS" if stable_candidate else "NEEDS_REVIEW",
        "summary": {
            "categories": len(categories),
            "strong": strong_count,
            "average_coverage_percent": avg_coverage,
            "critical_failures": critical_failures,
            "reports_scanned": len(source_reports),
            "stable_candidate": stable_candidate,
        },
        "categories": categories,
        "weak_areas": weak_areas,
        "source_reports": source_reports[:60],
        "notes": [
            "Coverage Map is diagnostic only; it does not patch Jarvis or modify Builder formulas.",
            "Coverage is based on fresh current-version Smoke/Panic/Fuzz/Replay evidence first. Older-version reports are ignored as active failures.",
            "Old Builder metadata cleanup was intentionally not changed in this patch to avoid damaging working exports.",
        ],
    }


def write_qa_coverage_report(coverage: Dict[str, Any]) -> Dict[str, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = QA_COVERAGE_REPORT_DIR / f"Jarvis_QA_Coverage_Map_{stamp}.zip"
    md_lines = [
        "# Jarvis QA Coverage Map\n",
        f"Version: {coverage.get('app_version')}\n",
        f"Generated: {coverage.get('generated_at')}\n",
        f"Status: {coverage.get('status')}\n",
        f"Summary: {coverage.get('summary')}\n",
        "\n## Coverage Categories\n",
    ]
    for cat in coverage.get("categories") or []:
        md_lines.append(f"### {cat.get('label')} — {cat.get('coverage_percent')}% / {cat.get('status')}\n")
        md_lines.append(f"- Total evidence: {cat.get('total')} · PASS: {cat.get('pass')} · BLOCKED_SAFE: {cat.get('blocked_safe')} · FAIL: {cat.get('fail')}\n")
        md_lines.append(f"- Risk if weak: {cat.get('risk_if_weak')}\n")
    if coverage.get("weak_areas"):
        md_lines.append("\n## Weak Areas / Review Items\n")
        for item in coverage.get("weak_areas") or []:
            md_lines.append(f"- {item.get('label')}: {item.get('status')} ({item.get('coverage_percent')}%) — {item.get('risk')}\n")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("qa_coverage_map.json", _safe_json_file_payload(coverage))
        zf.writestr("qa_coverage_map.md", "\n".join(md_lines))
        zf.writestr("source_reports.json", _safe_json_file_payload(coverage.get("source_reports") or []))
    return {
        "file": zip_path.name,
        "relative_path": str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/"),
        "download_url": clean_download_url(str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/")),
        "path": str(zip_path),
        "size_bytes": zip_path.stat().st_size,
    }


# v4.4.4.20 — Stable Release Gate
# Diagnostic/reporting only. Aggregates Smoke, Panic, Fuzz, Replay, Coverage, and packaging evidence before a version is called stable.
QA_RELEASE_REPORT_DIR = OUTPUT_DIR / "Jarvis_QA_Release_Gate_Reports"
QA_RELEASE_REPORT_DIR.mkdir(parents=True, exist_ok=True)

RELEASE_GATE_REQUIRED_CHECKS = [
    {"key": "smoke", "label": "Smoke QA", "required": True, "critical": True},
    {"key": "panic", "label": "Panic / Regression QA", "required": True, "critical": True},
    {"key": "fuzz", "label": "Generated mixed fuzz QA", "required": True, "critical": True},
    {"key": "replay", "label": "Debug replay intelligence", "required": True, "critical": True},
    {"key": "coverage", "label": "QA coverage map", "required": True, "critical": True},
    {"key": "reports", "label": "Report export evidence", "required": True, "critical": False},
    {"key": "packaging", "label": "Version packaging/handoff evidence", "required": True, "critical": False},
]

def _release_check(key: str, label: str, status: str, message: str, *, evidence: Optional[Dict[str, Any]] = None, critical: bool = True) -> Dict[str, Any]:
    return {
        "key": key,
        "label": label,
        "status": status,
        "critical": critical,
        "message": message,
        "evidence": evidence or {},
    }

def _release_packaging_evidence() -> Dict[str, Any]:
    # This is intentionally conservative and checks local source/handoff readiness only.
    # It does not require the final ZIP to already exist before the gate runs.
    expected_source_files = [ROOT / "app.py", ROOT / "static" / "index.html", ROOT / "static" / "assets" / "app.js"]
    present = [str(p.relative_to(ROOT)).replace("\\", "/") for p in expected_source_files if p.exists()]
    missing = [str(p.relative_to(ROOT)).replace("\\", "/") for p in expected_source_files if not p.exists()]
    handoff_markers = sorted([p.name for p in ROOT.glob("Jarvis_v4_4_4_*_NEXT_CHAT_HANDOFF.md")])[-5:]
    return {"present_source_files": present, "missing_source_files": missing, "recent_handoff_markers": handoff_markers}

def build_stable_release_gate() -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []
    source_reports: List[Dict[str, Any]] = []

    # Smoke gate
    try:
        smoke = run_qa_lab_tests("smoke")
        s = smoke.get("summary") or {}
        fail = int(s.get("fail") or 0)
        checks.append(_release_check("smoke", "Smoke QA", "PASS" if fail == 0 else "FAIL", f"{s.get('pass', 0)} PASS / {fail} FAIL", evidence={"summary": s}, critical=True))
        source_reports.append({"type": "smoke", "status": smoke.get("status"), "summary": s})
    except Exception as exc:
        checks.append(_release_check("smoke", "Smoke QA", "FAIL", f"Smoke QA failed to run: {exc}", critical=True))

    # Panic gate
    try:
        panic = run_qa_lab_tests("panic")
        s = panic.get("summary") or {}
        fail = int(s.get("fail") or 0)
        checks.append(_release_check("panic", "Panic / Regression QA", "PASS" if fail == 0 else "FAIL", f"{s.get('pass', 0)} PASS / {fail} FAIL", evidence={"summary": s}, critical=True))
        source_reports.append({"type": "panic", "status": panic.get("status"), "summary": s})
    except Exception as exc:
        checks.append(_release_check("panic", "Panic / Regression QA", "FAIL", f"Panic QA failed to run: {exc}", critical=True))

    # Fuzz gate
    try:
        fuzz_pack = generate_qa_test_pack(QAGeneratedTestPackRequest(provider="local_builtin", category="mixed", count=150, save_pack=False))
        fuzz_report = run_imported_qa_test_pack(fuzz_pack)
        s = fuzz_report.get("summary") or {}
        fail = int(s.get("fail") or 0)
        generated = len(fuzz_pack.get("tests") or [])
        status = "PASS" if fail == 0 and generated >= 150 else "FAIL"
        checks.append(_release_check("fuzz", "Generated mixed fuzz QA", status, f"Generated {generated}/150; {s.get('pass', 0)} PASS / {fail} FAIL", evidence={"summary": s, "generated": generated}, critical=True))
        source_reports.append({"type": "fuzz", "status": fuzz_report.get("status"), "summary": s, "generated": generated})
    except Exception as exc:
        checks.append(_release_check("fuzz", "Generated mixed fuzz QA", "FAIL", f"Fuzz QA failed to run: {exc}", critical=True))

    # Replay gate
    try:
        replay = analyze_debug_events(read_recent_events(240), source_name="stable_release_gate_recent_events")
        s = replay.get("summary") or {}
        critical_high = int(s.get("critical") or 0) + int(s.get("high") or 0)
        status = "PASS" if critical_high == 0 else "FAIL"
        checks.append(_release_check("replay", "Debug replay intelligence", status, f"Critical/high replay issues: {critical_high}", evidence={"summary": s}, critical=True))
        source_reports.append({"type": "replay", "status": replay.get("status"), "summary": s})
    except Exception as exc:
        checks.append(_release_check("replay", "Debug replay intelligence", "FAIL", f"Replay analysis failed to run: {exc}", critical=True))

    # Coverage gate
    coverage: Optional[Dict[str, Any]] = None
    try:
        coverage = build_qa_coverage_map()
        s = coverage.get("summary") or {}
        stable_candidate = bool(s.get("stable_candidate"))
        avg = int(s.get("average_coverage_percent") or 0)
        critical = int(s.get("critical_failures") or 0)
        strong = int(s.get("strong") or 0)
        total_cats = int(s.get("categories") or 0)
        status = "PASS" if stable_candidate and avg >= 90 and critical == 0 else "FAIL"
        checks.append(_release_check("coverage", "QA coverage map", status, f"Average {avg}% · Strong {strong}/{total_cats} · Critical failures {critical}", evidence={"summary": s, "weak_areas": coverage.get("weak_areas") or []}, critical=True))
        source_reports.append({"type": "coverage", "status": coverage.get("status"), "summary": s})
    except Exception as exc:
        checks.append(_release_check("coverage", "QA coverage map", "FAIL", f"Coverage map failed to run: {exc}", critical=True))

    # Report outputs gate
    recent_reports = _qa_recent_report_files(80)
    report_counts = {
        "qa_reports": len(list(QA_REPORT_DIR.glob("Jarvis_QA_Report_*.zip"))),
        "replay_reports": len(list(QA_REPORT_DIR.glob("Jarvis_Debug_Replay_Analysis_*.zip"))),
        "coverage_reports": len(list(QA_COVERAGE_REPORT_DIR.glob("Jarvis_QA_Coverage_Map_*.zip"))),
    }
    report_status = "PASS" if recent_reports else "FAIL"
    checks.append(_release_check("reports", "Report export evidence", report_status, f"Recent report files found: {len(recent_reports)}", evidence=report_counts, critical=False))

    # Packaging/handoff gate
    pkg = _release_packaging_evidence()
    pkg_status = "PASS" if not pkg.get("missing_source_files") else "FAIL"
    checks.append(_release_check("packaging", "Version packaging/handoff evidence", pkg_status, "Core source files present for packaging." if pkg_status == "PASS" else "Missing core source files.", evidence=pkg, critical=False))

    failed_critical = [c for c in checks if c.get("critical") and c.get("status") != "PASS"]
    failed_noncritical = [c for c in checks if not c.get("critical") and c.get("status") != "PASS"]
    pass_count = sum(1 for c in checks if c.get("status") == "PASS")
    stable_candidate = not failed_critical and not failed_noncritical
    stable_confidence = "HIGH" if stable_candidate else ("MEDIUM" if not failed_critical else "LOW")
    gate = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": "PASS" if stable_candidate else "NEEDS_REVIEW",
        "stable_candidate": stable_candidate,
        "stable_confidence": stable_confidence,
        "summary": {
            "checks": len(checks),
            "pass": pass_count,
            "fail": len(checks) - pass_count,
            "critical_failures": len(failed_critical),
            "noncritical_failures": len(failed_noncritical),
            "coverage_average_percent": ((coverage or {}).get("summary") or {}).get("average_coverage_percent"),
            "builder_engine_modified": False,
        },
        "checks": checks,
        "source_reports": source_reports,
        "release_notes": [
            "Stable Release Gate is diagnostic only and does not patch Jarvis.",
            "Blocked-safe conflict handling is acceptable when Jarvis stops before Builder instead of guessing.",
            "Builder formula/export engine remains unchanged from the locked stable engine.",
            "Old metadata cleanup remains non-priority and was not modified by this gate.",
        ],
    }
    return gate

def write_stable_release_gate_report(gate: Dict[str, Any]) -> Dict[str, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = QA_RELEASE_REPORT_DIR / f"Jarvis_Stable_Release_Gate_{stamp}.zip"
    md_lines = [
        "# Jarvis Stable Release Gate\n",
        f"Version: {gate.get('app_version')}\n",
        f"Generated: {gate.get('generated_at')}\n",
        f"Status: {gate.get('status')}\n",
        f"Stable candidate: {gate.get('stable_candidate')}\n",
        f"Stable confidence: {gate.get('stable_confidence')}\n",
        f"Summary: {gate.get('summary')}\n",
        "\n## Checks\n",
    ]
    for check in gate.get("checks") or []:
        md_lines.append(f"### {check.get('label')} — {check.get('status')}\n")
        md_lines.append(f"- Critical: {check.get('critical')}\n")
        md_lines.append(f"- Message: {check.get('message')}\n")
    if gate.get("release_notes"):
        md_lines.append("\n## Release Notes\n")
        for note in gate.get("release_notes") or []:
            md_lines.append(f"- {note}\n")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("stable_release_gate.json", _safe_json_file_payload(gate))
        zf.writestr("stable_release_gate.md", "\n".join(md_lines))
        zf.writestr("release_gate_checks.json", _safe_json_file_payload(gate.get("checks") or []))
    return {
        "file": zip_path.name,
        "relative_path": str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/"),
        "download_url": clean_download_url(str(zip_path.relative_to(OUTPUT_DIR)).replace("\\", "/")),
        "path": str(zip_path),
        "size_bytes": zip_path.stat().st_size,
    }


def _decode_json_objects(text: str) -> List[Any]:
    """Decode either normal JSON or concatenated pretty-printed JSON objects."""
    if not text:
        return []
    stripped = text.strip()
    if not stripped:
        return []
    try:
        value = json.loads(stripped)
        if isinstance(value, list):
            return value
        return [value]
    except Exception:
        pass
    decoder = json.JSONDecoder()
    idx = 0
    out: List[Any] = []
    length = len(text)
    while idx < length:
        while idx < length and text[idx].isspace():
            idx += 1
        if idx >= length:
            break
        try:
            value, next_idx = decoder.raw_decode(text, idx)
            out.append(value)
            idx = next_idx
        except Exception:
            # Move to next likely JSON object start so one corrupt line does not kill replay.
            nxt = text.find('{', idx + 1)
            if nxt < 0:
                break
            idx = nxt
    return out


def _latest_debug_report_zip() -> Optional[Path]:
    candidates = sorted(DEBUG_REPORT_DIR.glob('Jarvis_Debug_Report_*.zip'), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return candidates[0] if candidates else None


def list_debug_reports(limit: int = 25) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for path in sorted(DEBUG_REPORT_DIR.glob('Jarvis_Debug_Report_*.zip'), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)[:max(1, limit)]:
        try:
            st = path.stat()
            out.append({
                'file': path.name,
                'relative_path': str(path.relative_to(OUTPUT_DIR)).replace('\\', '/'),
                'download_url': clean_download_url(str(path.relative_to(OUTPUT_DIR)).replace('\\', '/')),
                'size_bytes': st.st_size,
                'modified': datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds'),
            })
        except Exception:
            pass
    return out


def _load_debug_report_zip(path: Path) -> Dict[str, Any]:
    payload: Dict[str, Any] = {'source_file': path.name, 'events': [], 'router_events': [], 'workflow': {}, 'errors_text': '', 'manifest': {}}
    try:
        with zipfile.ZipFile(path, 'r') as zf:
            names = set(zf.namelist())
            if 'jarvis_events_recent.jsonl' in names:
                raw = zf.read('jarvis_events_recent.jsonl').decode('utf-8', errors='replace')
                payload['events'] = [x for x in _decode_json_objects(raw) if isinstance(x, dict)]
            if 'latest_router_events.json' in names:
                raw = zf.read('latest_router_events.json').decode('utf-8', errors='replace')
                router = json.loads(raw) if raw.strip() else []
                payload['router_events'] = router if isinstance(router, list) else []
            if 'workflow_health_snapshot.json' in names:
                raw = zf.read('workflow_health_snapshot.json').decode('utf-8', errors='replace')
                payload['workflow'] = json.loads(raw) if raw.strip() else {}
            if 'errors.log' in names:
                payload['errors_text'] = zf.read('errors.log').decode('utf-8', errors='replace')[:12000]
            if 'app_manifest.json' in names:
                raw = zf.read('app_manifest.json').decode('utf-8', errors='replace')
                payload['manifest'] = json.loads(raw) if raw.strip() else {}
    except Exception as exc:
        payload['load_error'] = str(exc)
    if not payload.get('events') and payload.get('router_events'):
        payload['events'] = payload['router_events']
    return payload


def _route_issue_expected_intent(prompt: str) -> str:
    p = (prompt or '').lower()
    if 'export support log' in p or 'support log' == p.strip():
        return 'support_log_router'
    # BOQ writing should win only when the prompt is a writing task, not a Builder task.
    if ('boq description' in p or re.search(r'\bwrite\b.*\bdescription\b', p)) and not re.search(r'\b(build|base sheet|compare|format)\b', p):
        return 'boq_writer_router'
    # Mixed compare + active edit language should clarify, not force Compare.
    if ('compare' in p or 'discrepanc' in p or 'measured sheet' in p) and re.search(r'\b(remove|exclude|omit|leave out|take away|bring back|restore|add back|make\s+.*\s+first|put\s+.*\s+first|change\s+.*\s+to|replace|keep only|retain only)\b', p):
        return ''
    # Comparing a BOQ base sheet is a valid Compare task. Do not treat "base sheet" alone as Builder.
    if ('compare' in p or 'discrepanc' in p or 'measured sheet' in p) and not re.search(r'\bbuild\b|\bcreate\b.*\bbase sheet\b', p):
        return 'compare_boq_router'
    return ''


def _prompt_has_edit_language(prompt: str) -> bool:
    p = (prompt or '').lower()
    edit_core = r'\b(remove|exclude|omit|leave out|take away|bring back|restore|add back|make\s+.*\s+first|put\s+.*\s+first|change\s+.*\s+to|replace|keep only|retain only)\b'
    if re.search(edit_core, p):
        return True
    # "also" is only an edit signal when paired with a real edit action.
    # This avoids false context-loss reports for valid zone text like "Zone 1 is also Stage 1".
    if re.search(r'\balso\b', p) and re.search(r'\b(add|remove|exclude|omit|bring back|restore|change|replace)\b', p):
        return True
    return False


def _extract_zone_value_assignments_for_replay(prompt: str) -> Dict[int, List[str]]:
    """Best-effort replay-only extraction of Zone N value assignments.

    Ignores hierarchy-only references such as "Use Zone 1 as Head1" so valid
    commands are not marked as conflicts merely because a zone is mentioned twice.
    """
    raw_prompt = prompt or ''
    assignments: Dict[int, List[str]] = {}
    pattern = re.compile(r'zone\s*(\d+)\s*(?:is|has|values?\s*(?:are|=)|=)\s*([^.;]+)', re.I)
    stop_words = re.compile(r'\b(use|as\s+head|head\s*\d|levels?|door counts?|wall area|xget|unit|compare|build|format|write|remove|do not)\b', re.I)
    for m in pattern.finditer(raw_prompt):
        try:
            idx = int(m.group(1))
        except Exception:
            continue
        raw_values = stop_words.split(m.group(2))[0]
        vals = [v.strip(' ,') for v in re.split(r',|\band\b', raw_values, flags=re.I) if v.strip(' ,')]
        if vals:
            assignments.setdefault(idx, []).append(', '.join(vals).lower())
    return assignments


def _prompt_has_conflict_language(prompt: str) -> bool:
    p = (prompt or '').lower()
    # Same zone assigned two different value groups in explicit assignment phrases.
    assigns = _extract_zone_value_assignments_for_replay(prompt)
    for groups in assigns.values():
        if len(set(groups)) > 1:
            return True
    # Same zone explicitly assigned multiple heading levels.
    head_refs: Dict[str, set] = {}
    for m in re.finditer(r'zone\s*(\d+)\s*(?:as|=|in|to)?\s*head\s*(\d+)', p):
        head_refs.setdefault(m.group(1), set()).add(m.group(2))
    if any(len(v) > 1 for v in head_refs.values()):
        return True
    if re.search(r'\bremove\s+([a-z0-9 ]+?)\b.*\bdo\s+not\s+remove\s+\1\b', p):
        return True
    if ('xgetcount' in p and 'xgetwallarea' in p) or ('unit no' in p and 'm2' in p):
        return True
    # Mixed task conflict requires an actual build/create action, not merely "Compare BOQ base sheet".
    if 'compare' in p and re.search(r'\b(build|create)\b.*\bbase sheet\b|\bthen\b.*\bbuild\b', p):
        return True
    return False


def _summarize_builder_plan_for_replay(plan: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(plan, dict) or not plan:
        return {}
    project = plan.get('project_zone_hierarchy') or {}
    setup = plan.get('current_work_setup') or {}
    return {
        'trade': plan.get('trade_profile_name'),
        'function': plan.get('default_costx_function') or plan.get('costx_function') or setup.get('default_costx_function'),
        'unit': plan.get('unit') or setup.get('unit'),
        'confidence': plan.get('confidence'),
        'risk': plan.get('risk'),
        'levels': project.get('level_values') or _qa_levels(plan),
        'dynamic_zones': project.get('dynamic_zones') or [],
        'hierarchy': project.get('hierarchy') or [],
        'hierarchy_summary': _dynamic_hierarchy_summary(project),
        'hierarchy_description': project.get('hierarchy_description'),
    }


def _analyze_route_event(e: Dict[str, Any], previous_builder_seen: bool) -> Dict[str, Any]:
    payload = e.get('payload') or {}
    route = payload.get('route') or {}
    prompt = str(payload.get('prompt') or '')
    intent = route.get('intent')
    tool_key = route.get('tool_key')
    ctx = payload.get('context_snapshot') or route.get('context_snapshot') or {}
    plan = route.get('builder_command_plan') or {}
    clarification = route.get('clarification') or {}
    issues: List[Dict[str, Any]] = []

    expected = _route_issue_expected_intent(prompt)
    if expected and intent != expected:
        issues.append({
            'type': 'WRONG_ROUTE',
            'severity': 'critical',
            'message': f'Expected {expected}, got {intent}.',
            'patch_area': 'Router priority guard',
        })

    conflict_like = _prompt_has_conflict_language(prompt)
    conflict_blocked_safely = bool(conflict_like and intent == 'clarification_needed')
    if conflict_like and intent != 'clarification_needed':
        issues.append({
            'type': 'CONFLICT_NOT_BLOCKED',
            'severity': 'critical',
            'message': 'Prompt appears contradictory or mixed-task, but Jarvis did not ask clarification.',
            'patch_area': 'Panic Conflict Guard',
        })

    p = prompt.lower().strip()
    if re.match(r'^(do not|don\'t|dont)\s+remove\b', p):
        ctext = json.dumps(clarification, ensure_ascii=False).lower()
        if intent == 'clarification_needed' and 'conflict' in ctext and ' but ' not in p:
            issues.append({
                'type': 'FALSE_NEGATION_CONFLICT',
                'severity': 'high',
                'message': 'Simple negated remove was treated as a conflict.',
                'patch_area': 'Negation precision guard',
            })

    if _prompt_has_edit_language(prompt):
        active_flag = bool(ctx.get('active_builder_plan'))
        # If a mixed/conflicting edit is safely routed to clarification, that is not context loss.
        if not conflict_blocked_safely and not active_flag and previous_builder_seen and intent in {'general_ai', 'local_ai', 'clarification_needed'}:
            ctext = json.dumps(clarification, ensure_ascii=False).lower()
            if intent == 'general_ai' or ('restore' not in ctext and 'previous' not in ctext and 'active builder' not in ctext):
                issues.append({
                    'type': 'CONTEXT_LOST',
                    'severity': 'high',
                    'message': 'Edit-like message arrived after a Builder plan existed, but active Builder context was not used or restored.',
                    'patch_area': 'Active plan persistence / amendment guard',
                })
        if intent == 'general_ai':
            issues.append({
                'type': 'WRONG_ROUTE',
                'severity': 'high',
                'message': 'Edit/reorder phrase was routed to Local AI/general route.',
                'patch_area': 'Active Plan Edit Resolver',
            })

    # Plan structural risk checks.
    plan_summary = _summarize_builder_plan_for_replay(plan)
    if plan_summary:
        zones = plan_summary.get('dynamic_zones') or []
        zone_indices: Dict[int, List[str]] = {}
        for z in zones:
            try:
                idx = int((z or {}).get('index') or (z or {}).get('zone_index') or 0)
            except Exception:
                continue
            vals = [str(v) for v in ((z or {}).get('values') or [])]
            if idx in zone_indices and zone_indices[idx] != vals:
                issues.append({
                    'type': 'ZONE_CONFLICT',
                    'severity': 'critical',
                    'message': f'Zone {idx} has multiple value groups in the plan.',
                    'patch_area': 'Zone conflict guard',
                })
            zone_indices[idx] = vals
        used_heading_zones: Dict[int, str] = {}
        for h in plan_summary.get('hierarchy') or []:
            try:
                idx = int((h or {}).get('zone_index') or 0)
            except Exception:
                continue
            if idx and idx in used_heading_zones and str(h.get('head')) != used_heading_zones[idx]:
                issues.append({
                    'type': 'HIERARCHY_CONFLICT',
                    'severity': 'critical',
                    'message': f'Zone {idx} appears on multiple heading levels.',
                    'patch_area': 'Hierarchy conflict blocker',
                })
            if idx:
                used_heading_zones[idx] = str(h.get('head'))

    status = 'PASS'
    if any(i.get('severity') == 'critical' for i in issues):
        status = 'FAIL'
    elif issues:
        status = 'NEEDS_REVIEW'
    elif conflict_blocked_safely:
        status = 'BLOCKED_SAFE'
    elif intent == 'clarification_needed':
        status = 'NEEDS_CLARIFICATION'
    return {
        'timestamp': e.get('timestamp'),
        'prompt': prompt,
        'intent': intent,
        'tool_key': tool_key,
        'confidence': route.get('confidence'),
        'action': payload.get('action'),
        'active_builder_plan': bool(ctx.get('active_builder_plan')),
        'pending_type': ctx.get('pending_type'),
        'has_builder_plan': bool(plan),
        'has_clarification': bool(clarification),
        'status': status,
        'issues': issues,
        'plan_summary': plan_summary,
    }


def analyze_debug_events(events: List[Dict[str, Any]], *, source_name: str = 'live_events') -> Dict[str, Any]:
    route_events = [e for e in events if e.get('event') == 'route_request' or ((e.get('payload') or {}).get('route'))]
    builder_events = [e for e in events if str(e.get('event') or '').startswith('builder') or e.get('event') == 'job_created']
    errors = [e for e in events if 'error' in str(e.get('event') or '').lower() or 'failed' in str(e.get('event') or '').lower()]
    timeline: List[Dict[str, Any]] = []
    previous_builder_seen = False
    for e in route_events:
        item = _analyze_route_event(e, previous_builder_seen)
        timeline.append(item)
        if item.get('has_builder_plan'):
            previous_builder_seen = True
    all_issues: List[Dict[str, Any]] = []
    for item in timeline:
        for issue in item.get('issues') or []:
            all_issues.append({**issue, 'prompt': item.get('prompt'), 'timestamp': item.get('timestamp'), 'intent': item.get('intent')})
    if errors:
        for e in errors[-10:]:
            all_issues.append({
                'type': 'ERROR_EVENT',
                'severity': 'high',
                'message': str((e.get('payload') or {}).get('error') or e.get('event'))[:500],
                'patch_area': 'Runtime error handling',
                'timestamp': e.get('timestamp'),
            })
    # Dedupe repeated replay issues so one repeated route does not flood the report.
    deduped: List[Dict[str, Any]] = []
    seen_issue_keys: set = set()
    for issue in all_issues:
        key = (str(issue.get('type')), str(issue.get('severity')), str(issue.get('message')), str(issue.get('prompt'))[:220], str(issue.get('intent')))
        if key in seen_issue_keys:
            continue
        seen_issue_keys.add(key)
        deduped.append(issue)
    all_issues = deduped
    critical = sum(1 for i in all_issues if i.get('severity') == 'critical')
    high = sum(1 for i in all_issues if i.get('severity') == 'high')
    status = 'PASS' if not all_issues else ('FAIL' if critical else 'NEEDS_REVIEW')
    patch_areas: Dict[str, int] = {}
    for issue in all_issues:
        area = str(issue.get('patch_area') or 'Unclassified')
        patch_areas[area] = patch_areas.get(area, 0) + 1
    return {
        'app_version': APP_VERSION,
        'generated_at': datetime.now().isoformat(timespec='seconds'),
        'source': source_name,
        'status': status,
        'summary': {
            'events': len(events),
            'routes': len(route_events),
            'builder_events': len(builder_events),
            'errors': len(errors),
            'issues': len(all_issues),
            'critical': critical,
            'high': high,
        },
        'timeline': timeline[-30:],
        'issues': all_issues[-80:],
        'patch_area_counts': patch_areas,
        'workflow_health_snapshot': build_workflow_health_snapshot(events),
    }


def write_debug_replay_analysis_report(analysis: Dict[str, Any]) -> Dict[str, Any]:
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_source = _qa_slug(str(analysis.get('source') or 'debug_replay'), 'debug_replay')
    zip_path = QA_REPORT_DIR / f'Jarvis_Debug_Replay_Analysis_{stamp}_{safe_source}.zip'
    md_lines = [
        f"# Jarvis Debug Replay Analysis\n",
        f"Version: {analysis.get('app_version')}\n",
        f"Generated: {analysis.get('generated_at')}\n",
        f"Source: {analysis.get('source')}\n",
        f"Status: {analysis.get('status')}\n",
        f"Summary: {analysis.get('summary')}\n",
        "\n## Issues\n",
    ]
    for issue in analysis.get('issues') or []:
        md_lines.append(f"### {issue.get('type')} — {issue.get('severity')}\n")
        md_lines.append(f"- Message: {issue.get('message')}\n")
        md_lines.append(f"- Prompt: {issue.get('prompt', '')}\n")
        md_lines.append(f"- Patch area: {issue.get('patch_area')}\n")
    md_lines.append("\n## Timeline\n")
    for row in analysis.get('timeline') or []:
        md_lines.append(f"- {row.get('timestamp')} — {row.get('intent')} — {row.get('status')} — {row.get('prompt')}\n")
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('debug_replay_analysis.json', _safe_json_file_payload(analysis))
        zf.writestr('debug_replay_analysis.md', '\n'.join(md_lines))
        zf.writestr('workflow_health_snapshot.json', _safe_json_file_payload(analysis.get('workflow_health_snapshot') or {}))
    return {
        'file': zip_path.name,
        'relative_path': str(zip_path.relative_to(OUTPUT_DIR)).replace('\\', '/'),
        'download_url': clean_download_url(str(zip_path.relative_to(OUTPUT_DIR)).replace('\\', '/')),
        'path': str(zip_path),
        'size_bytes': zip_path.stat().st_size,
    }


def replay_latest_debug_log_summary(limit: int = 220) -> Dict[str, Any]:
    latest_zip = _latest_debug_report_zip()
    debug_payload: Dict[str, Any] = {}
    events: List[Dict[str, Any]] = []
    source = 'live_recent_events'
    if latest_zip:
        debug_payload = _load_debug_report_zip(latest_zip)
        events = debug_payload.get('events') or []
        source = latest_zip.name
    if not events:
        events = read_recent_events(limit)
    analysis = analyze_debug_events(events, source_name=source)
    analysis['available_debug_reports'] = list_debug_reports(12)
    if debug_payload:
        analysis['debug_report_manifest'] = debug_payload.get('manifest') or {}
        analysis['debug_report_workflow_snapshot'] = debug_payload.get('workflow') or {}
        if debug_payload.get('load_error'):
            analysis.setdefault('issues', []).append({
                'type': 'LOG_LOAD_ERROR',
                'severity': 'high',
                'message': debug_payload.get('load_error'),
                'patch_area': 'Debug log replay loader',
            })
    file_info = write_debug_replay_analysis_report(analysis)
    analysis['file'] = file_info
    return analysis


# ---------------------------------------------------------------------------
# v4.4.4.17/18 — Smart QA Generator + Debug Replay Intelligence
# Diagnostics only. Generated/imported tests and replay analysis exercise router/planner logic; no
# Builder formula/export engine rewrite and no external tool mutation.
# ---------------------------------------------------------------------------

QA_PACK_SCHEMA_VERSION = "1.0"


def _qa_slug(text: str, fallback: str = "qa_test_pack") -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(text or fallback)).strip("._-")
    return (value or fallback)[:90]


def _qa_now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _qa_pack_file_name(pack_name: str) -> str:
    return f"{_qa_now_stamp()}_{_qa_slug(pack_name)}.json"


def _qa_normalize_pack(raw_pack: Any, *, fallback_name: str = "Imported QA Test Pack") -> Dict[str, Any]:
    if isinstance(raw_pack, list):
        raw_pack = {"pack_name": fallback_name, "version": QA_PACK_SCHEMA_VERSION, "tests": raw_pack}
    if not isinstance(raw_pack, dict):
        raise HTTPException(status_code=400, detail="QA test pack must be a JSON object or array of tests.")
    tests = raw_pack.get("tests")
    if not isinstance(tests, list) or not tests:
        raise HTTPException(status_code=400, detail="QA test pack must include a non-empty tests array.")
    normalized_tests: List[Dict[str, Any]] = []
    for idx, test in enumerate(tests, start=1):
        if not isinstance(test, dict):
            raise HTTPException(status_code=400, detail=f"Test #{idx} must be an object.")
        prompt = str(test.get("prompt") or "").strip()
        if not prompt:
            raise HTTPException(status_code=400, detail=f"Test #{idx} is missing prompt.")
        tid = str(test.get("id") or f"AI-GEN-{idx:03d}").strip()
        expected_behavior = str(test.get("expected_behavior") or test.get("expected") or "route_or_clarify").strip().lower()
        normalized_tests.append({
            "id": tid,
            "name": str(test.get("name") or test.get("title") or tid).strip(),
            "category": str(test.get("category") or "imported").strip().lower(),
            "prompt": prompt,
            "setup_prompt": str(test.get("setup_prompt") or "").strip(),
            "requires_active_plan": bool(test.get("requires_active_plan") or test.get("active_plan")),
            "expected_behavior": expected_behavior,
            "expected_route": test.get("expected_route") or test.get("expected_intent"),
            "expected_trade": test.get("expected_trade"),
            "expected_function": test.get("expected_function"),
            "expected_unit": test.get("expected_unit"),
            "expected_levels": test.get("expected_levels") if isinstance(test.get("expected_levels"), list) else None,
            "expected_zones": test.get("expected_zones") if isinstance(test.get("expected_zones"), dict) else None,
            "must_contain": test.get("must_contain") if isinstance(test.get("must_contain"), list) else [],
            "must_not_contain": test.get("must_not_contain") if isinstance(test.get("must_not_contain"), list) else [],
            "severity": str(test.get("severity") or "normal").strip().lower(),
        })
    return {
        "pack_name": str(raw_pack.get("pack_name") or raw_pack.get("name") or fallback_name).strip() or fallback_name,
        "version": str(raw_pack.get("version") or QA_PACK_SCHEMA_VERSION),
        "target_jarvis_version": str(raw_pack.get("target_jarvis_version") or "v4.4.4.20+"),
        "generated_by": str(raw_pack.get("generated_by") or "manual_or_external_ai"),
        "imported_at": datetime.now().isoformat(timespec="seconds"),
        "tests": normalized_tests,
    }


def _qa_pack_text_to_json(pack_text: str) -> Dict[str, Any]:
    text = (pack_text or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="No QA test pack text provided.")
    # Allow code fences from ChatGPT/Claude/Gemini outputs.
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I).strip()
        text = re.sub(r"\s*```$", "", text).strip()
    try:
        raw = json.loads(text)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON test pack: {exc}")
    return _qa_normalize_pack(raw)


def save_qa_test_pack(pack: Dict[str, Any], pack_name: Optional[str] = None) -> Dict[str, Any]:
    name = str(pack_name or pack.get("pack_name") or "Imported QA Test Pack")
    file_name = _qa_pack_file_name(name)
    path = QA_TEST_PACK_DIR / file_name
    path.write_text(_safe_json_file_payload(pack), encoding="utf-8")
    return {"file": file_name, "path": str(path), "pack_name": pack.get("pack_name"), "tests": len(pack.get("tests") or [])}


def list_qa_test_packs() -> List[Dict[str, Any]]:
    packs: List[Dict[str, Any]] = []
    for path in sorted(QA_TEST_PACK_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            packs.append({
                "file": path.name,
                "pack_name": data.get("pack_name") or path.stem,
                "tests": len(data.get("tests") or []),
                "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
            })
        except Exception:
            packs.append({"file": path.name, "pack_name": path.stem, "tests": 0, "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"), "warning": "Unreadable JSON"})
    return packs


def load_qa_test_pack(pack_file: str) -> Dict[str, Any]:
    safe_name = Path(pack_file or "").name
    if not safe_name or safe_name in {".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid QA test pack file.")
    path = QA_TEST_PACK_DIR / safe_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="QA test pack not found.")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"QA test pack cannot be read: {exc}")
    return _qa_normalize_pack(raw, fallback_name=path.stem)


def _qa_route_text(route_payload: Dict[str, Any]) -> str:
    route = _qa_route_obj(route_payload)
    plan = route.get("builder_command_plan") or {}
    payload = {
        "intent": route.get("intent"),
        "tool_key": route.get("tool_key"),
        "confidence": route.get("confidence"),
        "risk": route.get("risk"),
        "message": route.get("message") or route.get("summary"),
        "clarification": route.get("clarification"),
        "trade": plan.get("trade_profile_name"),
        "function": plan.get("default_costx_function") or plan.get("costx_function"),
        "unit": plan.get("unit"),
        "levels": _qa_levels(plan) if plan else [],
        "zones": (_qa_project(plan).get("dynamic_zones") if plan else []),
    }
    return json.dumps(payload, ensure_ascii=False, default=str)


def _qa_evaluate_imported_test(test: Dict[str, Any], route_payload: Dict[str, Any]) -> Dict[str, Any]:
    route = _qa_route_obj(route_payload)
    plan = _qa_plan(route_payload)
    text = _qa_route_text(route_payload).lower()
    status_ok = True
    blocked_safe = False
    failures: List[str] = []

    expected_behavior = str(test.get("expected_behavior") or "").lower()
    intent = route.get("intent")
    if expected_behavior in {"blocked_or_clarification", "clarification", "needs_clarification", "blocked_safe"}:
        blocked_safe = intent == "clarification_needed"
        status_ok = blocked_safe
        if not status_ok:
            failures.append("Expected clarification/block before execution.")
    elif expected_behavior in {"route", "route_or_plan", "pass", "success"}:
        status_ok = bool(intent)
    elif expected_behavior in {"builder_plan", "builder"}:
        status_ok = intent == "builder_command_router" and bool(plan)
        if not status_ok:
            failures.append("Expected Builder command plan.")
    elif expected_behavior in {"builder_or_clarification", "builder_plan_or_clarification", "safe_builder_edit"}:
        status_ok = (intent == "builder_command_router" and bool(plan)) or intent == "clarification_needed"
        blocked_safe = intent == "clarification_needed"
        if not status_ok:
            failures.append("Expected Builder command plan or safe clarification.")

    expected_route = test.get("expected_route")
    if expected_route:
        if str(intent) != str(expected_route):
            status_ok = False
            failures.append(f"Expected route {expected_route}, got {intent}.")

    if plan:
        if test.get("expected_trade") and plan.get("trade_profile_name") != test.get("expected_trade"):
            status_ok = False
            failures.append(f"Expected trade {test.get('expected_trade')}, got {plan.get('trade_profile_name')}.")
        expected_function = test.get("expected_function")
        if expected_function:
            actual_function = str(plan.get("default_costx_function") or plan.get("costx_function") or "").upper()
            if actual_function != str(expected_function).upper():
                status_ok = False
                failures.append(f"Expected function {expected_function}, got {actual_function}.")
        if test.get("expected_levels") is not None and _qa_levels(plan) != test.get("expected_levels"):
            status_ok = False
            failures.append(f"Expected levels {test.get('expected_levels')}, got {_qa_levels(plan)}.")
        expected_zones = test.get("expected_zones") or {}
        for key, expected_values in expected_zones.items():
            try:
                zidx = int(str(key).replace("zone", "").replace("Zone", "").strip())
            except Exception:
                continue
            actual_values = _qa_zone_values(plan, zidx)
            if actual_values != expected_values:
                status_ok = False
                failures.append(f"Expected Zone {zidx} {expected_values}, got {actual_values}.")

    for needle in test.get("must_contain") or []:
        if str(needle).lower() not in text:
            status_ok = False
            failures.append(f"Missing required text: {needle}")
    for needle in test.get("must_not_contain") or []:
        if str(needle).lower() in text:
            status_ok = False
            failures.append(f"Forbidden text found: {needle}")

    return {
        "status": _qa_status(status_ok, blocked_safe=blocked_safe and status_ok),
        "actual": f"intent={intent}; failures={'; '.join(failures) if failures else 'none'}",
        "evidence": {"route": intent, "tool_key": route.get("tool_key"), "has_plan": bool(plan), "failures": failures},
    }


def _qa_default_active_plan() -> Dict[str, Any]:
    route = _qa_route(_qa_final_boss_prompt(), has_file=True)
    return _qa_plan(route)


def run_imported_qa_test_pack(pack: Dict[str, Any]) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    default_plan: Optional[Dict[str, Any]] = None
    for test in pack.get("tests") or []:
        active_plan = None
        setup_prompt = str(test.get("setup_prompt") or "").strip()
        if setup_prompt:
            setup_route = _qa_route(setup_prompt, has_file=True)
            active_plan = _qa_plan(setup_route)
        elif test.get("requires_active_plan"):
            if default_plan is None:
                default_plan = _qa_default_active_plan()
            active_plan = default_plan
        route = _qa_route(str(test.get("prompt") or ""), has_file=True, active_plan=active_plan)
        evaluation = _qa_evaluate_imported_test(test, route)
        _qa_add(
            results,
            str(test.get("id") or "IMPORTED"),
            str(test.get("name") or test.get("category") or "Imported test"),
            str(test.get("expected_behavior") or test.get("expected_route") or "see test pack"),
            evaluation.get("actual") or "",
            evaluation.get("status") or "FAIL",
            {"category": test.get("category"), "severity": test.get("severity"), **(evaluation.get("evidence") or {})},
        )
    pass_count = sum(1 for x in results if x["status"] == "PASS")
    blocked_count = sum(1 for x in results if x["status"] == "BLOCKED_SAFE")
    fail_count = sum(1 for x in results if x["status"] == "FAIL")
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "test_pack": f"imported:{pack.get('pack_name')}",
        "status": "PASS" if fail_count == 0 else "FAIL",
        "summary": {"total": len(results), "pass": pass_count, "blocked_safe": blocked_count, "fail": fail_count},
        "results": results,
        "pack_metadata": {"pack_name": pack.get("pack_name"), "version": pack.get("version"), "generated_by": pack.get("generated_by")},
    }


def _qa_template_tests(category: str = "mixed", count: int = 25) -> List[Dict[str, Any]]:
    """Generate a deterministic local fuzz pack.

    v4.4.4.18.2 expands beyond the old fixed 19-test pool by combining
    actions, trades, zones, levels, route tasks, and conflict patterns.
    No external API calls are made; generation is local, repeatable, and safe.
    """
    requested = max(1, min(int(count or 25), 300))
    cats = {c.strip().lower() for c in re.split(r"[,/ ]+", category or "mixed") if c.strip()}
    if not cats or "mixed" in cats or "all" in cats:
        cats = {"router", "zone", "formula", "edit", "negation", "reorder", "conflict", "restore", "replace"}
    tests: List[Dict[str, Any]] = []
    seen_prompts: set = set()

    def add(tid: str, cat: str, prompt: str, expected_behavior: str, *, route: Optional[str] = None, active: bool = False, must: Optional[List[str]] = None, must_not: Optional[List[str]] = None, severity: str = "normal") -> None:
        clean_prompt = re.sub(r"\s+", " ", str(prompt or "")).strip()
        key = clean_prompt.lower()
        if not clean_prompt or key in seen_prompts:
            return
        seen_prompts.add(key)
        tests.append({
            "id": tid,
            "name": tid.replace("-", " ").title(),
            "category": cat,
            "prompt": clean_prompt,
            "expected_behavior": expected_behavior,
            "expected_route": route,
            "requires_active_plan": active,
            "must_contain": must or [],
            "must_not_contain": must_not or [],
            "severity": severity,
        })

    if "router" in cats:
        route_variants = [
            ("Export support log", "support_log_router"),
            ("Please export support log", "support_log_router"),
            ("Export the support log for checking", "support_log_router"),
            ("Write a BOQ description for fire-rated doors.", "boq_writer_router"),
            ("Write a BOQ description for acoustic rated doors.", "boq_writer_router"),
            ("Write a BOQ description for external glazed doors.", "boq_writer_router"),
            ("Compare BOQ base sheet against measured sheet and report discrepancies.", "compare_boq_router"),
            ("Compare the base BOQ with the measured sheet and find discrepancies.", "compare_boq_router"),
            ("Run discrepancy check between BOQ base sheet and measured sheet.", "compare_boq_router"),
        ]
        for i, (prompt, route) in enumerate(route_variants, start=1):
            add(f"AI-ROUTE-{i:03d}", "router", prompt, "route", route=route)

    zone_value_sets = [
        (1, "Internal and External", 2, "Stage 1 and Stage 2"),
        (1, "Building A and Building B", 2, "Stage 1 and Stage 2"),
        (2, "Stage 1 and Stage 2", 3, "Internal and External"),
        (4, "East Wing and West Wing", 7, "Package A and Package B"),
        (1, "Tower A and Tower B", 3, "Wet Area and Dry Area"),
    ]
    if "zone" in cats:
        idx = 1
        for z1, vals1, z2, vals2 in zone_value_sets:
            add(f"AI-ZONE-{idx:03d}", "zone", f"Create Door Trade base sheet. Zone {z1} is {vals1}. Zone {z1} is also {vals2}. Levels L1. Door counts only.", "blocked_or_clarification", severity="critical"); idx += 1
            add(f"AI-ZONE-{idx:03d}", "zone", f"Create Door Trade base sheet. Zone {z2} is {vals2}. Use Zone {z2} as Head1 and Zone {z2} as Head2. Levels L1. Door counts only.", "blocked_or_clarification", severity="critical"); idx += 1
            # Valid non-skipped zone combinations should be Builder plans; skipped zones should clarify level placement.
            expected = "blocked_or_clarification" if max(z1, z2) > 3 else "builder_plan"
            add(f"AI-ZONE-{idx:03d}", "zone", f"Create Door Trade base sheet. Zone {z1} is {vals1}. Zone {z2} is {vals2}. Use Zone {z2} as Head1 and Zone {z1} as Head2. Levels L1 to L3. Door counts only.", expected, active=False); idx += 1
        add("AI-ZONE-SKIP-001", "zone", "Create Door Trade base sheet. Zone 4 is East Wing and West Wing. Zone 7 is Package A and Package B. Use Zone 7 Head1 and Zone 4 Head2. Levels L1 to L3. Door counts only.", "blocked_or_clarification", must=["level", "zone"])
        add("AI-ZONE-SKIP-002", "zone", "Create Door Trade base sheet. Zone 7 is Package A and Package B. Zone 4 is East Wing and West Wing. Zone 3 is Level Group A and Level Group B. Levels L1 to L3. Use Zone 7 Head1, Zone 4 Head2, Zone 3 Head3. Door counts only.", "builder_or_clarification")

    if "formula" in cats:
        formula_conflicts = [
            "Create Door Trade base sheet using wall area. Use XGETCOUNT and XGETWALLAREA. Unit no and m2. Levels L1.",
            "Create Wall Types base sheet using door counts. Use XGETWALLAREA and XGETCOUNT. Unit m2 and no. Levels L1.",
            "Create Door Trade base sheet. Door counts only but unit m2. Levels L1.",
            "Create Wall Types trade by area but unit no. Levels L1.",
            "Create Door Trade base sheet. Zone 2 is Stage \"A\" and Stage [B]. Zone 1 is Internal. Levels L1. Door counts only.",
        ]
        for i, prompt in enumerate(formula_conflicts, start=1):
            add(f"AI-FORMULA-{i:03d}", "formula", prompt, "blocked_or_clarification", severity="critical")

    level_targets = ["L1", "L2", "L3", "L4", "L5", "Roof"]
    edit_remove_verbs = ["remove", "omit", "exclude", "leave out", "take away"]
    restore_verbs = ["bring back", "restore", "add back", "include"]
    if "edit" in cats:
        idx = 1
        for verb in edit_remove_verbs:
            for level in level_targets[:6]:
                add(f"AI-EDIT-{idx:03d}", "edit", f"{verb} {level}", "builder_or_clarification", active=True, must_not=["general_ai"]); idx += 1
        add("AI-EDIT-COMBO-001", "edit", "Also remove L4 and add Roof.", "builder_plan", active=True, must_not=["general_ai"])
        add("AI-EDIT-COMBO-002", "edit", "remove L4 and add Roof", "builder_plan", active=True, must_not=["general_ai"])
    if "restore" in cats:
        idx = 1
        for verb in restore_verbs:
            for level in ["L2", "L3", "L6", "Roof"]:
                add(f"AI-RESTORE-{idx:03d}", "restore", f"{verb} {level}", "builder_or_clarification", active=True, must_not=["general_ai"]); idx += 1

    if "negation" in cats:
        idx = 1
        for level in ["L1", "L2", "L3", "L4", "Roof"]:
            add(f"AI-NEG-{idx:03d}", "negation", f"do not remove {level}", "builder_plan", active=True, must_not=["conflict", f"Removed level(s): {level}"]); idx += 1
            add(f"AI-NEG-{idx:03d}", "negation", f"remove {level} but do not remove {level}", "blocked_or_clarification", active=True, severity="critical"); idx += 1
        for branch in ["Internal", "External", "Stage 2", "Building B"]:
            add(f"AI-NEG-{idx:03d}", "negation", f"remove {branch} but do not remove {branch}", "blocked_or_clarification", active=True, severity="critical"); idx += 1

    if "reorder" in cats:
        reorder_prompts = [
            "make External first", "make Internal first", "put External first", "put Internal first",
            "put Stage 2 before Stage 1", "make Building B first", "make Stage 1b first",
        ]
        for i, prompt in enumerate(reorder_prompts, start=1):
            add(f"AI-ORDER-{i:03d}", "reorder", prompt, "builder_or_clarification", active=True, must_not=["general_ai"])

    if "replace" in cats:
        replacements = [("Stage 2", "Stage 2b"), ("Stage 1b", "Stage 1A"), ("Internal", "External"), ("Building B", "Building C")]
        for i, (a, b) in enumerate(replacements, start=1):
            add(f"AI-REPLACE-{i:03d}", "replace", f"change {a} to {b}", "builder_or_clarification", active=True, must_not=[f"{a}, {b}"])

    if "conflict" in cats:
        conflict_prompts = [
            "Build a Door Trade base sheet but format it now and do not format it yet.",
            "Keep the same setup, remove Internal but do not remove Internal, and compare this one.",
            "Compare BOQ base sheet against measured sheet, then build a Door Trade base sheet with Zone 2 as Stage 1 and Stage 2.",
            "Write a BOQ description and build a Door Trade base sheet at the same time.",
            "Keep only the other one",
            "remove everything except External",
        ]
        for i, prompt in enumerate(conflict_prompts, start=1):
            add(f"AI-CONFLICT-{i:03d}", "conflict", prompt, "blocked_or_clarification", active=(i in {2,5,6}), severity="critical" if i in {1,2,3,4} else "normal")

    zone_pairs = [(1, 2), (2, 1), (2, 3), (4, 7), (7, 4)]
    level_ranges = ["L1", "L1 to L2", "L1 to L3", "B2 to 1, GF, L1 to L3", "L5 and Roof"]
    variant_no = 1
    while len(tests) < requested and variant_no <= requested * 5:
        z_a, z_b = zone_pairs[variant_no % len(zone_pairs)]
        levels = level_ranges[variant_no % len(level_ranges)]
        group_a = ["Internal and External", "Building A and Building B", "East Wing and West Wing", "Tower A and Tower B"][variant_no % 4]
        group_b = ["Stage 1 and Stage 2", "Package A and Package B", "Wet Area and Dry Area", "Milestone 1 and Milestone 2"][variant_no % 4]
        mode = variant_no % 6
        if mode == 0:
            add(f"AI-FUZZ-ZONE-{variant_no:03d}", "zone", f"Create Door Trade base sheet. Zone {z_a} is {group_a}. Zone {z_a} is also {group_b}. Levels {levels}. Door counts only.", "blocked_or_clarification", severity="critical")
        elif mode == 1:
            add(f"AI-FUZZ-HEAD-{variant_no:03d}", "zone", f"Create Door Trade base sheet. Zone {z_a} is {group_a}. Use Zone {z_a} as Head1 and Zone {z_a} as Head2. Levels {levels}. Door counts only.", "blocked_or_clarification", severity="critical")
        elif mode == 2:
            level = level_targets[variant_no % len(level_targets)]
            add(f"AI-FUZZ-NEG-{variant_no:03d}", "negation", f"remove {level} but do not remove {level}", "blocked_or_clarification", active=True, severity="critical")
        elif mode == 3:
            level = level_targets[variant_no % len(level_targets)]
            add(f"AI-FUZZ-EDIT-{variant_no:03d}", "edit", f"{edit_remove_verbs[variant_no % len(edit_remove_verbs)]} {level}", "builder_or_clarification", active=True, must_not=["general_ai"])
        elif mode == 4:
            level = level_targets[variant_no % len(level_targets)]
            add(f"AI-FUZZ-RESTORE-{variant_no:03d}", "restore", f"{restore_verbs[variant_no % len(restore_verbs)]} {level}", "builder_or_clarification", active=True, must_not=["general_ai"])
        else:
            add(f"AI-FUZZ-FORMULA-{variant_no:03d}", "formula", f"Create Door Trade base sheet using wall area. Use XGETCOUNT and XGETWALLAREA. Unit no and m2. Levels {levels}.", "blocked_or_clarification", severity="critical")
        variant_no += 1

    filler_no = 1
    while len(tests) < requested and filler_no <= requested * 2:
        mod = filler_no % 3
        if mod == 0:
            add(f"AI-FILLER-SUPPORT-{filler_no:03d}", "router", f"Export support log for QA run {filler_no}", "route", route="support_log_router")
        elif mod == 1:
            add(f"AI-FILLER-BOQ-{filler_no:03d}", "router", f"Write a BOQ description for fire-rated door type QA-{filler_no}.", "route", route="boq_writer_router")
        else:
            add(f"AI-FILLER-COMPARE-{filler_no:03d}", "router", f"Compare BOQ base sheet against measured sheet and report discrepancies for QA run {filler_no}.", "route", route="compare_boq_router")
        filler_no += 1

    return tests[:requested]

def _qa_external_provider_status() -> Dict[str, Any]:
    return {
        "local_builtin": {"configured": True, "detail": "Offline deterministic template generator."},
        "openai": {"configured": bool(os.environ.get("OPENAI_API_KEY")), "env": "OPENAI_API_KEY"},
        "anthropic": {"configured": bool(os.environ.get("ANTHROPIC_API_KEY")), "env": "ANTHROPIC_API_KEY"},
        "gemini": {"configured": bool(os.environ.get("GEMINI_API_KEY")), "env": "GEMINI_API_KEY"},
    }


def generate_qa_test_pack(req: QAGeneratedTestPackRequest) -> Dict[str, Any]:
    provider = (req.provider or "local_builtin").strip().lower()
    category = (req.category or "mixed").strip().lower()
    count = max(1, min(int(req.count or 25), 150))
    # v4.4.4.18 is intentionally safe/offline by default. External API hooks are
    # represented in provider status and can be enabled later without changing the
    # test-pack schema. This avoids leaking keys or sending project files.
    if provider != "local_builtin":
        status = _qa_external_provider_status().get(provider)
        if not status or not status.get("configured"):
            raise HTTPException(status_code=400, detail=f"{provider} API is not configured. Add the API key to .env/environment first, or use local_builtin.")
        raise HTTPException(status_code=501, detail=f"{provider} connector is API-ready but intentionally disabled in v4.4.4.20 safety phase. Use local_builtin or manual JSON import.")
    tests = _qa_template_tests(category, count)
    return {
        "pack_name": f"Jarvis Smart QA Generated Pack — {category}",
        "version": QA_PACK_SCHEMA_VERSION,
        "target_jarvis_version": "v4.4.4.20+",
        "generated_by": "jarvis_local_builtin_generator",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "provider": provider,
        "category": category,
        "tests": tests,
    }


@app.post("/api/qa/run")
def api_qa_run(req: QALabRunRequest) -> Dict[str, Any]:
    report = run_qa_lab_tests(req.test_pack)
    file_info = write_qa_lab_report(report)
    write_log("qa_lab_run", {"test_pack": req.test_pack, "summary": report.get("summary"), "status": report.get("status"), "report": file_info})
    return {"report": report, "file": file_info}


@app.get("/api/qa/replay")
def api_qa_replay() -> Dict[str, Any]:
    summary = replay_latest_debug_log_summary()
    write_log("qa_lab_replay", {"summary": summary.get("summary")})
    return summary


@app.get("/api/qa/packs")
def api_qa_packs() -> Dict[str, Any]:
    packs = list_qa_test_packs()
    return {"packs": packs, "providers": _qa_external_provider_status()}


@app.post("/api/qa/import")
def api_qa_import(req: QATestPackImportRequest) -> Dict[str, Any]:
    pack = _qa_pack_text_to_json(req.pack_text)
    if req.pack_name:
        pack["pack_name"] = req.pack_name
    saved = save_qa_test_pack(pack, req.pack_name)
    report = None
    file_info = None
    if req.run_after_import:
        report = run_imported_qa_test_pack(pack)
        file_info = write_qa_lab_report(report)
    write_log("qa_lab_import", {"pack": saved, "run_after_import": req.run_after_import, "summary": (report or {}).get("summary")})
    return {"status": "imported", "pack": saved, "report": report, "file": file_info}


@app.post("/api/qa/generate")
def api_qa_generate(req: QAGeneratedTestPackRequest) -> Dict[str, Any]:
    pack = generate_qa_test_pack(req)
    saved = save_qa_test_pack(pack) if req.save_pack else None
    write_log("qa_lab_generate", {"provider": req.provider, "category": req.category, "count": len(pack.get("tests") or []), "saved": saved})
    return {"status": "generated", "pack": pack, "saved": saved, "providers": _qa_external_provider_status()}


@app.post("/api/qa/run-imported")
def api_qa_run_imported(req: QAImportedRunRequest) -> Dict[str, Any]:
    pack = load_qa_test_pack(req.pack_file)
    report = run_imported_qa_test_pack(pack)
    file_info = write_qa_lab_report(report)
    write_log("qa_lab_run_imported", {"pack_file": req.pack_file, "summary": report.get("summary"), "status": report.get("status"), "report": file_info})
    return {"report": report, "file": file_info}


@app.get("/api/qa/coverage")
def api_qa_coverage() -> Dict[str, Any]:
    coverage = build_qa_coverage_map()
    file_info = write_qa_coverage_report(coverage)
    write_log("qa_lab_coverage", {"summary": coverage.get("summary"), "status": coverage.get("status"), "report": file_info})
    return {"coverage": coverage, "file": file_info}


@app.get("/api/qa/release-gate")
def api_qa_release_gate() -> Dict[str, Any]:
    gate = build_stable_release_gate()
    file_info = write_stable_release_gate_report(gate)
    write_log("qa_lab_release_gate", {"summary": gate.get("summary"), "status": gate.get("status"), "stable_candidate": gate.get("stable_candidate"), "report": file_info})
    return {"gate": gate, "file": file_info}


@app.get("/api/qa/schema")
def api_qa_schema() -> Dict[str, Any]:
    example = {
        "pack_name": "Jarvis External AI Test Pack Example",
        "version": QA_PACK_SCHEMA_VERSION,
        "target_jarvis_version": "v4.4.4.20+",
        "tests": [
            {
                "id": "EXT-ZONE-001",
                "category": "zone_conflict",
                "prompt": "Create Door Trade base sheet. Zone 1 is Internal and External. Zone 1 is also Stage 1 and Stage 2. Levels L1. Door counts only.",
                "expected_behavior": "blocked_or_clarification",
                "must_contain": ["Zone 1"],
                "must_not_contain": ["Approve & Preview"],
                "severity": "critical"
            }
        ]
    }
    return {"schema_version": QA_PACK_SCHEMA_VERSION, "example": example, "providers": _qa_external_provider_status()}


@app.post("/api/upload")
async def api_upload(file: UploadFile = File(...)) -> Dict[str, Any]:
    safe_name = Path(file.filename or "uploaded_file").name
    if not safe_name or safe_name in {".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid filename.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = INPUT_DIR / f"{stamp}_{safe_name}"
    content = await file.read()
    settings = read_json("settings.json", {})
    max_bytes = int(settings.get("max_upload_mb", 200)) * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail="File is larger than the configured upload limit.")
    target.write_bytes(content)
    write_log("file_upload", {"filename": safe_name, "saved_to": str(target), "bytes": len(content)})
    return {
        "status": "saved",
        "filename": safe_name,
        "saved_name": target.name,
        "relative_path": target.name,
        "path": str(target),
        "bytes": len(content),
    }


@app.get("/api/outputs")
def api_outputs() -> Dict[str, Any]:
    files: List[Dict[str, Any]] = []
    for path in OUTPUT_DIR.rglob("*"):
        if path.is_file():
            try:
                rel_parts = path.relative_to(OUTPUT_DIR).parts
            except ValueError:
                rel_parts = ()
            if "Archive" in rel_parts:
                continue
            rel = str(path.relative_to(OUTPUT_DIR)).replace("\\", "/")
            files.append({
                "name": path.name,
                "relative_path": rel,
                "download_url": clean_download_url(rel),
                "size_bytes": path.stat().st_size,
                "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
            })
    files.sort(key=lambda x: x["modified"], reverse=True)
    return {"outputs": files[:200]}


@app.get("/api/download/{relative_path:path}")
def api_download(relative_path: str) -> FileResponse:
    path = safe_child(OUTPUT_DIR, relative_path)
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Output file not found.")
    return FileResponse(path, filename=path.name)


@app.get("/api/debug/export")
def api_debug_export(conversation_id: str = "") -> FileResponse:
    try:
        report = build_debug_report_zip(conversation_id)
    except Exception as exc:
        write_log("debug_report_export_failed", {"error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Could not create debug report: {exc}")
    return FileResponse(str(report), filename=report.name, media_type="application/zip")

@app.get("/api/chat/export")
def api_chat_export(kind: str = "conversation", conversation_id: str = "") -> FileResponse:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    kind_clean = re.sub(r"[^a-z0-9_\-]", "_", str(kind or "conversation").lower())[:40] or "conversation"
    out_dir = OUTPUT_DIR / "AI_Exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"Jarvis_{kind_clean}_{stamp}.md"
    chat = read_recent_chat_trace(160)
    selected_conv = None
    if conversation_id:
        store = _conversation_store_read()
        selected_conv = next((c for c in store.get("conversations", []) if c.get("id") == conversation_id), None)
        if selected_conv:
            chat = _conversation_compact_messages(selected_conv.get("messages") or []) or chat
    chat = _conversation_compact_messages(chat)
    events = read_recent_events(220)
    workflow = build_workflow_health_snapshot(events, selected_conv)
    lines = [f"# Jarvis {kind_clean.replace('_', ' ').title()}", "", f"Generated: {datetime.now().isoformat(timespec='seconds')}", f"App version: {APP_VERSION}", ""]
    if selected_conv:
        lines += [f"Conversation ID: {selected_conv.get('id') or conversation_id}", f"Title: {selected_conv.get('title') or 'New chat'}", f"Project: {selected_conv.get('project') or ''}", ""]
    if kind_clean in {"project_context", "task_summary", "summary"}:
        lines += ["## Current Task / Router Summary", "", "```json", _safe_json_file_payload(workflow), "```", ""]
    lines += ["## Visible Conversation", ""]
    for row in chat[-100:]:
        att = row.get("attachments") or []
        att_txt = (" · attachments: " + ", ".join([str((a or {}).get("filename") or "file") for a in att])) if att else ""
        role = str(row.get("role") or "message").title()
        lines.append(f"### {role} · {row.get('timestamp','')}{att_txt}")
        lines.append(str(row.get("text") or "").strip() or "[no text]")
        lines.append("")
    out.write_text("\n".join(lines), encoding="utf-8")
    write_log("conversation_exported", {"file": out.name, "kind": kind_clean, "messages": len(chat)})
    rel = str(out.relative_to(OUTPUT_DIR)).replace("\\", "/")
    return FileResponse(str(out), filename=out.name, media_type="text/markdown", headers={"X-Jarvis-Download-Url": clean_download_url(rel)})


@app.get("/api/helper-prompt")
def api_helper_prompt() -> Dict[str, Any]:
    path = ROOT / "06_Prompts" / "AI_Helper_Manual_Handoff_Template.txt"
    return {"template": path.read_text(encoding="utf-8") if path.exists() else ""}





def get_local_ai_config() -> Dict[str, Any]:
    """Return Local AI/Ollama configuration without requiring Open WebUI."""
    settings = read_json("settings.json", {})
    model_profiles = read_json("model_profiles.json", {})
    configured = settings.get("local_ai", {}) if isinstance(settings, dict) else {}
    default_model = configured.get("default_model") or "qwen2.5:3b"
    if default_model not in model_profiles and model_profiles:
        # Prefer lightweight general model if present, otherwise keep the configured default.
        for candidate in ["qwen2.5:3b", "qs-boq-writer-v2:latest", "qwen2.5-coder:3b"]:
            if candidate in model_profiles:
                default_model = candidate
                break
    return {
        "ollama_url": configured.get("ollama_url") or "http://127.0.0.1:11434",
        "default_model": default_model,
        "timeout_seconds": int(configured.get("timeout_seconds", 60)),
        "privacy_mode": "local_only_no_cloud",
        "role": "reviewer_only_classifier_not_direct_file_editor",
    }


def ollama_json_request(path: str, payload: Dict[str, Any], timeout: int = 60) -> Dict[str, Any]:
    cfg = get_local_ai_config()
    base = str(cfg["ollama_url"]).rstrip("/")
    url = base + path
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as response:  # nosec - local-only Ollama URL from settings
        raw = response.read().decode("utf-8", errors="replace")
    try:
        return json.loads(raw)
    except Exception:
        return {"raw": raw}


def ollama_get_json(path: str, timeout: int = 6) -> Dict[str, Any]:
    cfg = get_local_ai_config()
    base = str(cfg["ollama_url"]).rstrip("/")
    url = base + path
    with urllib.request.urlopen(url, timeout=timeout) as response:  # nosec - local-only Ollama URL from settings
        raw = response.read().decode("utf-8", errors="replace")
    try:
        return json.loads(raw)
    except Exception:
        return {"raw": raw}


def ollama_status() -> Dict[str, Any]:
    cfg = get_local_ai_config()
    reachable = port_open("127.0.0.1", 11434)
    models: List[str] = []
    detail = "Ollama port is offline. Local AI review will use safe heuristic fallback until Ollama is running."
    if reachable:
        try:
            tags = ollama_get_json("/api/tags", timeout=5)
            models = [m.get("name", "") for m in tags.get("models", []) if isinstance(m, dict) and m.get("name")]
            detail = "Ollama API reachable. Jarvis can ask the selected local model to review workbook structure."
        except Exception as exc:
            detail = f"Ollama port is open, but /api/tags failed: {exc}"
    return {
        "status": "working" if reachable else "offline",
        "ollama_url": cfg["ollama_url"],
        "default_model": cfg["default_model"],
        "available_models": models,
        "privacy_mode": cfg["privacy_mode"],
        "role": cfg["role"],
        "detail": detail,
    }


def workbook_structure_summary(input_file: str, max_rows: int = 140) -> Dict[str, Any]:
    """Create a compact workbook structure summary for Local AI.

    The Local AI sees only sampled row text/markers/units, not the full workbook dump.
    Python still performs the actual Excel formatting.
    """
    from openpyxl import load_workbook

    source = safe_child(INPUT_DIR, input_file)
    if not source.exists() or not source.is_file():
        raise HTTPException(status_code=404, detail="Input file not found. Attach the workbook again.")
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise HTTPException(status_code=400, detail="Local AI formatter review currently supports .xlsx and .xlsm only.")
    wb = load_workbook(source, data_only=False, read_only=True, keep_vba=source.suffix.lower() == ".xlsm")
    sheets: List[Dict[str, Any]] = []
    total_rows_sampled = 0
    total_formula_like = 0
    total_heading_markers = 0
    total_unit_rows = 0
    for ws in wb.worksheets:
        rows: List[Dict[str, Any]] = []
        max_scan = min(ws.max_row or 0, max(20, max_rows))
        for idx, row in enumerate(ws.iter_rows(min_row=1, max_row=max_scan), start=1):
            values = []
            for cell in row[:8]:
                value = cell.value
                if value is None:
                    values.append("")
                else:
                    text_value = str(value).replace("\n", " ").strip()
                    if len(text_value) > 160:
                        text_value = text_value[:157] + "..."
                    values.append(text_value)
            row_type = detect_row_type(row)
            unit_marker = detect_boq_unit_marker(row)
            formula_like = any(str(v).lstrip("=").upper().startswith("XGET") for v in values if v)
            if row_type:
                total_heading_markers += 1
            if unit_marker:
                total_unit_rows += 1
            if formula_like:
                total_formula_like += 1
            # keep rows that matter plus every 20th row for layout hints
            if row_type or unit_marker or formula_like or any(values[:4]) or idx <= 12 or idx % 20 == 0:
                rows.append({
                    "row": idx,
                    "marker_detected": row_type or "",
                    "unit_marker": unit_marker or "",
                    "formula_like": formula_like,
                    "A_to_H": values,
                })
            if len(rows) >= max_rows:
                break
        total_rows_sampled += len(rows)
        sheets.append({
            "sheet": ws.title,
            "max_row": ws.max_row,
            "max_column": ws.max_column,
            "sampled_rows": rows,
        })
    try:
        wb.close()
    except Exception:
        pass
    profile = resolve_formatter_profile()
    return {
        "input_file": source.name,
        "created_at": now_iso(),
        "sample_limit_per_workbook": max_rows,
        "total_rows_sampled": total_rows_sampled,
        "heading_markers_detected": total_heading_markers,
        "unit_rows_detected": total_unit_rows,
        "costx_formula_like_rows": total_formula_like,
        "active_profile": {"profile_key": profile.get("profile_key"), "display_name": profile.get("display_name")},
        "sheets": sheets,
        "privacy_note": "Local-only summary for Ollama. Private workbook is not sent to cloud AI.",
    }


def build_local_ai_formatter_prompt(summary: Dict[str, Any], profile: Dict[str, Any], user_prompt: str = "") -> str:
    compact = json.dumps(summary, ensure_ascii=False)[:24000]
    profile_hint = json.dumps({
        "profile_key": profile.get("profile_key"),
        "display_name": profile.get("display_name"),
        "casing": profile.get("casing", {}),
        "format_rules": profile.get("format_rules", {}),
    }, ensure_ascii=False)[:9000]
    return f"""You are Dhanrick Jarvis Local AI Formatter Brain.
You are running locally through Ollama. You are a reviewer/classifier only.
Do not claim to edit the Excel file. Python/OpenPyXL will apply changes safely.

Task:
Study the workbook row samples and active formatter profile. Return practical formatting guidance for Dhanrick's QS BOQ workbook style.

User command/context:
{user_prompt or 'Review the workbook for formatter rules and row classification.'}

Active formatter profile JSON:
{profile_hint}

Workbook structure summary JSON:
{compact}

Return JSON only using this shape:
{{
  "confidence": 0-100,
  "workbook_type": "QS BOQ / CostX raw list / Builder base sheet / unknown",
  "recommended_profile": "profile key or display name",
  "row_classification_notes": ["short note"],
  "preserve_terms_to_add": ["FRL", "Acoustic Rating"],
  "proper_phrases_to_add": {{"lower phrase": "Proper Phrase"}},
  "slash_terms_to_add": {{"ext": "Ext", "dry": "Dry"}},
  "warnings": ["short warning"],
  "safe_to_run_formatter": true/false,
  "reason": "brief reason"
}}
"""


def extract_json_object(text_value: str) -> Dict[str, Any]:
    if not text_value:
        return {}
    try:
        data = json.loads(text_value)
        return data if isinstance(data, dict) else {"value": data}
    except Exception:
        pass
    match = re.search(r"\{.*\}", text_value, flags=re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else {"value": data}
        except Exception:
            pass
    return {"raw_response": text_value[:4000]}


def heuristic_local_ai_analysis(summary: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    costx = int(summary.get("costx_formula_like_rows", 0) or 0)
    headings = int(summary.get("heading_markers_detected", 0) or 0)
    units = int(summary.get("unit_rows_detected", 0) or 0)
    if costx:
        workbook_type = "CostX raw list"
        recommended = "builder_base_sheet" if costx > headings else profile.get("profile_key", "default_qs_boq")
    elif headings or units:
        workbook_type = "QS BOQ"
        recommended = profile.get("profile_key", "default_qs_boq")
    else:
        workbook_type = "unknown"
        recommended = profile.get("profile_key", "default_qs_boq")
    notes = []
    if headings:
        notes.append(f"Detected {headings} Head/Level marker rows; use hierarchy rules for Head1-Head4 and child item rows.")
    if units:
        notes.append(f"Detected {units} BOQ unit rows; italicise non-heading item rows and keep unit text exact.")
    if costx:
        notes.append(f"Detected {costx} XGET-like rows; Builder connector may be more suitable for this workbook.")
    return {
        "confidence": 72 if workbook_type != "unknown" else 45,
        "workbook_type": workbook_type,
        "recommended_profile": recommended,
        "row_classification_notes": notes or ["No strong row markers detected; run formatter conservatively and review output."],
        "preserve_terms_to_add": ["FRL", "Rw", "NCC", "BCA", "UNO", "FFL"],
        "proper_phrases_to_add": {"acoustic rating": "Acoustic Rating", "thermal rating": "Thermal Rating", "fire rated": "Fire Rated"},
        "slash_terms_to_add": {"ext": "Ext", "dry": "Dry", "wet": "Wet", "void": "Void"},
        "warnings": ["Ollama is offline or did not return valid JSON; this is a safe heuristic review only."],
        "safe_to_run_formatter": True,
        "reason": "Python formatter will create a safe output copy and leave the original workbook unchanged.",
    }


def save_local_ai_analysis(input_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    LOCAL_AI_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "_", Path(input_name).stem).strip("_") or "workbook"
    out = LOCAL_AI_EXPORT_DIR / f"{stamp}_Local_AI_Formatter_Review_{safe_stem}.json"
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    rel = str(out.relative_to(OUTPUT_DIR)).replace("\\", "/")
    return {"analysis_file": out.name, "relative_path": rel, "download_url": clean_download_url(rel), "path": str(out)}


def run_local_ai_formatter_analysis(input_file: str, profile_key: Optional[str] = None, model: Optional[str] = None, prompt: str = "", max_rows: int = 140) -> Dict[str, Any]:
    cfg = get_local_ai_config()
    profile = resolve_formatter_profile(profile_key)
    summary = workbook_structure_summary(input_file, max_rows=max_rows)
    selected_model = model or cfg["default_model"]
    ai_prompt = build_local_ai_formatter_prompt(summary, profile, prompt)
    status = ollama_status()
    source = "heuristic_fallback"
    raw_response = ""
    if status.get("status") == "working":
        try:
            response = ollama_json_request("/api/generate", {
                "model": selected_model,
                "prompt": ai_prompt,
                "stream": False,
                "options": {"temperature": 0.1, "num_ctx": 8192},
            }, timeout=int(cfg.get("timeout_seconds", 60)))
            raw_response = str(response.get("response") or response.get("raw") or "")
            analysis = extract_json_object(raw_response)
            if not analysis or "raw_response" in analysis:
                fallback = heuristic_local_ai_analysis(summary, profile)
                fallback.setdefault("warnings", []).append("Local AI response was not clean JSON, so Jarvis used heuristic fallback.")
                analysis = fallback
                source = "ollama_invalid_json_plus_heuristic"
            else:
                source = "ollama_local_ai"
        except Exception as exc:
            analysis = heuristic_local_ai_analysis(summary, profile)
            analysis.setdefault("warnings", []).append(f"Ollama review failed: {exc}")
            source = "ollama_error_plus_heuristic"
    else:
        analysis = heuristic_local_ai_analysis(summary, profile)
    payload = {
        "status": "ok",
        "source": source,
        "model": selected_model,
        "local_ai_status": status,
        "input_file": summary.get("input_file"),
        "profile_key": profile.get("profile_key"),
        "profile_name": profile.get("display_name"),
        "analysis": analysis,
        "workbook_summary": summary,
        "raw_response_preview": raw_response[:2000],
        "privacy": "Local-only review. No cloud AI call and no direct Excel editing by AI.",
        "stable_tools_modified": False,
        "created_at": now_iso(),
    }
    export = save_local_ai_analysis(str(summary.get("input_file") or input_file), payload)
    payload.update(export)
    write_log("local_ai_formatter_analysis", {k: payload.get(k) for k in ["source", "model", "input_file", "profile_key", "analysis_file", "stable_tools_modified"]})
    return payload

@app.get("/api/safety/summary")
def api_safety_summary() -> Dict[str, Any]:
    permission_rules = read_json("permission_rules.json", {})
    settings = read_json("settings.json", {})
    approvals = load_approvals().get("approvals", [])
    backups = list_safety_backups()
    return {
        "version": "v3.3 Local AI Safe Profile Apply",
        "local_ai_role": "reviewer/classifier only; Python applies Excel changes",
        "safe_mode": bool(settings.get("safe_mode", True)),
        "stable_tools_modified": False,
        "permission_levels": permission_rules.get("levels", {}),
        "approval_required": permission_rules.get("approval_required", []),
        "pending_approvals": [a for a in approvals if a.get("status") == "pending"],
        "approved_recent": [a for a in approvals if a.get("status") == "approved"][-10:],
        "backup_count": len(backups),
        "latest_backup": backups[0] if backups else None,
        "protected_files": sorted(ALLOWED_RESTORE_FILES),
        "rules": [
            "Formatter jobs may create output copies without approval.",
            "Restore, delete, core app edits, DNS/tunnel changes and cloud AI file sending require approval.",
            "Stable tools are preserved unless an explicit approved migration is performed.",
            "Local AI may suggest profile/profile dictionary changes, but applying them requires approval.",
        ],
    }


@app.get("/api/permissions")
def api_permissions() -> Dict[str, Any]:
    return read_json("permission_rules.json", {})


@app.post("/api/approvals/request")
def api_approvals_request(req: ApprovalRequestCreate) -> Dict[str, Any]:
    data = load_approvals()
    approval_id = uuid.uuid4().hex[:10]
    risk = max(0, min(5, int(req.risk_level)))
    item = {
        "approval_id": approval_id,
        "action_key": req.action_key.strip().lower(),
        "description": req.description.strip() or req.action_key,
        "risk_level": risk,
        "target": req.target.strip(),
        "status": "pending",
        "created_at": now_iso(),
        "required_confirmation": "I APPROVE" if risk >= 4 or req.action_key in read_json("permission_rules.json", {}).get("approval_required", []) else "approve",
    }
    data.setdefault("approvals", []).append(item)
    save_approvals(data)
    write_log("approval_requested", item)
    return item


@app.post("/api/approvals/decision")
def api_approvals_decision(req: ApprovalDecisionRequest) -> Dict[str, Any]:
    data = load_approvals()
    found = None
    for item in data.get("approvals", []):
        if item.get("approval_id") == req.approval_id:
            found = item
            break
    if not found:
        raise HTTPException(status_code=404, detail="Approval request not found.")
    decision = req.decision.strip().lower()
    if decision not in {"approved", "rejected"}:
        raise HTTPException(status_code=400, detail="Decision must be approved or rejected.")
    if decision == "approved" and found.get("required_confirmation") == "I APPROVE" and req.typed_confirmation.strip() != "I APPROVE":
        raise HTTPException(status_code=400, detail="Type I APPROVE to confirm this protected action.")
    found["status"] = decision
    found["decided_at"] = now_iso()
    save_approvals(data)
    write_log("approval_decision", found)
    return found


@app.get("/api/approvals")
def api_approvals() -> Dict[str, Any]:
    data = load_approvals()
    rows = sorted(data.get("approvals", []), key=lambda x: x.get("created_at", ""), reverse=True)
    return {"approvals": rows[:100]}


@app.post("/api/backups/create")
def api_backups_create(req: BackupCreateRequest) -> Dict[str, Any]:
    return create_safety_backup(req.reason, req.include_jobs, req.include_outputs, req.include_inputs)


@app.get("/api/backups")
def api_backups() -> Dict[str, Any]:
    return {"backups": list_safety_backups()}


@app.get("/api/backups/download/{backup_file:path}")
def api_backups_download(backup_file: str) -> FileResponse:
    path = safe_child(BACKUP_DIR, backup_file)
    if not path.exists() or not path.is_file() or path.suffix.lower() != ".zip":
        raise HTTPException(status_code=404, detail="Backup file not found.")
    return FileResponse(path, filename=path.name)


@app.post("/api/backups/restore-settings-file")
def api_backups_restore_settings_file(req: BackupRestoreRequest) -> Dict[str, Any]:
    return restore_settings_file_from_backup(req.backup_file, req.target_file, req.approval_id)



@app.get("/api/local-ai/status")
def api_local_ai_status() -> Dict[str, Any]:
    return ollama_status()


@app.post("/api/local-ai/analyze-formatter")
def api_local_ai_analyze_formatter(req: LocalAIAnalyzeRequest) -> Dict[str, Any]:
    try:
        return run_local_ai_formatter_analysis(req.input_file, req.profile_key, req.model, req.prompt, req.max_rows)
    except HTTPException:
        raise
    except Exception as exc:
        write_log("local_ai_formatter_analysis_error", {"input_file": req.input_file, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Local AI formatter review failed: {exc}") from exc


@app.post("/api/local-ai/profile-draft")
def api_local_ai_profile_draft(req: LocalAIProfileDraftRequest) -> Dict[str, Any]:
    """Create a draft profile suggestion from Local AI review.

    This endpoint does not apply the profile. Applying Local AI profile changes
    remains protected and requires approval, per the v2.10 safety guard.
    """
    review = run_local_ai_formatter_analysis(req.input_file, req.profile_key, req.model, req.prompt, req.max_rows)
    analysis = review.get("analysis", {}) if isinstance(review, dict) else {}
    active = resolve_formatter_profile(req.profile_key)
    casing = active.get("casing", {}) if isinstance(active, dict) else {}
    protected_upper = list(dict.fromkeys(list(casing.get("protected_upper", [])) + [str(x) for x in analysis.get("preserve_terms_to_add", []) if str(x).strip()]))
    proper_phrases = dict(casing.get("proper_phrases", {}))
    for key, value in (analysis.get("proper_phrases_to_add", {}) or {}).items():
        proper_phrases[str(key).lower()] = str(value)
    slash_words = dict(casing.get("slash_words", {}))
    for key, value in (analysis.get("slash_terms_to_add", {}) or {}).items():
        slash_words[str(key).lower()] = str(value)
    draft_profile = {
        "profile_key": "ai_learned_qs_format",
        "display_name": "AI Learned QS Format",
        "description": "Draft only. Created by Local AI Formatter Brain from workbook/sample review. Requires approval before applying.",
        "version": "v3.3-draft",
        "format_rules": active.get("format_rules", {}),
        "casing": {
            "protected_upper": protected_upper,
            "protected_exact": casing.get("protected_exact", {}),
            "proper_phrases": proper_phrases,
            "slash_words": slash_words,
        },
        "source_review": review.get("relative_path"),
        "requires_approval_to_apply": True,
    }
    payload = {"status": "draft_created", "draft_profile": draft_profile, "review": review, "stable_tools_modified": False}
    write_log("local_ai_profile_draft_created", {"input_file": req.input_file, "source_review": review.get("relative_path")})
    return payload


def safe_ai_review_path(analysis_file: str) -> Path:
    """Resolve a Local AI review JSON path safely.

    Accepts either:
    - AI_Exports/file.json
    - file.json
    - an Output Center relative path

    Never allows path traversal outside 02_Output_Files.
    """
    raw = (analysis_file or "").strip().replace("\\", "/")
    if not raw:
        raise HTTPException(status_code=400, detail="AI review file is required.")
    if raw.startswith("AI_Exports/"):
        path = safe_child(OUTPUT_DIR, raw)
    elif "/" in raw:
        path = safe_child(OUTPUT_DIR, raw)
    else:
        path = safe_child(LOCAL_AI_EXPORT_DIR, raw)
    if not path.exists() or not path.is_file() or path.suffix.lower() != ".json":
        raise HTTPException(status_code=404, detail="AI review JSON not found in Output Center / AI_Exports.")
    return path


def _unique_append(items: List[str], value: str) -> bool:
    value = (value or "").strip()
    if not value:
        return False
    existing_norm = {str(x).strip().lower() for x in items}
    if value.lower() not in existing_norm:
        items.append(value)
        return True
    return False


def normalise_ai_profile_suggestions(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """Convert Local AI suggestions into safe formatter-profile changes.

    v3.3 deliberately filters risky suggestions. Example: if a weak model suggests
    slash term ext => External, Jarvis will keep the compact BOQ style Ext instead
    of expanding Ext/Dry into External/Dry.
    """
    changes = {
        "protected_upper": [],
        "protected_exact": {},
        "proper_phrases": {},
        "slash_words": {},
        "warnings": [],
    }

    def add_phrase(value: str) -> None:
        v = str(value or "").strip()
        if not v:
            return
        # All-caps acronyms and code-like rating terms go to protected_upper.
        compact = re.sub(r"[^A-Za-z0-9]", "", v)
        has_lower = any(ch.islower() for ch in v)
        if compact and compact.upper() == compact and len(compact) <= 12:
            _unique_append(changes["protected_upper"], v)
        elif "/" in v and len(v) <= 30:
            parts = [p.strip() for p in v.split("/") if p.strip()]
            for p in parts:
                changes["slash_words"][p.lower()] = p[:1].upper() + p[1:]
            changes["protected_exact"][v.lower()] = v
        else:
            # Title/proper QS phrases like Acoustic Rating / Thermal Rating.
            changes["proper_phrases"][v.lower()] = v
            # Also keep exact case so the formatter can restore it after sentence case.
            changes["protected_exact"][v.lower()] = v

    for term in analysis.get("preserve_terms_to_add", []) or []:
        add_phrase(str(term))

    for key, value in (analysis.get("proper_phrases_to_add", {}) or {}).items():
        k = str(key or "").strip().lower()
        v = str(value or "").strip()
        if k and v:
            changes["proper_phrases"][k] = v
            changes["protected_exact"][k] = v

    # Slash words are intentionally conservative: Ext/Dry/Wet/Void style only.
    known_short = {
        "ext": "Ext",
        "external": "Ext",
        "dry": "Dry",
        "wet": "Wet",
        "void": "Void",
        "int": "Int",
        "internal": "Int",
    }
    for key, value in (analysis.get("slash_terms_to_add", {}) or {}).items():
        k_raw = str(key or "").strip().lower()
        v_raw = str(value or "").strip()
        if not k_raw:
            continue
        if k_raw in known_short:
            changes["slash_words"][k_raw] = known_short[k_raw]
            if v_raw and v_raw != known_short[k_raw] and len(v_raw) > 6:
                changes["warnings"].append(f"Slash term '{k_raw} => {v_raw}' was shortened to '{known_short[k_raw]}' to preserve BOQ style like Ext/Dry.")
        elif re.fullmatch(r"[A-Za-z]{1,6}", v_raw):
            changes["slash_words"][k_raw] = v_raw[:1].upper() + v_raw[1:]
        else:
            changes["warnings"].append(f"Skipped slash suggestion '{k_raw} => {v_raw}' because it may expand compact BOQ terms incorrectly.")

    # Deduplicate protected_upper while preserving order.
    seen = set()
    deduped = []
    for item in changes["protected_upper"]:
        norm = item.lower()
        if norm not in seen:
            deduped.append(item)
            seen.add(norm)
    changes["protected_upper"] = deduped
    return changes


def merge_ai_suggestions_into_profile(profile: Dict[str, Any], changes: Dict[str, Any]) -> Dict[str, Any]:
    updated = dict(profile)
    casing = dict(updated.get("casing", {}) or {})
    protected_upper = list(casing.get("protected_upper", []) or [])
    protected_exact = dict(casing.get("protected_exact", {}) or {})
    proper_phrases = dict(casing.get("proper_phrases", {}) or {})
    slash_words = dict(casing.get("slash_words", {}) or {})

    added = {"protected_upper": [], "protected_exact": {}, "proper_phrases": {}, "slash_words": {}}
    for item in changes.get("protected_upper", []) or []:
        if _unique_append(protected_upper, str(item)):
            added["protected_upper"].append(str(item))
    for key, value in (changes.get("protected_exact", {}) or {}).items():
        k = str(key).strip().lower()
        v = str(value).strip()
        if k and v and protected_exact.get(k) != v:
            protected_exact[k] = v
            added["protected_exact"][k] = v
    for key, value in (changes.get("proper_phrases", {}) or {}).items():
        k = str(key).strip().lower()
        v = str(value).strip()
        if k and v and proper_phrases.get(k) != v:
            proper_phrases[k] = v
            added["proper_phrases"][k] = v
    for key, value in (changes.get("slash_words", {}) or {}).items():
        k = str(key).strip().lower()
        v = str(value).strip()
        if k and v and slash_words.get(k) != v:
            slash_words[k] = v
            added["slash_words"][k] = v

    casing.update({
        "protected_upper": protected_upper,
        "protected_exact": protected_exact,
        "proper_phrases": proper_phrases,
        "slash_words": slash_words,
    })
    updated["casing"] = casing
    updated["version"] = "v3.3-ai-safely-updated"
    return updated, added


@app.post("/api/local-ai/apply-review-suggestions")
def api_local_ai_apply_review_suggestions(req: LocalAIProfileApplyRequest) -> Dict[str, Any]:
    """Apply Local AI suggestions to a formatter profile only after approval.

    Local AI still never edits Excel directly. This endpoint only updates the
    active profile dictionary/settings after a typed approval and a safety backup.
    """
    if not approval_is_valid(req.approval_id, "apply_ai_profile_suggestions"):
        raise HTTPException(status_code=403, detail="Approved request required before applying Local AI profile suggestions.")

    review_path = safe_ai_review_path(req.analysis_file)
    review = json.loads(review_path.read_text(encoding="utf-8"))
    analysis = review.get("analysis", {}) if isinstance(review, dict) else {}
    if not isinstance(analysis, dict):
        raise HTTPException(status_code=400, detail="AI review file does not contain a valid analysis object.")

    store = load_formatter_profiles()
    target_key = normalise_profile_key(req.profile_key or store.get("active_profile") or "default_qs_boq")
    if target_key not in store.get("profiles", {}):
        raise HTTPException(status_code=404, detail="Target formatter profile not found.")

    # Safety first: backup settings before modifying profile memory.
    backup = create_safety_backup("before_apply_local_ai_profile_suggestions", include_jobs=True, include_outputs=False, include_inputs=False)

    current_profile = store["profiles"][target_key]
    changes = normalise_ai_profile_suggestions(analysis)
    updated_profile, added = merge_ai_suggestions_into_profile(current_profile, changes)
    updated_profile["last_ai_suggestion_review"] = str(review_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    updated_profile["last_ai_suggestion_applied_at"] = now_iso()
    updated_profile["last_ai_suggestion_warnings"] = changes.get("warnings", [])
    store["profiles"][target_key] = updated_profile
    store["active_profile"] = target_key
    save_formatter_profiles(store)

    result = {
        "status": "applied",
        "profile_key": target_key,
        "profile_name": updated_profile.get("display_name", target_key),
        "review_file": str(review_path.relative_to(OUTPUT_DIR)).replace("\\", "/"),
        "backup_created": backup.get("backup_name"),
        "added": added,
        "warnings": changes.get("warnings", []),
        "stable_tools_modified": False,
        "excel_files_modified": False,
        "message": "Local AI suggestions were applied to the formatter profile after approval. No workbook or stable tool was modified.",
    }
    write_log("local_ai_review_suggestions_applied", result)
    return result



def clean_feedback_candidate(value: str) -> str:
    text = str(value or "").strip()
    # Stop at likely next instruction/sentence so "Do not change Ext/Dry. Row 47..."
    # becomes only "Ext/Dry".
    text = re.split(r"(?:\.\s+|;\s+|\brow\s+\d+\b|\bitems?\s+below\b|\bsince\b|\bbecause\b|\bgiven\b|\bmake\s+sure\b|\bdo\s+not\b|\bdon\'t\b)", text, maxsplit=1, flags=re.IGNORECASE)[0]
    text = re.sub(r"[\s\.;,:]+$", "", text.strip())
    text = re.sub(r"^(the|a|an)\s+", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+(and|or)$", "", text, flags=re.IGNORECASE)
    return text.strip()


def add_feedback_term(changes: Dict[str, Any], term: str, reason: str = "") -> None:
    term = clean_feedback_candidate(term)
    if not term or len(term) > 80:
        return
    lower = term.lower()
    # Avoid weak generic terms that should not become a casing rule.
    if lower in {"row", "rows", "description", "descriptions", "item", "items", "heading", "head", "format", "drawing references", "original"}:
        return
    if lower.startswith("other ") or "types of" in lower or " any " in lower or lower.endswith(" any"):
        return
    has_slash = "/" in term and any(part.strip() for part in term.split("/"))
    has_code_shape = bool(re.search(r"[A-Z]+\d|\d+[A-Za-z]|[_*/]|Rw\d|R\d", term))
    if term.isupper() and re.search(r"[A-Z]", term):
        changes.setdefault("protected_upper", [])
        if term not in changes["protected_upper"]:
            changes["protected_upper"].append(term)
    elif has_slash or has_code_shape or any(c.isupper() for c in term[1:]):
        changes.setdefault("protected_exact", {})[lower] = term
    elif " " in term:
        # User-written phrase should become a proper phrase rule using their casing.
        changes.setdefault("proper_phrases", {})[lower] = term
    else:
        changes.setdefault("protected_exact", {})[lower] = term

    if has_slash:
        for part in term.split("/"):
            part = clean_feedback_candidate(part)
            if part and len(part) <= 20:
                changes.setdefault("slash_words", {})[part.lower()] = part


def parse_feedback_to_profile_changes(feedback_text: str) -> Dict[str, Any]:
    text = str(feedback_text or "").strip()
    lower = text.lower()
    changes: Dict[str, Any] = {
        "protected_upper": [],
        "protected_exact": {},
        "proper_phrases": {},
        "slash_words": {},
        "lower_mid_phrases": [],
        "letter_based_terms": {},
        "format_rules": {},
        "row_overrides": {},
        "temporary_row_overrides": {},
        "remove_protected_exact": [],
        "remove_proper_phrases": [],
        "notes": [],
        "warnings": [],
    }

    # Quoted/backticked exact terms are always strong user-provided terms.
    # Avoid treating apostrophes inside words like "it\'s" as quote delimiters.
    for quoted in re.findall(r'"([^"\\n]+)"|`([^`\\n]+)`', text):
        add_feedback_term(changes, quoted[0] or quoted[1], "quoted")

    # Common QS correction commands.
    patterns = [
        r"\bkeep\s+([A-Za-z0-9_./*+&'’\-]+(?:\s+[A-Za-z0-9_./*+&'’\-]+){0,4})\s+(?:capitalised|capitalized|uppercase|all\s+caps|unchanged|as\s+is)",
        r"\bpreserve\s+([A-Za-z0-9_./*+&'’\-]+(?:\s+[A-Za-z0-9_./*+&'’\-]+){0,4})",
        r"\bdo\s+not\s+change\s+([A-Za-z0-9_./*+&'’\-]+(?:\s+[A-Za-z0-9_./*+&'’\-]+){0,4})",
        r"\bdon't\s+change\s+([A-Za-z0-9_./*+&'’\-]+(?:\s+[A-Za-z0-9_./*+&'’\-]+){0,4})",
        r"\b([A-Za-z](?:-[A-Za-z])?(?:-[A-Za-z]+)?(?:\s+[A-Za-z]+){0,2})\s+should\s+be\s+(?:capital|capitalised|capitalized|uppercase|all\s+caps)",
        r"\bsame\s+with\s+([A-Za-z0-9_./*+&'’\-]+(?:\s+[A-Za-z0-9_./*+&'’\-]+){0,4})",
    ]
    for pattern in patterns:
        for candidate in re.findall(pattern, text, flags=re.IGNORECASE):
            candidate_s = str(candidate).strip()
            if candidate_s.lower().startswith("row ") or candidate_s.lower() in {"row", "rows"}:
                continue
            add_feedback_term(changes, candidate_s, "instruction")


    # v3.10 generic ALL-CAPS learner.
    # This handles new terms without hard-coding, e.g.
    # "MRI should be always capital all" -> protected_upper: MRI.
    all_caps_patterns = [
        r"\b([A-Za-z][A-Za-z0-9_./&+\-]{1,30})\s+(?:should\s+be|must\s+be|needs?\s+to\s+be|to\s+be|is)\s+(?:always\s+)?(?:all\s*caps|upper\s*case|uppercase|capital\s+all|capitalized\s+all|capitalised\s+all)\b",
        r"\b(?:keep|preserve|make)\s+([A-Za-z][A-Za-z0-9_./&+\-]{1,30})\s+(?:as\s+)?(?:always\s+)?(?:all\s*caps|upper\s*case|uppercase|capital\s+all|capitalized\s+all|capitalised\s+all)\b",
    ]
    weak_upper_terms = {"row", "rows", "head", "heads", "item", "items", "description", "descriptions", "sentence", "header", "headers", "paragraph", "code", "codes", "format", "filters", "panes"}
    for pattern in all_caps_patterns:
        for candidate in re.findall(pattern, text, flags=re.IGNORECASE):
            term = clean_feedback_candidate(str(candidate).strip())
            if not term or term.lower() in weak_upper_terms or len(term) > 30:
                continue
            # For explicit all-caps instructions, preserve the literal term as uppercase.
            # This is intentionally generic so future acronyms like MRI, ESD, HVAC, FFE, etc.
            # can be learned from user feedback without editing code.
            term_up = re.sub(r"\s+", "", term).upper() if " " not in term else term.upper()
            if term_up not in changes.setdefault("protected_upper", []):
                changes["protected_upper"].append(term_up)
            changes["notes"].append(f"Keep {term_up} in ALL CAPS as requested.")



    # v3.11 adaptive exact-casing learner.
    # Handles natural feedback such as:
    #   "Dhanrick will be capital in first letter and capital in last"
    # => protected_exact: dhanrick => DhanricK
    # This is intentionally generic. It learns the term from the sentence instead
    # of hard-coding a specific word/name.
    first_last_patterns = [
        r"\b([A-Za-z][A-Za-z'’\-]{1,40})\s+(?:will\s+be|should\s+be|must\s+be|needs?\s+to\s+be|to\s+be|is)\s+(?:capitali[sz]ed\s+)?(?:with\s+)?(?:capital\s+)?(?:in\s+)?(?:the\s+)?first\s+(?:letter\s+)?(?:and|&)\s+(?:capital\s+)?(?:in\s+)?(?:the\s+)?last\b",
        r"\b([A-Za-z][A-Za-z'’\-]{1,40})\s+(?:will\s+be|should\s+be|must\s+be|needs?\s+to\s+be|to\s+be|is)\s+(?:first\s+(?:letter\s+)?(?:and|&)\s+last\s+(?:letter\s+)?)\s+capital\b",
        r"\b(?:make|keep|format|set)\s+([A-Za-z][A-Za-z'’\-]{1,40})\s+(?:with\s+)?(?:the\s+)?first\s+(?:letter\s+)?(?:and|&)\s+(?:the\s+)?last\s+(?:letter\s+)?(?:capital|uppercase|upper-case)\b",
    ]
    weak_first_last_terms = {"row", "head", "item", "items", "description", "format", "sentence", "paragraph", "letter", "letters", "word", "words"}
    for pattern in first_last_patterns:
        for candidate in re.findall(pattern, text, flags=re.IGNORECASE):
            raw_term = clean_feedback_candidate(str(candidate).strip())
            if not raw_term or raw_term.lower() in weak_first_last_terms:
                continue
            letters_only = re.sub(r"[^A-Za-z'’\-]", "", raw_term)
            if len(letters_only) < 2:
                continue
            # Case each hyphen/apostrophe segment independently but preserve separators.
            def _first_last_segment(seg: str) -> str:
                if len(seg) <= 1:
                    return seg.upper()
                return seg[0].upper() + seg[1:-1].lower() + seg[-1].upper()
            parts = re.split(r"([\-'’])", raw_term)
            exact = "".join(_first_last_segment(part) if re.search(r"[A-Za-z]", part) else part for part in parts)
            key = raw_term.lower()
            changes.setdefault("protected_exact", {})[key] = exact
            changes["notes"].append(f"Learned custom first-and-last-letter capitalisation: {raw_term} => {exact}.")

    # Contextual lowercase instructions such as:
    # - keep non combustible lower if not first of paragraph
    # - fire rated should be lower-case when it is a descriptive phrase, not a rating/heading
    if re.search(r"non[ -]combustible", lower) and re.search(r"\b(lower|lowercase|lower-case|not\s+first)\b", lower):
        for phrase in ["non combustible", "non-combustible"]:
            if phrase not in changes.setdefault("lower_mid_phrases", []):
                changes["lower_mid_phrases"].append(phrase)
            if phrase not in changes.setdefault("remove_protected_exact", []):
                changes["remove_protected_exact"].append(phrase)
            if phrase not in changes.setdefault("remove_proper_phrases", []):
                changes["remove_proper_phrases"].append(phrase)
            changes.get("protected_exact", {}).pop(phrase, None)
            changes.get("proper_phrases", {}).pop(phrase, None)
        changes["notes"].append("Keep non combustible lowercase unless it starts the paragraph/clause.")

    if re.search(r"fire[ -]rated", lower) and (
        re.search(r"\b(description|descriptive|not\s+(?:being\s+)?(?:use|used)\s+as\s+rating|not\s+(?:a\s+)?rating|lower|lowercase|lower-case)\b", lower)
        or "sense of description" in lower
    ):
        for phrase in ["fire rated", "fire-rated"]:
            if phrase not in changes.setdefault("lower_mid_phrases", []):
                changes["lower_mid_phrases"].append(phrase)
            if phrase not in changes.setdefault("remove_protected_exact", []):
                changes["remove_protected_exact"].append(phrase)
            if phrase not in changes.setdefault("remove_proper_phrases", []):
                changes["remove_proper_phrases"].append(phrase)
            changes.get("protected_exact", {}).pop(phrase, None)
            changes.get("proper_phrases", {}).pop(phrase, None)
        changes["notes"].append("Keep fire rated lowercase inside descriptions when it is a descriptive material/property phrase; headings and rating labels may still be title case.")

    # Contextual rule for external/internal: capitalise only at start/header/code,
    # but keep lower-case mid item descriptions such as internal angles/external face.
    if re.search(r"\bexternal\b|\binternal\b", lower) and re.search(r"(start\s+of\s+sentence|header|code|only\s+when|capitali[sz]ed\s+only|capital\s+only)", lower):
        for phrase in ["external", "internal"]:
            if phrase in lower:
                if phrase not in changes.setdefault("lower_mid_phrases", []):
                    changes["lower_mid_phrases"].append(phrase)
                # Remove longer title-case proper phrases that would fight the contextual rule.
                for conflict in [phrase, f"{phrase} wall", f"{phrase} walls", f"{phrase} face", f"{phrase} faces", f"{phrase} angle", f"{phrase} angles"]:
                    if conflict not in changes.setdefault("remove_proper_phrases", []):
                        changes["remove_proper_phrases"].append(conflict)
                    if conflict not in changes.setdefault("remove_protected_exact", []):
                        changes["remove_protected_exact"].append(conflict)
                changes.get("protected_exact", {}).pop(phrase, None)
                changes.get("proper_phrases", {}).pop(phrase, None)
        changes["notes"].append("External/Internal are contextual: headings and sentence starts can be capitalised; mid-description wording stays lower-case.")

    # General letter-based construction terms such as E-stud, C-H Studs, Z-purlins.
    if re.search(r"letter\s*-?\s*base|letter\s*-?\s*based|e-stud|c-h\s+stud", lower, flags=re.IGNORECASE):
        for key, val in {"stud": "stud", "studs": "studs", "track": "track", "tracks": "tracks", "channel": "channel", "channels": "channels", "section": "section", "sections": "sections", "purlin": "purlin", "purlins": "purlins", "batten": "batten", "battens": "battens"}.items():
            changes.setdefault("letter_based_terms", {})[key] = val
        for term in ["E-stud", "E-studs", "C-H Stud", "C-H Studs"]:
            add_feedback_term(changes, term, "letter_based_term")
        changes["format_rules"].setdefault("item_rows", {})["preserve_letter_based_terms"] = True
        changes["notes"].append("Preserve letter-based stud/profile terms such as E-stud and C-H Studs.")

    # Row-level corrections such as: Row 47 should be Head4.
    # IMPORTANT: row numbers are client/workbook-specific, so they are treated
    # as temporary current-workbook overrides only. They are not saved globally
    # to the formatter profile because BOQ row positions differ by client.
    for row_no, row_type in re.findall(r"\brow\s+(\d+)\s+(?:should\s+be|is|as)\s+(head\s*[1-4]|head[1-4]|level|item|note)", lower, flags=re.IGNORECASE):
        normal = row_type.replace(" ", "").lower()
        changes.setdefault("temporary_row_overrides", {})[str(int(row_no))] = normal
        changes["notes"].append(f"Row {int(row_no)} marked as {normal} for this workbook/job only; it will not become a global profile rule.")

    # Formatting rule corrections.
    if "italic" in lower and ("below" in lower or "under" in lower or "item" in lower):
        changes["format_rules"].setdefault("item_rows", {})["italic"] = True
        changes["format_rules"].setdefault("item_rows", {})["below_any_heading"] = True
        changes["notes"].append("Keep non-heading rows below heading hierarchy italic.")
    if "sentence case" in lower and ("item" in lower or "description" in lower):
        changes["format_rules"].setdefault("item_rows", {})["case"] = "smart_qs_sentence"
        changes["notes"].append("Use smart QS sentence case for item descriptions.")
    if "no freeze" in lower or "do not freeze" in lower or "don't freeze" in lower or "remove freeze" in lower:
        changes["format_rules"]["freeze_panes"] = "clear"
        changes["notes"].append("Clear freeze panes.")
    if "no filter" in lower or "do not add filter" in lower or "don't add filter" in lower or "remove filter" in lower or "autofilter" in lower:
        changes["format_rules"]["autofilter"] = "clear"
        changes["notes"].append("Clear worksheet filters/autofilter.")

    # Domain terms that often appear unquoted; preserve clear QS tokens mentioned in feedback.
    candidates = re.findall(r"\b(?:FRL|NCC|BCA|AS|NZS|BOQ|RFI|NB|UNO|FFL|Rw\d*|R\d+(?:\.\d+)?m2\.K/W|[A-Z][A-Za-z]*\/[A-Z][A-Za-z]*|[A-Z][A-Za-z0-9]*_[A-Za-z0-9*]+)\b", text)
    for candidate in candidates:
        add_feedback_term(changes, candidate, "detected_qs_token")

    # v3.7 conflict resolver: contextual lowercase instructions must win over any
    # earlier/proper/exact casing suggestions captured from words such as
    # "Keep Fire Rated capitalised". This makes the preview honest: if the user
    # later says fire rated is lower-case in description context, do NOT show
    # fire rated => Fire Rated as an active exact rule.
    def _force_contextual_lower(phrases: List[str], note: str) -> None:
        for phrase in phrases:
            phrase_l = str(phrase).strip().lower()
            if not phrase_l:
                continue
            if phrase_l not in changes.setdefault("lower_mid_phrases", []):
                changes["lower_mid_phrases"].append(phrase_l)
            for key in [phrase_l, phrase_l.replace("-", " "), phrase_l.replace(" ", "-")]:
                if key and key not in changes.setdefault("remove_protected_exact", []):
                    changes["remove_protected_exact"].append(key)
                if key and key not in changes.setdefault("remove_proper_phrases", []):
                    changes["remove_proper_phrases"].append(key)
                if isinstance(changes.get("protected_exact"), dict):
                    changes["protected_exact"].pop(key, None)
                if isinstance(changes.get("proper_phrases"), dict):
                    changes["proper_phrases"].pop(key, None)
        if note and note not in changes.setdefault("notes", []):
            changes["notes"].append(note)

    if re.search(r"fire[ -]rated", lower) and re.search(r"(lower\s*-?\s*case|lowercase|description|descriptive|not\s+(?:being\s+)?(?:use|used)\s+as\s+(?:a\s+)?rating|not\s+(?:a\s+)?rating|sense\s+of\s+description)", lower):
        _force_contextual_lower(["fire rated", "fire-rated"], "Context rule: use fire rated lower-case in item/description context, while headings/rating labels may remain title case.")

    if re.search(r"non[ -]combustible", lower) and re.search(r"(lower|lowercase|lower-case|not\s+(?:in\s+)?first|not\s+first)", lower):
        _force_contextual_lower(["non combustible", "non-combustible"], "Context rule: use non combustible lower-case mid-description, but sentence case at the start of a paragraph/clause.")

    # Normalize duplicate lists after conflict cleanup.
    for list_key in ["lower_mid_phrases", "remove_protected_exact", "remove_proper_phrases", "protected_upper"]:
        if isinstance(changes.get(list_key), list):
            seen = set()
            deduped = []
            for item in changes[list_key]:
                item_s = str(item).strip()
                marker = item_s.lower()
                if item_s and marker not in seen:
                    seen.add(marker)
                    deduped.append(item_s)
            changes[list_key] = deduped

    # Drop empty containers for cleaner previews.
    for key in ["protected_upper", "protected_exact", "proper_phrases", "slash_words", "lower_mid_phrases", "letter_based_terms", "format_rules", "row_overrides", "temporary_row_overrides", "remove_protected_exact", "remove_proper_phrases"]:
        if not changes.get(key):
            changes[key] = [] if key in {"protected_upper", "lower_mid_phrases", "remove_protected_exact", "remove_proper_phrases"} else {}
    if not any(changes.get(k) for k in ["protected_upper", "protected_exact", "proper_phrases", "slash_words", "lower_mid_phrases", "letter_based_terms", "format_rules", "row_overrides", "temporary_row_overrides", "remove_protected_exact", "remove_proper_phrases"]):
        changes["warnings"].append("Jarvis could not find a strong reusable profile rule in this feedback. Try using phrases like: Keep FRL capitalised, Row 47 should be Head4, or Do not add filters.")
    return changes


def deep_merge_rules(base: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
    for key, value in (updates or {}).items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_merge_rules(base[key], value)
        else:
            base[key] = value
    return base


def merge_feedback_changes_into_profile(profile: Dict[str, Any], changes: Dict[str, Any]) -> Dict[str, Any]:
    casing = profile.setdefault("casing", {})
    # Contextual lowercase rules must override older exact/proper entries.
    for key in changes.get("remove_protected_exact", []) or []:
        casing.setdefault("protected_exact", {}).pop(str(key).lower(), None)
    for key in changes.get("remove_proper_phrases", []) or []:
        casing.setdefault("proper_phrases", {}).pop(str(key).lower(), None)
    upper = casing.setdefault("protected_upper", [])
    for term in changes.get("protected_upper", []) or []:
        if term not in upper:
            upper.append(term)
    for bucket in ["protected_exact", "proper_phrases", "slash_words", "letter_based_terms"]:
        target = casing.setdefault(bucket, {})
        for key, value in (changes.get(bucket, {}) or {}).items():
            target[str(key).lower()] = value
    lower_mid = casing.setdefault("lower_mid_phrases", [])
    for phrase in changes.get("lower_mid_phrases", []) or []:
        phrase_s = str(phrase).strip().lower()
        if phrase_s and phrase_s not in lower_mid:
            lower_mid.append(phrase_s)
    if changes.get("format_rules"):
        profile["format_rules"] = deep_merge_rules(profile.get("format_rules", {}) if isinstance(profile.get("format_rules"), dict) else {}, changes.get("format_rules", {}))
    if changes.get("row_overrides"):
        overrides = profile.setdefault("row_overrides", {})
        overrides.update({str(k): v for k, v in changes.get("row_overrides", {}).items()})
    history = profile.setdefault("feedback_history", [])
    history.append({
        "created_at": now_iso(),
        "changes": changes,
    })
    profile["version"] = "v3.13-qs-term-library-clarify-unknown-feedback"
    return profile


def list_generated_output_files(include_archive: bool = False) -> List[Path]:
    files: List[Path] = []
    if not OUTPUT_DIR.exists():
        return files
    for path in OUTPUT_DIR.rglob("*"):
        if not path.is_file():
            continue
        try:
            rel_parts = path.relative_to(OUTPUT_DIR).parts
        except ValueError:
            rel_parts = ()
        if not include_archive and "Archive" in rel_parts:
            continue
        files.append(path)
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files


def archive_paths(paths: List[Path], archive_label: str) -> Dict[str, Any]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_root = OUTPUT_DIR / "Archive" / archive_label / stamp
    moved: List[Dict[str, str]] = []
    for path in paths:
        if not path.exists() or not path.is_file():
            continue
        rel = path.relative_to(OUTPUT_DIR)
        if "Archive" in rel.parts:
            continue
        target = archive_root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(path), str(target))
        moved.append({"from": str(rel).replace("\\", "/"), "to": str(target.relative_to(OUTPUT_DIR)).replace("\\", "/")})
    return {"archive_folder": str(archive_root.relative_to(OUTPUT_DIR)).replace("\\", "/"), "moved": moved, "moved_count": len(moved)}


def cleanup_outputs(cleanup_type: str, keep_latest: int = 3) -> Dict[str, Any]:
    keep_latest = max(0, min(int(keep_latest or 0), 50))
    cleanup_type = (cleanup_type or "archive_old_outputs").strip().lower()
    if cleanup_type == "clear_ai_reviews":
        files = sorted([p for p in (OUTPUT_DIR / "AI_Exports").glob("*.json") if p.is_file()], key=lambda p: p.stat().st_mtime, reverse=True)
        result = archive_paths(files[keep_latest:], "AI_Reviews")
    elif cleanup_type == "clear_completed_jobs":
        archive_root = JOBS_DIR / "Archive" / datetime.now().strftime("%Y%m%d_%H%M%S")
        job_files = sorted([p for p in JOBS_DIR.glob("*.json") if p.is_file()], key=lambda p: p.stat().st_mtime, reverse=True)
        moved = []
        for path in job_files[keep_latest:]:
            target = archive_root / path.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), str(target))
            moved.append({"from": path.name, "to": str(target.relative_to(JOBS_DIR)).replace("\\", "/")})
        result = {"archive_folder": str(archive_root.relative_to(JOBS_DIR)).replace("\\", "/"), "moved": moved, "moved_count": len(moved)}
    elif cleanup_type == "archive_old_outputs":
        files = list_generated_output_files(include_archive=False)
        result = archive_paths(files[keep_latest:], "Generated_Outputs")
    else:
        raise HTTPException(status_code=400, detail="Unknown cleanup type.")
    write_log("output_cleanup", {"cleanup_type": cleanup_type, "keep_latest": keep_latest, **result})
    return {"status": "ok", "cleanup_type": cleanup_type, "keep_latest": keep_latest, **result}


def detect_unknown_qs_terms(text_value: str) -> Dict[str, Any]:
    library = load_qs_term_library()
    known_upper = {str(x).upper() for x in library.get("all_caps_terms", [])}
    known_exact = {str(k).lower() for k in (library.get("exact_terms", {}) or {}).keys()}
    known_exact.update(str(v).lower() for v in (library.get("exact_terms", {}) or {}).values())
    known_phrases = {str(k).lower() for k in (library.get("proper_phrases", {}) or {}).keys()}
    known_lower = {str(x).lower() for x in library.get("contextual_lowercase_phrases", [])}
    known_units = {str(x).lower() for x in library.get("units", [])}
    ignored = {str(x).lower() for x in library.get("ignored_terms", [])}
    stop_words = set(library.get("heading_connector_words", [])) | {
        "keep", "should", "capitalised", "capitalized", "always", "capital", "all", "same", "with", "since", "type", "types", "given", "make", "sure", "used", "use", "description", "rating", "sentence", "header", "code", "lower", "case", "first", "paragraph", "item", "items", "head", "heads", "freeze", "panes", "filters"
    }
    text_s = str(text_value or "")
    candidates: List[str] = []
    # Acronyms and mixed technical terms.
    for m in re.finditer(r"\b[A-Z][A-Z0-9/&+.-]{1,12}\b", text_s):
        candidates.append(m.group(0))
    for m in re.finditer(r"\b[A-Za-z]+(?:-[A-Za-z]+){1,3}(?:\s+[A-Za-z]+s?)?\b", text_s):
        candidates.append(m.group(0))
    for m in re.finditer(r"\b[A-Z][a-z]+[A-Z][A-Za-z0-9]*\b", text_s):
        candidates.append(m.group(0))
    uncertain = []
    seen = set()
    for raw in candidates:
        term = clean_feedback_candidate(raw)
        key = term.lower()
        if not term or key in seen or key in ignored:
            continue
        seen.add(key)
        if key in stop_words or key in known_exact or key in known_phrases or key in known_lower or key in known_units or term.upper() in known_upper:
            continue
        # Skip ordinary single title-case words unless they look technical/mixed/acronym-ish.
        if re.fullmatch(r"[A-Z][a-z]+", term) and len(term) < 8:
            continue
        options = [
            {"action": "all_caps", "label": term.upper()},
            {"action": "exact", "label": term},
            {"action": "proper", "label": term[:1].upper() + term[1:].lower()},
            {"action": "lower_mid", "label": term.lower()},
            {"action": "ignore", "label": "Ignore / keep automatic"},
        ]
        uncertain.append({"term": term, "reason": "Jarvis does not have a confident QS-library casing rule for this term.", "options": options})
    # Store pending review locally so the user can resolve later.
    if uncertain:
        pending = library.setdefault("unknown_pending_review", [])
        existing = {str(x.get("term", "")).lower() for x in pending if isinstance(x, dict)}
        for item in uncertain:
            if item["term"].lower() not in existing:
                pending.append({"term": item["term"], "first_seen_at": datetime.now().isoformat(timespec="seconds"), "source": "feedback_scan", "status": "pending"})
        save_qs_term_library(library)
    return {"uncertain_terms": uncertain, "summary": qs_library_summary(library)}


@app.get("/api/term-library")
def api_term_library() -> Dict[str, Any]:
    library = load_qs_term_library()
    return {"status": "ok", "library": library, "summary": qs_library_summary(library), "stable_tools_modified": False}


@app.post("/api/term-library/scan-feedback")
def api_term_library_scan_feedback(req: TermLibraryScanRequest) -> Dict[str, Any]:
    result = detect_unknown_qs_terms(req.text)
    return {"status": "ok", **result, "stable_tools_modified": False}


@app.post("/api/term-library/clarify")
def api_term_library_clarify(req: TermLibraryClarifyRequest) -> Dict[str, Any]:
    if (req.typed_confirmation or "").strip() != "I APPROVE":
        raise HTTPException(status_code=403, detail="Typed confirmation I APPROVE is required before saving to the QS term library.")
    term = clean_feedback_candidate(req.term)
    if not term:
        raise HTTPException(status_code=400, detail="No term provided.")
    action = (req.action or "exact").strip().lower()
    value = (req.value or term).strip()
    backup = create_safety_backup("before_qs_term_library_update", include_jobs=True, include_outputs=False, include_inputs=False)
    library = load_qs_term_library()
    if action in {"all_caps", "upper", "uppercase"}:
        entry = value.upper()
        library["all_caps_terms"] = _unique_list(list(library.get("all_caps_terms", [])) + [entry])
        saved_as = {"all_caps_terms": entry}
    elif action in {"exact", "keep_exact"}:
        library.setdefault("exact_terms", {})[term.lower()] = value
        saved_as = {"exact_terms": {term.lower(): value}}
    elif action in {"proper", "phrase", "proper_phrase"}:
        library.setdefault("proper_phrases", {})[term.lower()] = value
        saved_as = {"proper_phrases": {term.lower(): value}}
    elif action in {"lower_mid", "contextual_lower", "lowercase"}:
        library["contextual_lowercase_phrases"] = _unique_list(list(library.get("contextual_lowercase_phrases", [])) + [term.lower()])
        # Remove conflicting exact/proper rules.
        library.setdefault("exact_terms", {}).pop(term.lower(), None)
        library.setdefault("proper_phrases", {}).pop(term.lower(), None)
        saved_as = {"contextual_lowercase_phrases": term.lower()}
    elif action in {"heading_connector", "connector"}:
        library["heading_connector_words"] = _unique_list(list(library.get("heading_connector_words", [])) + [term.lower()])
        saved_as = {"heading_connector_words": term.lower()}
    elif action in {"unit", "units"}:
        library["units"] = _unique_list(list(library.get("units", [])) + [value or term])
        saved_as = {"units": value or term}
    elif action == "ignore":
        library["ignored_terms"] = _unique_list(list(library.get("ignored_terms", [])) + [term])
        saved_as = {"ignored_terms": term}
    else:
        raise HTTPException(status_code=400, detail="Unknown library action.")
    # Mark pending item resolved.
    pending = []
    for item in library.get("unknown_pending_review", []) or []:
        if isinstance(item, dict) and str(item.get("term", "")).lower() == term.lower():
            item = dict(item)
            item.update({"status": "resolved", "resolved_at": datetime.now().isoformat(timespec="seconds"), "action": action, "value": value})
        pending.append(item)
    library["unknown_pending_review"] = pending
    library = save_qs_term_library(library)
    write_log("qs_term_library_clarified", {"term": term, "action": action, "value": value, "backup": backup.get("backup_name")})
    return {"status": "ok", "term": term, "action": action, "value": value, "saved_as": saved_as, "backup_created": backup.get("backup_name"), "summary": qs_library_summary(library), "stable_tools_modified": False}



def default_mistake_memory() -> Dict[str, Any]:
    return {
        "version": "v3.18-mistake-memory",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "entries": [],
        "active_rules": [],
    }


def load_mistake_memory() -> Dict[str, Any]:
    if not MISTAKE_MEMORY_FILE.exists():
        return default_mistake_memory()
    try:
        data = json.loads(MISTAKE_MEMORY_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return default_mistake_memory()
        data.setdefault("entries", [])
        data.setdefault("active_rules", [])
        data.setdefault("version", "v3.18-mistake-memory")
        return data
    except Exception:
        return default_mistake_memory()


def save_mistake_memory(data: Dict[str, Any]) -> Dict[str, Any]:
    data["updated_at"] = now_iso()
    data.setdefault("version", "v3.18-mistake-memory")
    MISTAKE_MEMORY_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    return data


def latest_output_file_name() -> str:
    files = list_generated_output_files(include_archive=False)
    return files[0].name if files else ""


def categorize_correction_text(text: str) -> List[str]:
    t = str(text or "").lower()
    categories: List[str] = []
    checks = [
        ("row_role_mapping", ["note", "item", "below head", "head#", "heading", "row"]),
        ("sample_layout_mapping", ["sample", "same with format", "same as format", "column", "move", "mapped", "remap"]),
        ("style_signature", ["bold", "italic", "font", "font size", "center", "left", "wrap", "border", "fill", "colour", "color", "alignment"]),
        ("formula_value_safety", ["formula", "xget", "quantity", "value", "costx", "manual value", "deleted"]),
        ("casing_terms", ["capital", "lower", "uppercase", "case", "frl", "rated", "external", "internal"]),
        ("output_cleanup", ["duplicate", "blank", "missing", "extra", "wrong output"]),
    ]
    for name, words in checks:
        if any(w in t for w in words):
            categories.append(name)
    return categories or ["general_feedback"]


def build_correction_preview(feedback_text: str, profile_key: Optional[str] = None, output_file: Optional[str] = None, raw_file: Optional[str] = None, sample_file: Optional[str] = None) -> Dict[str, Any]:
    profile = resolve_formatter_profile(profile_key)
    changes = parse_feedback_to_profile_changes(feedback_text)
    categories = categorize_correction_text(feedback_text)
    t = str(feedback_text or "").lower()

    proposed_rules: List[Dict[str, Any]] = []
    if "row_role_mapping" in categories:
        proposed_rules.append({
            "rule_key": "only_head_markers_are_headings",
            "description": "Only Head1/Head2/Head3/Head4 are heading rows. Note, Item, units, levels, and blank-marker rows under a heading are content/item rows.",
            "scope": "active formatter profile",
        })
    if "sample_layout_mapping" in categories:
        proposed_rules.append({
            "rule_key": "follow_sample_role_targets",
            "description": "For sample-based jobs, map output by row role using the approved sample target columns, not fixed B/C/D assumptions.",
            "scope": "active formatter profile",
        })
    if "style_signature" in categories:
        proposed_rules.append({
            "rule_key": "follow_sample_style_signature",
            "description": "Use sample style signatures for font, bold, italic, alignment, wrap text, borders, fills and row-role fallback styles where available.",
            "scope": "active formatter profile",
        })
    if "formula_value_safety" in categories:
        proposed_rules.append({
            "rule_key": "formula_value_columns_are_protected",
            "description": "Formula/value columns preserve formulas, manual quantities and numeric values. They must never be overwritten or deleted during remap.",
            "scope": "global safety rule",
        })
    if any(w in t for w in ["blank", "missing", "not copied", "not showing"]):
        proposed_rules.append({
            "rule_key": "never_blank_content_if_source_has_description",
            "description": "If the source row has description text and is not a Head row, the output content target must not be blank.",
            "scope": "active formatter profile",
        })

    regression_checks = [
        "Run formatter self-test after saving correction memory.",
        "Check formula/value preservation.",
        "Check Note/Item/content rows are not blank.",
        "Check sample layout and style signature were not broken.",
    ]
    if output_file:
        regression_checks.append(f"Review output file: {output_file}")
    if sample_file:
        regression_checks.append(f"Compare against sample file: {sample_file}")

    return {
        "status": "preview",
        "version": "v3.18",
        "created_at": now_iso(),
        "profile_key": profile.get("profile_key"),
        "profile_name": profile.get("display_name", profile.get("profile_key")),
        "feedback_text": feedback_text,
        "categories": categories,
        "profile_changes": changes,
        "proposed_mistake_memory_rules": proposed_rules,
        "regression_checks": regression_checks,
        "context": {
            "output_file": output_file or latest_output_file_name(),
            "raw_file": raw_file or "",
            "sample_file": sample_file or "",
        },
        "approval_required": True,
        "message": "Preview only. No profile or mistake memory is changed until typed approval is provided.",
    }


def append_mistake_memory(preview: Dict[str, Any], backup_name: str = "") -> Dict[str, Any]:
    memory = load_mistake_memory()
    entry = {
        "id": f"mm_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "created_at": now_iso(),
        "profile_key": preview.get("profile_key"),
        "profile_name": preview.get("profile_name"),
        "feedback_text": preview.get("feedback_text"),
        "categories": preview.get("categories", []),
        "rules": preview.get("proposed_mistake_memory_rules", []),
        "profile_changes": preview.get("profile_changes", {}),
        "context": preview.get("context", {}),
        "backup_created": backup_name,
        "approved": True,
    }
    memory.setdefault("entries", []).append(entry)
    for rule in entry["rules"]:
        key = rule.get("rule_key")
        if key and key not in [r.get("rule_key") for r in memory.setdefault("active_rules", [])]:
            memory["active_rules"].append({**rule, "learned_at": entry["created_at"], "source_entry": entry["id"]})
    save_mistake_memory(memory)
    return entry


@app.get("/api/mistake-memory")
def api_mistake_memory() -> Dict[str, Any]:
    data = load_mistake_memory()
    return {
        "status": "ok",
        "version": data.get("version", "v3.18-mistake-memory"),
        "entries_count": len(data.get("entries", [])),
        "active_rules_count": len(data.get("active_rules", [])),
        "latest_entries": list(reversed(data.get("entries", [])))[0:10],
        "active_rules": data.get("active_rules", []),
        "file": str(MISTAKE_MEMORY_FILE),
    }


@app.post("/api/correction/preview")
def api_correction_preview(req: CorrectionPreviewRequest) -> Dict[str, Any]:
    if not req.feedback_text.strip():
        raise HTTPException(status_code=400, detail="Correction feedback is required.")
    return build_correction_preview(req.feedback_text, req.profile_key, req.output_file, req.raw_file, req.sample_file)


@app.post("/api/correction/apply")
def api_correction_apply(req: CorrectionApplyRequest) -> Dict[str, Any]:
    if req.typed_confirmation.strip() != "I APPROVE":
        raise HTTPException(status_code=403, detail="Typed approval I APPROVE is required before saving correction memory.")
    preview = build_correction_preview(req.feedback_text, req.profile_key, req.output_file, req.raw_file, req.sample_file)
    backup = create_safety_backup("before_correction_loop_mistake_memory", include_jobs=True, include_outputs=False, include_inputs=False)
    # Merge reusable feedback rules into the active profile if any were detected.
    store = load_formatter_profiles()
    key = normalise_profile_key(req.profile_key or store.get("active_profile") or "default_qs_boq")
    if key not in store.get("profiles", {}):
        raise HTTPException(status_code=404, detail="Formatter profile not found.")
    profile = store["profiles"][key]
    changes = preview.get("profile_changes", {})
    if changes and not changes.get("warnings"):
        merge_feedback_changes_into_profile(profile, changes)
    else:
        # Even if wording is not convertible into casing terms, keep the strategic mistake rules.
        profile.setdefault("format_rules", {}).setdefault("mistake_memory_enabled", True)
    profile.setdefault("correction_loop", {})["last_correction_at"] = now_iso()
    profile.setdefault("correction_loop", {})["last_categories"] = preview.get("categories", [])
    store["profiles"][key] = profile
    save_formatter_profiles(store)
    entry = append_mistake_memory(preview, backup.get("backup_name", ""))

    rerun: Dict[str, Any] = {"requested": bool(req.rerun_after_apply), "performed": False}
    if req.rerun_after_apply and req.raw_file:
        raw = safe_child(INPUT_DIR, req.raw_file)
        if raw.exists() and raw.suffix.lower() in {".xlsx", ".xlsm"}:
            out_dir = OUTPUT_DIR / "Formatter"
            out_dir.mkdir(parents=True, exist_ok=True)
            out_name = timestamp_name(f"Correction_Rerun_{raw.name}")
            output_path = out_dir / out_name
            token = FORMATTER_PROFILE_CONTEXT.set(profile)
            case_token = BOQ_CASE_CONTEXT.set(get_boq_case_dictionary(profile))
            try:
                formatter_summary = format_workbook_copy(raw, output_path, profile)
            finally:
                BOQ_CASE_CONTEXT.reset(case_token)
                FORMATTER_PROFILE_CONTEXT.reset(token)
            rerun = {
                "requested": True,
                "performed": True,
                "output_file": out_name,
                "relative_path": str(output_path.relative_to(OUTPUT_DIR)).replace("\\", "/"),
                "download_url": clean_download_url(str(output_path.relative_to(OUTPUT_DIR)).replace("\\", "/")),
                "formatter_summary": formatter_summary,
            }
        else:
            rerun = {"requested": True, "performed": False, "reason": "Raw file not found or not an Excel workbook."}

    record_dir = OUTPUT_DIR / "AI_Exports" / "Correction_Loop"
    record_dir.mkdir(parents=True, exist_ok=True)
    record_path = record_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_Correction_Loop_Record.json"
    record = {
        "status": "applied",
        "version": "v3.18",
        "created_at": now_iso(),
        "preview": preview,
        "mistake_memory_entry": entry,
        "backup_created": backup.get("backup_name"),
        "rerun": rerun,
        "stable_tools_modified": False,
    }
    record_path.write_text(json.dumps(record, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    rel = str(record_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    write_log("correction_loop_applied", {"profile_key": key, "entry_id": entry.get("id"), "rerun": rerun.get("performed")})
    return {**record, "download_url": clean_download_url(rel), "relative_path": rel}

@app.post("/api/feedback/preview")
def api_feedback_preview(req: FeedbackPreviewRequest) -> Dict[str, Any]:
    profile = resolve_formatter_profile(req.profile_key)
    changes = parse_feedback_to_profile_changes(req.feedback_text)
    return {
        "status": "ok",
        "profile_key": profile.get("profile_key"),
        "profile_name": profile.get("display_name"),
        "feedback_text": req.feedback_text,
        "changes": changes,
        "approval_required": True,
        "message": "Preview only. No profile memory changed until typed approval is provided.",
    }


@app.post("/api/feedback/apply")
def api_feedback_apply(req: FeedbackApplyRequest) -> Dict[str, Any]:
    if not approval_is_valid(req.approval_id, "apply_feedback_learning"):
        raise HTTPException(status_code=403, detail="Approved feedback-learning permission is required.")
    changes = parse_feedback_to_profile_changes(req.feedback_text)
    if changes.get("warnings") and not any(changes.get(k) for k in ["protected_upper", "protected_exact", "proper_phrases", "slash_words", "lower_mid_phrases", "letter_based_terms", "format_rules", "row_overrides", "temporary_row_overrides", "remove_protected_exact", "remove_proper_phrases"]):
        raise HTTPException(status_code=400, detail="No strong reusable rule was found in the feedback.")
    store = load_formatter_profiles()
    key = normalise_profile_key(req.profile_key or store.get("active_profile") or "default_qs_boq")
    if key not in store.get("profiles", {}):
        raise HTTPException(status_code=404, detail="Formatter profile not found.")
    backup = create_safety_backup("before_feedback_learning_apply", include_jobs=True, include_outputs=False, include_inputs=False)
    profile = store["profiles"][key]
    merge_feedback_changes_into_profile(profile, changes)
    store["profiles"][key] = profile
    save_formatter_profiles(store)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    feedback_dir = OUTPUT_DIR / "AI_Exports" / "Feedback_Learning"
    feedback_dir.mkdir(parents=True, exist_ok=True)
    record_name = f"{stamp}_Feedback_Learning_{key}.json"
    record_path = feedback_dir / record_name
    record = {
        "status": "applied",
        "created_at": now_iso(),
        "profile_key": key,
        "profile_name": profile.get("display_name", key),
        "feedback_text": req.feedback_text,
        "changes": changes,
        "backup_created": backup.get("backup_name"),
        "stable_tools_modified": False,
    }
    record_path.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
    rel = str(record_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    write_log("feedback_learning_applied", record)
    return {
        **record,
        "download_url": clean_download_url(rel),
        "relative_path": rel,
        "message": "Feedback rules applied safely to the active Formatter profile.",
    }


@app.get("/api/outputs/summary")
def api_outputs_summary() -> Dict[str, Any]:
    visible = list_generated_output_files(include_archive=False)
    archived = list_generated_output_files(include_archive=True)
    archived_count = max(0, len(archived) - len(visible))
    ai_reviews = [p for p in (OUTPUT_DIR / "AI_Exports").glob("*.json") if p.is_file()]
    job_files = [p for p in JOBS_DIR.glob("*.json") if p.is_file()]
    return {
        "visible_outputs": len(visible),
        "archived_outputs": archived_count,
        "ai_review_json": len(ai_reviews),
        "job_records": len(job_files),
        "latest_output": visible[0].name if visible else "",
    }


@app.post("/api/outputs/cleanup")
def api_outputs_cleanup(req: OutputCleanupRequest) -> Dict[str, Any]:
    # Safe cleanup archives/moves Jarvis-generated files only. It does not delete files.
    return cleanup_outputs(req.cleanup_type, req.keep_latest)


@app.post("/api/self-test/formatter")
def api_self_test_formatter() -> Dict[str, Any]:
    try:
        return run_formatter_regression_self_test()
    except Exception as exc:
        write_log("formatter_self_test_failed", {"error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Formatter self-test failed: {exc}")

@app.get("/api/formatter/status")
def api_formatter_status() -> Dict[str, Any]:
    try:
        import openpyxl  # type: ignore
        active = resolve_formatter_profile()
        return {"status": "working", "engine": "openpyxl", "detail": f"Ready to format workbook copies through Jarvis v3.3 using formatter profile: {active.get('display_name', active.get('profile_key'))}.", "active_profile": active}
    except Exception as exc:
        return {"status": "offline", "engine": "openpyxl", "detail": str(exc)}


@app.get("/api/formatter/profiles")
def api_formatter_profiles() -> Dict[str, Any]:
    store = load_formatter_profiles()
    profiles = store.get("profiles", {})
    editor_text = {key: profile_to_editor_text(profile) for key, profile in profiles.items()}
    return {"active_profile": store.get("active_profile"), "profiles": profiles, "editor_text": editor_text}


@app.post("/api/formatter/profiles/active")
def api_formatter_profiles_active(req: FormatterProfileActiveRequest) -> Dict[str, Any]:
    store = load_formatter_profiles()
    key = normalise_profile_key(req.profile_key)
    if key not in store.get("profiles", {}):
        raise HTTPException(status_code=404, detail="Formatter profile not found.")
    store["active_profile"] = key
    save_formatter_profiles(store)
    write_log("formatter_profile_active", {"profile_key": key})
    return {"status": "ok", "active_profile": key, "profile": store["profiles"][key]}


@app.post("/api/formatter/profiles/save")
def api_formatter_profiles_save(req: FormatterProfileSaveRequest) -> Dict[str, Any]:
    store = load_formatter_profiles()
    # v2.10: protect profile edits with an automatic settings backup.
    try:
        create_safety_backup("before_formatter_profile_save", include_jobs=True, include_outputs=False, include_inputs=False)
    except Exception as exc:
        write_log("auto_backup_before_profile_save_failed", {"error": str(exc)})
    key = normalise_profile_key(req.profile_key or req.display_name)
    existing = store.get("profiles", {}).get(key) or default_formatter_profiles()["profiles"]["default_qs_boq"]
    profile = {
        "display_name": req.display_name.strip() or existing.get("display_name") or key,
        "description": req.description.strip() or existing.get("description") or "Custom Jarvis formatter profile.",
        "version": "v3.5",
        "format_rules": existing.get("format_rules") or default_formatter_profiles()["profiles"]["default_qs_boq"].get("format_rules"),
        "casing": {
            "protected_upper": parse_lines_text(req.protected_upper_text),
            "protected_exact": parse_map_text(req.protected_exact_text),
            "proper_phrases": parse_map_text(req.proper_phrases_text),
            "slash_words": parse_map_text(req.slash_words_text),
        },
    }
    store.setdefault("profiles", {})[key] = profile
    if req.set_active:
        store["active_profile"] = key
    save_formatter_profiles(store)
    write_log("formatter_profile_saved", {"profile_key": key, "set_active": req.set_active})
    return {"status": "ok", "profile_key": key, "active_profile": store.get("active_profile"), "profile": profile}


def create_formatter_output(input_file: str, output_prefix: Optional[str] = None, profile_key: Optional[str] = None) -> Dict[str, Any]:
    """Run the internal Formatter engine on a safe copy and return output metadata."""
    source = safe_child(INPUT_DIR, input_file)
    profile = resolve_formatter_profile(profile_key)
    if not source.exists() or not source.is_file():
        raise HTTPException(status_code=404, detail="Input file not found. Attach the workbook again.")
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise HTTPException(status_code=400, detail="Formatter v3.0 currently supports .xlsx and .xlsm only.")

    formatter_dir = OUTPUT_DIR / "Formatter"
    formatter_dir.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = output_prefix or "Jarvis_Formatted"
    safe_prefix = re.sub(r"[^A-Za-z0-9_-]+", "_", prefix).strip("_") or "Jarvis_Formatted"
    output_name = f"{stamp}_{safe_prefix}_{source.stem}{source.suffix}"
    output_path = formatter_dir / output_name

    token = FORMATTER_PROFILE_CONTEXT.set(profile)
    case_token = BOQ_CASE_CONTEXT.set(get_boq_case_dictionary(profile))
    try:
        summary = format_workbook_copy(source, output_path, profile)
    finally:
        BOQ_CASE_CONTEXT.reset(case_token)
        FORMATTER_PROFILE_CONTEXT.reset(token)

    rel = str(output_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    explicit_rows = summary.get("head1", 0) + summary.get("head2", 0) + summary.get("head3", 0) + summary.get("head4", 0) + summary.get("level_rows", 0)
    if summary.get("costx_entries", 0):
        note = "Raw CostX XGET list detected. Jarvis added a CostX Extract sheet with parsed relationship, tag, unit, original formula, and builder-ready notes."
    elif explicit_rows:
        note = "Applied V6-learned hierarchy formatting: Head1/Head2/Head3/Head4 rows styled, and all non-heading item rows below headings italicised with smart sentence case."
    else:
        note = "No Head1/Head2/Head3/Head4 row markers were detected, so Jarvis applied visible general cleanup and added a format report sheet."
    return {
        "status": "ok",
        "message": "Formatted workbook copy created safely. Original uploaded file and stable Formatter v6 were not modified.",
        "input_name": source.name,
        "output_name": output_path.name,
        "relative_path": rel,
        "download_url": clean_download_url(rel),
        "note": note,
        "summary": summary,
        "profile_key": profile.get("profile_key"),
        "profile_name": profile.get("display_name"),
    }



@app.post("/api/formatter/layout/analyze")
def api_formatter_layout_analyze(req: ClientLayoutAnalyzeRequest) -> Dict[str, Any]:
    try:
        if not req.input_file:
            raise HTTPException(status_code=400, detail="Attach a workbook before analyzing client layout.")
        source = safe_child(INPUT_DIR, req.input_file)
        if not source.exists() or not source.is_file():
            raise HTTPException(status_code=404, detail="Input workbook not found. Attach it again.")
        if source.suffix.lower() not in {".xlsx", ".xlsm"}:
            raise HTTPException(status_code=400, detail="Client layout analysis currently supports .xlsx and .xlsm workbooks.")
        profile = resolve_formatter_profile(req.profile_key)
        result = analyze_workbook_column_layout(source, profile, max_rows=max(20, min(req.max_rows, 1000)))
        out_dir = OUTPUT_DIR / "AI_Exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_name = f"{timestamp_name('Client_Layout_Analysis', source.name)}.json"
        out_path = out_dir / out_name
        out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        rel = str(out_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
        result["relative_path"] = rel
        result["download_url"] = clean_download_url(rel)
        write_log("client_layout_analyzed", {"input_file": source.name, "average_confidence": result.get("average_confidence")})
        return result
    except HTTPException:
        raise
    except Exception as exc:
        write_log("client_layout_analyze_failed", {"input_file": getattr(req, "input_file", ""), "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Client layout analysis failed: {exc}")


@app.post("/api/formatter/layout/apply")
def api_formatter_layout_apply(req: ClientLayoutApplyRequest) -> Dict[str, Any]:
    try:
        if (req.typed_confirmation or "").strip() != "I APPROVE":
            raise HTTPException(status_code=403, detail="Typed approval required: I APPROVE")
        if not req.input_file:
            raise HTTPException(status_code=400, detail="Attach a workbook before learning client layout.")
        source = safe_child(INPUT_DIR, req.input_file)
        if not source.exists() or not source.is_file():
            raise HTTPException(status_code=404, detail="Input workbook not found. Attach it again.")
        profile_store = load_formatter_profiles()
        key = normalise_profile_key(req.profile_key or profile_store.get("active_profile") or "default_qs_boq")
        if key not in profile_store.get("profiles", {}):
            raise HTTPException(status_code=404, detail="Formatter profile not found.")
        backup = create_settings_backup("Before v3.15 client layout learning", include_jobs=True)
        profile = profile_store["profiles"][key]
        analysis = analyze_workbook_column_layout(source, {**profile, "profile_key": key}, max_rows=max(20, min(req.max_rows, 1000)))
        profile.setdefault("format_rules", {})
        profile["format_rules"]["layout_detection"] = {
            "mode": "auto_detect_per_sheet",
            "description_column": analysis.get("recommended_layout", {}).get("description_column") or "auto",
            "row_type_column": analysis.get("recommended_layout", {}).get("row_type_column") or "auto",
            "unit_column": analysis.get("recommended_layout", {}).get("unit_column") or "auto",
            "formula_columns": "auto_protect",
            "protect_formula_columns": True,
            "client_format_learning": True,
            "last_learned_from": source.name,
            "last_learned_at": now_iso(),
            "average_confidence": analysis.get("average_confidence"),
        }
        profile["client_layout_memory"] = analysis.get("recommended_layout", {})
        profile_store["profiles"][key] = profile
        save_formatter_profiles(profile_store)
        write_log("client_layout_applied", {"profile_key": key, "backup": backup.get("backup_name"), "input_file": source.name})
        return {
            "status": "ok",
            "profile_key": key,
            "profile_name": profile.get("display_name", key),
            "backup_created": backup.get("backup_name"),
            "analysis": analysis,
            "message": "Client layout learned safely. Formatter still auto-detects per sheet and protects formula columns.",
        }
    except HTTPException:
        raise
    except Exception as exc:
        write_log("client_layout_apply_failed", {"input_file": getattr(req, "input_file", ""), "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Client layout learning failed: {exc}")



def _cell_style_snapshot(cell: Any) -> Dict[str, Any]:
    """Compact style signature used by the sample-based learner.

    v3.17 expands this beyond bold/italic: it captures alignment, wrap,
    font size/name, fill and border hints so Jarvis can copy the visual style
    of the formatted sample workbook without hard-coding Calibri/italic/etc.
    """
    font = getattr(cell, "font", None)
    fill = getattr(cell, "fill", None)
    border = getattr(cell, "border", None)
    alignment = getattr(cell, "alignment", None)
    def _border_side(side_name: str) -> str:
        try:
            return str(getattr(getattr(border, side_name, None), "style", "") or "")
        except Exception:
            return ""
    return {
        "bold": bool(getattr(font, "bold", False)) if font else False,
        "italic": bool(getattr(font, "italic", False)) if font else False,
        "underline": bool(getattr(font, "underline", None)) if font else False,
        "font_name": str(getattr(font, "name", "") or ""),
        "font_size": getattr(font, "sz", None),
        "font_color": str(getattr(getattr(font, "color", None), "rgb", "") or ""),
        "fill_type": str(getattr(fill, "fill_type", "") or ""),
        "fgColor": str(getattr(getattr(fill, "fgColor", None), "rgb", "") or getattr(getattr(fill, "fgColor", None), "indexed", "") or ""),
        "top_border": _border_side("top"),
        "bottom_border": _border_side("bottom"),
        "left_border": _border_side("left"),
        "right_border": _border_side("right"),
        "horizontal": str(getattr(alignment, "horizontal", "") or "") if alignment else "",
        "vertical": str(getattr(alignment, "vertical", "") or "") if alignment else "",
        "wrap_text": bool(getattr(alignment, "wrap_text", False)) if alignment else False,
        "shrink_to_fit": bool(getattr(alignment, "shrink_to_fit", False)) if alignment else False,
        "indent": getattr(alignment, "indent", 0) if alignment else 0,
        "number_format": str(getattr(cell, "number_format", "") or ""),
    }


def _merge_style_counter(counter: Dict[str, Any], style: Dict[str, Any]) -> None:
    counter["count"] = int(counter.get("count", 0)) + 1
    for key in ["bold", "italic", "underline", "wrap_text", "shrink_to_fit"]:
        if style.get(key):
            counter[key] = int(counter.get(key, 0)) + 1
    for key in ["font_name", "font_size", "font_color", "fill_type", "fgColor", "top_border", "bottom_border", "left_border", "right_border", "horizontal", "vertical", "indent", "number_format"]:
        val = style.get(key)
        if val in (None, ""):
            continue
        bucket = counter.setdefault(key, {})
        bucket[str(val)] = int(bucket.get(str(val), 0)) + 1


def _dominant_style(counter: Dict[str, Any]) -> Dict[str, Any]:
    count = max(1, int(counter.get("count", 0)))
    out = {
        "sample_count": count,
        "bold": int(counter.get("bold", 0)) / count >= 0.6,
        "italic": int(counter.get("italic", 0)) / count >= 0.6,
        "underline": int(counter.get("underline", 0)) / count >= 0.6,
        "wrap_text": int(counter.get("wrap_text", 0)) / count >= 0.6,
        "shrink_to_fit": int(counter.get("shrink_to_fit", 0)) / count >= 0.6,
    }
    for key in ["font_name", "font_size", "font_color", "fill_type", "fgColor", "top_border", "bottom_border", "left_border", "right_border", "horizontal", "vertical", "indent", "number_format"]:
        bucket = counter.get(key, {}) if isinstance(counter.get(key), dict) else {}
        if bucket:
            out[key] = max(bucket.items(), key=lambda x: x[1])[0]
    return out


def sample_workbook_style_signature(source: Path, profile: Optional[Dict[str, Any]] = None, max_rows: int = 250) -> Dict[str, Any]:
    """Read a formatted sample workbook and extract row/column/style patterns.

    This does not overwrite anything. It creates a reusable local profile hint
    so Jarvis can learn from examples instead of hard-coded columns only.
    """
    from openpyxl import load_workbook
    wb = load_workbook(source, data_only=False, keep_vba=source.suffix.lower() == ".xlsm")
    sheet_signatures: List[Dict[str, Any]] = []
    aggregate: Dict[str, Dict[str, Any]] = {}
    total_rows = 0
    italic_child_rows = 0
    child_rows = 0
    try:
        for ws in wb.worksheets:
            if ws.title.lower().startswith("jarvis_"):
                continue
            formula_info = detect_formula_columns(ws, scan_rows=max_rows)
            layout = detect_sheet_column_layout(ws, formula_info, profile, scan_rows=max_rows)
            desc_col = int(layout.get("description_column_index") or 2)
            row_type_cols = [int(layout.get("row_type_column_index"))] if layout.get("row_type_column_index") else []
            unit_cols = [int(layout.get("unit_column_index"))] if layout.get("unit_column_index") else []
            active_heading = ""
            row_counts: Dict[str, int] = {}
            example_rows: List[Dict[str, Any]] = []
            style_counters: Dict[str, Dict[str, Any]] = {}
            max_scan = min(ws.max_row or 0, max_rows)
            for row in ws.iter_rows(min_row=1, max_row=max_scan):
                row_idx = row[0].row
                row_type = detect_row_type(row, row_type_cols)
                unit_marker = detect_boq_unit_marker(row, unit_cols)
                desc_cell = ws.cell(row=row_idx, column=desc_col)
                text = str(desc_cell.value).strip() if desc_cell.value not in (None, "") else ""
                if row_type in {"head1", "head2", "head3", "head4"}:
                    active_heading = row_type
                    bucket = row_type
                elif row_type == "level" or looks_like_level_row(row, desc_col):
                    bucket = "level"
                elif text and active_heading:
                    bucket = "item_below_heading"
                    child_rows += 1
                    if getattr(desc_cell.font, "italic", False):
                        italic_child_rows += 1
                elif unit_marker:
                    bucket = "unit_item"
                elif text:
                    bucket = "text_note"
                else:
                    bucket = "blank"
                row_counts[bucket] = row_counts.get(bucket, 0) + 1
                total_rows += 1
                if bucket not in {"blank"}:
                    style = _cell_style_snapshot(desc_cell)
                    _merge_style_counter(style_counters.setdefault(bucket, {}), style)
                    _merge_style_counter(aggregate.setdefault(bucket, {}), style)
                    if len(example_rows) < 30 and text:
                        example_rows.append({
                            "row": row_idx,
                            "bucket": bucket,
                            "text_preview": text[:160],
                            "unit": unit_marker,
                            "style": style,
                        })
            sheet_signatures.append({
                "sheet": ws.title,
                "layout": layout,
                "row_counts": row_counts,
                "dominant_styles": {k: _dominant_style(v) for k, v in style_counters.items()},
                "example_rows": example_rows,
                "freeze_panes": str(ws.freeze_panes or ""),
                "autofilter": str(getattr(ws.auto_filter, "ref", "") or ""),
            })
    finally:
        try:
            wb.close()
        except Exception:
            pass
    return {
        "input_file": source.name,
        "created_at": now_iso(),
        "total_rows_sampled": total_rows,
        "item_rows_below_heading": child_rows,
        "italic_child_rows": italic_child_rows,
        "italic_child_row_ratio": round(italic_child_rows / max(1, child_rows), 3),
        "dominant_styles": {k: _dominant_style(v) for k, v in aggregate.items()},
        "sheet_signatures": sheet_signatures,
    }


def compare_raw_to_sample_format(raw_file: str, sample_file: str, profile_key: Optional[str] = None, max_rows: int = 250) -> Dict[str, Any]:
    raw = safe_child(INPUT_DIR, raw_file)
    sample = safe_child(INPUT_DIR, sample_file)
    if not raw.exists() or not raw.is_file():
        raise HTTPException(status_code=404, detail="Raw workbook not found. Attach the raw workbook again.")
    if not sample.exists() or not sample.is_file():
        raise HTTPException(status_code=404, detail="Sample formatted workbook not found. Attach the sample workbook again.")
    if raw.suffix.lower() not in {".xlsx", ".xlsm"} or sample.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise HTTPException(status_code=400, detail="Sample-based format learning currently supports .xlsx and .xlsm only.")
    profile = resolve_formatter_profile(profile_key)
    raw_layout = analyze_workbook_column_layout(raw, profile, max_rows=max_rows)
    sample_layout = analyze_workbook_column_layout(sample, profile, max_rows=max_rows)
    sample_signature = sample_workbook_style_signature(sample, profile, max_rows=max_rows)
    italic_ratio = float(sample_signature.get("italic_child_row_ratio", 0) or 0)
    suggestions = {
        "description_column": sample_layout.get("recommended_layout", {}).get("description_column") or raw_layout.get("recommended_layout", {}).get("description_column"),
        "row_type_column": sample_layout.get("recommended_layout", {}).get("row_type_column") or raw_layout.get("recommended_layout", {}).get("row_type_column"),
        "unit_column": sample_layout.get("recommended_layout", {}).get("unit_column") or raw_layout.get("recommended_layout", {}).get("unit_column"),
        "protect_formula_columns": True,
        "item_rows_below_heading_italic": italic_ratio >= 0.6,
        "clear_freeze_panes": True,
        "clear_autofilter": True,
        "sample_style_signature_saved": True,
    }
    payload = {
        "status": "ok",
        "version": APP_VERSION,
        "raw_file": raw.name,
        "sample_file": sample.name,
        "profile_key": profile.get("profile_key"),
        "profile_name": profile.get("display_name"),
        "created_at": now_iso(),
        "raw_layout": raw_layout,
        "sample_layout": sample_layout,
        "sample_style_signature": sample_signature,
        "suggested_profile_updates": suggestions,
        "safety": {
            "stable_tools_modified": False,
            "original_files_modified": False,
            "formula_columns_protected": True,
            "requires_approval_to_learn": True,
        },
        "notes": [
            "Jarvis compares a raw workbook and a correctly formatted sample workbook locally.",
            "Learning saves a compact style/layout signature to the active Formatter profile only after typed approval.",
            "Python/OpenPyXL still formats the workbook safely; Local AI/sample learning does not directly overwrite originals.",
        ],
    }
    out_dir = OUTPUT_DIR / "AI_Exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_name = f"{timestamp_name('Sample_Format_Analysis', raw.name)}.json"
    out_path = out_dir / out_name
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    rel = str(out_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    payload["relative_path"] = rel
    payload["download_url"] = clean_download_url(rel)
    write_log("sample_format_analyzed", {"raw_file": raw.name, "sample_file": sample.name, "profile_key": profile.get("profile_key")})
    return payload


@app.post("/api/formatter/sample/analyze")
def api_formatter_sample_analyze(req: SampleFormatAnalyzeRequest) -> Dict[str, Any]:
    try:
        return compare_raw_to_sample_format(req.raw_file, req.sample_file, req.profile_key, max_rows=max(20, min(req.max_rows, 1000)))
    except HTTPException:
        raise
    except Exception as exc:
        write_log("sample_format_analyze_failed", {"raw_file": getattr(req, "raw_file", ""), "sample_file": getattr(req, "sample_file", ""), "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Sample format analysis failed: {exc}") from exc


@app.post("/api/formatter/sample/learn")
def api_formatter_sample_learn(req: SampleFormatLearnRequest) -> Dict[str, Any]:
    try:
        if (req.typed_confirmation or "").strip() != "I APPROVE":
            raise HTTPException(status_code=403, detail="Typed approval required: I APPROVE")
        store = load_formatter_profiles()
        key = normalise_profile_key(req.profile_key or store.get("active_profile") or "default_qs_boq")
        if key not in store.get("profiles", {}):
            raise HTTPException(status_code=404, detail="Formatter profile not found.")
        backup = create_safety_backup("before_sample_format_learning", include_jobs=True, include_outputs=False, include_inputs=False)
        analysis = compare_raw_to_sample_format(req.raw_file, req.sample_file, key, max_rows=max(20, min(req.max_rows, 1000)))
        profile = store["profiles"][key]
        profile.setdefault("format_rules", {})
        profile["format_rules"]["sample_based_learning"] = True
        profile["format_rules"]["sample_learning_version"] = "v3.18"
        profile["format_rules"]["layout_detection"] = {
            "mode": "auto_detect_per_sheet",
            "description_column": analysis.get("suggested_profile_updates", {}).get("description_column") or "auto",
            "row_type_column": analysis.get("suggested_profile_updates", {}).get("row_type_column") or "auto",
            "unit_column": analysis.get("suggested_profile_updates", {}).get("unit_column") or "auto",
            "formula_columns": "auto_protect",
            "protect_formula_columns": True,
            "client_format_learning": True,
            "sample_based_learning": True,
            "sample_output_layout_mode": "copy_sample_columns",
            "last_sample_raw_file": req.raw_file,
            "last_sample_file": req.sample_file,
            "last_learned_at": now_iso(),
        }
        profile["sample_based_learning"] = {
            "version": "v3.18",
            "raw_file": req.raw_file,
            "sample_file": req.sample_file,
            "learned_at": now_iso(),
            "analysis_file": analysis.get("relative_path"),
            "suggested_profile_updates": analysis.get("suggested_profile_updates", {}),
            "raw_layout": analysis.get("raw_layout", {}),
            "sample_layout": analysis.get("sample_layout", {}),
            "sample_style_signature": analysis.get("sample_style_signature", {}),
        }
        profile["client_layout_memory"] = analysis.get("sample_layout", {}).get("recommended_layout", {}) or analysis.get("raw_layout", {}).get("recommended_layout", {})
        store["profiles"][key] = profile
        store["active_profile"] = key
        save_formatter_profiles(store)
        payload = {
            "status": "ok",
            "profile_key": key,
            "profile_name": profile.get("display_name", key),
            "backup_created": backup.get("backup_name"),
            "analysis": analysis,
            "message": "Sample format learned safely. Active Formatter profile now stores the sample layout/style signature and can map output columns to the sample layout.",
            "stable_tools_modified": False,
        }
        write_log("sample_format_learned", {"profile_key": key, "backup": backup.get("backup_name"), "raw_file": req.raw_file, "sample_file": req.sample_file})
        return payload
    except HTTPException:
        raise
    except Exception as exc:
        write_log("sample_format_learn_failed", {"raw_file": getattr(req, "raw_file", ""), "sample_file": getattr(req, "sample_file", ""), "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Sample format learning failed: {exc}") from exc

@app.post("/api/formatter/run")
def api_formatter_run(req: FormatterRunRequest) -> Dict[str, Any]:
    """Synchronous legacy endpoint kept as a fallback for testing.

    Jarvis v3.3 UI uses /api/jobs/start so formatting runs as a background job
    and the page can show progress while the engine is working.
    """
    try:
        payload = create_formatter_output(req.input_file, req.output_prefix, req.profile_key)
    except HTTPException:
        raise
    except Exception as exc:
        write_log("formatter_error", {"input": req.input_file, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Formatter failed: {exc}") from exc
    write_log("formatter_run", payload)
    return payload


def run_formatter_background_job(job_id: str, input_file: str, output_prefix: Optional[str] = None, profile_key: Optional[str] = None) -> None:
    """Background worker for the Formatter engine.

    The AI/controller layer starts a job, then the Python engine performs the
    actual file creation safely. Stable external tools are not opened, clicked,
    overwritten, or modified.
    """
    update_job(job_id, status="running", progress=8, stage="Validating input workbook")
    try:
        source = safe_child(INPUT_DIR, input_file)
        if not source.exists() or not source.is_file():
            raise FileNotFoundError("Input file not found. Attach the workbook again.")
        update_job(job_id, progress=18, stage="Preparing safe output copy", input_name=source.name)
        payload = create_formatter_output(input_file, output_prefix, profile_key)
        update_job(job_id, progress=92, stage="Saving job report", result=payload)
        write_log("formatter_background_job_completed", {"job_id": job_id, **payload})
        update_job(job_id, status="completed", progress=100, stage="Completed", completed_at=now_iso(), result=payload)
    except Exception as exc:
        write_log("formatter_background_job_failed", {"job_id": job_id, "error": str(exc)})
        update_job(job_id, status="failed", progress=100, stage="Failed", error=str(exc), completed_at=now_iso())




# -----------------------------
# Jarvis v4.2.2 Builder Base Sheet Lite
# -----------------------------

SUPPORTED_COSTX_FUNCTIONS = [
    "XGETWALLAREA",
    "XGETAREA",
    "XGETLENGTH",
    "XGETCOUNT",
    "XGETVOLUME",
    "XGETCUSTOM",
    "XGETPERIMETER",
    "XGETWALLLENGTH",
    "XGETWALLVOLUME",
    "XGETNUMBER",
]


def sanitize_costx_function(value: Any, fallback: str = "XGETWALLAREA") -> str:
    raw = str(value or fallback or "XGETWALLAREA").strip().upper().lstrip("=")
    raw = re.sub(r"[^A-Z0-9_]+", "", raw)
    if not raw.startswith("XGET"):
        raw = fallback or "XGETWALLAREA"
    return raw if raw in SUPPORTED_COSTX_FUNCTIONS or raw.startswith("XGET") else (fallback or "XGETWALLAREA")


def builder_unit_for_function(function_name: str) -> str:
    f = sanitize_costx_function(function_name or "").upper()
    if "CUSTOM" in f:
        # XGETCUSTOM varies by CostX setup, so leave unit for review rather than guessing.
        return "Review"
    if "VOLUME" in f:
        return "m3"
    if "LENGTH" in f or "PERIMETER" in f:
        return "m"
    if "COUNT" in f or "NUMBER" in f:
        return "no"
    if "WEIGHT" in f or "MASS" in f:
        return "kg"
    # Wall area, area, floor area, ceiling area etc.
    return "m2"




def canonical_builder_unit(unit: Any) -> str:
    """Standardise Builder output unit text.

    User rule: count units must output exactly as lowercase `no`
    (not `No.`, `No`, or capitalised variants).
    """
    raw = str(unit or "").strip()
    if re.fullmatch(r"(?i)no\.?", raw):
        return "no"
    return raw



# -----------------------------
# Jarvis v4.4.4.4 Flexible BOQ Item Code Column
# -----------------------------
def sanitize_item_code_config(data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Return a safe, output-only BOQ item-code configuration.

    Item codes are deliberately independent from CostX formulas, zones and
    heading logic. They only populate Column A in the generated Builder output.
    """
    data = data if isinstance(data, dict) else {}

    def clean(value: Any, fallback: str = "") -> str:
        return re.sub(r"[\r\n]+", " ", str(value if value is not None else fallback)).strip()

    enabled_raw = data.get("enabled", data.get("item_code_enabled", False))
    enabled = bool(enabled_raw)
    if isinstance(enabled_raw, str):
        enabled = enabled_raw.strip().lower() in {"1", "true", "yes", "on", "enabled"}

    prefix = clean(data.get("prefix") or data.get("trade_code") or data.get("section_code") or "A", "A")
    prefix = re.sub(r"[^A-Za-z0-9]+", "", prefix).upper() or "A"
    separator = clean(data.get("separator") or data.get("sep") or "/", "/")
    if separator.lower() in {"slash", "forward slash"}:
        separator = "/"
    elif separator.lower() in {"dash", "hyphen"}:
        separator = "-"
    elif separator.lower() in {"dot", "period"}:
        separator = "."
    separator = separator[:1] if separator else "/"
    if separator not in {"/", "-", ".", "_"}:
        separator = "/"

    try:
        start_number = int(data.get("start_number") or data.get("start") or 1)
    except Exception:
        start_number = 1
    start_number = max(1, start_number)

    try:
        padding = int(data.get("number_padding") or data.get("padding") or 0)
    except Exception:
        padding = 0
    padding = max(0, min(4, padding))

    reset_scope = clean(data.get("reset_scope") or data.get("reset") or "whole_run", "whole_run").lower().replace(" ", "_").replace("-", "_")
    if reset_scope not in {"whole_run", "per_head3", "per_section", "never"}:
        reset_scope = "whole_run"

    apply_raw = data.get("apply_to") or data.get("apply_codes_to") or ["formula", "item", "note"]
    if isinstance(apply_raw, str):
        apply_to = [x.strip().lower() for x in re.split(r"[,;/]+", apply_raw) if x.strip()]
    elif isinstance(apply_raw, list):
        apply_to = [str(x).strip().lower() for x in apply_raw if str(x).strip()]
    else:
        apply_to = ["formula", "item", "note"]
    if not apply_to:
        apply_to = ["formula", "item", "note"]

    section_code_raw = data.get("section_code_enabled", data.get("put_prefix_on_first_heading", True))
    section_code_enabled = bool(section_code_raw)
    if isinstance(section_code_raw, str):
        section_code_enabled = section_code_raw.strip().lower() in {"1", "true", "yes", "on", "enabled"}

    return {
        "enabled": enabled,
        "prefix": prefix,
        "separator": separator,
        "start_number": start_number,
        "number_padding": padding,
        "reset_scope": reset_scope,
        "apply_to": apply_to,
        "section_code_enabled": section_code_enabled,
        "section_code_row": clean(data.get("section_code_row") or "first_heading", "first_heading"),
        "trade_title_enabled": bool(data.get("trade_title_enabled", False)) if not isinstance(data.get("trade_title_enabled", False), str) else data.get("trade_title_enabled", "").strip().lower() in {"1", "true", "yes", "on", "enabled"},
        "trade_title": clean(data.get("trade_title") or "", ""),
        "trade_title_row_type": clean(data.get("trade_title_row_type") or "Head2", "Head2"),
        "source": clean(data.get("source") or "command_or_workspace", "command_or_workspace"),
    }


def detect_item_code_intent(prompt: str) -> Optional[Dict[str, Any]]:
    """Parse flexible item-code instructions from the user command."""
    raw = str(prompt or "")
    text = raw.lower()
    if not any(k in text for k in ["item code", "item codes", "boq code", "code column", "with codes", "item coding", "code prefix"]):
        return None

    cfg: Dict[str, Any] = {"enabled": True, "prefix": "A", "separator": "/", "start_number": 1, "number_padding": 0, "reset_scope": "whole_run", "source": "command"}
    # v4.4.4.5: support sample-like trade/section title coding.
    # Example: "start at A from trade title" -> put A on the trade title row,
    # then item/formula rows continue as A-1, A-2, A-3.
    if any(k in text for k in ["no trade title row", "without trade title", "stage rows are first", "zones are first"]):
        cfg["trade_title_enabled"] = False
        cfg["section_code_row"] = "first_heading"
    elif any(k in text for k in ["trade title", "from trade title", "section title", "trade heading", "trade title as separate top row", "separate top row"]):
        cfg["trade_title_enabled"] = True
        cfg["section_code_row"] = "trade_title"
    if re.search(r"\bwall\s*types?\s+trade\b", raw, flags=re.I) and not any(k in text for k in ["no trade title row", "without trade title", "stage rows are first", "zones are first"]):
        cfg["trade_title_enabled"] = True
        cfg["section_code_row"] = "trade_title"
        cfg["trade_title"] = "Wall Types Trade"
    title_match = re.search(r"\b(?:trade title|section title|trade heading)\s*(?:is|=|:|as)?\s*([A-Za-z0-9][A-Za-z0-9 /_.-]{2,60})", raw, flags=re.I)
    if title_match:
        title = re.split(r"\b(?:with|using|use|and|separator|start|levels?|zone|do not format|no format)\b", title_match.group(1), maxsplit=1, flags=re.I)[0].strip(" ,.;:-")
        if title:
            cfg["trade_title_enabled"] = True
            cfg["section_code_row"] = "trade_title"
            cfg["trade_title"] = title
    sample_match = re.search(r"\b([A-Za-z][A-Za-z0-9]{0,5})([/._-])(0*\d+)\b", raw)
    if sample_match:
        cfg["prefix"] = sample_match.group(1).upper()
        cfg["separator"] = sample_match.group(2)
        cfg["start_number"] = int(sample_match.group(3) or "1")
        cfg["number_padding"] = len(sample_match.group(3)) if sample_match.group(3).startswith("0") else 0
    prefix_match = re.search(r"\b(?:prefix|trade code|section code|code prefix)\s*(?:is|=|:|as|using|of|to)?\s*([A-Za-z][A-Za-z0-9]{0,5})\b", raw, flags=re.I)
    if prefix_match:
        cfg["prefix"] = prefix_match.group(1).upper()
    sep_match = re.search(r"\bseparator\s*(?:is|=|:|as|using|to)?\s*[\"'“”]?([/._-]|slash|dash|hyphen|dot|period)[\"'“”]?", raw, flags=re.I)
    if sep_match:
        sep = sep_match.group(1).lower()
        cfg["separator"] = "/" if "slash" in sep else ("-" if sep in {"dash", "hyphen"} else ("." if sep in {"dot", "period"} else sep))
    elif " slash" in text or "separator /" in text:
        cfg["separator"] = "/"
    elif " dash" in text or " hyphen" in text:
        cfg["separator"] = "-"
    start_match = re.search(r"\bstart(?:ing)?(?: number)?\s*(?:at|from|=|:)?\s*(\d+)\b", raw, flags=re.I)
    if start_match:
        cfg["start_number"] = int(start_match.group(1))
    padding_match = re.search(r"\b(?:padding|pad|digits?)\s*(?:to|=|:)?\s*(\d+)\b", raw, flags=re.I)
    if padding_match:
        cfg["number_padding"] = int(padding_match.group(1))
    elif any(k in text for k in ["001", "three digit", "3 digit", "3-digit"]):
        cfg["number_padding"] = max(int(cfg.get("number_padding") or 0), 3)
    elif any(k in text for k in ["01", "two digit", "2 digit", "2-digit"]):
        cfg["number_padding"] = max(int(cfg.get("number_padding") or 0), 2)
    if any(k in text for k in ["reset per head3", "reset each head3", "per head3"]):
        cfg["reset_scope"] = "per_head3"
    elif any(k in text for k in ["reset per section", "per section"]):
        cfg["reset_scope"] = "per_section"
    elif any(k in text for k in ["continue numbering", "do not reset", "no reset"]):
        cfg["reset_scope"] = "whole_run"
    return sanitize_item_code_config(cfg)


def builder_format_item_code(config: Dict[str, Any], number: int) -> str:
    cfg = sanitize_item_code_config(config)
    padding = int(cfg.get("number_padding") or 0)
    number_text = str(int(number or 1)).zfill(padding) if padding else str(int(number or 1))
    return f"{cfg.get('prefix') or 'A'}{cfg.get('separator') or '/'}{number_text}"


def builder_item_code_summary(config: Dict[str, Any]) -> str:
    cfg = sanitize_item_code_config(config)
    if not cfg.get("enabled"):
        return "Off"
    sample = builder_format_item_code(cfg, int(cfg.get("start_number") or 1))
    trade_title_note = "; trade title row on" if cfg.get("trade_title_enabled") else ""
    return f"On - {cfg.get('prefix')}{cfg.get('separator')}number pattern, sample {sample}, reset {cfg.get('reset_scope')}{trade_title_note}"


def builder_item_code_state(config: Dict[str, Any]) -> Dict[str, Any]:
    cfg = sanitize_item_code_config(config)
    return {"config": cfg, "counter": int(cfg.get("start_number") or 1), "section_written": False}


def builder_next_item_code(state: Dict[str, Any], row_role: str = "formula") -> str:
    cfg = sanitize_item_code_config(state.get("config") or {})
    if not cfg.get("enabled") or str(row_role).lower() not in set(cfg.get("apply_to") or []):
        return ""
    code = builder_format_item_code(cfg, int(state.get("counter") or cfg.get("start_number") or 1))
    state["counter"] = int(state.get("counter") or cfg.get("start_number") or 1) + 1
    return code


def builder_section_code_for_heading(state: Dict[str, Any]) -> str:
    cfg = sanitize_item_code_config(state.get("config") or {})
    if not cfg.get("enabled") or not cfg.get("section_code_enabled") or state.get("section_written"):
        return ""
    state["section_written"] = True
    return str(cfg.get("prefix") or "A")


def builder_reset_item_code_counter(state: Dict[str, Any]) -> None:
    cfg = sanitize_item_code_config(state.get("config") or {})
    state["counter"] = int(cfg.get("start_number") or 1)
    state["section_written"] = False


def builder_item_code_trade_title(item_code_cfg: Dict[str, Any], current_work: Optional[Dict[str, Any]] = None) -> str:
    """Return the optional trade/section title for Column A section coding.

    This is deliberately output-only. It creates a visible trade title row such
    as "A  Wall Types Trade" before the project Head3/Head4 hierarchy, while
    CostX dimensions/formulas/zones remain unchanged.
    """
    cfg = sanitize_item_code_config(item_code_cfg)
    if not cfg.get("enabled") or not cfg.get("trade_title_enabled"):
        return ""
    title = str(cfg.get("trade_title") or "").strip()
    if title:
        return title
    cw = current_work if isinstance(current_work, dict) else {}
    profile_id = normalize_builder_trade_profile_id(cw.get("trade_profile_id") or "walls_partitions", "walls_partitions")
    if profile_id == "walls_partitions":
        return "Wall Types Trade"
    return trade_profile_display_name_for_router(profile_id)


def maybe_write_builder_trade_title_row(ws: Any, row_idx: int, item_code_state: Dict[str, Any], current_work: Dict[str, Any], head_font: Any, head_fill: Any, light_bottom: Any, normal_font: Any, Alignment: Any) -> int:
    """Write optional coded trade title row and return the next row index."""
    cfg = sanitize_item_code_config(item_code_state.get("config") or {})
    title = builder_item_code_trade_title(cfg, current_work)
    if not title:
        return row_idx
    code = str(cfg.get("prefix") or "A") if cfg.get("section_code_enabled", True) else ""
    write_builder_heading_row(ws, row_idx, title, str(cfg.get("trade_title_row_type") or "Head2"), head_font, head_fill, light_bottom, normal_font, Alignment, code)
    if code:
        item_code_state["section_written"] = True
    return row_idx + 1


# -----------------------------
# Jarvis v4.3.7 XGETCUSTOM Custom Quantity Templates
# -----------------------------

DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE: Dict[str, List[Dict[str, str]]] = {
    "metalwork_structural_steel": [
        {"name": "Slope Length", "unit": "m", "source": "CostX steel purlins/girts sample"},
        {"name": "Steel Surface Area", "unit": "m2", "source": "CostX steel custom quantity sample"},
        {"name": "Weight", "unit": "t", "source": "CostX steel custom quantity sample"},
        {"name": "RAKING CUTTING", "unit": "m", "source": "CostX raking cutting custom sample"},
    ],
    "concrete_reo": [
        {"name": "Formworks", "unit": "m2", "source": "CostX concrete/reo custom quantity sample"},
        {"name": "Reinforcement by Ratio", "unit": "t", "source": "CostX concrete/reo custom quantity sample"},
        {"name": "PT Reinforcement", "unit": "t", "source": "CostX concrete/reo custom quantity sample"},
        {"name": "Core Filling", "unit": "m3", "source": "CostX concrete custom quantity sample"},
        {"name": "Slab Thickness", "unit": "m", "source": "CostX concrete custom quantity sample"},
        {"name": "Weight", "unit": "t", "source": "CostX concrete/reo custom quantity sample"},
    ],
    "civil_earthworks": [
        {"name": "RAKING CUTTING", "unit": "m", "source": "CostX civil raking cutting sample"},
        {"name": "Slope Length", "unit": "m", "source": "CostX civil/steel slope sample"},
        {"name": "Core Filling", "unit": "m3", "source": "CostX custom quantity sample"},
    ],
    "civil_works": [
        {"name": "RAKING CUTTING", "unit": "m", "source": "CostX civil raking cutting sample"},
        {"name": "Slope Length", "unit": "m", "source": "CostX civil/steel slope sample"},
        {"name": "Core Filling", "unit": "m3", "source": "CostX custom quantity sample"},
    ],
    "generic_custom": [
        {"name": "Slope Length", "unit": "m", "source": "CostX XGETCUSTOM sample"},
        {"name": "Steel Surface Area", "unit": "m2", "source": "CostX XGETCUSTOM sample"},
        {"name": "Weight", "unit": "t", "source": "CostX XGETCUSTOM sample"},
        {"name": "Formworks", "unit": "m2", "source": "CostX XGETCUSTOM sample"},
        {"name": "Reinforcement by Ratio", "unit": "t", "source": "CostX XGETCUSTOM sample"},
        {"name": "PT Reinforcement", "unit": "t", "source": "CostX XGETCUSTOM sample"},
        {"name": "Core Filling", "unit": "m3", "source": "CostX XGETCUSTOM sample"},
        {"name": "RAKING CUTTING", "unit": "m", "source": "CostX XGETCUSTOM sample"},
    ],
}


def sanitize_custom_quantity_name(value: Any, fallback: str = "") -> str:
    text = re.sub(r'["\r\n]+', ' ', str(value if value is not None else fallback)).strip()
    # CostX custom quantity name is passed as a quoted string; do not allow delimiters that break formula syntax.
    text = re.sub(r'[\[\];]+', ' ', text).strip()
    return text


def sanitize_custom_quantity_template(item: Any) -> Optional[Dict[str, str]]:
    if not isinstance(item, dict):
        return None
    name = sanitize_custom_quantity_name(item.get("name") or item.get("custom_quantity_name") or item.get("quantity") or "")
    if not name:
        return None
    unit = canonical_builder_unit(item.get("unit") or item.get("uom") or item.get("custom_quantity_unit") or "Review")
    source = re.sub(r'[\r\n]+', ' ', str(item.get("source") or item.get("notes") or "")).strip()
    return {"name": name, "unit": unit or "Review", "source": source}


def custom_quantity_templates_for_profile(profile: Optional[Dict[str, Any]]) -> List[Dict[str, str]]:
    profile = profile or {}
    profile_id = normalize_builder_trade_profile_id(profile.get("profile_id"), "generic_custom") if "normalize_builder_trade_profile_id" in globals() else str(profile.get("profile_id") or "generic_custom")
    templates: List[Dict[str, str]] = []
    for item in profile.get("custom_quantity_templates") or []:
        clean = sanitize_custom_quantity_template(item)
        if clean:
            templates.append(clean)
    for item in DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.get(profile_id, []):
        clean = sanitize_custom_quantity_template(item)
        if clean:
            templates.append(clean)
    if profile_id not in DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE:
        for item in DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.get("generic_custom", []):
            clean = sanitize_custom_quantity_template(item)
            if clean:
                templates.append(clean)
    # De-duplicate by lowercase name, keeping first/source profile preference.
    seen: set[str] = set()
    out: List[Dict[str, str]] = []
    for item in templates:
        key = item["name"].lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def custom_quantity_unit_lookup(custom_quantity_name: Any, profile: Optional[Dict[str, Any]]) -> str:
    wanted = sanitize_custom_quantity_name(custom_quantity_name).lower()
    if not wanted:
        return "Review"
    # First check the active profile templates.
    for item in custom_quantity_templates_for_profile(profile):
        if item.get("name", "").lower() == wanted:
            return canonical_builder_unit(item.get("unit") or "Review")
    # v4.3.8: CostX_Extract may contain mixed trade test/source rows while the
    # current run profile is Steel/Doors/etc. Fall back to the generic template
    # library so Formworks, Core Filling, PT Reinforcement, etc. do not show Review.
    for item in DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.get("generic_custom", []):
        if item.get("name", "").lower() == wanted:
            return canonical_builder_unit(item.get("unit") or "Review")
    # Then search all known profile template libraries.
    for items in DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.values():
        for item in items:
            if item.get("name", "").lower() == wanted:
                return canonical_builder_unit(item.get("unit") or "Review")
    return "Review"


def resolve_custom_quantity_config(current_work: Dict[str, Any], profile: Dict[str, Any], dim: Optional[Dict[str, Any]] = None) -> tuple[str, str]:
    """Resolve XGETCUSTOM quantity name and unit.

    v4.3.8.3 rule:
    - Force Default mode: the active UI/profile custom quantity is the source of truth.
    - Preserve Detected mode: a detected source XGETCUSTOM quantity is stronger than
      the active UI quantity, so duplicate dimensions such as BR01 Structural Beam
      can keep Slope Length, Steel Surface Area, and Weight as separate contexts.
    """
    dim = dim or {}
    templates = custom_quantity_templates_for_profile(profile)
    detected_name = sanitize_custom_quantity_name(dim.get("custom_quantity_name") or dim.get("custom_quantity") or "")
    costx_mode = str(current_work.get("costx_function_mode") or profile.get("recommended_function_mode") or "preserve_detected").strip().lower()
    active_name = sanitize_custom_quantity_name(
        current_work.get("custom_quantity_name")
        or current_work.get("default_custom_quantity")
        or profile.get("default_custom_quantity")
        or ""
    )
    if costx_mode != "force_default" and detected_name:
        preferred = detected_name
    else:
        preferred = sanitize_custom_quantity_name(
            active_name
            or detected_name
            or (templates[0].get("name") if templates else "")
            or "Slope Length"
        )
    template_unit = custom_quantity_unit_lookup(preferred, profile)
    current_unit = canonical_builder_unit(current_work.get("custom_quantity_unit") or current_work.get("default_custom_quantity_unit") or "")
    profile_default_name = sanitize_custom_quantity_name(profile.get("default_custom_quantity") or "")
    profile_default_unit = canonical_builder_unit(profile.get("default_custom_quantity_unit") or profile.get("default_unit") or "")
    detected_unit = canonical_builder_unit(dim.get("custom_quantity_unit") or dim.get("unit") or "")

    # Strongest rule: template for the chosen custom quantity. In Preserve Detected
    # mode, this means detected Steel Surface Area stays m2 and Weight stays t.
    for candidate in (template_unit, detected_unit, current_unit):
        text = str(candidate or "").strip()
        if text and text.lower() != "review":
            return preferred, canonical_builder_unit(text)
    if profile_default_name and preferred.lower() == profile_default_name.lower() and profile_default_unit and profile_default_unit.lower() != "review":
        return preferred, canonical_builder_unit(profile_default_unit)
    return preferred, "Review"

def normalise_xget_formula_text(value: Any) -> str:
    """Return readable CostX formula text from normal cells or openpyxl ArrayFormula objects."""
    if value is None:
        return ""
    # CostX exports often store formulas as Excel array formulas. openpyxl returns
    # an ArrayFormula object with a .text attribute; string(value) is not useful.
    try:
        array_text = getattr(value, "text", None)
        if array_text:
            txt = str(array_text).strip()
            return txt if txt.startswith("=") else f"={txt}"
    except Exception:
        pass
    try:
        txt = str(value or "").strip()
    except Exception:
        return ""
    if not txt:
        return ""
    if txt.startswith("<openpyxl."):
        return ""
    return txt



def normalize_dimension_codes(tag: str) -> str:
    """Normalise CostX dimension/type code tokens for Builder v4.2.2.

    Examples: Sp1_F2 -> SP1_F2, while mixed-case tags such as S6c_A1*
    remain protected by the existing BOQ code repair helpers.
    """
    if not isinstance(tag, str):
        return tag
    def _fix_token(m: re.Match[str]) -> str:
        token = m.group(0)
        try:
            return repair_boq_code_token(token)
        except Exception:
            # Conservative fallback: known SP prefix is commonly Speed Panel.
            return re.sub(r"^sp(?=\d)", "SP", token, flags=re.IGNORECASE)
    return re.sub(r"\b[A-Za-z]+\d+[A-Za-z]*(?:_[A-Za-z]+\d+[A-Za-z]*\*?)*\b", _fix_token, tag)



def strip_costx_zone_tokens_from_dimension(dimension_name: str) -> tuple[str, str]:
    """Strip existing CostX bracket tokens from a dimension name.

    Raw CostX workbooks may already contain names like:
    Door D01[1|Loading / BOH;3|LGF]

    v4.3.2 Builder output must not append a second token to that. Keep the clean
    dimension name and store the removed source token for the extract/report.
    """
    text = str(dimension_name or "").strip()
    source_token = ""
    # Remove one or more trailing CostX zone tokens that contain n|value parts.
    while True:
        m = re.search(r"\[(?P<token>\d+\|[^\]]+)\]\s*$", text)
        if not m:
            break
        token = sanitize_costx_token_parts(m.group("token"))
        if not token:
            break
        source_token = token if not source_token else f"{token};{source_token}"
        text = text[:m.start()].strip()
    return text or str(dimension_name or "").strip(), source_token
def parse_xget_entry(text: str, source_sheet: str = "", source_row: int = 0, source_col: str = "") -> Optional[Dict[str, Any]]:
    raw = normalise_xget_formula_text(text)
    if not raw:
        return None
    candidate = raw.lstrip("=").strip()
    if "XGET" not in candidate.upper():
        return None
    m = re.search(r'(?P<function>XGET[A-Z0-9_]+)\s*\(\s*["\'](?P<dimension>[^"\']+)["\']', candidate, re.IGNORECASE)
    if not m:
        return None
    function_name = m.group("function").upper()
    dimension_name_raw = m.group("dimension").strip()
    custom_quantity_name = ""
    if function_name == "XGETCUSTOM":
        cm = re.search(r'XGETCUSTOM\s*\(\s*["\'][^"\']+["\']\s*,\s*["\'](?P<custom>[^"\']+)["\']', candidate, re.IGNORECASE)
        if cm:
            custom_quantity_name = sanitize_custom_quantity_name(cm.group("custom"))
    dimension_name, source_zone_token = strip_costx_zone_tokens_from_dimension(dimension_name_raw)
    relationship = ""
    tag = dimension_name
    if " - " in dimension_name:
        relationship, tag = [part.strip() for part in dimension_name.split(" - ", 1)]
    # Protect known wall/type code casing, but do not aggressively change unknown tags.
    tag = normalize_dimension_codes(tag)
    dimension_normalised = f"{relationship} - {tag}" if relationship else tag
    formula = raw if raw.startswith("=") else f"={candidate}"
    return {
        "function": function_name,
        "dimension": dimension_name,
        "dimension_raw": dimension_name_raw,
        "source_zone_token": source_zone_token,
        "dimension_normalised": dimension_normalised,
        "relationship": relationship,
        "tag": tag,
        "unit": builder_unit_for_function(function_name),
        "custom_quantity_name": custom_quantity_name,
        "formula": formula,
        "source_sheet": source_sheet,
        "source_row": source_row,
        "source_col": source_col,
        "source_value": raw,
    }




def is_builder_source_sheet_ignored(sheet_name: str) -> bool:
    """Ignore instruction/expected/report sheets when learning source dimensions."""
    name = re.sub(r"\s+", "_", str(sheet_name or "").strip().lower())
    ignored_prefixes = (
        "readme", "expected", "qa", "checklist", "profile_qa", "jarvis_builder_report", "ignore",
        "builder_base", "level_zone_setup", "costx_extract", "custom_quantity_library"
    )
    return any(name.startswith(prefix) for prefix in ignored_prefixes)


def is_placeholder_dimension_name(name: Any) -> bool:
    text = str(name or "").strip().lower()
    if not text:
        return True
    placeholders = {"dimension", "dimension group", "dimension[token]", "dimension group name", "dim", "name"}
    if text in placeholders:
        return True
    if "dimension[token]" in text or "dimension group name" in text:
        return True
    return False


def infer_costx_function_from_uom_and_measurement(uom: Any, measurement_type: Any = "") -> str:
    mtype = str(measurement_type or "").strip().lower()
    unit = canonical_builder_unit(uom or "").lower()
    if "custom" in mtype:
        return "XGETCUSTOM"
    if unit == "m2":
        return "XGETAREA"
    if unit == "m3":
        return "XGETVOLUME"
    if unit == "m":
        return "XGETLENGTH"
    if unit == "no":
        return "XGETCOUNT"
    if unit in {"kg", "t"}:
        return "XGETCUSTOM"
    return "XGETCUSTOM" if "custom" in mtype else "XGETAREA"


def extract_structured_costx_dimension_entries(wb: Any) -> List[Dict[str, Any]]:
    """Read CostX dimension group export tables that do not contain XGET formulas.

    Supports sheets with headers such as Folder, Dimension Group, Quantity, UOM,
    Measurement Type, ZC1, ZC3, etc. This prevents Jarvis from depending on
    Expected_* test sheets and allows real CostX Dimension Group exports.
    """
    entries: List[Dict[str, Any]] = []
    for ws in wb.worksheets:
        if is_builder_source_sheet_ignored(ws.title):
            continue
        header_row = None
        headers: Dict[str, int] = {}
        max_scan = min(ws.max_row or 0, 20)
        for r in range(1, max_scan + 1):
            row_headers: Dict[str, int] = {}
            for c in range(1, min(ws.max_column or 0, 80) + 1):
                raw = ws.cell(r, c).value
                key = re.sub(r"[^a-z0-9]+", "_", str(raw or "").strip().lower()).strip("_")
                if key:
                    row_headers[key] = c
            if "dimension_group" in row_headers or ("name" in row_headers and "uom" in row_headers):
                header_row = r
                headers = row_headers
                break
        if not header_row:
            continue
        dim_col = headers.get("dimension_group") or headers.get("name")
        uom_col = headers.get("uom") or headers.get("unit")
        folder_col = headers.get("folder") or headers.get("trade") or headers.get("section")
        mtype_col = headers.get("measurement_type") or headers.get("type")
        if not dim_col:
            continue
        for r in range(header_row + 1, min(ws.max_row or 0, 20000) + 1):
            dim_raw = ws.cell(r, dim_col).value
            if is_placeholder_dimension_name(dim_raw):
                continue
            dimension_name, source_zone_token = strip_costx_zone_tokens_from_dimension(str(dim_raw).strip())
            if is_placeholder_dimension_name(dimension_name):
                continue
            uom = canonical_builder_unit(ws.cell(r, uom_col).value if uom_col else "")
            measurement_type = ws.cell(r, mtype_col).value if mtype_col else ""
            folder = str(ws.cell(r, folder_col).value or "").strip() if folder_col else ""
            function_name = infer_costx_function_from_uom_and_measurement(uom, measurement_type)
            relationship = folder or "Structured Export"
            tag = normalize_dimension_codes(dimension_name)
            entries.append({
                "function": function_name,
                "dimension": dimension_name,
                "dimension_raw": str(dim_raw).strip(),
                "source_zone_token": source_zone_token,
                "dimension_normalised": tag,
                "relationship": relationship,
                "tag": tag,
                "unit": uom or builder_unit_for_function(function_name),
                "custom_quantity_name": "",
                "formula": "",
                "source_sheet": ws.title,
                "source_row": r,
                "source_col": "structured",
                "source_value": str(dim_raw).strip(),
                "source_type": "structured_dimension_export",
            })
    return entries

def extract_costx_xget_entries(source: Path, scan_limit_rows: int = 20000) -> Dict[str, Any]:
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    wb = load_workbook(source, data_only=False, read_only=False)
    entries: List[Dict[str, Any]] = []
    scanned_cells = 0
    ignored_sheets: List[str] = []
    for ws in wb.worksheets:
        if is_builder_source_sheet_ignored(ws.title):
            ignored_sheets.append(ws.title)
            continue
        max_row = min(ws.max_row or 0, scan_limit_rows)
        for row in ws.iter_rows(min_row=1, max_row=max_row):
            for cell in row:
                scanned_cells += 1
                value = getattr(cell, "value", None)
                if value in (None, ""):
                    continue
                text = normalise_xget_formula_text(value)
                if "XGET" not in text.upper():
                    continue
                parsed = parse_xget_entry(text, ws.title, int(cell.row), get_column_letter(int(cell.column)))
                if parsed and not is_placeholder_dimension_name(parsed.get("dimension_normalised") or parsed.get("dimension")):
                    entries.append(parsed)
    # Add structured CostX export rows. These are used when the workbook is a
    # Dimension Group export without live XGET formula cells.
    structured_entries = extract_structured_costx_dimension_entries(wb)
    entries.extend(structured_entries)

    groups: Dict[str, int] = {}
    functions: Dict[str, int] = {}
    source_types: Dict[str, int] = {}
    for item in entries:
        groups[item.get("relationship") or "Ungrouped"] = groups.get(item.get("relationship") or "Ungrouped", 0) + 1
        functions[item.get("function") or "XGET"] = functions.get(item.get("function") or "XGET", 0) + 1
        source_types[item.get("source_type") or "formula"] = source_types.get(item.get("source_type") or "formula", 0) + 1
    return {
        "entries": entries,
        "groups": groups,
        "functions": functions,
        "source_types": source_types,
        "ignored_sheets": ignored_sheets,
        "scanned_cells": scanned_cells,
    }




# -----------------------------
# Jarvis v4.3.2 Project-Learned Trade Output Layouts + Builder Base Sheet helpers
# -----------------------------

DEFAULT_BUILDER_LEVELS = [
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "B2", "description": "Basement 2 (MH-B2-001-02 to MH-B2-005-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "B3", "description": "Basement 3 (MH-B3-001-02 to MH-B3-004-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "LGF", "description": "Lower Ground Floor (MH-B1-001-02 to MH-B1-009-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "GF", "description": "Ground Floor (MH-L0-001-03 to MH-L0-010-03)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L1", "description": "Level 1 (MH-L1-001-02 to MH-L1-009-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L2", "description": "Level 2 (MH-L2-001-02 to MH-L2-005-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L3", "description": "Level 3 (MH-L3-001-02 to MH-L3-005-02)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L4", "description": "Level 4 (MH-L4-001-01 to MH-L4-005-01)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L5", "description": "Level 5 (MH-L5-001-01 to MH-L5-005-01)"},
    {"zone_index": 1, "zone_name": "Milestone 2", "level_index": 3, "level_code": "L6", "description": "Level 6 (MH-L6-001-01 to MH-L6-003-01)"},
]


DEFAULT_BUILDER_ZONE_LIBRARY = [
    {"category_index": 1, "category_name": "Milestone / Stage", "value_code": "Milestone 1", "description": "Construction of Stage 1"},
    {"category_index": 1, "category_name": "Milestone / Stage", "value_code": "Milestone 1b", "description": "Construction of Stage 1"},
    {"category_index": 1, "category_name": "Milestone / Stage", "value_code": "Milestone 2", "description": "Construction of Stage 2"},
    {"category_index": 3, "category_name": "Level", "value_code": "B3", "description": "Basement 3"},
    {"category_index": 3, "category_name": "Level", "value_code": "B2", "description": "Basement 2"},
    {"category_index": 3, "category_name": "Level", "value_code": "LGF", "description": "Lower Ground Floor"},
    {"category_index": 3, "category_name": "Level", "value_code": "GF", "description": "Ground Floor"},
    {"category_index": 3, "category_name": "Level", "value_code": "L1", "description": "Level 1"},
    {"category_index": 3, "category_name": "Level", "value_code": "L2", "description": "Level 2"},
    {"category_index": 3, "category_name": "Level", "value_code": "L3", "description": "Level 3"},
    {"category_index": 3, "category_name": "Level", "value_code": "L4", "description": "Level 4"},
    {"category_index": 3, "category_name": "Level", "value_code": "L5", "description": "Level 5"},
    {"category_index": 3, "category_name": "Level", "value_code": "L6", "description": "Level 6"},
    {"category_index": 5, "category_name": "Internal / External", "value_code": "internal", "description": "internal"},
    {"category_index": 5, "category_name": "Internal / External", "value_code": "external", "description": "external"},
    {"category_index": 7, "category_name": "Door Type", "value_code": "Double Leaf Fire Rated", "description": "Double Leaf Fire Rated"},
    {"category_index": 7, "category_name": "Door Type", "value_code": "Double Leaf Solid Core", "description": "Double Leaf Solid Core"},
    {"category_index": 7, "category_name": "Door Type", "value_code": "Single Leaf Solid Core", "description": "Single Leaf Solid Core"},
    {"category_index": 7, "category_name": "Door Type", "value_code": "Single Leaf Fire Rated", "description": "Single Leaf Fire Rated"},
]


DEFAULT_BUILDER_ACTIVE_CATEGORIES = [
    {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
    {"category_index": 2, "category_name": "Area / System / Package", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
    {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
    {"category_index": 4, "category_name": "Height / Depth / Range", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
    {"category_index": 5, "category_name": "Location / Internal / External", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
    {"category_index": 6, "category_name": "Strength / Material / Bar Type", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
    {"category_index": 7, "category_name": "Door / Window / Reo Type", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
    {"category_index": 8, "category_name": "Optional", "active": False, "behavior": "choosable", "default_value": "", "locked_source": ""},
]

DEFAULT_BUILDER_ZONE_COMBOS = [
    {
        "combo_id": "walls_milestone_2_by_level",
        "combo_name": "Walls - Milestone 2 by Level",
        "description": "Use ZC1 as a global milestone and ZC3 as the locked builder row level.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
        ],
    },
    {
        "combo_id": "walls_milestone_1_by_level",
        "combo_name": "Walls - Milestone 1 by Level",
        "description": "Use ZC1 Milestone 1 and ZC3 levels only.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 1", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
        ],
    },
    {
        "combo_id": "doors_milestone_1_by_level_classification",
        "combo_name": "Doors - Milestone 1 by Level + Classification",
        "description": "Use ZC1 Milestone 1, locked ZC3 levels, and a row dropdown for ZC5 classification.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 1", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
            {"category_index": 5, "category_name": "Location / Internal / External", "active": True, "behavior": "choosable", "default_value": "", "locked_source": ""},
        ],
    },
    {
        "combo_id": "metalwork_milestone_2_by_level_item_type",
        "combo_name": "Metalwork - Milestone 2 by Level + Item Type",
        "description": "Use ZC1 Milestone 2, locked ZC3 levels, and optional ZC7 item/member type.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
            {"category_index": 7, "category_name": "Door / Window / Reo Type", "active": True, "behavior": "choosable", "default_value": "", "locked_source": ""},
        ],
    },
    {
        "combo_id": "concrete_reo_milestone_2_by_level_reo_type",
        "combo_name": "Concrete/Reo - Milestone 2 by Level + Type",
        "description": "Use ZC1 Milestone 2, locked ZC3 levels, optional ZC6 strength/material/bar type, and optional ZC7 reo/product type.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
            {"category_index": 6, "category_name": "Strength / Material / Bar Type", "active": True, "behavior": "choosable", "default_value": "", "locked_source": ""},
            {"category_index": 7, "category_name": "Door / Window / Reo Type", "active": True, "behavior": "choosable", "default_value": "", "locked_source": ""},
        ],
    },
    {
        "combo_id": "finishes_milestone_2_by_level",
        "combo_name": "Finishes - Milestone 2 by Level",
        "description": "Use ZC1 Milestone 2 and locked ZC3 levels for finish items.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
        ],
    },
    {
        "combo_id": "joinery_milestone_2_by_level",
        "combo_name": "Joinery - Milestone 2 by Level",
        "description": "Use ZC1 Milestone 2 and locked ZC3 levels for joinery items.",
        "active_categories": [
            {"category_index": 1, "category_name": "Stage / Milestone", "active": True, "behavior": "global", "default_value": "Milestone 2", "locked_source": ""},
            {"category_index": 3, "category_name": "Level", "active": True, "behavior": "locked", "default_value": "", "locked_source": "level_code"},
        ],
    },

]


DEFAULT_BUILDER_TRADE_PROFILES = [
    {
        "profile_id": "walls_partitions",
        "display_name": "Walls / Partitions",
        "description": "Wall and partition dimension groups as Head4, with level rows below each wall type.",
        "default_costx_function": "XGETWALLAREA",
        "default_unit": "m2",
        "recommended_combo_id": "walls_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: Dimension Group / Wall Type as Head4, with ZC3 level rows below.",
        "zones_rule": "ZC1 Global stage/milestone + ZC3 Locked from Builder Row Level Code.",
        "future_notes": "Later add wall description libraries, fire/acoustic/thermal templates, and wall-type grouping rules.",
    },
    {
        "profile_id": "doors_windows",
        "display_name": "Doors / Windows",
        "description": "Door/window schedule profile. Project-learned rule: level-first with door/window item rows below each level.",
        "default_costx_function": "XGETCOUNT",
        "default_unit": "no",
        "recommended_combo_id": "doors_milestone_1_by_level_classification",
        "recommended_function_mode": "force_default",
        "recommended_formula_mode": "Compact",
        "layout_mode": "level_first_items_below",
        "layout_rule": "Level-first: each Builder level becomes a Head4, then door/window dimension items below that level.",
        "zones_rule": "ZC1 Global stage/milestone + ZC3 Locked level + optional ZC5/ZC7 classification dropdowns.",
        "future_notes": "Confirmed by user: Doors and Windows use level-first layout. Add classification mapping later when real CostX samples are available.",
    },
    {
        "profile_id": "doors",
        "display_name": "Doors",
        "description": "Door schedule profile, count-based and level-first.",
        "default_costx_function": "XGETCOUNT",
        "default_unit": "no",
        "recommended_combo_id": "doors_milestone_1_by_level_classification",
        "recommended_function_mode": "force_default",
        "recommended_formula_mode": "Compact",
        "layout_mode": "level_first_items_below",
        "layout_rule": "Level-first: Level as Head4, door type/item rows below.",
        "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC5/ZC7 for classification/door type.",
        "future_notes": "Use when door formulas and schedule items are separated from windows.",
    },
    {
        "profile_id": "windows",
        "display_name": "Windows",
        "description": "Window schedule profile, count-based and level-first.",
        "default_costx_function": "XGETCOUNT",
        "default_unit": "no",
        "recommended_combo_id": "doors_milestone_1_by_level_classification",
        "recommended_function_mode": "force_default",
        "recommended_formula_mode": "Compact",
        "layout_mode": "level_first_items_below",
        "layout_rule": "Level-first: Level as Head4, window type/item rows below.",
        "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC5/ZC7 for classification/window type.",
        "future_notes": "Use when window schedule items are separated from doors.",
    },
    {
        "profile_id": "metalwork_structural_steel",
        "display_name": "Metalwork / Structural Steel",
        "description": "Metalwork, framing and steel member profiles with mixed units depending on member/item type.",
        "default_costx_function": "XGETCUSTOM",
        "default_unit": "m",
        "default_custom_quantity": "Slope Length",
        "default_custom_quantity_unit": "m",
        "custom_quantity_templates": DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.get("metalwork_structural_steel", []),
        "recommended_combo_id": "metalwork_milestone_2_by_level_item_type",
        "recommended_function_mode": "force_default",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: category/member item as Head4 with level rows below. Preserve detected functions where available.",
        "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC7 member/item type.",
        "future_notes": "v4.3.7 supports XGETCUSTOM steel templates such as Slope Length, Steel Surface Area and Weight. Use live CostX XGETCUSTOM formulas with the active item name, active zone token and selected custom quantity.",
    },
    {
        "profile_id": "concrete_reo",
        "display_name": "Concrete / Reo",
        "description": "Concrete and reinforcement workflow; conservative because reo often uses custom CostX exports and metadata.",
        "default_costx_function": "XGETCUSTOM",
        "default_unit": "m2",
        "default_custom_quantity": "Formworks",
        "default_custom_quantity_unit": "m2",
        "custom_quantity_templates": DEFAULT_CUSTOM_QUANTITY_TEMPLATES_BY_PROFILE.get("concrete_reo", []),
        "recommended_combo_id": "concrete_reo_milestone_2_by_level_reo_type",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "conservative_structural",
        "layout_rule": "Conservative structural: keep item-first base for now. Future mode should support Level > Pour/Element > Bar/Product type.",
        "zones_rule": "ZC1 Global + ZC3 Locked level + optional ZC6 strength/material/bar type and ZC7 reo type.",
        "future_notes": "v4.3.7 supports conservative XGETCUSTOM templates from user samples: Formworks, Reinforcement by Ratio, PT Reinforcement, Core Filling and Slab Thickness. Keep structural/reo outputs for review until more samples are provided.",
    },
    {
        "profile_id": "finishes",
        "display_name": "Finishes",
        "description": "Floor, wall, ceiling finishes, waterproofing, plastering, tiling, vinyl and carpet profiles.",
        "default_costx_function": "XGETAREA",
        "default_unit": "m2",
        "recommended_combo_id": "finishes_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: finish type/item as Head4 with level rows below; preserve detected functions where source uses length/count.",
        "zones_rule": "ZC1 Global + ZC3 Locked level; optional ZC5 for internal/external/wet-area classification.",
        "future_notes": "Later support mixed-unit finish schedules and finish-subtype grouping.",
    },
    {
        "profile_id": "ceilings",
        "display_name": "Ceilings",
        "description": "Ceiling finish and ceiling item profile, usually item-first with level rows.",
        "default_costx_function": "XGETAREA",
        "default_unit": "m2",
        "recommended_combo_id": "finishes_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: ceiling finish/item as Head4 with level rows below.",
        "zones_rule": "ZC1 Global + ZC3 Locked level.",
        "future_notes": "Later support ceiling trims, bulkheads, access panels and mixed m/m2/no units.",
    },
    {
        "profile_id": "joinery",
        "display_name": "Joinery / FFE",
        "description": "Joinery and FFE item-code based profile, typically count-based with levels below each item.",
        "default_costx_function": "XGETCOUNT",
        "default_unit": "no",
        "recommended_combo_id": "joinery_milestone_2_by_level",
        "recommended_function_mode": "force_default",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: joinery/FFE item code or description as Head4, levels below, default unit no",
        "zones_rule": "ZC1 Global + ZC3 Locked level. Optional ZC7 for joinery/FFE type later.",
        "future_notes": "Later add joinery code/description library and schedule-specific grouping.",
    },
    {
        "profile_id": "civil_earthworks",
        "display_name": "Civil / Earthworks",
        "description": "Civil, earthworks and external works profile with mixed sections and mixed units.",
        "default_costx_function": "XGETAREA",
        "default_unit": "m2 / m3 / m / no / t for review",
        "recommended_combo_id": "finishes_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "mixed_section_driven",
        "layout_rule": "Mixed section-driven: preserve simple item-first base, but mark output for manual section review.",
        "zones_rule": "ZC1 Global + ZC3 Locked level where applicable; optional zones only when needed.",
        "future_notes": "Needs separate civil/earthworks profile rules for excavation, pavements, drainage and external works.",
    },
    {
        "profile_id": "demolition",
        "display_name": "Demolition",
        "description": "Demolition profile with section-driven items and mixed units.",
        "default_costx_function": "XGETAREA",
        "default_unit": "m2 / m / no for review",
        "recommended_combo_id": "finishes_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "mixed_section_driven",
        "layout_rule": "Mixed section-driven: use item-first base for formula generation and flag for manual BOQ section review.",
        "zones_rule": "ZC1 Global + ZC3 Locked level where applicable.",
        "future_notes": "Later support demolition scope categories and exclusions.",
    },
    {
        "profile_id": "landscape",
        "display_name": "Landscape",
        "description": "Landscape and external finishes profile with mixed units but usually item-first with levels/areas.",
        "default_costx_function": "XGETAREA",
        "default_unit": "m2 / m / no for review",
        "recommended_combo_id": "finishes_milestone_2_by_level",
        "recommended_function_mode": "preserve_detected",
        "recommended_formula_mode": "Compact",
        "layout_mode": "item_first_levels_below",
        "layout_rule": "Item-first: landscape/external finish item as Head4 with level/area rows below.",
        "zones_rule": "ZC1 Global + ZC3 Locked level/area where applicable.",
        "future_notes": "Later support external zones, landscape areas and civil handoff.",
    },
]





def normalize_trade_layout_mode(value: Any, default: str = "item_first_levels_below") -> str:
    raw = str(value or "").strip().lower().replace(" ", "_").replace("-", "_")
    alias = {
        "item_first": "item_first_levels_below",
        "item_first_levels_below": "item_first_levels_below",
        "head4_then_levels": "item_first_levels_below",
        "level_first": "level_first_items_below",
        "level_first_items_below": "level_first_items_below",
        "levels_then_items": "level_first_items_below",
        "mixed": "mixed_section_driven",
        "mixed_section": "mixed_section_driven",
        "mixed_section_driven": "mixed_section_driven",
        "section_driven": "mixed_section_driven",
        "structural": "conservative_structural",
        "conservative_structural": "conservative_structural",
        "conservative": "conservative_structural",
    }
    normalized = alias.get(raw, raw)
    valid = {"item_first_levels_below", "level_first_items_below", "mixed_section_driven", "conservative_structural"}
    return normalized if normalized in valid else default

def trade_layout_label(layout_mode: str) -> str:
    return {
        "item_first_levels_below": "Item-first: item/description Head4 with level rows below",
        "level_first_items_below": "Level-first: level Head4 with item rows below",
        "mixed_section_driven": "Mixed section-driven: keep output conservative for review",
        "conservative_structural": "Conservative structural/reo: keep output conservative for review",
    }.get(normalize_trade_layout_mode(layout_mode), "Item-first: item/description Head4 with level rows below")
def sanitize_builder_trade_profiles(profiles: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    safe: List[Dict[str, Any]] = []
    seen: set[str] = set()
    incoming = profiles if isinstance(profiles, list) and profiles else DEFAULT_BUILDER_TRADE_PROFILES
    for item in incoming:
        if not isinstance(item, dict):
            continue
        profile_id = re.sub(r"[^A-Za-z0-9_-]+", "_", str(item.get("profile_id", "") or item.get("id", "") or item.get("display_name", "")).strip().lower()).strip("_")
        if not profile_id or profile_id in seen:
            continue
        seen.add(profile_id)
        base_profile = next((bp for bp in DEFAULT_BUILDER_TRADE_PROFILES if re.sub(r"[^A-Za-z0-9_-]+", "_", str(bp.get("profile_id", "") or bp.get("display_name", "")).strip().lower()).strip("_") == profile_id), {})
        display = re.sub(r'[\r\n]+', ' ', str(item.get("display_name", "") or item.get("name", "") or base_profile.get("display_name") or profile_id.replace("_", " ")).strip())
        combo_id = re.sub(r"[^A-Za-z0-9_-]+", "_", str(item.get("recommended_combo_id", "") or base_profile.get("recommended_combo_id") or "walls_milestone_2_by_level")).strip("_")
        safe.append({
            "profile_id": profile_id,
            "display_name": display or profile_id,
            "description": re.sub(r'[\r\n]+', ' ', str(item.get("description", "") or base_profile.get("description", "") or "").strip()),
            "default_costx_function": sanitize_costx_function(item.get("default_costx_function") or base_profile.get("default_costx_function") or "XGETWALLAREA", "XGETWALLAREA"),
            "default_unit": re.sub(r'[\r\n]+', ' ', str(item.get("default_unit", "") or base_profile.get("default_unit") or "Review").strip()),
            "default_custom_quantity": sanitize_custom_quantity_name(item.get("default_custom_quantity") or item.get("custom_quantity_name") or base_profile.get("default_custom_quantity") or ""),
            "default_custom_quantity_unit": canonical_builder_unit(item.get("default_custom_quantity_unit") or item.get("custom_quantity_unit") or base_profile.get("default_custom_quantity_unit") or ""),
            "custom_quantity_templates": custom_quantity_templates_for_profile({**base_profile, **item, "profile_id": profile_id}),
            "recommended_combo_id": combo_id,
            "recommended_function_mode": "force_default" if str(item.get("recommended_function_mode", base_profile.get("recommended_function_mode", ""))).lower() == "force_default" else "preserve_detected",
            "recommended_formula_mode": "Full" if str(item.get("recommended_formula_mode", base_profile.get("recommended_formula_mode", "Compact"))).lower() == "full" else "Compact",
            "layout_mode": normalize_trade_layout_mode(item.get("layout_mode") or item.get("output_layout") or item.get("layout") or base_profile.get("layout_mode"), "item_first_levels_below"),
            "layout_rule": re.sub(r'[\r\n]+', ' ', str(item.get("layout_rule", "") or base_profile.get("layout_rule", "") or "").strip()),
            "zones_rule": re.sub(r'[\r\n]+', ' ', str(item.get("zones_rule", "") or base_profile.get("zones_rule", "") or "").strip()),
            "future_notes": re.sub(r'[\r\n]+', ' ', str(item.get("future_notes", "") or base_profile.get("future_notes", "") or "").strip()),
        })
    if profiles:
        for item in DEFAULT_BUILDER_TRADE_PROFILES:
            profile_id = re.sub(r"[^A-Za-z0-9_-]+", "_", str(item.get("profile_id", "") or item.get("display_name", "")).strip().lower()).strip("_")
            if profile_id and profile_id not in seen:
                safe.append(dict(item))
                seen.add(profile_id)
    return safe or [dict(p) for p in DEFAULT_BUILDER_TRADE_PROFILES]


def normalize_zone_behavior(value: Any, idx: int) -> str:
    raw = str(value or "").strip().lower().replace(" ", "_").replace("-", "_")
    if raw in {"global", "global_value"}:
        return "global"
    if raw in {"locked", "locked_from_level_row", "locked_level_row", "locked_from_row"}:
        return "locked"
    if raw in {"choosable", "optional", "dropdown", "row_dropdown", "optional_row_dropdown"}:
        return "choosable"
    if idx == 1:
        return "global"
    if idx == 3:
        return "locked"
    return "choosable"


def zone_behavior_label(behavior: str) -> str:
    b = normalize_zone_behavior(behavior, 0)
    return {"global": "Global", "locked": "Locked", "choosable": "Choosable"}.get(b, "Choosable")


def sanitize_builder_active_categories(categories: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    by_idx: Dict[int, Dict[str, Any]] = {int(default["category_index"]): dict(default) for default in DEFAULT_BUILDER_ACTIVE_CATEGORIES}
    for item in categories or []:
        if not isinstance(item, dict):
            continue
        try:
            idx = int(item.get("category_index", 0) or 0)
        except Exception:
            continue
        if idx < 1 or idx > 8:
            continue
        base = by_idx.get(idx, {})
        name = re.sub(r'["\[\]\r\n;]+', ' ', str(item.get("category_name", "") or base.get("category_name") or f"Zone Category {idx}")).strip()
        default_value = re.sub(r'["\[\]\r\n;]+', ' ', str(item.get("default_value", "") or item.get("global_value", "") or "")).strip()
        behavior = normalize_zone_behavior(item.get("behavior") or item.get("role") or base.get("behavior"), idx)
        locked_source = str(item.get("locked_source", "") or ("level_code" if idx == 3 else "")).strip()
        active = bool(item.get("active", False))
        # Always keep locked level safe when ZC3 is active.
        if idx == 3 and active:
            behavior = "locked"
            locked_source = "level_code"
        by_idx[idx] = {
            "category_index": idx,
            "category_name": name or f"Zone Category {idx}",
            "active": active,
            "behavior": behavior,
            "default_value": default_value,
            "locked_source": locked_source,
            "role": zone_behavior_label(behavior),
        }
    out = []
    for idx in range(1, 9):
        row = by_idx[idx]
        behavior = normalize_zone_behavior(row.get("behavior"), idx)
        row["behavior"] = behavior
        row["role"] = zone_behavior_label(behavior)
        if behavior != "global":
            row["default_value"] = ""
        if behavior == "locked" and idx == 3:
            row["locked_source"] = "level_code"
        out.append(row)
    return out


def combo_id_from_name(name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", str(name or "").strip().lower()).strip("_")
    return base or "zone_combo"


def sanitize_builder_zone_combos(combos: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    safe: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for item in combos or []:
        if not isinstance(item, dict):
            continue
        combo_name = re.sub(r'[\r\n]+', ' ', str(item.get("combo_name", "") or item.get("name", "") or "")).strip()
        if not combo_name:
            continue
        combo_id = re.sub(r"[^A-Za-z0-9_-]+", "_", str(item.get("combo_id", "") or combo_id_from_name(combo_name))).strip("_") or combo_id_from_name(combo_name)
        if combo_id in seen:
            continue
        seen.add(combo_id)
        cats = sanitize_builder_active_categories(item.get("active_categories") or item.get("categories"))
        # Keep only active categories in combo storage, but sanitized with behavior.
        cats = [cat for cat in cats if cat.get("active")]
        if not cats:
            continue
        desc = re.sub(r'[\r\n]+', ' ', str(item.get("description", "") or "")).strip()
        safe.append({"combo_id": combo_id, "combo_name": combo_name, "description": desc, "active_categories": cats})
    if not safe:
        return [dict(combo) for combo in DEFAULT_BUILDER_ZONE_COMBOS]
    # Ensure core defaults are available for new installs unless user removed all deliberately.
    existing = {c["combo_id"] for c in safe}
    for combo in DEFAULT_BUILDER_ZONE_COMBOS:
        if combo["combo_id"] not in existing:
            safe.append(dict(combo))
    return safe


def sanitize_costx_token_parts(token_parts: str) -> str:
    """Clean a CostX bracket token without forcing all ZC1-ZC8 categories."""
    raw = str(token_parts or "").strip().strip("[]")
    if not raw:
        return ""
    cleaned_parts: List[str] = []
    for part in raw.split(";"):
        if "|" not in part:
            continue
        left, right = part.split("|", 1)
        try:
            idx = int(str(left).strip())
        except Exception:
            continue
        if idx < 1 or idx > 8:
            continue
        value = re.sub(r'["\[\]\r\n;]+', ' ', str(right or '')).strip()
        if not value:
            continue
        cleaned_parts.append(f"{idx}|{value}")
    return ";".join(cleaned_parts)


def sanitize_builder_zone_library(zones: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """Sanitize CostX zone values remembered by Jarvis.

    This is a library only; it does not automatically force all zones into formulas.
    """
    safe: List[Dict[str, Any]] = []
    for item in zones or []:
        if not isinstance(item, dict):
            continue
        try:
            category_index = int(item.get("category_index", 1) or 1)
        except Exception:
            category_index = 1
        if category_index < 1 or category_index > 8:
            continue
        category_name = str(item.get("category_name", "") or f"Zone Category {category_index}").strip()
        value_code = str(item.get("value_code", "") or item.get("name", "") or "").strip()
        description = str(item.get("description", "") or "").strip()
        if not value_code:
            continue
        category_name = re.sub(r'["\[\]\r\n;]+', ' ', category_name).strip()
        value_code = re.sub(r'["\[\]\r\n;]+', ' ', value_code).strip()
        description = re.sub(r'[\r\n]+', ' ', description).strip()
        safe.append({
            "category_index": category_index,
            "category_name": category_name or f"Zone Category {category_index}",
            "value_code": value_code,
            "description": description or value_code,
        })
    return safe or [dict(zone) for zone in DEFAULT_BUILDER_ZONE_LIBRARY]


def sanitize_builder_levels(levels: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """Sanitize editable builder output rows.

    v4.3.2 supports behavior-driven token_parts, so a row can use any compact CostX zone
    combination without requiring all eight zone categories.
    """
    safe: List[Dict[str, Any]] = []
    for item in levels or []:
        if not isinstance(item, dict):
            continue
        try:
            zone_index = int(item.get("zone_index", 1) or 1)
        except Exception:
            zone_index = 1
        try:
            level_index = int(item.get("level_index", 3) or 3)
        except Exception:
            level_index = 3
        zone_name = str(item.get("zone_name", "") or "").strip() or "Milestone 2"
        level_code = str(item.get("level_code", "") or "").strip()
        description = str(item.get("description", "") or item.get("level_description", "") or "").strip()
        token_parts = sanitize_costx_token_parts(str(item.get("token_parts", "") or ""))
        if not token_parts:
            if not level_code:
                continue
            zone_name = re.sub(r'["\[\]\r\n]+', ' ', zone_name).strip()
            level_code = re.sub(r'["\[\]\r\n;]+', ' ', level_code).strip()
            token_parts = sanitize_costx_token_parts(f"{zone_index}|{zone_name};{level_index}|{level_code}")
        else:
            parts = token_parts.split(";")
            if parts:
                first = parts[0].split("|", 1)
                if len(first) == 2:
                    try: zone_index = int(first[0])
                    except Exception: pass
                    zone_name = first[1] or zone_name
            if len(parts) > 1:
                # v4.4.4.11: compact project tokens can include several hierarchy
                # zones before the level token. Use the final token as the level
                # index/code unless the row explicitly supplied a level_code.
                last = parts[-1].split("|", 1)
                if len(last) == 2:
                    try: level_index = int(last[0])
                    except Exception: pass
                    if not level_code:
                        level_code = last[1] or level_code
        description = re.sub(r'[\r\n]+', ' ', description).strip() or level_code or token_parts
        row_payload = {
            "zone_index": zone_index,
            "zone_name": zone_name,
            "level_index": level_index,
            "level_code": level_code,
            "description": description,
            "token_parts": token_parts,
        }
        if item.get("run_only"):
            row_payload["run_only"] = True
        if item.get("head3_group"):
            row_payload["head3_group"] = str(item.get("head3_group") or "").strip()
        if item.get("head4_suffix"):
            row_payload["head4_suffix"] = str(item.get("head4_suffix") or "").strip()
        if item.get("dimension_suffix"):
            row_payload["dimension_suffix"] = str(item.get("dimension_suffix") or "").strip()
        if isinstance(item.get("hierarchy_path"), list):
            row_payload["hierarchy_path"] = item.get("hierarchy_path")
        safe.append(row_payload)
    return safe or [dict(level, token_parts=f"{level['zone_index']}|{level['zone_name']};{level['level_index']}|{level['level_code']}") for level in DEFAULT_BUILDER_LEVELS]





def normalize_builder_trade_profile_id(value: Any, default: str = "walls_partitions") -> str:
    """Normalize saved/display trade profile values to stable profile IDs.

    Older UI saves may contain display labels like 'Walls / Partitions' in
    trade_profile_id. The frontend select uses profile_id values, so leaving the
    display label causes a blank selected dropdown.
    """
    raw = str(value or "").strip()
    if not raw:
        return default
    key = re.sub(r"[^a-z0-9]+", "_", raw.lower()).strip("_")
    alias = {
        "walls_partitions": "walls_partitions",
        "walls": "walls_partitions",
        "partitions": "walls_partitions",
        "doors_windows": "doors_windows",
        "doors_and_windows": "doors_windows",
        "door_window": "doors_windows",
        "doors": "doors",
        "door": "doors",
        "windows": "windows",
        "window": "windows",
        "metalwork_structural_steel": "metalwork_structural_steel",
        "metalwork": "metalwork_structural_steel",
        "structural_steel": "metalwork_structural_steel",
        "steel": "metalwork_structural_steel",
        "concrete_reo": "concrete_reo",
        "concrete": "concrete_reo",
        "reo": "concrete_reo",
        "reinforcement": "concrete_reo",
        "finishes": "finishes",
        "floor_finishes": "finishes",
        "external_finishes": "finishes",
        "internal_finishes": "finishes",
        "ceiling": "ceilings",
        "ceilings": "ceilings",
        "joinery": "joinery",
        "ffe": "joinery",
        "civil": "civil_earthworks",
        "earthworks": "civil_earthworks",
        "civil_earthworks": "civil_earthworks",
        "demolition": "demolition",
        "landscape": "landscape",
    }
    normalized = alias.get(key, key)
    valid_ids = {str(p.get("profile_id")) for p in DEFAULT_BUILDER_TRADE_PROFILES}
    return normalized if normalized in valid_ids else default



def default_trade_profile_by_id(profile_id: Any) -> Dict[str, Any]:
    normalized = normalize_builder_trade_profile_id(profile_id, "walls_partitions")
    return next((p for p in DEFAULT_BUILDER_TRADE_PROFILES if normalize_builder_trade_profile_id(p.get("profile_id"), "walls_partitions") == normalized), DEFAULT_BUILDER_TRADE_PROFILES[0])


def expected_unit_for_profile_function(function_name: Any, profile: Optional[Dict[str, Any]] = None, raw_expected: Any = None) -> str:
    """Resolve expected unit without allowing stale UI/profile state.

    v4.3.7 rule: count functions always report lowercase `no`; profile default
    units are used only when they do not conflict with the active function.
    """
    func = sanitize_costx_function(function_name or (profile or {}).get("default_costx_function") or "XGETWALLAREA", "XGETWALLAREA")
    # Function mapping is the strongest guard because output formulas follow the function.
    mapped = builder_unit_for_function(func)
    if func in {"XGETCOUNT", "XGETNUMBER"} or "COUNT" in func or "NUMBER" in func:
        return "no"
    profile_unit = canonical_builder_unit((profile or {}).get("default_unit") or "")
    raw_unit = canonical_builder_unit(raw_expected or "")
    if func == "XGETCUSTOM":
        custom_unit = canonical_builder_unit((profile or {}).get("default_custom_quantity_unit") or "")
        # For XGETCUSTOM, the selected custom quantity controls the unit, not the generic function.
        for candidate in (raw_unit, custom_unit, profile_unit):
            text = str(candidate or "").strip()
            if text and text.lower() != "review":
                return text
        return "Review"
    # Mixed/review profiles are guidance only. Keep their label in the UI/report.
    for candidate in (profile_unit, raw_unit):
        text = str(candidate or "").strip()
        if text and ("/" in text or "review" in text.lower()):
            return text
    # Single profile unit can override generic mapping when it is clear and not stale.
    if profile_unit and profile_unit.lower() not in {"review"}:
        return profile_unit
    if raw_unit and raw_unit.lower() not in {"review"}:
        # Do not let stale count/non-count mismatches through; otherwise keep a valid raw value.
        if raw_unit.lower() in {"no", "no."} and mapped != "no":
            return mapped
        return raw_unit
    return mapped
def sanitize_current_work_setup(data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Store the user's current working setup so Jarvis knows the active project/trade/function context."""
    data = data if isinstance(data, dict) else {}
    def clean(value: Any, fallback: str = "") -> str:
        return re.sub(r'[\r\n]+', ' ', str(value if value is not None else fallback)).strip()
    project_name = clean(data.get("project_name"), "Current Project") or "Current Project"
    setup_name = clean(data.get("setup_name"), "Default Wall Setup") or "Default Wall Setup"
    # v4.3.7: Trade Profile is the single source of truth. Legacy trade_type is only accepted as fallback when reading older settings.
    trade_profile_id = normalize_builder_trade_profile_id(data.get("trade_profile_id") or data.get("trade_profile") or data.get("trade_type"), "walls_partitions")
    notes = clean(data.get("notes"), "")
    zone_token_mode_raw = clean(data.get("zone_token_mode"), "preserve_source").lower().replace(" ", "_").replace("-", "_")
    zone_token_mode = "rebuild" if zone_token_mode_raw in {"rebuild", "rebuild_selected", "rebuild_using_selected_working_zone_combo", "selected_combo"} else "preserve_source"
    formula_mode = clean(data.get("formula_mode"), "Compact") or "Compact"
    if formula_mode.lower() not in {"compact", "full"}:
        formula_mode = "Compact"
    normalized_profile_id = normalize_builder_trade_profile_id(trade_profile_id, "walls_partitions")
    profile = default_trade_profile_by_id(normalized_profile_id)
    default_costx_function = sanitize_costx_function(data.get("default_costx_function") or data.get("costx_function") or profile.get("default_costx_function"), "XGETWALLAREA")
    function_mode_raw = clean(data.get("costx_function_mode") or data.get("function_mode") or profile.get("recommended_function_mode"), "preserve_detected").lower().replace(" ", "_").replace("-", "_")
    if function_mode_raw in {"force", "force_default", "force_selected", "force_selected_default", "force_selected_default_function"}:
        costx_function_mode = "force_default"
    else:
        costx_function_mode = "preserve_detected"
    custom_quantity_name = sanitize_custom_quantity_name(data.get("custom_quantity_name") or data.get("default_custom_quantity") or profile.get("default_custom_quantity") or "")
    custom_quantity_unit = canonical_builder_unit(data.get("custom_quantity_unit") or data.get("default_custom_quantity_unit") or profile.get("default_custom_quantity_unit") or custom_quantity_unit_lookup(custom_quantity_name, profile) or "")
    if default_costx_function == "XGETCUSTOM":
        if not custom_quantity_name:
            custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config({"custom_quantity_name": custom_quantity_name, "custom_quantity_unit": custom_quantity_unit}, profile, {})
        expected_unit = canonical_builder_unit(custom_quantity_unit or expected_unit_for_profile_function(default_costx_function, profile, data.get("expected_unit")))
    else:
        expected_unit = expected_unit_for_profile_function(default_costx_function, profile, data.get("expected_unit"))
    return {
        "project_name": project_name,
        "setup_name": setup_name,
        "trade_profile_id": normalized_profile_id,
        "expected_unit": expected_unit,
        "formula_mode": "Compact" if formula_mode.lower() == "compact" else "Full",
        "default_costx_function": default_costx_function,
        "costx_function_mode": costx_function_mode,
        "custom_quantity_name": custom_quantity_name,
        "custom_quantity_unit": custom_quantity_unit or expected_unit,
        "custom_quantity_templates": custom_quantity_templates_for_profile(profile),
        "supported_costx_functions": SUPPORTED_COSTX_FUNCTIONS,
        "zone_token_mode": zone_token_mode,
        "notes": notes,
        "item_code_config": sanitize_item_code_config(data.get("item_code_config") or {
            "enabled": data.get("item_code_enabled", False),
            "prefix": data.get("item_code_prefix", "A"),
            "separator": data.get("item_code_separator", "/"),
            "start_number": data.get("item_code_start_number", 1),
            "number_padding": data.get("item_code_number_padding", 0),
            "reset_scope": data.get("item_code_reset_scope", "whole_run"),
        }),
    }


def validate_builder_level_zone_setup_payload(level_setup: Dict[str, Any], levels: List[Dict[str, Any]]) -> List[str]:
    """Return user-facing validation warnings/errors before Builder export."""
    problems: List[str] = []
    active_categories = [cat for cat in sanitize_builder_active_categories(level_setup.get("active_categories")) if cat.get("active")]
    for cat in active_categories:
        idx = int(cat.get("category_index") or 0)
        behavior = normalize_zone_behavior(cat.get("behavior"), idx)
        if behavior == "global" and not str(cat.get("default_value") or "").strip():
            problems.append(f"ZC{idx} is active as Global but has no selected value.")
        if behavior == "locked" and idx == 3:
            blank_count = sum(1 for row in levels if not str(row.get("level_code") or "").strip())
            if blank_count:
                problems.append(f"ZC3 is locked from Level Code, but {blank_count} builder row(s) have blank Level Code.")
    seen_codes: set[str] = set()
    duplicates: set[str] = set()
    seen_tokens: set[str] = set()
    duplicate_tokens: set[str] = set()
    run_only_project = any(row.get("run_only") and row.get("head3_group") for row in levels)
    for row in levels:
        code = str(row.get("level_code") or "").strip()
        token = sanitize_costx_token_parts(row.get("token_parts") or "")
        if token:
            if token.lower() in seen_tokens:
                duplicate_tokens.add(token)
            seen_tokens.add(token.lower())
        if not code:
            continue
        if code.lower() in seen_codes:
            duplicates.add(code)
        seen_codes.add(code.lower())
    if duplicate_tokens:
        problems.append("Duplicate token row(s): " + ", ".join(sorted(duplicate_tokens)))
    elif duplicates and not run_only_project:
        problems.append("Duplicate Level Code(s): " + ", ".join(sorted(duplicates)))
    return problems

def default_builder_level_zone_payload() -> Dict[str, Any]:
    levels = sanitize_builder_levels(DEFAULT_BUILDER_LEVELS)
    zone_combos = sanitize_builder_zone_combos(DEFAULT_BUILDER_ZONE_COMBOS)
    active_combo_id = "walls_milestone_2_by_level"
    active_combo = next((combo for combo in zone_combos if combo.get("combo_id") == active_combo_id), zone_combos[0])
    return {
        "active_preset": active_combo.get("combo_name", "Walls - Milestone 2 by Level"),
        "current_work_setup": sanitize_current_work_setup({
            "project_name": "Current Project",
            "setup_name": "Walls - Milestone 2 by Level",
            "trade_profile_id": "walls_partitions",
            "expected_unit": "m2",
            "formula_mode": "Compact",
            "default_costx_function": "XGETWALLAREA",
            "costx_function_mode": "preserve_detected",
            "notes": ""
        }),
        "version": "v4.3.9.1",
        "updated_at": now_iso(),
        "levels": levels,
        "zone_library": sanitize_builder_zone_library(DEFAULT_BUILDER_ZONE_LIBRARY),
        "active_categories": sanitize_builder_active_categories(active_combo.get("active_categories")),
        "zone_combos": zone_combos,
        "trade_profiles": sanitize_builder_trade_profiles(DEFAULT_BUILDER_TRADE_PROFILES),
        "active_combo_id": active_combo.get("combo_id", active_combo_id),
        "compact_token_mode": True,
        "zone_behavior_modes": ["global", "locked", "choosable"],
        "formula_marker_mode": "live_excel_formula",
        "rejected_hotfix": "v4.1.1 CostX text formula marker is intentionally not used",
    }


def load_builder_level_zone_setup() -> Dict[str, Any]:
    data = read_json("builder_level_zone_setup.json", {})
    if not isinstance(data, dict) or not data.get("levels"):
        return default_builder_level_zone_payload()
    data["levels"] = sanitize_builder_levels(data.get("levels"))
    data["zone_library"] = sanitize_builder_zone_library(data.get("zone_library") or data.get("zones"))
    data["zone_combos"] = sanitize_builder_zone_combos(data.get("zone_combos"))
    data["trade_profiles"] = sanitize_builder_trade_profiles(data.get("trade_profiles"))
    active_combo_id = str(data.get("active_combo_id", "") or "").strip()
    if not active_combo_id or not any(combo.get("combo_id") == active_combo_id for combo in data["zone_combos"]):
        active_combo_id = data["zone_combos"][0].get("combo_id", "walls_milestone_2_by_level")
    data["active_combo_id"] = active_combo_id
    # Active categories are taken from saved active_categories, otherwise from active combo.
    combo = next((c for c in data["zone_combos"] if c.get("combo_id") == active_combo_id), None)
    data["active_categories"] = sanitize_builder_active_categories(data.get("active_categories") or (combo or {}).get("active_categories"))
    data.setdefault("active_preset", (combo or {}).get("combo_name", "Active"))
    data["version"] = "v4.3.9.1"
    data["current_work_setup"] = sanitize_current_work_setup(data.get("current_work_setup") or {
        "setup_name": data.get("active_preset") or (combo or {}).get("combo_name", "Active"),
        "trade_profile_id": "walls_partitions",
        "formula_mode": "Compact",
    })
    data.setdefault("compact_token_mode", True)
    data.setdefault("formula_marker_mode", "live_excel_formula")
    return data


def save_builder_level_zone_setup(
    levels: List[Dict[str, Any]],
    preset_name: str = "Active",
    zone_library: Optional[List[Dict[str, Any]]] = None,
    active_categories: Optional[List[Dict[str, Any]]] = None,
    zone_combos: Optional[List[Dict[str, Any]]] = None,
    active_combo_id: Optional[str] = None,
    current_work_setup: Optional[Dict[str, Any]] = None,
    trade_profiles: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    combos = sanitize_builder_zone_combos(zone_combos)
    profiles = sanitize_builder_trade_profiles(trade_profiles)
    active_id = str(active_combo_id or "").strip()
    if not active_id or not any(combo.get("combo_id") == active_id for combo in combos):
        active_id = combos[0].get("combo_id", "walls_milestone_2_by_level")
    categories = sanitize_builder_active_categories(active_categories)
    # If the user saves a new combo name, store/update it in the combo library.
    combo_name = (preset_name or "Active").strip() or "Active"
    combo_id = combo_id_from_name(combo_name)
    if combo_name and combo_name.lower() not in {"active", "default"}:
        existing = next((c for c in combos if c.get("combo_id") == combo_id), None)
        active_subset = [cat for cat in categories if cat.get("active")]
        combo_payload = {"combo_id": combo_id, "combo_name": combo_name, "description": "Saved from Jarvis v4.3.9.1 UI", "active_categories": active_subset}
        if existing:
            existing.update(combo_payload)
        else:
            combos.append(combo_payload)
        active_id = combo_id
    payload = {
        "active_preset": combo_name,
        "current_work_setup": sanitize_current_work_setup(current_work_setup or {
            "setup_name": combo_name,
            "trade_profile_id": "walls_partitions",
        }),
        "version": "v4.3.9.1",
        "updated_at": now_iso(),
        "levels": sanitize_builder_levels(levels),
        "zone_library": sanitize_builder_zone_library(zone_library),
        "active_categories": categories,
        "zone_combos": combos,
        "trade_profiles": profiles,
        "active_combo_id": active_id,
        "compact_token_mode": True,
        "zone_behavior_modes": ["global", "locked", "choosable"],
        "formula_marker_mode": "live_excel_formula",
        "rejected_hotfix": "v4.1.1 CostX text formula marker is intentionally not used",
    }
    write_json("builder_level_zone_setup.json", payload)
    write_log("builder_level_zone_setup_saved", {"preset": payload["active_preset"], "active_combo_id": active_id, "current_work_setup": payload.get("current_work_setup"), "level_count": len(payload["levels"]), "zone_library_count": len(payload["zone_library"]), "combo_count": len(combos)})
    return payload


@app.get("/api/builder/level-zone-setup")
def api_builder_level_zone_setup() -> Dict[str, Any]:
    return load_builder_level_zone_setup()


@app.get("/api/builder/trade-profiles")
def api_builder_trade_profiles() -> Dict[str, Any]:
    setup = load_builder_level_zone_setup()
    return {"profiles": sanitize_builder_trade_profiles(setup.get("trade_profiles")), "active_trade_profile_id": normalize_builder_trade_profile_id(setup.get("current_work_setup", {}).get("trade_profile_id"), "walls_partitions")}


@app.post("/api/builder/level-zone-setup")
def api_builder_level_zone_setup_save(req: BuilderLevelZoneSaveRequest) -> Dict[str, Any]:
    return save_builder_level_zone_setup(req.levels, req.preset_name, req.zone_library, req.active_categories, req.zone_combos, req.active_combo_id, req.current_work_setup, req.trade_profiles)


def save_builder_current_work_setup(
    current_work_setup: Dict[str, Any],
    active_combo_id: Optional[str] = None,
    active_categories: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Persist only the Builder current work/profile context.

    v4.3.9 state-lock guard: selecting a Trade Profile and XGETCUSTOM quantity should survive
    Workspace navigation without requiring a full Zone Manager save. This
    intentionally preserves levels, zone library, combo library and trade
    profile definitions; it updates only the active current_work_setup plus
    the selected combo/categories shown in the UI.
    """
    setup = load_builder_level_zone_setup()
    combos = sanitize_builder_zone_combos(setup.get("zone_combos"))
    active_id = str(active_combo_id or setup.get("active_combo_id") or "").strip()
    if active_id and any(combo.get("combo_id") == active_id for combo in combos):
        setup["active_combo_id"] = active_id
    else:
        setup["active_combo_id"] = setup.get("active_combo_id") or (combos[0].get("combo_id") if combos else "walls_milestone_2_by_level")
    active_combo = next((combo for combo in combos if combo.get("combo_id") == setup.get("active_combo_id")), None)
    setup["active_preset"] = (active_combo or {}).get("combo_name") or setup.get("active_preset") or "Active"
    setup["current_work_setup"] = sanitize_current_work_setup(current_work_setup or {})
    setup["active_categories"] = sanitize_builder_active_categories(active_categories if active_categories is not None else (setup.get("active_categories") or (active_combo or {}).get("active_categories")))
    setup["levels"] = sanitize_builder_levels(setup.get("levels"))
    setup["zone_library"] = sanitize_builder_zone_library(setup.get("zone_library"))
    setup["zone_combos"] = combos
    setup["trade_profiles"] = sanitize_builder_trade_profiles(setup.get("trade_profiles"))
    setup["version"] = "v4.3.9.1"
    setup["updated_at"] = now_iso()
    setup.setdefault("compact_token_mode", True)
    setup.setdefault("formula_marker_mode", "live_excel_formula")
    write_json("builder_level_zone_setup.json", setup)
    write_log("builder_current_work_setup_saved", {
        "trade_profile_id": setup["current_work_setup"].get("trade_profile_id"),
        "default_costx_function": setup["current_work_setup"].get("default_costx_function"),
        "custom_quantity_name": setup["current_work_setup"].get("custom_quantity_name"),
        "active_combo_id": setup.get("active_combo_id"),
    })
    return setup


@app.post("/api/builder/current-work-setup")
def api_builder_current_work_setup_save(req: BuilderCurrentWorkSaveRequest) -> Dict[str, Any]:
    return save_builder_current_work_setup(req.current_work_setup, req.active_combo_id, req.active_categories)

def builder_exact_dimension_name(entry: Dict[str, Any]) -> str:
    """Return the exact CostX dimension name Jarvis should use in formulas.

    Do not title-case or normalise source dimension names. CostX dimension names
    can be case-sensitive/project-specific, e.g. BR01 Structural Beam or
    FF01 Vinyl Floor Finish.
    """
    return str(entry.get("dimension") or entry.get("dimension_raw") or entry.get("dimension_normalised") or "").strip()


def unique_builder_dimensions(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Backward-compatible dimension grouping using exact source names."""
    seen: set[str] = set()
    out: List[Dict[str, Any]] = []
    for entry in entries:
        key = builder_exact_dimension_name(entry)
        if not key or key.lower() in seen:
            continue
        seen.add(key.lower())
        out.append({**entry, "builder_formula_dimension": key, "builder_output_description": key})
    return out


def unique_builder_dimensions_for_run(entries: List[Dict[str, Any]], current_work: Dict[str, Any], profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return output dimension contexts for this run.

    v4.3.8.3 weak-proof rule:
    - Force Default mode keeps the old safe behaviour: one output context per
      exact CostX dimension, using the selected profile/default function.
    - Preserve Detected mode uses Dimension + Function + Custom Quantity + Unit
      as the unique key, so repeated CostX names with different XGETCUSTOM
      quantities do not collapse into one Head4.
    """
    function_mode = str(current_work.get("costx_function_mode") or profile.get("recommended_function_mode") or "preserve_detected").strip().lower()
    seen: set[str] = set()
    out: List[Dict[str, Any]] = []
    for entry in entries:
        exact_dim = builder_exact_dimension_name(entry)
        if not exact_dim or is_placeholder_dimension_name(exact_dim):
            continue
        function_name, unit = resolve_dimension_function_unit(entry, current_work, profile)
        custom_name = ""
        if function_name == "XGETCUSTOM":
            custom_name, custom_unit = resolve_custom_quantity_config(current_work, profile, entry)
            unit = canonical_builder_unit(custom_unit or unit)
        if function_mode == "force_default":
            key = f"{exact_dim.lower()}"
        else:
            key = f"{exact_dim.lower()}|{function_name}|{custom_name.lower()}|{str(unit).lower()}"
        if key in seen:
            continue
        seen.add(key)
        item = dict(entry)
        item["builder_formula_dimension"] = exact_dim
        item["builder_context_function"] = function_name
        item["builder_context_unit"] = canonical_builder_unit(unit)
        item["builder_context_custom_quantity"] = custom_name
        item["builder_context_key"] = key
        out.append(item)

    dim_counts: Dict[str, int] = {}
    for item in out:
        exact_dim = builder_exact_dimension_name(item)
        dim_counts[exact_dim.lower()] = dim_counts.get(exact_dim.lower(), 0) + 1
    for item in out:
        exact_dim = item.get("builder_formula_dimension") or builder_exact_dimension_name(item)
        if dim_counts.get(str(exact_dim).lower(), 0) > 1:
            custom_name = sanitize_custom_quantity_name(item.get("builder_context_custom_quantity") or "")
            function_name = sanitize_costx_function(item.get("builder_context_function") or item.get("function") or "", "XGET")
            unit = canonical_builder_unit(item.get("builder_context_unit") or item.get("unit") or "")
            if function_name == "XGETCUSTOM" and custom_name:
                suffix = custom_name
            else:
                suffix = f"{function_name} {unit}".strip()
            item["builder_output_description"] = f"{exact_dim} — {suffix}" if suffix else str(exact_dim)
        else:
            item["builder_output_description"] = str(exact_dim)
    return out


def builder_level_token(level: Dict[str, Any]) -> str:
    token_parts = sanitize_costx_token_parts(str(level.get("token_parts", "") or ""))
    if token_parts:
        return token_parts
    zone_idx = level.get("zone_index", 1)
    zone_name = level.get("zone_name", "Milestone 2")
    level_idx = level.get("level_index", 3)
    code = level.get("level_code", "")
    return f"{zone_idx}|{zone_name};{level_idx}|{code}"


def token_parts_to_map(token_parts: Any) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for part in sanitize_costx_token_parts(str(token_parts or "")).split(";"):
        if "|" not in part:
            continue
        left, right = part.split("|", 1)
        if left and right:
            out[str(left).strip()] = str(right).strip()
    return out


def builder_level_token_for_categories(level: Dict[str, Any], active_categories: Optional[List[Dict[str, Any]]] = None) -> str:
    """Build token from active zone behavior, overriding stale saved row tokens.

    v4.3.7: Global zones must use the current combo value and ZC3 must be locked
    from the Builder Row Level Code. This prevents a saved row token from keeping
    an old milestone after the user switches Working Zone Combo.
    """
    cats = [cat for cat in sanitize_builder_active_categories(active_categories) if cat.get("active")] if active_categories else []
    if not cats:
        return builder_level_token(level)
    existing = token_parts_to_map(level.get("token_parts", ""))
    parts: List[str] = []
    for cat in sorted(cats, key=lambda c: int(c.get("category_index") or 0)):
        idx = int(cat.get("category_index") or 0)
        if idx < 1 or idx > 8:
            continue
        behavior = normalize_zone_behavior(cat.get("behavior"), idx)
        value = ""
        if behavior == "global":
            value = str(cat.get("default_value") or existing.get(str(idx)) or "").strip()
        elif behavior == "locked":
            if idx == 3:
                value = str(level.get("level_code") or existing.get("3") or "").strip()
            else:
                value = str(existing.get(str(idx)) or cat.get("default_value") or "").strip()
        elif behavior == "choosable":
            value = str(existing.get(str(idx)) or cat.get("default_value") or "").strip()
        value = re.sub(r'["\[\]\r\n;]+', ' ', value).strip()
        if value:
            parts.append(f"{idx}|{value}")
    return ";".join(parts) or builder_level_token(level)


def build_level_xget_formula(
    function_name: str,
    dimension_name: str,
    level: Dict[str, Any],
    active_categories: Optional[List[Dict[str, Any]]] = None,
    custom_quantity_name: Optional[str] = None,
    source_zone_token: Optional[str] = None,
    zone_token_mode: str = "preserve_source",
) -> str:
    """Build CostX level/zone formula string.

    v4.3.8 rule: Preserve an existing source zone token such as
    [1|S;3|Roof] by default. Rebuild from the selected Working Zone Combo only
    when zone_token_mode is set to rebuild.
    """
    func = sanitize_costx_function((function_name or "XGETWALLAREA").strip().upper(), "XGETWALLAREA")
    dim = (dimension_name or "").strip().replace('"', '\"')
    source_token = sanitize_costx_token_parts(str(source_zone_token or ""))
    mode = str(zone_token_mode or "preserve_source").strip().lower()
    if source_token and mode != "rebuild":
        token = source_token
    else:
        token = builder_level_token_for_categories(level, active_categories)
    if func == "XGETCUSTOM":
        custom = sanitize_custom_quantity_name(custom_quantity_name or "Slope Length").replace('"', '\"')
        return f'=XGETCUSTOM("{dim}[{token}]","{custom}",0)'
    return f'= {func}("{dim}[{token}]",0)'.replace('= ', '=')


def build_dimension_placeholder_description(entry: Dict[str, Any]) -> str:
    """Use the extracted dimension/context as a safe Head4 placeholder.

    Full specification descriptions can be added later through a Builder/description library.
    v4.3.8.3 preserves exact CostX dimension casing and only appends a context
    suffix when duplicate source dimensions must remain separate.
    """
    return (entry.get("builder_output_description") or builder_exact_dimension_name(entry) or "").strip()


def resolve_active_trade_profile(level_setup: Dict[str, Any], current_work: Dict[str, Any]) -> Dict[str, Any]:
    profiles = sanitize_builder_trade_profiles(level_setup.get("trade_profiles"))
    profile_id = normalize_builder_trade_profile_id(current_work.get("trade_profile_id") or current_work.get("trade_type"), "walls_partitions")
    return next((p for p in profiles if normalize_builder_trade_profile_id(p.get("profile_id"), "walls_partitions") == profile_id), profiles[0] if profiles else DEFAULT_BUILDER_TRADE_PROFILES[0])


def resolve_dimension_function_unit(dim: Dict[str, Any], current_work: Dict[str, Any], trade_profile: Dict[str, Any]) -> tuple[str, str]:
    """Resolve CostX function and unit using v4.2.12 function mode + v4.3.2 profile defaults."""
    function_mode = current_work.get("costx_function_mode", trade_profile.get("recommended_function_mode", "preserve_detected"))
    default_function = sanitize_costx_function(
        current_work.get("default_costx_function") or trade_profile.get("default_costx_function") or "XGETWALLAREA",
        "XGETWALLAREA",
    )
    detected_function = sanitize_costx_function(dim.get("function") or "", "") if dim.get("function") else ""
    if function_mode == "force_default":
        function_name = default_function
        unit = builder_unit_for_function(function_name)
    else:
        function_name = sanitize_costx_function(detected_function or default_function or "XGETWALLAREA", "XGETWALLAREA")
        unit = dim.get("unit") or builder_unit_for_function(function_name)
    # XGETCUSTOM unit comes from the selected/detected custom quantity template.
    if function_name == "XGETCUSTOM":
        _custom_name, custom_unit = resolve_custom_quantity_config(current_work, trade_profile, dim)
        unit = custom_unit or unit or trade_profile.get("default_unit") or "Review"
    # If a profile forces count but unit mapping is unknown, respect profile unit guidance.
    if not unit or str(unit).lower() == "review":
        unit = trade_profile.get("default_unit") or builder_unit_for_function(function_name)
    return function_name, canonical_builder_unit(unit)


def write_builder_head_row(ws: Any, row_idx: int, description: str, head_font: Any, head_fill: Any, light_bottom: Any, normal_font: Any, Alignment: Any, item_code: str = "") -> None:
    if item_code:
        ws.cell(row_idx, 1, item_code)
    ws.cell(row_idx, 2, description)
    ws.cell(row_idx, 4, "Head4")
    ws.cell(row_idx, 2).font = head_font
    ws.cell(row_idx, 2).fill = head_fill
    ws.cell(row_idx, 2).border = light_bottom
    ws.cell(row_idx, 2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row_idx, 4).font = normal_font
    ws.cell(row_idx, 4).alignment = Alignment(horizontal="center", vertical="top")


def write_builder_heading_row(ws: Any, row_idx: int, description: str, row_type: str, head_font: Any, head_fill: Any, light_bottom: Any, normal_font: Any, Alignment: Any, item_code: str = "") -> None:
    safe_type = row_type if row_type in {"Head1", "Head2", "Head3", "Head4"} else "Head4"
    if item_code:
        ws.cell(row_idx, 1, item_code)
    ws.cell(row_idx, 2, description)
    ws.cell(row_idx, 4, safe_type)
    ws.cell(row_idx, 2).font = head_font
    ws.cell(row_idx, 2).fill = head_fill
    ws.cell(row_idx, 2).border = light_bottom
    ws.cell(row_idx, 2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row_idx, 4).font = normal_font
    ws.cell(row_idx, 4).alignment = Alignment(horizontal="center", vertical="top")


def write_builder_item_row(ws: Any, row_idx: int, description: str, formula: str, unit: str, level_font: Any, formula_font: Any, normal_font: Any, Alignment: Any, item_code: str = "") -> None:
    if item_code:
        ws.cell(row_idx, 1, item_code)
    ws.cell(row_idx, 2, description)
    ws.cell(row_idx, 3, formula)
    ws.cell(row_idx, 4, unit)
    ws.cell(row_idx, 2).font = level_font
    ws.cell(row_idx, 2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row_idx, 3).font = formula_font
    ws.cell(row_idx, 3).alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row_idx, 4).font = normal_font
    ws.cell(row_idx, 4).alignment = Alignment(horizontal="center", vertical="top")




def builder_xgetcustom_report_note(current_work: Dict[str, Any], profile: Dict[str, Any], dim: Optional[Dict[str, Any]] = None) -> str:
    """Human-safe XGETCUSTOM note for reports.

    Do not use fake formula placeholders in QA/report cells because those
    strings can be re-scanned as weak source data in future test loops.
    """
    function_name = sanitize_costx_function(
        current_work.get("default_costx_function") or profile.get("default_costx_function") or "XGETWALLAREA",
        "XGETWALLAREA",
    )
    costx_mode = str(current_work.get("costx_function_mode") or profile.get("recommended_function_mode") or "preserve_detected").strip().lower()
    detected_custom = sanitize_custom_quantity_name((dim or {}).get("custom_quantity_name") or "")
    custom_name, custom_unit = resolve_custom_quantity_config(current_work, profile, dim or {})
    if function_name != "XGETCUSTOM":
        return f"Function {function_name} does not use a custom quantity. Live formulas are generated from the real dimension name and active zone token only."
    if costx_mode != "force_default" and not detected_custom:
        return "Not forced for this run. Jarvis preserves detected CostX functions unless the selected profile forces XGETCUSTOM."
    return f"Active custom quantity: {custom_name or 'none'}; unit: {custom_unit}. Live formulas are generated from the real dimension name and active zone token only."


def summarize_builder_detected_run(entries: List[Dict[str, Any]], extracted: Dict[str, Any]) -> Dict[str, Any]:
    """Summarise what this Builder run learned from the uploaded workbook.

    This is run-scoped learning: it lets Jarvis relearn the source workbook every run
    without permanently rewriting trade profiles or stable tools.
    """
    functions: Dict[str, int] = {}
    units: Dict[str, int] = {}
    custom_quantities: Dict[str, int] = {}
    source_zone_tokens: List[str] = []
    source_sheets: Dict[str, int] = {}
    source_types = dict(extracted.get("source_types") or {})
    for item in entries:
        fn = sanitize_costx_function(item.get("function") or "", "") or "UNKNOWN"
        functions[fn] = functions.get(fn, 0) + 1
        unit = canonical_builder_unit(item.get("unit") or "") or "Review"
        units[unit] = units.get(unit, 0) + 1
        cq = sanitize_custom_quantity_name(item.get("custom_quantity_name") or "")
        if cq:
            custom_quantities[cq] = custom_quantities.get(cq, 0) + 1
        token = sanitize_costx_token_parts(item.get("source_zone_token") or "")
        if token and token not in source_zone_tokens:
            source_zone_tokens.append(token)
        sh = str(item.get("source_sheet") or "Unknown").strip() or "Unknown"
        source_sheets[sh] = source_sheets.get(sh, 0) + 1
    return {
        "functions": functions,
        "units": units,
        "custom_quantities": custom_quantities,
        "source_zone_token_count": len(source_zone_tokens),
        "source_zone_token_examples": source_zone_tokens[:8],
        "source_sheets": source_sheets,
        "source_types": source_types,
        "ignored_sheets": list(extracted.get("ignored_sheets") or []),
    }


def format_count_map(values: Dict[str, int], empty: str = "None") -> str:
    if not values:
        return empty
    return ", ".join(f"{key}: {values[key]}" for key in sorted(values))


def build_builder_run_learning_rows(
    extracted: Dict[str, Any],
    entries: List[Dict[str, Any]],
    dimensions: List[Dict[str, Any]],
    level_setup: Dict[str, Any],
    current_work: Dict[str, Any],
    profile: Dict[str, Any],
    levels: List[Dict[str, Any]],
) -> tuple[List[Dict[str, str]], Dict[str, Any]]:
    """Create run-scoped adaptive learning/relearning notes for QA and reports."""
    learned = summarize_builder_detected_run(entries, extracted)
    zone_mode = str(current_work.get("zone_token_mode") or "preserve_source").strip().lower()
    source_token_count = int(learned.get("source_zone_token_count") or 0)
    costx_mode = str(current_work.get("costx_function_mode") or profile.get("recommended_function_mode") or "preserve_detected").strip().lower()
    default_function = sanitize_costx_function(current_work.get("default_costx_function") or profile.get("default_costx_function") or "XGETWALLAREA", "XGETWALLAREA")
    rows: List[Dict[str, str]] = []

    def add(area: str, status: str, detail: str) -> None:
        rows.append({"area": area, "status": status, "detail": detail})

    add("Run-scope learning", "PASS", "Jarvis relearned the uploaded workbook for this run only. No permanent profile or stable-tool change is applied by the Builder output step.")
    add("Source detection", "PASS", f"Detected {len(entries)} source entr{'y' if len(entries) == 1 else 'ies'} and {len(dimensions)} unique Builder dimension group(s). Source types: {format_count_map(learned.get('source_types', {}))}.")
    add("Function learning", "PASS", f"Detected functions: {format_count_map(learned.get('functions', {}))}. Function mode: {costx_mode}; default function: {default_function}.")
    add("Unit learning", "PASS", f"Detected/normalised measurement units: {format_count_map(filtered_builder_unit_summary(learned.get('units', {})))}. Non-measurement review markers are filtered from reports. Count units remain lowercase no; XGETCUSTOM units are resolved from the active custom quantity template.")
    add("Custom quantity learning", "PASS" if learned.get("custom_quantities") or default_function == "XGETCUSTOM" else "INFO", f"Detected source custom quantities: {format_count_map(learned.get('custom_quantities', {}))}. {builder_xgetcustom_report_note(current_work, profile)}")

    source_context_keys: set[str] = set()
    source_name_counts: Dict[str, int] = {}
    source_name_contexts: Dict[str, set[str]] = {}
    source_name_display: Dict[str, str] = {}
    for item in entries:
        exact_dim = builder_exact_dimension_name(item)
        if not exact_dim:
            continue
        fn, unit = resolve_dimension_function_unit(item, current_work, profile)
        custom_name = ""
        if fn == "XGETCUSTOM":
            custom_name, custom_unit = resolve_custom_quantity_config(current_work, profile, item)
            unit = canonical_builder_unit(custom_unit or unit)
        context_key = f"{exact_dim.lower()}|{fn}|{custom_name.lower()}|{str(unit).lower()}"
        source_context_keys.add(context_key)
        dim_key = exact_dim.lower()
        source_name_counts[dim_key] = source_name_counts.get(dim_key, 0) + 1
        source_name_contexts.setdefault(dim_key, set()).add(context_key)
        source_name_display.setdefault(dim_key, exact_dim)
    output_context_keys = {str(item.get("builder_context_key") or "") for item in dimensions if item.get("builder_context_key")}
    duplicate_source_names = sorted(source_name_display[key] for key, keys in source_name_contexts.items() if len(keys) > 1)
    if costx_mode == "force_default":
        add("Duplicate context guard", "INFO", f"Force Default mode intentionally collapses duplicate source names into one context per exact dimension. Source contexts detected: {len(source_context_keys)}; output contexts: {len(dimensions)}.")
    else:
        status = "PASS" if len(output_context_keys) >= len(source_context_keys) else "WARN"
        detail = f"Preserve Detected mode uses Dimension + Function + Custom Quantity + Unit as the context key. Source contexts detected: {len(source_context_keys)}; output contexts generated: {len(output_context_keys) or len(dimensions)}."
        if duplicate_source_names:
            detail += " Duplicate source names protected: " + ", ".join(duplicate_source_names[:12]) + ("..." if len(duplicate_source_names) > 12 else "") + "."
        add("Duplicate context guard", status, detail)

    if zone_mode == "rebuild":
        add("Zone token decision", "PASS", "Zone token mode is rebuild, so formulas use the active Working Zone Combo instead of source tokens.")
    elif source_token_count:
        examples = "; ".join(learned.get("source_zone_token_examples") or [])
        add("Zone token decision", "PASS", f"Preserve-source mode is active and {source_token_count} source token(s) were detected. Examples preserved: {examples}.")
    else:
        add("Zone token decision", "PASS", "Preserve-source mode is active but no source formula tokens were detected, so Jarvis rebuilt tokens from the active Working Zone Combo for structured dimension exports.")
    add("Profile adjustment", "PASS", f"Active trade profile: {profile.get('display_name', profile.get('profile_id'))}. Jarvis uses the run-context snapshot first, then detected source data, then safe defaults as fallback.")
    ignored = ", ".join(learned.get("ignored_sheets") or []) or "None"
    add("Weak-source guard", "PASS", f"Ignored helper/report/expected sheets: {ignored}. Fake placeholder formula text is not written to QA/report cells.")
    project_hierarchy = current_work.get("project_zone_hierarchy") if isinstance(current_work.get("project_zone_hierarchy"), dict) else None
    if project_hierarchy and project_hierarchy.get("run_only"):
        summary_lines = project_hierarchy.get("hierarchy_summary_lines") or dynamic_hierarchy_summary_lines(project_hierarchy)
        summary_text = " | ".join(summary_lines) if summary_lines else "Requested hierarchy applied."
        add("Project hierarchy guard", "PASS", f"Run-only project hierarchy active. Dynamic zone mapping is used for this run only. {project_hierarchy.get('hierarchy_description') or 'Requested hierarchy applied.'} Summary: {summary_text}. Stable Workspace defaults are not intended to be overwritten by this run.")
    add("Level/zone guard", "PASS", f"{len(levels)} Builder row(s) available. ZC1 Global and ZC3 locked behaviour are validated before output.")
    add("Formula guard", "PASS", "Formulas remain live Excel/CostX formulas; no v4.1.1 text-marker hotfix is used.")
    add("Background readiness guard", "PASS", "Preview and export share the same locked run-context snapshot, so background Builder jobs can reuse the reviewed profile/function/custom quantity/unit/zone setup without silently changing the working profile.")
    return rows, learned

def builder_profile_layout_qa(level_setup: Dict[str, Any], profile: Dict[str, Any], current_work: Dict[str, Any], levels: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """v4.3.7 profile QA report for layout, units, zone behavior and classification controls."""
    cats = sanitize_builder_active_categories(level_setup.get("active_categories"))
    active = [cat for cat in cats if cat.get("active")]
    active_by_idx = {int(cat.get("category_index")): cat for cat in active}
    function_name = sanitize_costx_function(current_work.get("default_costx_function") or profile.get("default_costx_function") or "XGETWALLAREA", "XGETWALLAREA")
    expected_unit = expected_unit_for_profile_function(function_name, profile, current_work.get("expected_unit"))
    rows: List[Dict[str, str]] = []
    def add(check: str, status: str, detail: str) -> None:
        rows.append({"check": check, "status": status, "detail": detail})
    add("Single source of truth", "PASS", "Trade Profile controls function, expected unit, layout mode and recommended zone combo. Legacy Trade / Work Type is ignored.")
    zc3 = active_by_idx.get(3)
    if zc3 and normalize_zone_behavior(zc3.get("behavior"), 3) == "locked" and zc3.get("locked_source") == "level_code":
        add("ZC3 level lock", "PASS", "ZC3 is locked from Builder Row Level Code and is not intended to be edited as a per-row dropdown.")
    else:
        add("ZC3 level lock", "WARN", "ZC3 should normally be active and locked from Level Code.")
    if function_name in {"XGETCOUNT", "XGETNUMBER"}:
        add("Count unit standard", "PASS" if expected_unit == "no" else "WARN", f"{function_name} expected unit is {expected_unit!r}; required count unit is lowercase 'no'.")
    else:
        add("Count unit standard", "PASS", f"Function {function_name} is not count-based; unit guard remains active.")
    if function_name == "XGETCUSTOM":
        custom_name, custom_unit = resolve_custom_quantity_config(current_work, profile, {})
        add("XGETCUSTOM quantity", "PASS" if custom_name and custom_unit.lower() != "review" else "WARN", f"Custom quantity: {custom_name or 'none'}; unit: {custom_unit}. Live Builder formulas use the active dimension, active zone token and this custom quantity.")
    layout = normalize_trade_layout_mode(profile.get("layout_mode"), "item_first_levels_below")
    if normalize_builder_trade_profile_id(profile.get("profile_id")) in {"doors", "windows", "doors_windows"}:
        add("Door/window layout", "PASS" if layout == "level_first_items_below" else "WARN", f"Door/window profile layout is {layout}; expected level_first_items_below.")
        classification = [idx for idx in (5, 7) if idx in active_by_idx and normalize_zone_behavior(active_by_idx[idx].get("behavior"), idx) == "choosable"]
        add("Door/window classification controls", "PASS" if classification else "INFO", "Choosable classification zone(s): " + (", ".join(f"ZC{idx}" for idx in classification) if classification else "none; simple count exports can proceed without classification unless a classification/split was requested."))
    else:
        add("Profile layout mode", "PASS", trade_layout_label(layout))
    if levels:
        add("Builder row count", "PASS", f"{len(levels)} builder row(s) available for output.")
    else:
        add("Builder row count", "WARN", "No builder rows detected.")
    add("Formula mode", "PASS", "Live CostX/Excel formulas remain enabled. Rejected v4.1.1 text-marker hotfix is not used.")
    return rows


def apply_builder_run_context_snapshot(
    level_setup: Dict[str, Any],
    builder_levels: Optional[List[Dict[str, Any]]] = None,
    run_context: Optional[Dict[str, Any]] = None,
) -> tuple[Dict[str, Any], List[Dict[str, Any]], Dict[str, Any]]:
    """Apply the UI run-context snapshot without changing stable Builder logic.

    v4.3.9 shares this between Preview and Export so the review panel checks the
    exact same profile/function/zone snapshot that the export will use.
    """
    run_context = run_context if isinstance(run_context, dict) else {}
    if run_context.get("zone_library") is not None:
        level_setup["zone_library"] = sanitize_builder_zone_library(run_context.get("zone_library"))
    if run_context.get("zone_combos") is not None:
        level_setup["zone_combos"] = sanitize_builder_zone_combos(run_context.get("zone_combos"))
    if run_context.get("active_combo_id"):
        level_setup["active_combo_id"] = str(run_context.get("active_combo_id"))
    if run_context.get("active_categories") is not None:
        level_setup["active_categories"] = sanitize_builder_active_categories(run_context.get("active_categories"))
    current_work_source = run_context.get("current_work_setup") or level_setup.get("current_work_setup")
    if run_context.get("zone_token_mode") and isinstance(current_work_source, dict):
        current_work_source = {**current_work_source, "zone_token_mode": run_context.get("zone_token_mode")}
    levels = sanitize_builder_levels(builder_levels) if builder_levels else sanitize_builder_levels(level_setup.get("levels"))
    # v4.5.1.24.2A: when an active project hierarchy is present, never feed old
    # workspace combo tokens (e.g. Milestone 2) into preview/export. If the
    # project has no explicit levels yet, reuse only the visible level codes from
    # the legacy setup, then rebuild token_parts from the active hierarchy.
    if isinstance(current_work_source, dict) and isinstance(current_work_source.get("project_zone_hierarchy"), dict):
        project_source = _deepcopy_json(current_work_source.get("project_zone_hierarchy") or {})
        explicit_level_instruction = bool(project_source.get("explicit_level_instruction") or project_source.get("level_instruction_detected"))
        if not project_source.get("level_values"):
            if explicit_level_instruction:
                project_source["level_values_missing_warning"] = "Explicit level instruction was detected, but no parsed level values were available; workspace/default levels were not used."
                builder_levels = []
                levels = []
            else:
                fallback_levels = sanitize_builder_levels(builder_levels) if builder_levels else sanitize_builder_levels(level_setup.get("levels"))
                level_values = _dedupe_keep_order([_level_label(str(lv.get("level_code") or lv.get("description") or "")) for lv in fallback_levels if str(lv.get("level_code") or lv.get("description") or "").strip()])
                if level_values:
                    project_source["level_values"] = level_values
                    project_source["level_zone_index"] = int(project_source.get("level_zone_index") or 3)
        rebuilt_levels = build_project_builder_levels(project_source)
        if rebuilt_levels:
            builder_levels = rebuilt_levels
            levels = sanitize_builder_levels(rebuilt_levels)
            current_work_source = {**current_work_source, "project_zone_hierarchy": project_source, "zone_token_mode": "rebuild"}
        elif explicit_level_instruction and not project_source.get("level_values"):
            current_work_source = {**current_work_source, "project_zone_hierarchy": project_source, "zone_token_mode": "rebuild"}
    current_work = sanitize_current_work_setup(current_work_source)
    # v4.4.4.11 summary cleanup: non-XGETCUSTOM runs must not carry stale
    # custom quantity labels such as Slope Length (m) from a previous workspace.
    if sanitize_costx_function(current_work.get("default_costx_function") or "", "") != "XGETCUSTOM":
        current_work["custom_quantity_name"] = ""
        current_work["custom_quantity_unit"] = ""
        current_work["expected_unit"] = expected_unit_for_profile_function(current_work.get("default_costx_function"), {}, current_work.get("expected_unit"))
    if isinstance(current_work_source, dict) and isinstance(current_work_source.get("project_zone_hierarchy"), dict):
        current_work["project_zone_hierarchy"] = current_work_source.get("project_zone_hierarchy")
        current_work["zone_token_mode"] = "rebuild"
        level_setup["active_preset"] = "Run-only dynamic project hierarchy"
        level_setup["active_combo_id"] = "run_only_dynamic_project_hierarchy"
    level_setup["current_work_setup"] = current_work
    return level_setup, levels, current_work


def filtered_builder_unit_summary(units: Dict[str, int]) -> Dict[str, int]:
    """Return preview-facing unit counts without non-measurement review markers."""
    filtered: Dict[str, int] = {}
    for key, value in (units or {}).items():
        unit = canonical_builder_unit(key or "")
        if not unit or unit.lower() == "review":
            continue
        filtered[unit] = filtered.get(unit, 0) + int(value or 0)
    return filtered


def _source_token_level_label(source_zone_token: str) -> str:
    """Return the source level token label from a CostX token string."""
    token = sanitize_costx_token_parts(source_zone_token or "")
    parts: List[tuple[int, str]] = []
    for part in token.split(";"):
        if "|" not in part:
            continue
        k, v = part.split("|", 1)
        try:
            idx = int(str(k).strip())
        except Exception:
            continue
        value = str(v or "").strip()
        if value:
            parts.append((idx, value))
    for idx, value in parts:
        if idx == 3:
            return _level_label(value) or value
    return (parts[0][1] if parts else "Source")


def _is_source_preserve_count_builder_run(current_work: Dict[str, Any], profile: Dict[str, Any], entries: Optional[List[Dict[str, Any]]] = None) -> bool:
    """Narrow v4.5.1.25 guard for Doors/Windows source-preserve count rows."""
    profile_id = normalize_builder_trade_profile_id(current_work.get("trade_profile_id") or profile.get("profile_id"), "")
    if profile_id not in {"doors", "windows", "doors_windows"}:
        return False
    function_name = sanitize_costx_function(current_work.get("default_costx_function") or profile.get("default_costx_function") or "", "")
    if function_name not in {"XGETCOUNT", "XGETNUMBER"}:
        return False
    if str(current_work.get("zone_token_mode") or "preserve_source").strip().lower() != "preserve_source":
        return False
    if entries is None:
        return True
    return any(sanitize_costx_token_parts(e.get("source_zone_token") or "") for e in entries or [])


def build_source_preserve_count_levels(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Build display levels directly from source formula tokens for count workflows."""
    levels: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for entry in entries or []:
        token = sanitize_costx_token_parts(entry.get("source_zone_token") or "")
        if not token:
            continue
        label = _source_token_level_label(token)
        key = f"{label.lower()}|{token.lower()}"
        if key in seen:
            continue
        seen.add(key)
        levels.append({
            "zone_index": 0,
            "zone_name": "Source",
            "level_index": 3,
            "level_code": label,
            "description": label,
            "token_parts": token,
            "source_preserve": True,
            "run_only": True,
        })
    return levels


def source_preserve_count_dimensions(entries: List[Dict[str, Any]], current_work: Dict[str, Any], profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return one output context per source dimension + source token for count workflows."""
    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    default_function = sanitize_costx_function(current_work.get("default_costx_function") or profile.get("default_costx_function") or "XGETCOUNT", "XGETCOUNT")
    default_unit = canonical_builder_unit(current_work.get("expected_unit") or profile.get("default_unit") or "no")
    for entry in entries or []:
        token = sanitize_costx_token_parts(entry.get("source_zone_token") or "")
        exact_dim = builder_exact_dimension_name(entry)
        if not exact_dim or is_placeholder_dimension_name(exact_dim) or not token:
            continue
        key = f"{exact_dim.lower()}|{token.lower()}|{default_function}"
        if key in seen:
            continue
        seen.add(key)
        item = dict(entry)
        item["builder_formula_dimension"] = exact_dim
        item["builder_context_function"] = default_function
        item["builder_context_unit"] = default_unit
        item["builder_context_custom_quantity"] = ""
        item["builder_context_key"] = key
        item["source_level_label"] = _source_token_level_label(token)
        out.append(item)
    return out


def build_builder_output_preview_rows(
    dimensions: List[Dict[str, Any]],
    levels: List[Dict[str, Any]],
    level_setup: Dict[str, Any],
    current_work: Dict[str, Any],
    profile: Dict[str, Any],
    layout_mode: str,
    limit: int = 50,
) -> List[Dict[str, Any]]:
    """Create a read-only sample of generated Builder rows without writing a workbook.

    This mirrors the export ordering and formula resolution used by create_builder_output,
    but it only returns sample rows for UI review. It does not change the export engine.
    """
    rows: List[Dict[str, Any]] = []
    formula_row_no = 0
    safe_limit = max(1, min(int(limit or 50), 100))
    project_hierarchy = current_work.get("project_zone_hierarchy") if isinstance(current_work.get("project_zone_hierarchy"), dict) else None
    use_project_token = bool(project_hierarchy and (project_hierarchy.get("hierarchy_zones") or project_hierarchy.get("head3_source") in {"zone1", "dynamic_zone"}))
    item_code_cfg = sanitize_item_code_config(current_work.get("item_code_config") if isinstance(current_work.get("item_code_config"), dict) else {})
    item_code_state = builder_item_code_state(item_code_cfg)

    def add_preview_row(dim: Dict[str, Any], level: Dict[str, Any], group_description: str, row_description: str) -> None:
        nonlocal formula_row_no
        if len(rows) >= safe_limit:
            return
        function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
        custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config(current_work, profile, dim) if function_name == "XGETCUSTOM" else ("", unit)
        if function_name == "XGETCUSTOM":
            unit = canonical_builder_unit(custom_quantity_unit or unit)
        dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
        formula = build_level_xget_formula(
            function_name,
            dimension_for_formula,
            level,
            None if use_project_token else level_setup.get("active_categories"),
            custom_quantity_name,
            "" if use_project_token else dim.get("source_zone_token"),
            "rebuild" if use_project_token else current_work.get("zone_token_mode", "preserve_source"),
        )
        formula_row_no += 1
        rows.append({
            "row_no": formula_row_no,
            "item_code": builder_next_item_code(item_code_state, "formula"),
            "group_description": group_description or build_dimension_placeholder_description(dim),
            "row_description": row_description or level.get("description") or level.get("level_code") or "Level",
            "costx_dimension": dimension_for_formula,
            "formula": formula,
            "unit": unit,
            "function": function_name,
            "custom_quantity": custom_quantity_name,
            "source_zone_token": sanitize_costx_token_parts(dim.get("source_zone_token") or ""),
            "level_code": level.get("level_code") or "",
        })

    if _is_source_preserve_count_builder_run(current_work, profile) and dimensions:
        source_levels = levels or build_source_preserve_count_levels(dimensions)
        level_order = [str(level.get("level_code") or level.get("description") or "").strip() for level in source_levels]
        level_order = _dedupe_keep_order([v for v in level_order if v])
        if not level_order:
            level_order = _dedupe_keep_order([str(dim.get("source_level_label") or _source_token_level_label(dim.get("source_zone_token") or "")).strip() for dim in dimensions])
        for level_label in level_order:
            for dim in dimensions:
                dim_level = str(dim.get("source_level_label") or _source_token_level_label(dim.get("source_zone_token") or "")).strip()
                if dim_level.lower() != str(level_label).lower():
                    continue
                if len(rows) >= safe_limit:
                    return rows
                level = {"level_code": level_label, "description": level_label, "token_parts": sanitize_costx_token_parts(dim.get("source_zone_token") or "")}
                add_preview_row(dim, level, level_label, build_dimension_placeholder_description(dim))
        return rows

    if project_hierarchy and project_hierarchy.get("hierarchy_zones"):
        # v4.4.4.11 multi-zone tree preview: show the hierarchy path in the
        # same order that export will write headings. The formula still comes
        # from the stable Builder formula function via each row's token_parts.
        path_keys = _dedupe_keep_order([" / ".join(str(n.get("value") or "").strip() for n in (level.get("hierarchy_path") or []) if str(n.get("value") or "").strip()) for level in levels]) or [""]
        for path_key in path_keys:
            path_levels = [level for level in levels if (" / ".join(str(n.get("value") or "").strip() for n in (level.get("hierarchy_path") or []) if str(n.get("value") or "").strip())) == path_key]
            for dim in dimensions:
                suffixes = _dedupe_keep_order([str(level.get("dimension_suffix") or level.get("head4_suffix") or "").strip() for level in path_levels]) or [""]
                for suffix in suffixes:
                    suffix_levels = [level for level in path_levels if str(level.get("dimension_suffix") or level.get("head4_suffix") or "").strip().lower() == suffix.lower()]
                    head_desc = build_dimension_placeholder_description(dim)
                    group_head = f"{head_desc} - {suffix}" if suffix else head_desc
                    group_desc = " / ".join([x for x in [path_key, group_head] if x])
                    for level in suffix_levels:
                        if len(rows) >= safe_limit:
                            return rows
                        add_preview_row(dim, level, group_desc, level.get("description") or level.get("level_code") or "Level")
        return rows

    if project_hierarchy and project_hierarchy.get("head3_source") in {"zone1", "dynamic_zone"}:
        head3_values = project_hierarchy.get("head3_values") or project_hierarchy.get("zone1_values") or []
        for head3_value in head3_values:
            h3_levels = [level for level in levels if str(level.get("head3_group") or level.get("zone_name") or "").strip().lower() == str(head3_value).strip().lower()]
            for dim in dimensions:
                suffixes = _dedupe_keep_order([str(level.get("head4_suffix") or "").strip() for level in h3_levels]) or [""]
                for suffix in suffixes:
                    suffix_levels = [level for level in h3_levels if str(level.get("head4_suffix") or "").strip().lower() == suffix.lower()]
                    head_desc = build_dimension_placeholder_description(dim)
                    group_head = f"{head_desc} - {suffix}" if suffix else head_desc
                    group_desc = f"{head3_value} / {group_head}"
                    for level in suffix_levels:
                        if len(rows) >= safe_limit:
                            return rows
                        add_preview_row(dim, level, group_desc, level.get("description") or level.get("level_code") or "Level")
        return rows

    if layout_mode == "level_first_items_below":
        for level in levels:
            level_head = str(level.get("description") or level.get("level_code") or "Level").strip()
            for dim in dimensions:
                if len(rows) >= safe_limit:
                    return rows
                item_desc = build_dimension_placeholder_description(dim)
                if item_desc:
                    add_preview_row(dim, level, level_head, item_desc)
    else:
        for dim in dimensions:
            group_desc = build_dimension_placeholder_description(dim)
            if not group_desc:
                continue
            for level in levels:
                if len(rows) >= safe_limit:
                    return rows
                add_preview_row(dim, level, group_desc, level.get("description") or level.get("level_code") or "Level")
    return rows


def create_builder_output_preview(input_file: str, builder_levels: Optional[List[Dict[str, Any]]] = None, run_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Scan a workbook and return a no-write Builder export preview.

    The preview is intentionally read-only: it does not create the output workbook,
    does not modify the uploaded workbook, and does not change stable Builder v6.
    """
    source = safe_child(INPUT_DIR, input_file)
    if not source.exists() or not source.is_file():
        raise HTTPException(status_code=404, detail="Input file not found. Attach the workbook again.")
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise HTTPException(status_code=400, detail="Builder v4.4.0 router preview uses the stable v4.3.9.2 engine and currently supports .xlsx and .xlsm only.")

    extracted = extract_costx_xget_entries(source)
    entries: List[Dict[str, Any]] = extracted.get("entries", [])
    level_setup = load_builder_level_zone_setup()
    level_setup, levels, current_work = apply_builder_run_context_snapshot(level_setup, builder_levels, run_context)
    profile = resolve_active_trade_profile(level_setup, current_work)
    current_work["expected_unit"] = expected_unit_for_profile_function(current_work.get("default_costx_function"), profile, current_work.get("expected_unit"))
    source_preserve_count_mode = _is_source_preserve_count_builder_run(current_work, profile, entries)
    if source_preserve_count_mode:
        current_work["zone_token_mode"] = "preserve_source"
        levels = build_source_preserve_count_levels(entries)
        validation_issues = []
        dimensions = source_preserve_count_dimensions(entries, current_work, profile)
    else:
        validation_issues = validate_builder_level_zone_setup_payload(level_setup, levels)
        dimensions = unique_builder_dimensions_for_run(entries, current_work, profile) if entries else []
    profile_qa_rows = builder_profile_layout_qa(level_setup, profile, current_work, levels)
    run_learning_rows, run_learning_summary = build_builder_run_learning_rows(extracted, entries, dimensions, level_setup, current_work, profile, levels)
    layout_mode = normalize_trade_layout_mode(profile.get("layout_mode"), "item_first_levels_below")
    predicted_formula_rows = len(dimensions) if source_preserve_count_mode else (len(dimensions) * len(levels) if entries and levels else 0)

    warnings: List[str] = []
    if not entries:
        warnings.append("No CostX XGET formulas or structured Dimension Group rows were detected.")
    if not levels:
        warnings.append("No Builder rows/levels are available for output.")
    warnings.extend(validation_issues)
    for row in profile_qa_rows + run_learning_rows:
        if str(row.get("status") or "").upper() == "WARN":
            warnings.append(f"{row.get('check') or row.get('area')}: {row.get('detail')}")
    default_function = sanitize_costx_function(current_work.get("default_costx_function") or profile.get("default_costx_function") or "XGETWALLAREA", "XGETWALLAREA")
    if default_function == "XGETCUSTOM" and not sanitize_custom_quantity_name(current_work.get("custom_quantity_name") or profile.get("default_custom_quantity") or ""):
        warnings.append("XGETCUSTOM is selected but no custom quantity is selected.")

    duplicate_context = next((row for row in run_learning_rows if row.get("area") == "Duplicate context guard"), {})
    zone_decision = next((row for row in run_learning_rows if row.get("area") == "Zone token decision"), {})
    preview_rows = build_builder_output_preview_rows(dimensions, levels, level_setup, current_work, profile, layout_mode, limit=50)
    formula_integrity = validate_builder_preview_integrity(preview_rows, current_work)
    if formula_integrity.get("issues"):
        warnings.extend(["Formula Integrity Guard: " + issue for issue in formula_integrity.get("issues", [])])
    self_assessment = {
        "status": "BLOCKED" if formula_integrity.get("status") == "BLOCKED" or validation_issues else "PASS",
        "formula_integrity": formula_integrity,
        "non_blocking_warnings": warnings[:10],
        "checks": ["intent", "active context", "zone mapping", "hierarchy", "levels/exclusions", "function/unit pairing", "formula syntax", "token consistency", "attachment state"],
    }
    safe_to_export = bool(entries and levels and not validation_issues and formula_integrity.get("safe_to_preview") and not any(str(row.get("status") or "").upper() == "WARN" for row in run_learning_rows))
    review = {
        "builder_version": "v4.3.9.2 Report Polish + Background-Ready Preview Guard",
        "input_name": source.name,
        "trade_profile_id": current_work.get("trade_profile_id"),
        "trade_profile_name": profile.get("display_name", current_work.get("trade_profile_id", "Trade Profile")),
        "function_mode": current_work.get("costx_function_mode", "preserve_detected"),
        "default_costx_function": default_function,
        "custom_quantity_name": (current_work.get("custom_quantity_name") or profile.get("default_custom_quantity") or "") if default_function == "XGETCUSTOM" else "",
        "custom_quantity_unit": (current_work.get("custom_quantity_unit") or profile.get("default_custom_quantity_unit") or "") if default_function == "XGETCUSTOM" else "",
        "expected_unit": current_work.get("expected_unit"),
        "zone_token_mode": current_work.get("zone_token_mode", "preserve_source"),
        "item_code_config": sanitize_item_code_config(current_work.get("item_code_config") if isinstance(current_work.get("item_code_config"), dict) else {}),
        "item_code_summary": builder_item_code_summary(current_work.get("item_code_config") if isinstance(current_work.get("item_code_config"), dict) else {}),
        "active_combo_id": "source_preserve_count_rows" if source_preserve_count_mode else level_setup.get("active_combo_id", ""),
        "active_level_zone_preset": "Source-preserve count rows" if source_preserve_count_mode else level_setup.get("active_preset", "Active"),
        "layout_mode": layout_mode,
        "layout_label": trade_layout_label(layout_mode),
        "project_zone_hierarchy": current_work.get("project_zone_hierarchy") if isinstance(current_work.get("project_zone_hierarchy"), dict) else None,
        "run_only_project_setup": bool(isinstance(current_work.get("project_zone_hierarchy"), dict) and current_work.get("project_zone_hierarchy", {}).get("run_only")),
        "entries_detected": len(entries),
        "unique_dimensions": len(dimensions),
        "editable_levels": len(levels),
        "predicted_formula_rows": predicted_formula_rows,
        "source_preserve_count_mode": bool(source_preserve_count_mode),
        "preview_rows": preview_rows,
        "preview_row_limit": 50,
        "preview_rows_shown": len(preview_rows),
        "preview_rows_remaining": max(0, predicted_formula_rows - len(preview_rows)),
        "functions": run_learning_summary.get("functions", {}),
        "units": filtered_builder_unit_summary(run_learning_summary.get("units", {})),
        "custom_quantities": run_learning_summary.get("custom_quantities", {}),
        "source_zone_token_count": run_learning_summary.get("source_zone_token_count", 0),
        "source_zone_token_examples": run_learning_summary.get("source_zone_token_examples", []),
        "source_types": extracted.get("source_types", {}),
        "ignored_sheets": extracted.get("ignored_sheets", []),
        "duplicate_context_guard": duplicate_context,
        "zone_decision": zone_decision,
        "warnings": warnings[:30],
        "formula_integrity": formula_integrity,
        "self_assessment": self_assessment,
        "profile_qa": profile_qa_rows,
        "run_learning": run_learning_rows,
        "stable_builder_v6_modified": False,
        "stable_formatter_modified": False,
        "background_ready_guard": {
            "status": "PASS",
            "detail": "Jarvis v4.4.4.15.3 preserves the v4.4.4.15.2 panic/router guards and fixes post-preview/previous-plan persistence plus precise negation handling for edits like do not remove L3."
    },
    }
    return {
        "status": "ok" if safe_to_export else "warn",
        "safe_to_export": safe_to_export,
        "message": "Builder preview completed. Review the setup before export.",
        "input_name": source.name,
        "review": review,
        "summary": review,
    }

def create_builder_output(input_file: str, output_prefix: Optional[str] = None, builder_levels: Optional[List[Dict[str, Any]]] = None, run_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Jarvis v4.2.6 Builder Base Sheet Lite with Zone Behavior Modes and Working Zone Combo Presets.

    Reads a raw CostX/XGET dimension group list and creates a practical base sheet:
    Column B = Description / Dimension Group Head / Level
    Column C = CostX formula per level
    Column D = Unit / Row Type

    This is intentionally a lite base generator: it gives the user an editable starting
    point with one Head4 per Dimension Group and default level rows below each head.
    It does not replace Builder v6 and does not modify the uploaded workbook.
    """
    source = safe_child(INPUT_DIR, input_file)
    if not source.exists() or not source.is_file():
        raise HTTPException(status_code=404, detail="Input file not found. Attach the workbook again.")
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise HTTPException(status_code=400, detail="Builder v4.4.0 router uses the stable v4.3.9.2 engine and currently supports .xlsx and .xlsm only.")

    extracted = extract_costx_xget_entries(source)
    entries: List[Dict[str, Any]] = extracted.get("entries", [])
    if not entries:
        raise HTTPException(status_code=400, detail="No CostX XGET formulas or structured Dimension Group rows were detected. Attach a CostX formula list or Dimension Group export.")

    # Dimensions are resolved after the run context/profile is locked so Preserve
    # Detected mode can keep duplicate XGETCUSTOM contexts separate.
    dimensions: List[Dict[str, Any]] = []
    level_setup = load_builder_level_zone_setup()
    # v4.3.9: Preview and Export share the same run-context snapshot logic.
    level_setup, levels, current_work = apply_builder_run_context_snapshot(level_setup, builder_levels, run_context)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
    from openpyxl.utils import get_column_letter

    BUILDER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = output_prefix or "Jarvis_Builder_Base_Lite"
    safe_prefix = re.sub(r"[^A-Za-z0-9_-]+", "_", prefix).strip("_") or "Jarvis_Builder_Base_Lite"
    output_name = f"{stamp}_{safe_prefix}_{source.stem}.xlsx"
    output_path = BUILDER_OUTPUT_DIR / output_name

    wb = Workbook()
    ws = wb.active
    ws.title = "Builder_Base"

    # Style definitions matching the existing QS base-sheet style: simple, editable, no filter/freeze.
    thin = Side(style="thin", color="FFD9D9D9")
    light_bottom = Border(bottom=thin)
    head_fill = PatternFill("solid", fgColor="FFF4F8FB")
    head_font = Font(name="Calibri", size=11, underline="single")
    level_font = Font(name="Calibri", size=11, italic=True)
    normal_font = Font(name="Calibri", size=11)
    formula_font = Font(name="Calibri", size=11, italic=True)

    item_code_config = sanitize_item_code_config(current_work.get("item_code_config") if isinstance(current_work.get("item_code_config"), dict) else {})
    item_code_state = builder_item_code_state(item_code_config)

    row_idx = 1
    generated_formula_rows = 0
    head_rows = 0
    profile = resolve_active_trade_profile(level_setup, current_work)
    current_work["expected_unit"] = expected_unit_for_profile_function(current_work.get("default_costx_function"), profile, current_work.get("expected_unit"))
    source_preserve_count_mode = _is_source_preserve_count_builder_run(current_work, profile, entries)
    if source_preserve_count_mode:
        current_work["zone_token_mode"] = "preserve_source"
        levels = build_source_preserve_count_levels(entries)
        validation_issues = []
        dimensions = source_preserve_count_dimensions(entries, current_work, profile)
    else:
        validation_issues = validate_builder_level_zone_setup_payload(level_setup, levels)
        if validation_issues:
            raise HTTPException(status_code=400, detail="Builder setup validation failed: " + "; ".join(validation_issues))
        dimensions = unique_builder_dimensions_for_run(entries, current_work, profile)
    profile_qa_rows = builder_profile_layout_qa(level_setup, profile, current_work, levels)
    run_learning_rows, run_learning_summary = build_builder_run_learning_rows(extracted, entries, dimensions, level_setup, current_work, profile, levels)
    profile_qa_rows.extend({"check": row.get("area"), "status": row.get("status"), "detail": row.get("detail")} for row in run_learning_rows if row.get("area") in {"Run-scope learning", "Zone token decision", "Duplicate context guard", "Weak-source guard", "Formula guard", "Project hierarchy guard"})
    layout_mode = normalize_trade_layout_mode(profile.get("layout_mode"), "item_first_levels_below")
    layout_label = trade_layout_label(layout_mode)
    # v4.4.4.10 Right Track Guard: run a no-write formula/token self-check
    # before creating the workbook. This does not rewrite the stable formula engine;
    # it blocks export when the generated sample is internally inconsistent.
    formula_guard_rows = build_builder_output_preview_rows(dimensions, levels, level_setup, current_work, profile, layout_mode, limit=200)
    formula_guard = validate_builder_preview_integrity(formula_guard_rows, current_work)
    if not formula_guard.get("safe_to_export"):
        raise HTTPException(status_code=400, detail="Formula Integrity Guard blocked export: " + "; ".join(formula_guard.get("issues") or ["Formula/token validation failed."]))

    # v4.3.2 layout modes plus v4.4.4.6 run-only dynamic project hierarchy:
    # - project_zone_hierarchy: selected dynamic zone as requested Head level, detected dimensions/types plus combo zones as the next Head level, levels below.
    # - item_first_levels_below: Wall/finish/joinery style. Item Head4 first, levels underneath.
    # - level_first_items_below: Door/window style. Level Head4 first, items underneath.
    # - mixed_section_driven and conservative_structural currently use the safe item-first base but are flagged in the report.
    # v4.4.4.6 optional trade title code row, e.g. A / Wall Types Trade, before project hierarchy rows.
    row_idx = maybe_write_builder_trade_title_row(ws, row_idx, item_code_state, current_work, head_font, head_fill, light_bottom, normal_font, Alignment)
    if row_idx > 1:
        head_rows += 1

    if source_preserve_count_mode:
        # v4.5.1.25: Doors/Windows source-preserve count output. The source
        # formula token decides the level; do not cross-join every item against
        # workspace/default Builder levels. This keeps D0.11[3|GF] under GF only
        # and avoids invented L2/L3/L4 rows.
        level_order = _dedupe_keep_order([str(level.get("level_code") or level.get("description") or "").strip() for level in levels if str(level.get("level_code") or level.get("description") or "").strip()])
        if not level_order:
            level_order = _dedupe_keep_order([str(dim.get("source_level_label") or _source_token_level_label(dim.get("source_zone_token") or "")).strip() for dim in dimensions])
        for level_label in level_order:
            if not level_label:
                continue
            write_builder_head_row(ws, row_idx, level_label, head_font, head_fill, light_bottom, normal_font, Alignment, builder_section_code_for_heading(item_code_state))
            head_rows += 1
            row_idx += 1
            for dim in dimensions:
                dim_level = str(dim.get("source_level_label") or _source_token_level_label(dim.get("source_zone_token") or "")).strip()
                if dim_level.lower() != level_label.lower():
                    continue
                item_desc = build_dimension_placeholder_description(dim)
                if not item_desc:
                    continue
                function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
                dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
                level = {"level_code": level_label, "description": level_label, "token_parts": sanitize_costx_token_parts(dim.get("source_zone_token") or "")}
                write_builder_item_row(
                    ws,
                    row_idx,
                    item_desc,
                    build_level_xget_formula(function_name, dimension_for_formula, level, None, "", dim.get("source_zone_token"), "preserve_source"),
                    unit,
                    level_font,
                    formula_font,
                    normal_font,
                    Alignment,
                    builder_next_item_code(item_code_state, "formula"),
                )
                generated_formula_rows += 1
                row_idx += 1
    project_hierarchy = current_work.get("project_zone_hierarchy") if isinstance(current_work.get("project_zone_hierarchy"), dict) else None
    if (not source_preserve_count_mode) and project_hierarchy and project_hierarchy.get("hierarchy_zones"):
        # v4.4.4.14 hierarchy parent grouping cleanup. Write nested parent
        # headings once per branch (for example Stage 1 once, then Internal and
        # External as sibling Head2 rows) instead of repeating the same parent
        # Head1 for every child path. Formula strings still come from the locked
        # stable Builder function via each row's token_parts.
        dimension_head_type = project_hierarchy.get("dimension_head") or "Head4"
        section_code_written = False

        def node_key_for_level(level: Dict[str, Any], depth: int) -> str:
            path = level.get("hierarchy_path") if isinstance(level.get("hierarchy_path"), list) else []
            if depth >= len(path):
                return ""
            node = path[depth] if isinstance(path[depth], dict) else {}
            return f"{node.get('zone_index')}::{str(node.get('value') or '').strip().lower()}::{str(node.get('head') or '').strip().lower()}"

        def node_for_level(level: Dict[str, Any], depth: int) -> Dict[str, Any]:
            path = level.get("hierarchy_path") if isinstance(level.get("hierarchy_path"), list) else []
            if depth < len(path) and isinstance(path[depth], dict):
                return path[depth]
            return {}

        def write_dimension_blocks(block_levels: List[Dict[str, Any]]) -> None:
            nonlocal row_idx, head_rows, generated_formula_rows
            for dim in dimensions:
                base_head_desc = build_dimension_placeholder_description(dim)
                if not base_head_desc:
                    continue
                suffixes = _dedupe_keep_order([str(level.get("dimension_suffix") or level.get("head4_suffix") or "").strip() for level in block_levels]) or [""]
                for suffix in suffixes:
                    suffix_levels = [level for level in block_levels if str(level.get("dimension_suffix") or level.get("head4_suffix") or "").strip().lower() == suffix.lower()]
                    if not suffix_levels:
                        continue
                    head_desc = f"{base_head_desc} - {suffix}" if suffix else base_head_desc
                    write_builder_heading_row(ws, row_idx, head_desc, dimension_head_type, head_font, head_fill, light_bottom, normal_font, Alignment)
                    head_rows += 1
                    row_idx += 1
                    function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
                    custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config(current_work, profile, dim) if function_name == "XGETCUSTOM" else ("", unit)
                    if function_name == "XGETCUSTOM":
                        unit = canonical_builder_unit(custom_quantity_unit or unit)
                    dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
                    for level in suffix_levels:
                        write_builder_item_row(
                            ws,
                            row_idx,
                            level.get("description") or level.get("level_code"),
                            build_level_xget_formula(function_name, dimension_for_formula, level, None, custom_quantity_name, "", "rebuild"),
                            unit,
                            level_font,
                            formula_font,
                            normal_font,
                            Alignment,
                            builder_next_item_code(item_code_state, "formula"),
                        )
                        generated_formula_rows += 1
                        row_idx += 1

        def write_hierarchy_branch(block_levels: List[Dict[str, Any]], depth: int = 0) -> None:
            nonlocal row_idx, head_rows, section_code_written
            if not block_levels:
                return
            max_depth = max((len(level.get("hierarchy_path") or []) for level in block_levels), default=0)
            if depth >= max_depth:
                write_dimension_blocks(block_levels)
                return
            keys = _dedupe_keep_order([node_key_for_level(level, depth) for level in block_levels if node_key_for_level(level, depth)])
            if not keys:
                write_dimension_blocks(block_levels)
                return
            for key in keys:
                child_levels = [level for level in block_levels if node_key_for_level(level, depth) == key]
                node = node_for_level(child_levels[0], depth) if child_levels else {}
                desc = str(node.get("value") or "").strip()
                if desc:
                    code = ""
                    if depth == 0 and not section_code_written:
                        code = builder_section_code_for_heading(item_code_state)
                        section_code_written = True
                    write_builder_heading_row(ws, row_idx, desc, str(node.get("head") or "Head3"), head_font, head_fill, light_bottom, normal_font, Alignment, code)
                    head_rows += 1
                    row_idx += 1
                write_hierarchy_branch(child_levels, depth + 1)

        write_hierarchy_branch(levels, 0)
    elif (not source_preserve_count_mode) and project_hierarchy and project_hierarchy.get("head3_source") in {"zone1", "dynamic_zone"}:
        primary_head_type = project_hierarchy.get("primary_head") or project_hierarchy.get("start_head") or "Head3"
        dimension_head_type = project_hierarchy.get("dimension_head") or _next_head_label(primary_head_type)
        for head3_value in project_hierarchy.get("head3_values") or project_hierarchy.get("zone1_values") or []:
            head3_value = str(head3_value).strip()
            if not head3_value:
                continue
            if item_code_config.get("enabled") and item_code_config.get("reset_scope") == "per_head3":
                builder_reset_item_code_counter(item_code_state)
            write_builder_heading_row(ws, row_idx, head3_value, primary_head_type, head_font, head_fill, light_bottom, normal_font, Alignment, builder_section_code_for_heading(item_code_state))
            head_rows += 1
            row_idx += 1
            h3_levels = [level for level in levels if str(level.get("head3_group") or level.get("zone_name") or "").strip().lower() == head3_value.lower()]
            for dim in dimensions:
                base_head_desc = build_dimension_placeholder_description(dim)
                if not base_head_desc:
                    continue
                suffixes = _dedupe_keep_order([str(level.get("head4_suffix") or "").strip() for level in h3_levels]) or [""]
                for suffix in suffixes:
                    suffix_levels = [level for level in h3_levels if str(level.get("head4_suffix") or "").strip().lower() == suffix.lower()]
                    head_desc = f"{base_head_desc} - {suffix}" if suffix else base_head_desc
                    write_builder_heading_row(ws, row_idx, head_desc, dimension_head_type, head_font, head_fill, light_bottom, normal_font, Alignment)
                    head_rows += 1
                    row_idx += 1
                    function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
                    custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config(current_work, profile, dim) if function_name == "XGETCUSTOM" else ("", unit)
                    if function_name == "XGETCUSTOM":
                        unit = canonical_builder_unit(custom_quantity_unit or unit)
                    dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
                    for level in suffix_levels:
                        write_builder_item_row(
                            ws,
                            row_idx,
                            level.get("description") or level.get("level_code"),
                            build_level_xget_formula(function_name, dimension_for_formula, level, None, custom_quantity_name, "", "rebuild"),
                            unit,
                            level_font,
                            formula_font,
                            normal_font,
                            Alignment,
                            builder_next_item_code(item_code_state, "formula"),
                        )
                        generated_formula_rows += 1
                        row_idx += 1
    elif (not source_preserve_count_mode) and layout_mode == "level_first_items_below":
        for level in levels:
            level_head = str(level.get("description") or level.get("level_code") or "Level").strip()
            write_builder_head_row(ws, row_idx, level_head, head_font, head_fill, light_bottom, normal_font, Alignment, builder_section_code_for_heading(item_code_state))
            head_rows += 1
            row_idx += 1
            for dim in dimensions:
                item_desc = build_dimension_placeholder_description(dim)
                if not item_desc:
                    continue
                function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
                custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config(current_work, profile, dim) if function_name == "XGETCUSTOM" else ("", unit)
                if function_name == "XGETCUSTOM":
                    unit = canonical_builder_unit(custom_quantity_unit or unit)
                dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
                write_builder_item_row(
                    ws,
                    row_idx,
                    item_desc,
                    build_level_xget_formula(function_name, dimension_for_formula, level, level_setup.get("active_categories"), custom_quantity_name, dim.get("source_zone_token"), current_work.get("zone_token_mode", "preserve_source")),
                    unit,
                    level_font,
                    formula_font,
                    normal_font,
                    Alignment,
                    builder_next_item_code(item_code_state, "formula"),
                )
                generated_formula_rows += 1
                row_idx += 1
    elif not source_preserve_count_mode:
        for dim in dimensions:
            head_desc = build_dimension_placeholder_description(dim)
            if not head_desc:
                continue
            write_builder_head_row(ws, row_idx, head_desc, head_font, head_fill, light_bottom, normal_font, Alignment, builder_section_code_for_heading(item_code_state))
            head_rows += 1
            row_idx += 1
            function_name, unit = resolve_dimension_function_unit(dim, current_work, profile)
            custom_quantity_name, custom_quantity_unit = resolve_custom_quantity_config(current_work, profile, dim) if function_name == "XGETCUSTOM" else ("", unit)
            if function_name == "XGETCUSTOM":
                unit = canonical_builder_unit(custom_quantity_unit or unit)
            dimension_for_formula = dim.get("builder_formula_dimension") or builder_exact_dimension_name(dim)
            for level in levels:
                write_builder_item_row(
                    ws,
                    row_idx,
                    level.get("description"),
                    build_level_xget_formula(function_name, dimension_for_formula, level, level_setup.get("active_categories"), custom_quantity_name, dim.get("source_zone_token"), current_work.get("zone_token_mode", "preserve_source")),
                    unit,
                    level_font,
                    formula_font,
                    normal_font,
                    Alignment,
                    builder_next_item_code(item_code_state, "formula"),
                )
                generated_formula_rows += 1
                row_idx += 1

    ws.column_dimensions["A"].width = 16 if item_code_config.get("enabled") else 4
    ws.column_dimensions["B"].width = 72
    ws.column_dimensions["C"].width = 76
    ws.column_dimensions["D"].width = 16
    for r in range(1, ws.max_row + 1):
        ws.row_dimensions[r].height = 18
    ws.freeze_panes = None
    ws.auto_filter.ref = None

    sx = wb.create_sheet("CostX_Extract")
    sx.append(["Function", "Original Dimension", "Normalised Dimension", "Relationship", "Tag", "Unit", "Custom Quantity", "Formula", "Source Sheet", "Source Row", "Source Col"])
    for cell in sx[1]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    for entry in entries:
        extract_function, extract_unit = resolve_dimension_function_unit(entry, current_work, profile)
        extract_custom = entry.get("custom_quantity_name") or (resolve_custom_quantity_config(current_work, profile, entry)[0] if extract_function == "XGETCUSTOM" else "")
        if extract_function == "XGETCUSTOM":
            # Prefer the detected custom quantity unit when present; otherwise selected run-context custom quantity unit.
            detected_unit = custom_quantity_unit_lookup(entry.get("custom_quantity_name"), profile) if entry.get("custom_quantity_name") else ""
            extract_unit = canonical_builder_unit(detected_unit if detected_unit and detected_unit.lower() != "review" else extract_unit)
        sx.append([extract_function, entry.get("dimension"), entry.get("dimension_normalised"), entry.get("relationship"), entry.get("tag"), extract_unit, extract_custom, entry.get("formula"), entry.get("source_sheet"), entry.get("source_row"), entry.get("source_col")])
    for col in range(1, sx.max_column + 1):
        sx.column_dimensions[get_column_letter(col)].width = 22 if col != 7 else 60
    sx.freeze_panes = "A2"
    sx.auto_filter.ref = sx.dimensions

    zone_library = sanitize_builder_zone_library(level_setup.get("zone_library"))
    lzs = wb.create_sheet("Level_Zone_Setup")
    lzs.append(["Current Work Setup", "", "", "", "", ""])
    for cell in lzs[1]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
    lzs.append(["Project / Setup", current_work.get("project_name"), "Trade Profile", profile.get("display_name", ""), "Formula Mode", current_work.get("formula_mode")])
    lzs.append(["Setup Name", current_work.get("setup_name"), "Working Combo", "Source-preserve count rows" if source_preserve_count_mode else level_setup.get("active_preset", "Active"), "Default Function", current_work.get("default_costx_function")])
    lzs.append(["Expected Unit", current_work.get("expected_unit") or expected_unit_for_profile_function(current_work.get("default_costx_function"), profile, profile.get("default_unit")), "Layout Mode", layout_mode, "Layout Label", layout_label])
    lzs.append(["Custom Quantity", current_work.get("custom_quantity_name") or profile.get("default_custom_quantity") or "", "Custom Quantity Unit", current_work.get("custom_quantity_unit") or profile.get("default_custom_quantity_unit") or "", "XGETCUSTOM Rule", builder_xgetcustom_report_note(current_work, profile)])
    lzs.append(["Item Code", builder_item_code_summary(item_code_config), "Code Prefix", item_code_config.get("prefix") if item_code_config.get("enabled") else "", "Separator", item_code_config.get("separator") if item_code_config.get("enabled") else ""])
    lzs.append(["Function Mode", current_work.get("costx_function_mode", "preserve_detected"), "Notes", current_work.get("notes", ""), "", ""])
    lzs.append([])
    lzs.append(["Builder Output Rows / Formula Tokens", "", "", "", "", ""])
    lzs.append(["Zone Index", "Zone Name", "Level Index", "Level Code", "Level Description", "Formula Token"])
    for cell in lzs[1]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
    for cell in lzs[2]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for level in levels:
        lzs.append([level.get("zone_index"), level.get("zone_name"), level.get("level_index"), level.get("level_code"), level.get("description"), builder_level_token(level)])
    lzs.append([])
    lzs.append(["CostX Zone Library", "", "", "", "", ""])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
    lzs.append(["Category Index", "Category Name", "Value Code", "Description", "Example Token Part", "Used Automatically?"])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for zone in zone_library:
        idx = zone.get("category_index")
        val = zone.get("value_code")
        lzs.append([idx, zone.get("category_name"), val, zone.get("description"), f"{idx}|{val}", "No - add to Builder token row only when needed"])
    lzs.append([])
    lzs.append(["Active Zone Behavior / Current Combo", "", "", "", "", ""])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
    lzs.append(["Category Index", "Category Name", "Active", "Behavior", "Global Value", "Locked Source"])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for cat in sanitize_builder_active_categories(level_setup.get("active_categories")):
        lzs.append([cat.get("category_index"), cat.get("category_name"), "Yes" if cat.get("active") else "No", cat.get("behavior"), cat.get("default_value"), cat.get("locked_source")])
    lzs.append([])
    lzs.append(["Working Zone Combo Presets", "", "", "", "", ""])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
    lzs.append(["Combo ID", "Combo Name", "Description", "Active Zones", "", ""])
    for cell in lzs[lzs.max_row]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for combo in sanitize_builder_zone_combos(level_setup.get("zone_combos")):
        active_bits = []
        for cat in sanitize_builder_active_categories(combo.get("active_categories")):
            if cat.get("active"):
                bit = f"ZC{cat.get('category_index')} {cat.get('behavior')}"
                if cat.get("default_value"):
                    bit += f"={cat.get('default_value')}"
                if cat.get("locked_source"):
                    bit += f" from {cat.get('locked_source')}"
                active_bits.append(bit)
        lzs.append([combo.get("combo_id"), combo.get("combo_name"), combo.get("description"), "; ".join(active_bits), "", ""])
    for col in range(1, lzs.max_column + 1):
        lzs.column_dimensions[get_column_letter(col)].width = 20 if col not in {3, 4, 6} else 48
    lzs.freeze_panes = "A3"
    lzs.auto_filter.ref = lzs.dimensions

    qa = wb.create_sheet("Profile_QA")
    qa.append(["Check", "Status", "Detail"])
    for cell in qa[1]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for row in profile_qa_rows:
        qa.append([row.get("check"), row.get("status"), row.get("detail")])
    for col in range(1, qa.max_column + 1):
        qa.column_dimensions[get_column_letter(col)].width = 24 if col < 3 else 90
    qa.freeze_panes = "A2"
    qa.auto_filter.ref = qa.dimensions

    learn_ws = wb.create_sheet("Jarvis_Run_Learning")
    learn_ws.append(["Area", "Status", "Run Learning / Relearning Detail"])
    for cell in learn_ws[1]:
        cell.font = Font(name="Calibri", size=11, bold=True)
        cell.fill = head_fill
        cell.border = light_bottom
    for row in run_learning_rows:
        learn_ws.append([row.get("area"), row.get("status"), row.get("detail")])
    for col in range(1, learn_ws.max_column + 1):
        learn_ws.column_dimensions[get_column_letter(col)].width = 24 if col < 3 else 110
    learn_ws.freeze_panes = "A2"
    learn_ws.auto_filter.ref = learn_ws.dimensions

    rpt = wb.create_sheet("Jarvis_Builder_Report")
    report_rows = [
        ("Jarvis version", APP_VERSION),
        ("Builder engine", "v4.3.9.2 Report Polish + Background-Ready Preview Guard"),
        ("Input file", source.name),
        ("Output file", output_name),
        ("Created at", now_iso()),
        ("Dimension entries detected", len(entries)),
        ("Source types", ", ".join(f"{k}: {v}" for k, v in sorted(extracted.get("source_types", {}).items()))),
        ("Run-learned functions", format_count_map(run_learning_summary.get("functions", {}))),
        ("Run-learned units", format_count_map(filtered_builder_unit_summary(run_learning_summary.get("units", {})))),
        ("Run-learned custom quantities", format_count_map(run_learning_summary.get("custom_quantities", {}))),
        ("Source zone tokens detected", run_learning_summary.get("source_zone_token_count", 0)),
        ("Ignored helper sheets", ", ".join(extracted.get("ignored_sheets", [])) or "None"),
        ("Unique dimension groups / " + ((current_work.get("project_zone_hierarchy") or {}).get("dimension_head") or "Head4") + " rows", len(dimensions)),
        ("Editable levels per dimension", len(levels)),
        ("Active level/zone preset", "Source-preserve count rows" if source_preserve_count_mode else level_setup.get("active_preset", "Active")),
        ("Active zone combo id", "source_preserve_count_rows" if source_preserve_count_mode else level_setup.get("active_combo_id", "")),
        ("Current project/setup", current_work.get("project_name", "")),
        ("Current setup name", current_work.get("setup_name", "")),
        ("Current trade profile id", current_work.get("trade_profile_id", "walls_partitions")),
        ("Trade profile used", profile.get("display_name", "Walls / Partitions")),
        ("Trade profile layout mode", layout_mode),
        ("Trade profile layout rule", profile.get("layout_rule", "")),
        ("Project-learned layout label", layout_label),
        ("Expected unit", current_work.get("expected_unit") or expected_unit_for_profile_function(current_work.get("default_costx_function"), profile, profile.get("default_unit"))),
        ("Custom quantity", current_work.get("custom_quantity_name") or profile.get("default_custom_quantity") or ""),
        ("Custom quantity unit", current_work.get("custom_quantity_unit") or profile.get("default_custom_quantity_unit") or ""),
        ("Item code mode", builder_item_code_summary(item_code_config)),
        ("XGETCUSTOM rule", builder_xgetcustom_report_note(current_work, profile)),
        ("Current formula mode", current_work.get("formula_mode", "Compact")),
        ("Zone token mode", current_work.get("zone_token_mode", "preserve_source")),
        ("Run context lock", "Enabled - this Builder job used the UI snapshot sent at run time."),
        ("Background readiness", "Enabled - preview and export use the same locked snapshot, so background jobs can run without drifting profile/function/custom quantity/unit/zone state."),
        ("Default CostX function", current_work.get("default_costx_function", "XGETWALLAREA")),
        ("CostX function mode", current_work.get("costx_function_mode", "preserve_detected")),
        ("Function fallback rule", "Preserve detected raw XGET function unless CostX Function Mode is Force selected default function."),
        ("Validation", "Passed"),
        ("Profile QA", "; ".join(f"{r.get('check')}: {r.get('status')}" for r in profile_qa_rows)),
        ("Working zone combo count", len(sanitize_builder_zone_combos(level_setup.get("zone_combos")))),
        ("Generated formula rows", generated_formula_rows),
        ("Relationship groups", len(extracted.get("groups", {}))),
        ("Functions detected", ", ".join(f"{k}: {v}" for k, v in sorted(extracted.get("functions", {}).items()))),
        ("Base layout", "Column A = Item Code (optional), Column B = Description / " + ((current_work.get("project_zone_hierarchy") or {}).get("dimension_head") or "Head4") + " / Level, Column C = CostX formula, Column D = Unit / Row Type"),
        ("Token pattern", "[ZoneIndex|ZoneName;LevelIndex|LevelCode]"),
        ("CostX zone library rows", len(sanitize_builder_zone_library(level_setup.get("zone_library")))),
        ("Compact token mode", "On - only selected zone combo categories are included in each row token"),
        ("Zone behavior modes", "Global / Locked / Choosable"),
        ("Stable Builder v6 modified", "No"),
        ("Stable Formatter modified", "No"),
        ("Safety note", "Builder v4.3.9.2 created a safe output using a locked run-context snapshot, preview-first/background-ready safeguards, run-only learning/relearning, exact dimension casing, duplicate custom context guard, expected unit guard, profile layout QA, preserved source zones when enabled, and helper-sheet filtering. Stable tools were not modified."),
    ]
    for r, (k, v) in enumerate(report_rows, start=1):
        rpt.cell(r, 1, k)
        rpt.cell(r, 2, v)
        rpt.cell(r, 1).font = Font(name="Calibri", size=11, bold=True)
        rpt.cell(r, 2).font = Font(name="Calibri", size=11)
        rpt.cell(r, 2).alignment = Alignment(wrap_text=True, vertical="top")
    rpt.column_dimensions["A"].width = 34
    rpt.column_dimensions["B"].width = 110

    wb.save(output_path)
    rel = str(output_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    summary = {
        "builder_version": "v4.3.9.2 Report Polish + Background-Ready Preview Guard",
        "entries_detected": len(entries),
        "unique_dimensions": len(dimensions),
        "levels_per_dimension": len(levels),
        "active_level_zone_preset": "Source-preserve count rows" if source_preserve_count_mode else level_setup.get("active_preset", "Active"),
        "active_combo_id": "source_preserve_count_rows" if source_preserve_count_mode else level_setup.get("active_combo_id", ""),
        "current_work_setup": current_work,
        "trade_profile_used": profile,
        "trade_profile_layout_mode": layout_mode,
        "trade_profile_layout_label": layout_label,
        "expected_unit": current_work.get("expected_unit") or expected_unit_for_profile_function(current_work.get("default_costx_function"), profile, profile.get("default_unit")),
        "zone_token_mode": current_work.get("zone_token_mode", "preserve_source"),
        "run_context_locked": bool(run_context),
        "custom_quantity_name": (current_work.get("custom_quantity_name") or profile.get("default_custom_quantity") or "") if current_work.get("default_costx_function") == "XGETCUSTOM" else "",
        "custom_quantity_unit": (current_work.get("custom_quantity_unit") or profile.get("default_custom_quantity_unit") or "") if current_work.get("default_costx_function") == "XGETCUSTOM" else "",
        "item_code_config": item_code_config,
        "item_code_summary": builder_item_code_summary(item_code_config),
        "profile_qa": profile_qa_rows,
        "run_learning": run_learning_rows,
        "run_learning_summary": run_learning_summary,
        "head_rows": head_rows,
        "default_costx_function": current_work.get("default_costx_function", "XGETWALLAREA"),
        "costx_function_mode": current_work.get("costx_function_mode", "preserve_detected"),
        "supported_costx_functions": SUPPORTED_COSTX_FUNCTIONS,
        "validation": "passed",
        "zone_combo_count": len(sanitize_builder_zone_combos(level_setup.get("zone_combos"))),
        "trade_profile_count": len(sanitize_builder_trade_profiles(level_setup.get("trade_profiles"))),
        "generated_formula_rows": generated_formula_rows,
        "zone_library_rows": len(sanitize_builder_zone_library(level_setup.get("zone_library"))),
        "compact_token_mode": True,
        "zone_behavior_modes": ["global", "locked", "choosable"],
        "relationship_groups": extracted.get("groups", {}),
        "functions": extracted.get("functions", {}),
        "scanned_cells": extracted.get("scanned_cells", 0),
        "source_types": extracted.get("source_types", {}),
        "ignored_sheets": extracted.get("ignored_sheets", []),
        "sheets": ["Builder_Base", "CostX_Extract", "Level_Zone_Setup", "Profile_QA", "Jarvis_Run_Learning", "Jarvis_Builder_Report"],
        "base_layout": "A=Item Code (optional), B=Description, C=Formula, D=Unit/Row Type",
        "layout_modes_available": ["item_first_levels_below", "level_first_items_below", "mixed_section_driven", "conservative_structural"],
        "stable_builder_v6_modified": False,
        "stable_formatter_modified": False,
        "background_ready_guard": {
            "status": "PASS",
            "detail": "Jarvis v4.4.4.15.3 preserves the v4.4.4.15.2 panic/router guards and fixes post-preview/previous-plan persistence plus precise negation handling for edits like do not remove L3."
    },
    }
    payload = {
        "status": "ok",
        "message": "Builder base sheet created safely. Original upload and stable Builder v6 were not modified.",
        "input_name": source.name,
        "output_name": output_path.name,
        "relative_path": rel,
        "download_url": clean_download_url(rel),
        "note": "Jarvis v4.3.9.2 generated Builder output using a locked UI run-context snapshot, preview-first/background-ready guard, clean report unit summaries, helper-sheet ignore guard, exact source dimension casing, duplicate custom context guard, source zone token preserve mode, XGETCUSTOM unit guard, compact zone tokens, and standardized count units, and optional flexible BOQ item-code Column A.",
        "summary": summary,
    }
    write_log("builder_run", payload)
    return payload


def run_builder_background_job(job_id: str, input_file: str, output_prefix: Optional[str] = None, builder_levels: Optional[List[Dict[str, Any]]] = None, run_context: Optional[Dict[str, Any]] = None) -> None:
    update_job(job_id, status="running", progress=8, stage="Validating raw CostX/XGET workbook")
    try:
        source = safe_child(INPUT_DIR, input_file)
        if not source.exists() or not source.is_file():
            raise FileNotFoundError("Input file not found. Attach the workbook again.")
        update_job(job_id, progress=24, stage="Scanning CostX/XGET formulas", input_name=source.name)
        write_state_shadow_snapshot("builder_export_started", str((run_context or {}).get("conversation_id") or ""), {"job_id": job_id, "input_file": input_file, "run_context": run_context})
        payload = create_builder_output(input_file, output_prefix, builder_levels, run_context)
        update_job(job_id, progress=92, stage="Saving Builder job report", result=payload)
        write_log("builder_background_job_completed", {"job_id": job_id, **payload})
        write_state_shadow_snapshot("builder_export_completed", str((run_context or {}).get("conversation_id") or ""), {"job_id": job_id, "input_file": input_file, "result": payload})
        update_job(job_id, status="completed", progress=100, stage="Completed", completed_at=now_iso(), result=payload)
    except Exception as exc:
        write_log("builder_background_job_failed", {"job_id": job_id, "error": str(exc)})
        write_state_shadow_snapshot("builder_export_failed", str((run_context or {}).get("conversation_id") or ""), {"job_id": job_id, "input_file": input_file, "error": str(exc), "run_context": run_context})
        update_job(job_id, status="failed", progress=100, stage="Failed", error=str(exc), completed_at=now_iso())


def normalize_builder_run_snapshot_request(req: Any) -> tuple[Optional[List[Dict[str, Any]]], Dict[str, Any]]:
    """Prefer the locked frontend Builder run snapshot over old Workspace defaults.

    v4.5.1.24.2A: the frontend already sends builder_run_snapshot. Older
    backend request models dropped it, so preview/export could silently fall
    back to Milestone/default setup. This adapter maps the snapshot back into
    the existing stable Builder engine contract without rewriting formula code.
    """
    snapshot = getattr(req, "builder_run_snapshot", None)
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    plan = snapshot.get("plan") if isinstance(snapshot.get("plan"), dict) else {}
    snapshot_setup = snapshot.get("current_work_setup") if isinstance(snapshot.get("current_work_setup"), dict) else {}
    plan_setup = plan.get("current_work_setup") if isinstance(plan.get("current_work_setup"), dict) else {}
    request_setup = getattr(req, "current_work_setup", None) if isinstance(getattr(req, "current_work_setup", None), dict) else {}
    current_work_setup: Dict[str, Any] = {}
    current_work_setup.update(request_setup or {})
    current_work_setup.update(plan_setup or {})
    current_work_setup.update(snapshot_setup or {})
    # Promote plan-level trade/function/unit slots into the stable current_work_setup.
    if plan.get("trade_profile_id"):
        current_work_setup["trade_profile_id"] = plan.get("trade_profile_id")
    if plan.get("default_function"):
        current_work_setup["default_costx_function"] = plan.get("default_function")
    if plan.get("function_mode"):
        current_work_setup["costx_function_mode"] = plan.get("function_mode")
    if plan.get("custom_quantity") or plan.get("custom_quantity_name"):
        current_work_setup["custom_quantity_name"] = plan.get("custom_quantity") or plan.get("custom_quantity_name")
    if plan.get("unit"):
        current_work_setup["expected_unit"] = plan.get("unit")
        current_work_setup["custom_quantity_unit"] = current_work_setup.get("custom_quantity_unit") or plan.get("unit")
    project = None
    for candidate in (
        current_work_setup.get("project_zone_hierarchy"),
        plan.get("project_zone_hierarchy"),
        plan_setup.get("project_zone_hierarchy"),
        snapshot.get("project_zone_hierarchy"),
    ):
        if isinstance(candidate, dict) and candidate:
            project = candidate
            break
    builder_levels = snapshot.get("builder_levels") if isinstance(snapshot.get("builder_levels"), list) else getattr(req, "builder_levels", None)
    if isinstance(project, dict) and project:
        current_work_setup["project_zone_hierarchy"] = project
        current_work_setup["zone_token_mode"] = "rebuild"
        if not builder_levels:
            builder_levels = build_project_builder_levels(project)
    zone_token_mode = "rebuild" if isinstance(project, dict) and project else (snapshot.get("zone_token_mode") or getattr(req, "zone_token_mode", None))
    run_context = {
        "current_work_setup": current_work_setup,
        "active_categories": getattr(req, "active_categories", None),
        "zone_library": getattr(req, "zone_library", None),
        "zone_combos": getattr(req, "zone_combos", None),
        "active_combo_id": getattr(req, "active_combo_id", None),
        "zone_token_mode": zone_token_mode,
        "builder_run_snapshot_source": "builder_run_snapshot" if snapshot else "legacy_request",
    }
    return builder_levels, run_context


@app.post("/api/builder/preview")
def api_builder_preview(req: BuilderRunRequest) -> Dict[str, Any]:
    try:
        builder_levels, run_context = normalize_builder_run_snapshot_request(req)
        write_state_shadow_snapshot("builder_preview_started", req.conversation_id, {
            "input_file": req.input_file,
            "ui_action": req.ui_action,
            "client_action_id": req.client_action_id,
            "active_task_status_before": req.active_task_status_before,
            "run_context": run_context,
            "builder_levels_count": len(builder_levels or []),
        })
        result = create_builder_output_preview(req.input_file, builder_levels, run_context)
        write_state_shadow_snapshot("builder_preview_completed", req.conversation_id, {
            "input_file": req.input_file,
            "ui_action": req.ui_action,
            "client_action_id": req.client_action_id,
            "safe_to_export": result.get("safe_to_export"),
            "review": result.get("review"),
        })
        return result
    except HTTPException:
        raise
    except Exception as exc:
        write_log("builder_preview_error", {"input": req.input_file, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Builder preview failed: {exc}") from exc


@app.post("/api/builder/run")
def api_builder_run(req: BuilderRunRequest) -> Dict[str, Any]:
    try:
        builder_levels, run_context = normalize_builder_run_snapshot_request(req)
        return create_builder_output(req.input_file, req.output_prefix, builder_levels, run_context)
    except HTTPException:
        raise
    except Exception as exc:
        write_log("builder_error", {"input": req.input_file, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Builder failed: {exc}") from exc


@app.post("/api/jobs/start")
def api_jobs_start(req: ToolJobStartRequest) -> Dict[str, Any]:
    tool_key = req.tool_key.strip().lower()
    if tool_key not in {"formatter", "builder"}:
        raise HTTPException(status_code=400, detail="Jarvis background runner currently supports Formatter and Builder internal engines.")
    if not req.input_file:
        raise HTTPException(status_code=400, detail="Attach a workbook before starting the job.")

    job_id = uuid.uuid4().hex[:12]
    is_builder = tool_key == "builder"
    job = {
        "job_id": job_id,
        "tool_key": tool_key,
        "tool_name": "Jarvis Internal Builder Engine" if is_builder else "Jarvis Internal Formatter Engine",
        "prompt": req.prompt,
        "mode": req.mode,
        "input_file": req.input_file,
        "profile_key": "builder_v4_4_0_router_stable_v4_3_9_2_engine" if is_builder else normalise_profile_key(req.profile_key or load_formatter_profiles().get("active_profile") or "default_qs_boq"),
        "profile_name": "Builder Command Router MVP v4.4.0 using stable v4.3.9.2 engine" if is_builder else resolve_formatter_profile(req.profile_key).get("display_name"),
        "status": "queued",
        "progress": 1,
        "stage": "Queued",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "safe_execution": True,
        "stable_tools_modified": False,
    }
    with JOB_LOCK:
        JOBS[job_id] = job
        persist_job(job)
    write_log("job_created", job)
    write_state_shadow_snapshot("job_created", req.conversation_id, {"job": job, "input_file": req.input_file, "tool_key": tool_key})
    if is_builder:
        builder_levels, run_context = normalize_builder_run_snapshot_request(req)
        run_context = dict(run_context or {})
        run_context["ui_action"] = req.ui_action
        run_context["client_action_id"] = req.client_action_id
        run_context["conversation_id"] = req.conversation_id
        JOB_EXECUTOR.submit(run_builder_background_job, job_id, req.input_file, req.output_prefix or "Jarvis_Builder_Base_Lite", builder_levels, run_context)
    else:
        JOB_EXECUTOR.submit(run_formatter_background_job, job_id, req.input_file, req.output_prefix, req.profile_key)
    return dict(job)


@app.get("/api/jobs")
def api_jobs() -> Dict[str, Any]:
    return {"jobs": list_known_jobs()}


@app.get("/api/jobs/{job_id}")
def api_job_detail(job_id: str) -> Dict[str, Any]:
    with JOB_LOCK:
        job = JOBS.get(job_id)
    if not job:
        job = load_job_from_disk(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return dict(job)




def excel_col_letter(col_idx: Optional[int]) -> str:
    if not col_idx:
        return ""
    try:
        from openpyxl.utils import get_column_letter
        return get_column_letter(int(col_idx))
    except Exception:
        return str(col_idx or "")


def excel_col_index(col: Any) -> Optional[int]:
    if col in (None, "", "auto"):
        return None
    if isinstance(col, int):
        return col if col > 0 else None
    s = str(col).strip()
    if not s or s.lower() == "auto":
        return None
    if s.isdigit():
        return int(s)
    try:
        from openpyxl.utils import column_index_from_string
        return int(column_index_from_string(s.upper()))
    except Exception:
        return None


def cell_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def detect_sheet_column_layout(ws: Any, protected_formula_info: Optional[Dict[int, Dict[str, Any]]] = None, profile: Optional[Dict[str, Any]] = None, scan_rows: int = 250) -> Dict[str, Any]:
    """Detect client BOQ layout dynamically for v3.15.

    This avoids hard-coding Column B/C/D. Jarvis learns which column appears to
    be Description, Row Type / Head marker, Unit, Formula/Quantity, and other
    quantity columns for each workbook/client layout.
    """
    protected_formula_info = protected_formula_info or detect_formula_columns(ws, scan_rows=scan_rows)
    formula_cols = set(protected_formula_info.keys())
    max_row = min(ws.max_row or 0, scan_rows)
    stats: Dict[int, Dict[str, Any]] = {}
    for col in range(1, (ws.max_column or 0) + 1):
        stats[col] = {
            "col": col,
            "letter": excel_col_letter(col),
            "non_empty": 0,
            "text_count": 0,
            "long_text_count": 0,
            "total_text_len": 0,
            "marker_count": 0,
            "unit_count": 0,
            "numeric_count": 0,
            "formula_count": int((protected_formula_info.get(col) or {}).get("count", 0)),
            "samples": [],
            "unique_values": set(),
        }

    marker_values = {"head1", "heading1", "h1", "head2", "heading2", "h2", "head3", "heading3", "h3", "head4", "heading4", "h4", "level", "lvl", "floor", "storey", "note", "notes", "item"}
    for row in ws.iter_rows(min_row=1, max_row=max_row):
        for cell in row:
            col = int(cell.column)
            st = stats[col]
            v = getattr(cell, "value", None)
            if v in (None, ""):
                continue
            txt = cell_text(v)
            if not txt:
                continue
            st["non_empty"] += 1
            st["unique_values"].add(txt[:120].lower())
            if len(st["samples"]) < 5:
                st["samples"].append({"row": int(cell.row), "value": txt[:90] + ("..." if len(txt) > 90 else "")})
            low_marker = txt.lower().replace(" ", "")
            if low_marker in marker_values:
                st["marker_count"] += 1
            if is_boq_unit_marker(txt):
                st["unit_count"] += 1
            if is_formula_cell_value(v) or getattr(cell, "data_type", None) == "f":
                st["formula_count"] += 1
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                st["numeric_count"] += 1
            if isinstance(v, str):
                st["text_count"] += 1
                st["total_text_len"] += len(txt)
                if len(txt) >= 16:
                    st["long_text_count"] += 1

    # Profile can provide fixed hints later, but auto is default.
    layout_cfg = ((profile or {}).get("format_rules", {}) or {}).get("layout_detection", {}) if isinstance(profile, dict) else {}
    fixed_desc = excel_col_index(layout_cfg.get("description_column"))
    fixed_row_type = excel_col_index(layout_cfg.get("row_type_column"))
    fixed_unit = excel_col_index(layout_cfg.get("unit_column"))

    # v3.16.4: profile/sample-learned layout values are hints only, not hard rules.
    # If a client workbook moves columns, reject stale hints and auto-detect again.
    hint_rejections: List[str] = []
    def _stat(col_idx: Optional[int]) -> Dict[str, Any]:
        return stats.get(int(col_idx), {}) if col_idx else {}
    if fixed_row_type:
        st = _stat(fixed_row_type)
        if int(st.get("marker_count", 0) or 0) < 2:
            hint_rejections.append(f"Ignored stale row type hint {excel_col_letter(fixed_row_type)} because it has no strong Head/Note/Item markers.")
            fixed_row_type = None
    if fixed_unit:
        st = _stat(fixed_unit)
        # Same column can contain Head markers and units; require either actual units or marker/unit mix.
        if int(st.get("unit_count", 0) or 0) < 2 and int(st.get("marker_count", 0) or 0) < 2:
            hint_rejections.append(f"Ignored stale unit hint {excel_col_letter(fixed_unit)} because it has no strong unit/marker values.")
            fixed_unit = None
    if fixed_desc:
        st = _stat(fixed_desc)
        unique_count = len(st.get("unique_values", set()) or [])
        avg_len = (st.get("total_text_len", 0) or 0) / max(1, st.get("text_count", 0) or 0)
        if int(st.get("text_count", 0) or 0) < 3 or (int(st.get("long_text_count", 0) or 0) < 2 and avg_len < 12) or unique_count < 3:
            hint_rejections.append(f"Ignored stale description hint {excel_col_letter(fixed_desc)} because it is not text-heavy in this workbook.")
            fixed_desc = None

    row_type_col = fixed_row_type
    if not row_type_col:
        candidates = sorted(stats.values(), key=lambda s: (s["marker_count"], -s["formula_count"], -s["numeric_count"], s["non_empty"]), reverse=True)
        if candidates and candidates[0]["marker_count"] >= 2:
            row_type_col = candidates[0]["col"]

    unit_col = fixed_unit
    if not unit_col:
        candidates = [s for s in stats.values() if s["col"] not in formula_cols]
        candidates = sorted(candidates, key=lambda s: (s["unit_count"], s["non_empty"], -s["long_text_count"]), reverse=True)
        if candidates and candidates[0]["unit_count"] >= 2:
            unit_col = candidates[0]["col"]

    desc_col = fixed_desc
    if not desc_col:
        candidates = []
        for s in stats.values():
            col = s["col"]
            if col in formula_cols or col == row_type_col or col == unit_col:
                continue
            # Description tends to be text-heavy AND varied.
            # Repeated metadata columns can have long text too, so uniqueness matters.
            unique_count = len(s.get("unique_values", set()))
            unique_ratio = unique_count / max(1, s["non_empty"])
            avg_len = s["total_text_len"] / max(1, s["text_count"])
            score = (s["long_text_count"] * 6) + (s["text_count"] * 1.5) + min(s["total_text_len"] / 100, 70) + (unique_ratio * 120) + min(unique_count, 80) - (s["numeric_count"] * 4) - (s["unit_count"] * 5) - (s["marker_count"] * 8)
            if unique_ratio < 0.15 and s["non_empty"] > 20:
                score -= 180
            if avg_len < 8:
                score -= 40
            if col == 2:  # gentle preference only, not a hard code
                score += 10
            candidates.append((score, s))
        candidates.sort(key=lambda x: x[0], reverse=True)
        if candidates and candidates[0][0] > 0:
            desc_col = candidates[0][1]["col"]
        else:
            desc_col = 2 if (ws.max_column or 0) >= 2 else 1

    quantity_cols = []
    for s in stats.values():
        col = s["col"]
        if col in {desc_col, row_type_col, unit_col}:
            continue
        if col in formula_cols or s["numeric_count"] >= 3:
            quantity_cols.append(col)

    confidence = 0
    reasons = []
    if desc_col:
        confidence += 35; reasons.append(f"Description column likely {excel_col_letter(desc_col)} based on text-heavy cells")
    if row_type_col:
        confidence += 25; reasons.append(f"Row type marker column likely {excel_col_letter(row_type_col)}")
    if unit_col:
        confidence += 15; reasons.append(f"Unit column likely {excel_col_letter(unit_col)}")
    if formula_cols:
        confidence += 20; reasons.append("Formula/CostX columns detected and protected")
    if quantity_cols:
        confidence += 5; reasons.append("Quantity/formula-related columns detected")
    if hint_rejections:
        reasons.extend(hint_rejections)
    confidence = min(100, confidence)

    return {
        "sheet": ws.title,
        "confidence": confidence,
        "description_column_index": desc_col,
        "description_column": excel_col_letter(desc_col),
        "row_type_column_index": row_type_col,
        "row_type_column": excel_col_letter(row_type_col),
        "unit_column_index": unit_col,
        "unit_column": excel_col_letter(unit_col),
        "formula_columns": [excel_col_letter(c) for c in sorted(formula_cols)],
        "formula_column_indices": sorted(formula_cols),
        "quantity_columns": [excel_col_letter(c) for c in sorted(quantity_cols)],
        "quantity_column_indices": sorted(quantity_cols),
        "reasons": reasons,
        "column_stats": {excel_col_letter(c): {**{k: v for k, v in st.items() if k not in {"col", "unique_values"}}, "unique_count": len(st.get("unique_values", set())), "unique_ratio": round(len(st.get("unique_values", set())) / max(1, st.get("non_empty", 0)), 3)} for c, st in stats.items() if st.get("non_empty")},
        "safe_rule": "Description/text casing applies only to detected description column. Formula/CostX columns are protected dynamically.",
    }


def analyze_workbook_column_layout(source: Path, profile: Optional[Dict[str, Any]] = None, max_rows: int = 250) -> Dict[str, Any]:
    from openpyxl import load_workbook
    wb = load_workbook(source, keep_vba=source.suffix.lower() == ".xlsm", data_only=False)
    layouts = []
    for ws in wb.worksheets:
        if ws.title.lower().startswith("jarvis_"):
            continue
        formula_info = detect_formula_columns(ws, scan_rows=max_rows)
        layouts.append(detect_sheet_column_layout(ws, formula_info, profile, scan_rows=max_rows))
    def most_common(field: str):
        counts: Dict[str, int] = {}
        for layout in layouts:
            value = layout.get(field) or ""
            if value:
                counts[value] = counts.get(value, 0) + 1
        return max(counts.items(), key=lambda x: x[1])[0] if counts else ""
    recommended = {
        "description_column": most_common("description_column") or "auto",
        "row_type_column": most_common("row_type_column") or "auto",
        "unit_column": most_common("unit_column") or "auto",
        "formula_columns": sorted({c for layout in layouts for c in layout.get("formula_columns", [])}),
        "mode": "auto_detect_per_sheet",
        "protect_formula_columns": True,
        "client_format_learning": True,
    }
    confidence = round(sum(int(x.get("confidence", 0)) for x in layouts) / max(1, len(layouts)), 1)
    return {
        "status": "ok",
        "version": "v3.15",
        "input_file": source.name,
        "created_at": now_iso(),
        "average_confidence": confidence,
        "recommended_layout": recommended,
        "sheet_layouts": layouts,
        "notes": [
            "Jarvis detects Description / Row Type / Unit / Formula columns dynamically, not by fixed Column B/C/D assumptions.",
            "Formula columns are protected from value/text edits even when they move between client workbooks.",
            "Client layout can be saved to the active formatter profile after approval, but per-sheet auto detection remains enabled for safety.",
        ],
    }

def is_formula_cell_value(value: Any) -> bool:
    """Return True when a cell value represents an Excel/CostX formula.

    v3.14 safety: formulas are case-sensitive and must not be recased,
    especially CostX / XGET formula columns that may move between clients.
    """
    if value is None:
        return False
    if isinstance(value, str):
        stripped = value.strip()
        return stripped.startswith("=") or stripped.upper().startswith("XGET") or "XGET" in stripped.upper()
    cls_name = value.__class__.__name__.lower()
    return "formula" in cls_name


def detect_formula_columns(ws: Any, scan_rows: int = 250) -> Dict[int, Dict[str, Any]]:
    """Detect dynamic formula / CostX quantity columns.

    Not hard-coded to Column C. If any column contains Excel formulas,
    openpyxl formula objects, or CostX/XGET expressions, Jarvis protects that
    column from text/casing edits.
    """
    protected: Dict[int, Dict[str, Any]] = {}
    max_row = min(ws.max_row or 0, scan_rows)
    for row in ws.iter_rows(min_row=1, max_row=max_row):
        for cell in row:
            value = getattr(cell, "value", None)
            is_formula = False
            if is_formula_cell_value(value):
                is_formula = True
            try:
                if getattr(cell, "data_type", None) == "f":
                    is_formula = True
            except Exception:
                pass
            if not is_formula:
                continue
            col = int(cell.column)
            info = protected.setdefault(col, {"count": 0, "samples": []})
            info["count"] += 1
            if len(info["samples"]) < 5:
                txt = str(value)
                if len(txt) > 120:
                    txt = txt[:117] + "..."
                info["samples"].append({"row": cell.row, "value_preview": txt})
    return protected


def is_protected_formula_cell(cell: Any, protected_formula_columns: set[int]) -> bool:
    try:
        if int(cell.column) in protected_formula_columns:
            return True
    except Exception:
        pass
    return is_formula_cell_value(getattr(cell, "value", None))


def _layout_col_index(layout: Dict[str, Any], letter_key: str, index_key: str = "") -> Optional[int]:
    """Return a 1-based column index from a layout dict that may store A/B/C letters or indices."""
    if not isinstance(layout, dict):
        return None
    if index_key and layout.get(index_key):
        try:
            return int(layout.get(index_key))
        except Exception:
            pass
    value = layout.get(letter_key)
    if isinstance(value, int):
        return int(value)
    if isinstance(value, str) and value and value.lower() != "auto":
        try:
            return excel_col_index(value)
        except Exception:
            return None
    return None


def _sample_target_layout_for_sheet(profile: Optional[Dict[str, Any]], sheet_name: str = "") -> Optional[Dict[str, Any]]:
    """Get the approved sample workbook target layout for this sheet.

    v3.16.4: sample learning should not only learn styles. If the sample workbook
    places Description in Column B and Formula in Column C, Jarvis can map the
    current workbook's detected Description/Formula/Unit columns to those sample
    target columns in the output copy. The sample layout is still only a target;
    the current workbook scan remains the source of truth for where data is now.
    """
    if not isinstance(profile, dict):
        return None
    sample_info = profile.get("sample_based_learning") or {}
    if not isinstance(sample_info, dict) or not sample_info:
        return None
    rules = profile.get("format_rules", {}) or {}
    mode = str(rules.get("sample_output_layout_mode") or rules.get("sample_column_mapping_mode") or "copy_sample_columns").lower()
    if mode in {"off", "none", "disabled", "false"}:
        return None

    # Prefer explicit saved sample layout from v3.16.4.
    sample_layout_payload = sample_info.get("sample_layout") or {}
    if isinstance(sample_layout_payload, dict):
        layouts = sample_layout_payload.get("sheet_layouts") or []
        if isinstance(layouts, list) and layouts:
            for item in layouts:
                if str(item.get("sheet", "")).strip().lower() == str(sheet_name).strip().lower():
                    return item
            return layouts[0]
        recommended = sample_layout_payload.get("recommended_layout") or {}
        if recommended:
            return recommended

    # Backward-compatible fallback: sample_style_signature stores each sheet's layout.
    sig = sample_info.get("sample_style_signature") or {}
    if isinstance(sig, dict):
        sheets = sig.get("sheet_signatures") or []
        if isinstance(sheets, list) and sheets:
            for item in sheets:
                if str(item.get("sheet", "")).strip().lower() == str(sheet_name).strip().lower():
                    return item.get("layout") or {}
            return (sheets[0] or {}).get("layout") or {}
    return None




def _cell_payload(cell: Any) -> Dict[str, Any]:
    """Snapshot a cell value for safe role mapping.

    v3.16.9 optimisation/reliability fix: avoid deep-copying OpenPyXL style
    proxy objects during role remap. Large workbooks with array formulas can be
    slow or unstable when styles are copied thousands of times. The formatter
    applies the final sample/profile styles after mapping, so preserving value,
    formula text, data type, and number format is enough here.
    """
    from openpyxl.worksheet.formula import ArrayFormula
    raw_value = cell.value
    formula_text = None
    formula_kind = None
    if isinstance(raw_value, ArrayFormula):
        formula_text = getattr(raw_value, "text", None)
        formula_kind = "array"
    elif isinstance(raw_value, str) and raw_value.startswith("="):
        formula_text = raw_value
        formula_kind = "formula"
    return {
        "value": raw_value,
        "formula_text": formula_text,
        "formula_kind": formula_kind,
        "data_type": getattr(cell, "data_type", None),
        "number_format": cell.number_format,
    }


def _write_cell_payload(cell: Any, payload: Dict[str, Any]) -> None:
    """Write a value/formula snapshot without breaking moved formulas."""
    from openpyxl.worksheet.formula import ArrayFormula
    if payload.get("formula_kind") == "array" and payload.get("formula_text"):
        cell.value = ArrayFormula(cell.coordinate, payload.get("formula_text"))
    elif payload.get("formula_kind") == "formula" and payload.get("formula_text"):
        cell.value = payload.get("formula_text")
    else:
        cell.value = payload.get("value")
        try:
            if payload.get("data_type"):
                cell.data_type = payload.get("data_type")
        except Exception:
            pass
    if payload.get("number_format"):
        cell.number_format = payload.get("number_format")


def _looks_like_level_text(value: Any) -> bool:
    txt = str(value or "").strip().lower()
    if not txt:
        return False
    return bool(re.search(r"\b(level|ground floor|lower ground|basement|roof|mezzanine)\b", txt))


def infer_sample_role_targets_from_file(profile: Optional[Dict[str, Any]], sheet_name: str = "") -> Optional[Dict[str, Any]]:
    """Infer output target columns from the approved formatted sample workbook.

    v3.16.4 improvement: sample learning is not just column-role mapping. Some
    QS samples place Head markers and Level labels in the same column, keep the
    main descriptions in Column B, and put formulas/units elsewhere. This function
    reads the sample rows and creates row-role targets:
      - description_col: Head descriptions / Head4 description text
      - marker_col: Head1/Head2/Head3/Head4/Note/Item marker column
      - level_col: floor/level description column for quantity rows
      - formula_col: formula/quantity result column from the sample row pattern
      - unit_col: m2/No./Item unit column
    """
    if not isinstance(profile, dict):
        return None
    sample_info = profile.get("sample_based_learning") or {}
    if not isinstance(sample_info, dict) or not sample_info.get("sample_file"):
        return None
    sample_path = safe_child(INPUT_DIR, str(sample_info.get("sample_file")))
    if not sample_path.exists():
        return None
    try:
        from openpyxl import load_workbook
        from openpyxl.utils import get_column_letter
        wb = load_workbook(sample_path, data_only=False, read_only=False)
        ws = wb[sheet_name] if sheet_name and sheet_name in wb.sheetnames else wb.worksheets[0]
        max_rows = min(ws.max_row or 1, 250)
        marker_counts: Dict[int, int] = {}
        unit_counts: Dict[int, int] = {}
        level_counts: Dict[int, int] = {}
        desc_scores: Dict[int, int] = {}
        formula_scores: Dict[int, int] = {}
        error_scores: Dict[int, int] = {}
        numeric_scores: Dict[int, int] = {}
        from openpyxl.worksheet.formula import ArrayFormula
        unit_marker_set = {normalize_boq_unit_text(x) for x in BOQ_UNIT_MARKERS}
        for row in ws.iter_rows(min_row=1, max_row=max_rows):
            for c in row:
                col = int(c.column)
                raw_value = c.value
                is_array_formula = isinstance(raw_value, ArrayFormula)
                is_normal_formula = isinstance(raw_value, str) and raw_value.startswith("=")
                # Critical v3.16.8 fix: OpenPyXL represents CostX/XGET array formulas as
                # ArrayFormula objects. Their string representation looks like a long text
                # object, so earlier role inference incorrectly selected the formula column
                # as the sample description target. Treat those cells as formula targets
                # and never as description text.
                if is_array_formula or is_normal_formula:
                    formula_scores[col] = formula_scores.get(col, 0) + 3
                    continue
                txt = str(raw_value or "").strip()
                low = txt.lower()
                if not txt:
                    continue
                if low in {"head1", "head2", "head3", "head4", "note", "item", "items"}:
                    marker_counts[col] = marker_counts.get(col, 0) + 1
                norm_unit = normalize_boq_unit_text(txt)
                if norm_unit in unit_marker_set:
                    unit_counts[col] = unit_counts.get(col, 0) + 1
                if _looks_like_level_text(txt):
                    level_counts[col] = level_counts.get(col, 0) + 1
                # Formula/cache error cells such as #NAME? show the formula/value target
                # in sample workbooks opened outside CostX. Do not let them become
                # description candidates.
                if txt.startswith("#") or low in {"#name?", "#value!", "#ref!", "#n/a"}:
                    error_scores[col] = error_scores.get(col, 0) + 2
                    continue
                if isinstance(raw_value, (int, float)):
                    numeric_scores[col] = numeric_scores.get(col, 0) + 1
                    continue
                if "openpyxl.worksheet.formula.arrayformula" in low:
                    formula_scores[col] = formula_scores.get(col, 0) + 3
                    continue
                # Description score: real words that are not markers, units, formula errors, or level labels.
                if len(txt) >= 8 and low not in {"head1", "head2", "head3", "head4", "note", "item", "items"} and norm_unit not in unit_marker_set and not _looks_like_level_text(txt):
                    desc_scores[col] = desc_scores.get(col, 0) + min(len(txt), 120)
        def best(d: Dict[int, int]) -> Optional[int]:
            return max(d.items(), key=lambda kv: kv[1])[0] if d else None
        desc_col = best(desc_scores)
        marker_col = best(marker_counts)
        level_col = best(level_counts) or marker_col
        unit_col = best(unit_counts)
        formula_col = best(formula_scores) or best(error_scores)
        # If the sample uses computed error values instead of saved formulas,
        # error cells are still the best signal for the formula/quantity target.
        if not formula_col:
            # If there is a clear level column and unit column, use a populated numeric/error-like column between/near them.
            candidates = dict(numeric_scores)
            for k, v in error_scores.items():
                candidates[k] = candidates.get(k, 0) + v * 2
            if candidates:
                formula_col = best(candidates)
        # Natural fallback: if sample has description then marker/level but no formula signal,
        # put formula between description and marker/level. This is a hint only.
        if not formula_col and desc_col and (level_col or marker_col):
            right = level_col or marker_col
            if int(right) - int(desc_col) >= 2:
                formula_col = int(desc_col) + 1
        role_map = {
            "description_col": desc_col,
            "marker_col": marker_col,
            "level_col": level_col,
            "formula_col": formula_col,
            "unit_col": unit_col,
            "source": sample_path.name,
            "confidence_notes": {
                "description_scores": {get_column_letter(k): v for k, v in sorted(desc_scores.items())},
                "marker_counts": {get_column_letter(k): v for k, v in sorted(marker_counts.items())},
                "level_counts": {get_column_letter(k): v for k, v in sorted(level_counts.items())},
                "formula_scores": {get_column_letter(k): v for k, v in sorted(formula_scores.items())},
                "error_scores": {get_column_letter(k): v for k, v in sorted(error_scores.items())},
                "unit_counts": {get_column_letter(k): v for k, v in sorted(unit_counts.items())},
            },
        }
        # Allow explicit role-map overrides saved in a profile later.
        override = (((profile.get("format_rules") or {}).get("sample_output_role_map") or {}) if isinstance(profile, dict) else {})
        if isinstance(override, dict):
            for key, value in override.items():
                idx = excel_col_index(value) if isinstance(value, str) else value
                if idx and key in role_map:
                    role_map[key] = int(idx)
        return role_map
    except Exception:
        return None






def _clean_hex_color(value: Any) -> str:
    txt = str(value or "").strip().upper()
    if not txt or txt in {"0", "00000000", "000000", "NONE"}:
        return ""
    if len(txt) == 8:
        return txt[-6:]
    if len(txt) == 6:
        return txt
    return ""


def _style_sig_to_openpyxl(cell: Any, sig: Dict[str, Any]) -> None:
    """Apply a learned style signature to one cell without touching its value/formula.

    This is intentionally conservative: empty fields are ignored. It applies
    visual formatting only, so formula/value safety remains intact.
    """
    if not isinstance(sig, dict) or not sig:
        return
    try:
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        font_kwargs: Dict[str, Any] = {
            "name": sig.get("font_name") or getattr(cell.font, "name", None) or "Calibri",
            "bold": bool(sig.get("bold", False)),
            "italic": bool(sig.get("italic", False)),
            "underline": "single" if sig.get("underline") else None,
        }
        try:
            if sig.get("font_size") not in (None, ""):
                font_kwargs["size"] = float(sig.get("font_size"))
        except Exception:
            pass
        color = _clean_hex_color(sig.get("font_color"))
        if color:
            font_kwargs["color"] = color
        cell.font = Font(**font_kwargs)
        if str(sig.get("fill_type") or "").lower() == "solid":
            fg = _clean_hex_color(sig.get("fgColor"))
            if fg:
                cell.fill = PatternFill("solid", fgColor=fg)
        def _side(name: str):
            style = str(sig.get(name) or "").strip()
            return Side(style=style, color="DDDDDD") if style else Side(style=None)
        if any(sig.get(k) for k in ["top_border", "bottom_border", "left_border", "right_border"]):
            cell.border = Border(
                top=_side("top_border"), bottom=_side("bottom_border"),
                left=_side("left_border"), right=_side("right_border")
            )
        align_kwargs: Dict[str, Any] = {
            "vertical": sig.get("vertical") or getattr(cell.alignment, "vertical", None) or "center",
            "wrap_text": bool(sig.get("wrap_text", False)),
            "shrink_to_fit": bool(sig.get("shrink_to_fit", False)),
        }
        if sig.get("horizontal"):
            align_kwargs["horizontal"] = sig.get("horizontal")
        try:
            align_kwargs["indent"] = float(sig.get("indent") or 0)
        except Exception:
            pass
        cell.alignment = Alignment(**align_kwargs)
        if sig.get("number_format"):
            cell.number_format = str(sig.get("number_format"))
    except Exception:
        return


def _merge_role_style(counter: Dict[str, Any], cell: Any) -> None:
    _merge_style_counter(counter, _cell_style_snapshot(cell))


def _dominant_role_style_map(style_counters: Dict[str, Dict[str, Dict[str, Any]]]) -> Dict[str, Dict[str, Dict[str, Any]]]:
    out: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for bucket, role_counters in style_counters.items():
        out[bucket] = {}
        for role, counter in role_counters.items():
            out[bucket][role] = _dominant_style(counter)
    return out


def infer_sample_role_styles_from_file(profile: Optional[Dict[str, Any]], sheet_name: str = "") -> Dict[str, Any]:
    """Learn per-row-role and per-cell-role style signatures from the approved sample.

    v3.17: column mapping is already stable in v3.16.9. This function adds the
    missing visual layer: Head3 style, Head4 style, level row style, unit cell
    style, formula/value cell style, alignment/wrap/font/fill/borders, etc.
    """
    role_map = infer_sample_role_targets_from_file(profile, sheet_name)
    if not isinstance(profile, dict) or not isinstance(role_map, dict):
        return {}
    sample_info = profile.get("sample_based_learning") or {}
    if not isinstance(sample_info, dict) or not sample_info.get("sample_file"):
        return {}
    sample_path = safe_child(INPUT_DIR, str(sample_info.get("sample_file")))
    if not sample_path.exists():
        return {}
    try:
        from openpyxl import load_workbook
        wb = load_workbook(sample_path, data_only=False, read_only=False)
        ws = wb[sheet_name] if sheet_name and sheet_name in wb.sheetnames else wb.worksheets[0]
        max_rows = min(ws.max_row or 1, 400)
        desc_col = int(role_map.get("description_col") or 0)
        marker_col = int(role_map.get("marker_col") or 0)
        level_col = int(role_map.get("level_col") or marker_col or 0)
        formula_col = int(role_map.get("formula_col") or 0)
        unit_col = int(role_map.get("unit_col") or 0)
        marker_cols = [c for c in [marker_col, unit_col] if c]
        unit_cols = [c for c in [unit_col, marker_col] if c]
        style_counters: Dict[str, Dict[str, Dict[str, Any]]] = {}
        row_counts: Dict[str, int] = {}
        active_heading = ""
        for row in ws.iter_rows(min_row=1, max_row=max_rows):
            idx = int(row[0].row)
            row_type = str(detect_row_type(row, marker_cols) or "").lower()
            unit_marker = detect_boq_unit_marker(row, unit_cols)
            # Choose a sample bucket.
            if row_type in {"head1", "head2", "head3", "head4"}:
                bucket = row_type
                active_heading = row_type
            elif row_type == "note":
                bucket = "note"
            elif row_type == "item":
                bucket = "item"
            elif level_col and _looks_like_level_text(str(ws.cell(idx, level_col).value or "")):
                bucket = "level"
            elif unit_marker:
                bucket = "unit_item"
            elif active_heading:
                bucket = "item_below_heading"
            else:
                bucket = "text_note"
            row_counts[bucket] = row_counts.get(bucket, 0) + 1
            role_defs = {
                "description": desc_col,
                "marker": marker_col,
                "level": level_col,
                "formula_value": formula_col,
                "unit": unit_col,
            }
            for role, col in role_defs.items():
                if not col:
                    continue
                cell = ws.cell(idx, col)
                _merge_role_style(style_counters.setdefault(bucket, {}).setdefault(role, {}), cell)
        try:
            wb.close()
        except Exception:
            pass
        missing = []
        for needed in ["head1", "head2", "head3", "head4", "note", "item", "level", "unit_item", "item_below_heading"]:
            if needed not in row_counts:
                missing.append(needed)
        return {
            "status": "ok",
            "version": "v3.17",
            "sample_file": sample_path.name,
            "role_styles": _dominant_role_style_map(style_counters),
            "row_counts": row_counts,
            "missing_role_examples": missing,
            "note": "If a role is missing from the sample, Jarvis falls back to the nearest known sample style and reports the missing role so Dhanrick can upload a richer sample or confirm a fallback.",
        }
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


def _fallback_style_bucket(bucket: str, role_styles: Dict[str, Any]) -> str:
    if bucket in role_styles:
        return bucket
    order_map = {
        "note": ["text_note", "item_below_heading", "unit_item", "level"],
        "item": ["unit_item", "item_below_heading", "level"],
        "hierarchy_item": ["item_below_heading", "unit_item", "level", "text_note"],
        "unit_item": ["unit_item", "level", "item_below_heading"],
        "level": ["level", "unit_item", "item_below_heading"],
        "text_note": ["text_note", "item_below_heading", "unit_item"],
        "head1": ["head1", "head2", "head3"],
        "head2": ["head2", "head3", "head1"],
        "head3": ["head3", "head2", "head1"],
        "head4": ["head4", "head3"],
    }
    for candidate in order_map.get(bucket, []):
        if candidate in role_styles:
            return candidate
    return ""


def apply_sample_role_styles_to_output_row(ws: Any, row_index: int, bucket: str, role_map: Optional[Dict[str, Any]], role_style_payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Apply learned sample styles to row-role target cells only.

    Returns a small report with the applied/fallback style bucket for debugging.
    """
    if not isinstance(role_map, dict) or not isinstance(role_style_payload, dict):
        return {"applied": False}
    role_styles = role_style_payload.get("role_styles") if isinstance(role_style_payload.get("role_styles"), dict) else {}
    if not role_styles:
        return {"applied": False}
    chosen_bucket = _fallback_style_bucket(bucket, role_styles) or bucket
    bucket_styles = role_styles.get(chosen_bucket) or {}
    if not isinstance(bucket_styles, dict):
        return {"applied": False}
    role_to_col_key = {
        "description": "description_col",
        "marker": "marker_col",
        "level": "level_col",
        "formula_value": "formula_col",
        "unit": "unit_col",
    }
    applied_roles: List[str] = []
    for role, col_key in role_to_col_key.items():
        col = role_map.get(col_key)
        if not col:
            continue
        sig = bucket_styles.get(role)
        # If a specific role cell style is missing, use the most similar style.
        if not sig and role == "level":
            sig = bucket_styles.get("marker") or bucket_styles.get("description")
        if not sig and role == "marker":
            sig = bucket_styles.get("level") or bucket_styles.get("description")
        if not sig:
            continue
        _style_sig_to_openpyxl(ws.cell(row=row_index, column=int(col)), sig)
        applied_roles.append(role)
    return {"applied": bool(applied_roles), "bucket": bucket, "style_bucket": chosen_bucket, "roles": applied_roles}

def _layout_from_sample_role_targets(role_map: Optional[Dict[str, Any]], protected_formula_info: Optional[Dict[int, Any]] = None) -> Optional[Dict[str, Any]]:
    """Build an explicit output layout from the approved sample role map.

    After role-based remapping, normal auto-detection can incorrectly choose the
    child content column as the global description column because it contains many
    note/level rows. For formatting, headings must still use the sample heading
    description column while child rows can use the sample content/level column.
    """
    if not isinstance(role_map, dict):
        return None
    try:
        desc = int(role_map.get("description_col") or 0) or None
        marker = int(role_map.get("marker_col") or 0) or None
        unit = int(role_map.get("unit_col") or 0) or None
        formula = int(role_map.get("formula_col") or 0) or None
    except Exception:
        return None
    from openpyxl.utils import get_column_letter
    formula_indices = sorted(set([int(k) for k in (protected_formula_info or {}).keys()] + ([formula] if formula else [])))
    return {
        "sheet": "",
        "confidence": 100,
        "description_column_index": desc,
        "description_column": get_column_letter(desc) if desc else "",
        "row_type_column_index": marker,
        "row_type_column": get_column_letter(marker) if marker else "",
        "unit_column_index": unit,
        "unit_column": get_column_letter(unit) if unit else "",
        "formula_columns": [get_column_letter(i) for i in formula_indices],
        "formula_column_indices": formula_indices,
        "quantity_columns": [get_column_letter(i) for i in formula_indices],
        "quantity_column_indices": formula_indices,
        "reasons": ["Sample role map applied explicitly after remap; heading descriptions use the sample description column and child content uses the sample content/level column."],
    }

def remap_sheet_columns_by_sample_roles(ws: Any, current_layout: Dict[str, Any], role_map: Dict[str, Any]) -> Dict[str, Any]:
    """Map current workbook rows into the approved sample layout by row role.

    v3.16.8 keeps the v3.16.4 limitation: a BOQ calculation column is not
    formula-only. The same column can contain CostX/XGET formulas, manual
    quantities, zeros, blanks, and normal values. Jarvis now treats it as a
    protected formula/quantity VALUE column and preserves every row value.

    Main rule from Dhanrick: after any Head1/Head2/Head3/Head4 row, every
    non-heading row is an item/content row until the next heading. Mapping is
    based on row role, not hard-coded rows or columns.
    """
    if not isinstance(role_map, dict) or not isinstance(current_layout, dict):
        return {"applied": False, "reason": "missing role map"}

    src_desc = _layout_col_index(current_layout, "description_column", "description_column_index")
    src_row_type = _layout_col_index(current_layout, "row_type_column", "row_type_column_index")
    src_unit = _layout_col_index(current_layout, "unit_column", "unit_column_index")

    # Source value columns are formula columns plus numeric quantity columns.
    # This is intentionally broader than formula columns only, because BOQs can
    # have manual quantities in the same calculation column.
    src_value_cols: List[int] = []
    for raw_key in ["formula_column_indices", "quantity_column_indices"]:
        raw = current_layout.get(raw_key) or []
        if isinstance(raw, list):
            for item in raw:
                try:
                    idx = int(item)
                except Exception:
                    continue
                if idx and idx not in {src_desc, src_row_type, src_unit} and idx not in src_value_cols:
                    src_value_cols.append(idx)
    # Backward fallback from letter lists if needed.
    if not src_value_cols:
        for raw_key in ["formula_columns", "quantity_columns"]:
            raw = current_layout.get(raw_key) or []
            if isinstance(raw, list):
                for item in raw:
                    idx = excel_col_index(str(item))
                    if idx and idx not in {src_desc, src_row_type, src_unit} and idx not in src_value_cols:
                        src_value_cols.append(idx)
    src_formula = src_value_cols[0] if src_value_cols else None

    tgt_desc = role_map.get("description_col")
    tgt_marker = role_map.get("marker_col")
    tgt_level = role_map.get("level_col") or tgt_marker
    tgt_formula = role_map.get("formula_col")
    tgt_unit = role_map.get("unit_col")
    try:
        tgt_desc = int(tgt_desc) if tgt_desc else None
        tgt_marker = int(tgt_marker) if tgt_marker else None
        tgt_level = int(tgt_level) if tgt_level else None
        tgt_formula = int(tgt_formula) if tgt_formula else None
        tgt_unit = int(tgt_unit) if tgt_unit else None
    except Exception:
        return {"applied": False, "reason": "invalid target role columns"}
    if not any([tgt_desc, tgt_marker, tgt_level, tgt_formula, tgt_unit]):
        return {"applied": False, "reason": "empty target role columns"}

    source_cols = sorted({c for c in [src_desc, src_row_type, src_unit, *src_value_cols] if c})
    target_cols = sorted({c for c in [tgt_desc, tgt_marker, tgt_level, tgt_formula, tgt_unit] if c})
    if not source_cols or not target_cols:
        return {"applied": False, "reason": "missing source or target columns"}

    max_row = ws.max_row or 0
    snapshots: Dict[int, List[Dict[str, Any]]] = {}
    for col in source_cols:
        snapshots[col] = [_cell_payload(ws.cell(row=r, column=col)) for r in range(1, max_row + 1)]

    def payload(col: Optional[int], row: int) -> Optional[Dict[str, Any]]:
        if not col or col not in snapshots:
            return None
        return snapshots[col][row - 1]

    def payload_has_value(item: Optional[Dict[str, Any]]) -> bool:
        if not item:
            return False
        val = item.get("value")
        if val is None:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    def value_payload(row: int) -> Optional[Dict[str, Any]]:
        """Return formula/manual quantity payload for this row, if present."""
        for col in src_value_cols:
            item = payload(col, row)
            if payload_has_value(item):
                return item
        return None

    # Clear target role columns first so stale data from the raw workbook does
    # not remain in the output. Snapshots above preserve everything before clear.
    for col in target_cols:
        for r in range(1, max_row + 1):
            c = ws.cell(row=r, column=col)
            c.value = None
            c.comment = None

    mapped_rows = 0
    value_rows_preserved = 0
    manual_value_rows_preserved = 0
    heading_rows = 0
    child_rows = 0
    active_heading_context = ""
    unit_set = {normalize_boq_unit_text(x) for x in BOQ_UNIT_MARKERS}

    for r in range(1, max_row + 1):
        row_marker_payload = payload(src_row_type, r)
        unit_payload = payload(src_unit, r)
        desc_payload = payload(src_desc, r)
        val_payload = value_payload(r)

        src_marker_val = row_marker_payload.get("value") if row_marker_payload else None
        src_unit_val = unit_payload.get("value") if unit_payload else None
        src_desc_val = desc_payload.get("value") if desc_payload else None
        marker = str(src_marker_val or "").strip()
        marker_low = marker.lower().replace(" ", "")
        unit_marker = normalize_boq_unit_text(str(src_unit_val or ""))

        is_head = marker_low in {"head1", "heading1", "h1", "head2", "heading2", "h2", "head3", "heading3", "h3", "head4", "heading4", "h4"}
        is_note_marker = marker_low in {"note", "notes"}
        is_item_marker = marker_low in {"item", "items"}
        is_level_row = _looks_like_level_text(src_desc_val)
        is_unit_row = bool(unit_marker in unit_set) and not is_head and not is_note_marker and not is_item_marker
        has_quantity_value = payload_has_value(val_payload)

        if is_head:
            active_heading_context = marker_low.replace("heading", "head").replace("h", "head") if marker_low in {"h1", "h2", "h3", "h4"} else marker_low
            if tgt_desc and payload_has_value(desc_payload):
                _write_cell_payload(ws.cell(row=r, column=tgt_desc), desc_payload)
            if tgt_marker and payload_has_value(row_marker_payload):
                _write_cell_payload(ws.cell(row=r, column=tgt_marker), row_marker_payload)
            heading_rows += 1
            mapped_rows += 1
            continue

        # Main hierarchy rule: any non-heading row under a heading is an item/
        # content row. Units help classify it, but are not required.
        under_heading = active_heading_context in {"head1", "head2", "head3", "head4"}
        is_child_content = under_heading or is_unit_row or is_level_row or is_note_marker or is_item_marker or has_quantity_value

        if is_child_content:
            # v3.16.9 correction: follow the sample's CONTENT column for
            # every non-Head row. In Dhanrick's sample, headings use B+C, but
            # child rows (Note, Item, m2 levels, blank-marker content) use the
            # level/content column (often C), with formula/value in the sample
            # value column and marker/unit in the sample unit/status column.
            #
            # This avoids treating Note/Item as headings or forcing their
            # descriptions back to Column B when the sample shows child content
            # in Column C. If no level/content column exists, fall back to the
            # main description column.
            label_target = tgt_level or tgt_desc

            wrote_description = False
            if label_target and payload_has_value(desc_payload):
                _write_cell_payload(ws.cell(row=r, column=label_target), desc_payload)
                wrote_description = True

            # Preserve formulas and manual quantities/values for any content row,
            # not only rows with m2/No./Item units.
            if tgt_formula and payload_has_value(val_payload):
                _write_cell_payload(ws.cell(row=r, column=tgt_formula), val_payload)
                value_rows_preserved += 1
                if not val_payload.get("formula_kind"):
                    manual_value_rows_preserved += 1

            # Preserve Note/Item markers and units without overwriting real
            # content text. For child rows, the sample's unit/status column is
            # the safest fallback when the marker column is also the content
            # column (e.g. Column C contains level/note/item text).
            marker_payload = row_marker_payload if payload_has_value(row_marker_payload) else unit_payload
            if tgt_unit and payload_has_value(unit_payload) and (is_unit_row or is_item_marker):
                _write_cell_payload(ws.cell(row=r, column=tgt_unit), unit_payload)
            elif (is_note_marker or is_item_marker) and payload_has_value(marker_payload):
                if tgt_unit and (not label_target or int(tgt_unit) != int(label_target)):
                    _write_cell_payload(ws.cell(row=r, column=tgt_unit), marker_payload)
                elif tgt_marker and (not label_target or int(tgt_marker) != int(label_target)):
                    _write_cell_payload(ws.cell(row=r, column=tgt_marker), marker_payload)

            # Final guard: never leave the CHOSEN content target blank when
            # the source row has description text. Do not write to alternate
            # columns such as the level/marker column, because that creates
            # duplicate descriptions and can overwrite Note/Item markers.
            if label_target and payload_has_value(desc_payload):
                target_cell = ws.cell(row=r, column=int(label_target))
                marker_text = str(src_marker_val or "").strip().lower()
                target_text = str(target_cell.value or "").strip().lower()
                if not target_text or target_text == marker_text:
                    _write_cell_payload(target_cell, desc_payload)

            child_rows += 1
            mapped_rows += 1
            continue

        # Outside heading context: preserve readable notes/text conservatively.
        if tgt_desc and payload_has_value(desc_payload):
            _write_cell_payload(ws.cell(row=r, column=tgt_desc), desc_payload)
            mapped_rows += 1
        if tgt_marker and payload_has_value(row_marker_payload):
            _write_cell_payload(ws.cell(row=r, column=tgt_marker), row_marker_payload)

    # Clear old source role columns that are no longer output target columns.
    for col in source_cols:
        if col in target_cols:
            continue
        for r in range(1, max_row + 1):
            c = ws.cell(row=r, column=col)
            c.value = None
            c.comment = None

    return {
        "applied": True,
        "mode": "sample_role_type_fallback_mapping_v3_17_style_signature",
        "mapped_rows": mapped_rows,
        "heading_rows_mapped": heading_rows,
        "child_content_rows_mapped": child_rows,
        "formula_or_value_rows_preserved": value_rows_preserved,
        "manual_value_rows_preserved": manual_value_rows_preserved,
        "source_columns": {
            "description": excel_col_letter(src_desc),
            "row_type_or_unit": excel_col_letter(src_row_type),
            "unit": excel_col_letter(src_unit),
            "formula_or_value": [excel_col_letter(c) for c in src_value_cols],
        },
        "target_roles": {
            "description": excel_col_letter(tgt_desc),
            "head_marker": excel_col_letter(tgt_marker),
            "level_or_item_text": excel_col_letter(tgt_level),
            "formula_or_value": excel_col_letter(tgt_formula),
            "unit": excel_col_letter(tgt_unit),
        },
        "sample_source": role_map.get("source", ""),
        "safety": "Output copy only. Formula/manual quantity values are preserved row-by-row. Non-heading rows below Head1/Head2/Head3/Head4 are treated as item/content rows.",
    }
def remap_sheet_columns_to_sample_layout(ws: Any, current_layout: Dict[str, Any], target_layout: Dict[str, Any]) -> Dict[str, Any]:
    """Move detected data columns into the sample workbook's target columns.

    This handles the user's v3.16 issue: if the current workbook has Description
    in Column N and the approved sample workbook has Description in Column B,
    the formatted output should put Description in Column B. Formula/CostX text
    is copied exactly to the sample's formula target column and protected after
    remap. This operates only on the output copy, never on the source workbook.
    """
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.formula import ArrayFormula

    if not isinstance(target_layout, dict) or not isinstance(current_layout, dict):
        return {"applied": False, "reason": "missing layout"}

    src_desc = _layout_col_index(current_layout, "description_column", "description_column_index")
    src_row_type = _layout_col_index(current_layout, "row_type_column", "row_type_column_index")
    src_unit = _layout_col_index(current_layout, "unit_column", "unit_column_index")
    tgt_desc = _layout_col_index(target_layout, "description_column", "description_column_index")
    tgt_row_type = _layout_col_index(target_layout, "row_type_column", "row_type_column_index")
    tgt_unit = _layout_col_index(target_layout, "unit_column", "unit_column_index")

    def _indices(layout: Dict[str, Any]) -> List[int]:
        raw = layout.get("formula_column_indices") or []
        out: List[int] = []
        if isinstance(raw, list):
            for x in raw:
                try:
                    out.append(int(x))
                except Exception:
                    pass
        if not out:
            raw_letters = layout.get("formula_columns") or []
            if isinstance(raw_letters, list):
                for x in raw_letters:
                    idx = excel_col_index(str(x))
                    if idx:
                        out.append(idx)
        return sorted(set(out))

    src_formula_cols = _indices(current_layout)
    tgt_formula_cols = _indices(target_layout)

    # v3.16.4: Some formatted samples do not expose formula columns cleanly
    # during layout learning, especially when CostX/XGET quantities are stored as
    # array formulas or recovered formulas. If the current workbook has a formula
    # column but the sample target did not record one, infer the target quantity/
    # formula column from the sample layout. In the common QS BOQ layout this is
    # the column between Description and Row Type/Unit (e.g. B/C/D). This keeps
    # sample-based output mapping useful without hard-coding Column C globally.
    if src_formula_cols and not tgt_formula_cols:
        if tgt_desc and tgt_row_type and abs(int(tgt_row_type) - int(tgt_desc)) >= 2:
            inferred = int(tgt_desc) + 1 if int(tgt_desc) < int(tgt_row_type) else int(tgt_desc) - 1
            if inferred > 0 and inferred not in {int(tgt_desc), int(tgt_row_type), int(tgt_unit or 0)}:
                tgt_formula_cols = [inferred]
        elif tgt_desc:
            inferred = int(tgt_desc) + 1
            if inferred > 0 and inferred not in {int(tgt_desc), int(tgt_row_type or 0), int(tgt_unit or 0)}:
                tgt_formula_cols = [inferred]

    mapping: Dict[int, int] = {}
    labels: Dict[str, str] = {}
    def _add(src: Optional[int], tgt: Optional[int], label: str) -> None:
        if src and tgt and src != tgt:
            mapping[int(src)] = int(tgt)
            labels[f"{get_column_letter(int(src))}->{get_column_letter(int(tgt))}"] = label
    _add(src_desc, tgt_desc, "description")
    _add(src_row_type, tgt_row_type, "row_type")
    # Unit can be same as row type; only map it separately when distinct or no row_type mapping exists.
    if not (src_unit == src_row_type and tgt_unit == tgt_row_type):
        _add(src_unit, tgt_unit, "unit")
    elif src_unit and tgt_unit and src_unit != tgt_unit and src_unit not in mapping:
        _add(src_unit, tgt_unit, "unit/row_type")

    for i, src in enumerate(src_formula_cols):
        if i < len(tgt_formula_cols):
            _add(src, tgt_formula_cols[i], "formula")

    if not mapping:
        return {"applied": False, "reason": "current workbook already matches sample target layout"}

    max_row = ws.max_row or 0
    source_cols = sorted(mapping.keys())
    target_cols = sorted(set(mapping.values()))
    snapshots: Dict[int, List[Dict[str, Any]]] = {}
    for src_col in source_cols:
        col_snap: List[Dict[str, Any]] = []
        for r in range(1, max_row + 1):
            c = ws.cell(row=r, column=src_col)
            raw_value = c.value
            formula_text = None
            formula_kind = None
            if isinstance(raw_value, ArrayFormula):
                formula_text = getattr(raw_value, "text", None)
                formula_kind = "array"
            elif isinstance(raw_value, str) and raw_value.startswith("="):
                formula_text = raw_value
                formula_kind = "formula"
            col_snap.append({
                "value": raw_value,
                "formula_text": formula_text,
                "formula_kind": formula_kind,
                "data_type": getattr(c, "data_type", None),
                "style": copy(c._style),
                "number_format": c.number_format,
                "alignment": copy(c.alignment),
                "font": copy(c.font),
                "fill": copy(c.fill),
                "border": copy(c.border),
                "protection": copy(c.protection),
                "comment": copy(c.comment) if c.comment else None,
            })
        snapshots[src_col] = col_snap

    # Write all moved columns from snapshots first, so C->D and O->C chains do not lose data.
    for src_col, tgt_col in mapping.items():
        snap = snapshots[src_col]
        for r, item in enumerate(snap, start=1):
            t = ws.cell(row=r, column=tgt_col)
            # v3.16.4: Never copy ArrayFormula objects with their old cell ref
            # (e.g. O48) into a new target cell (e.g. C48). Excel will repair the
            # workbook because the array formula ref no longer matches. Rebuild
            # single-cell array formulas with the target coordinate, or write the
            # normal formula string exactly for standard formulas.
            if item.get("formula_kind") == "array" and item.get("formula_text"):
                t.value = ArrayFormula(t.coordinate, item.get("formula_text"))
            elif item.get("formula_kind") == "formula" and item.get("formula_text"):
                t.value = item.get("formula_text")
            else:
                t.value = item["value"]
            # Do not force data_type for formulas; openpyxl sets it from value.
            if not item.get("formula_kind"):
                try:
                    if item.get("data_type"):
                        t.data_type = item["data_type"]
                except Exception:
                    pass
            t._style = copy(item["style"])
            t.number_format = item["number_format"]
            t.alignment = copy(item["alignment"])
            t.font = copy(item["font"])
            t.fill = copy(item["fill"])
            t.border = copy(item["border"])
            t.protection = copy(item["protection"])
            t.comment = copy(item["comment"]) if item.get("comment") else None

    # Clear old source columns only when they are not also sample target columns.
    for src_col in source_cols:
        if src_col in target_cols:
            continue
        for r in range(1, max_row + 1):
            c = ws.cell(row=r, column=src_col)
            c.value = None
            c.comment = None

    return {
        "applied": True,
        "mode": "copy_sample_columns",
        "mapping": labels,
        "source_columns": {"description": excel_col_letter(src_desc), "row_type": excel_col_letter(src_row_type), "unit": excel_col_letter(src_unit), "formula": [excel_col_letter(c) for c in src_formula_cols]},
        "target_columns": {"description": excel_col_letter(tgt_desc), "row_type": excel_col_letter(tgt_row_type), "unit": excel_col_letter(tgt_unit), "formula": [excel_col_letter(c) for c in tgt_formula_cols]},
        "safety": "Output copy only. Formula values were copied exactly from detected formula columns into sample target columns; moved array formulas were rebuilt with the new target cell reference.",
    }

def format_workbook_copy(source: Path, output_path: Path, profile: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Create a visibly formatted workbook copy without touching the source file.

    This is intentionally conservative compared with the separate stable Formatter v6:
    - preserves formulas and values;
    - does not delete rows;
    - styles explicit Head1/Head2/Head3/Head4/Level markers when present;
    - italicises every non-heading item row below the active heading hierarchy;
    - applies visible general cleanup so the output is not a plain duplicate;
    - adds a Jarvis format report sheet to confirm what was applied.
    """
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    keep_vba = source.suffix.lower() == ".xlsm"
    wb = load_workbook(source, keep_vba=keep_vba)

    base_font = Font(name="Calibri", size=11)
    bold_font = Font(name="Calibri", size=11, bold=True)
    underline_font = Font(name="Calibri", size=11, underline="single")
    bold_underline_font = Font(name="Calibri", size=11, bold=True, underline="single")
    italic_font = Font(name="Calibri", size=11, italic=True)
    head_fill = PatternFill("solid", fgColor="F3F3F3")
    light_fill = PatternFill("solid", fgColor="FAFAFA")
    thin_gray = Side(style="thin", color="DDDDDD")
    bottom_border = Border(bottom=thin_gray)

    summary: Dict[str, Any] = {
        "sheets": [],
        "rows_styled": 0,
        "head1": 0,
        "head2": 0,
        "head3": 0,
        "head4": 0,
        "level_rows": 0,
        "general_cleanup_sheets": 0,
        "report_sheet_added": True,
        "costx_entries": 0,
        "costx_groups": 0,
        "costx_extract_sheet_added": False,
        "freeze_panes_cleared": True,
        "autofilter_removed": True,
        "boq_safe_head4_casing": True,
        "boq_safe_head4_sentence_case": True,
        "smart_item_sentence_case": True,
        "v6_learned_logic": True,
        "unit_item_rows": 0,
        "hierarchy_item_rows": 0,
        "item_rows": 0,
        "boq_unit_row_italic": True,
        "boq_hierarchy_item_italic": True,
        "format_logic": "V6-learned + v3.9 effective contextual casing: Head rows are styled by marker; any non-heading row below Head1/Head2/Head3/Head4 with a Column B description is italicised and converted to smart QS sentence case. Descriptive phrases such as fire rated and non combustible are lower-case mid-sentence while rating labels/headings stay protected.",
        "unit_markers_supported": sorted(list(BOQ_UNIT_MARKERS)),
        "profile_key": (profile or {}).get("profile_key", "default_qs_boq"),
        "profile_name": (profile or {}).get("display_name", "Default QS BOQ Format"),
        "formula_columns_protected": True,
        "protected_formula_columns": {},
        "formula_cells_detected": 0,
        "dimension_code_normaliser": "v3.14: normalises known code prefixes such as SP1_F2 while preserving mixed-case tags such as S6c_A1* and TH8f.",
        "smart_column_detection": True,
        "client_format_learning": "v3.18: maps output by sample row roles, applies learned sample style signatures, and supports correction-loop mistake memory with regression safety.",
        "sample_output_layout_mapping": {},
        "sample_style_learning": {},
        "detected_column_layouts": {},
        "sample_based_learning": (profile or {}).get("sample_based_learning", {}) if isinstance(profile, dict) else {},
    }
    costx_entries: List[Dict[str, Any]] = []

    for ws in list(wb.worksheets):
        if ws.title.lower().startswith("jarvis_format_report"):
            wb.remove(ws)
            continue

        sheet_counts = {"sheet": ws.title, "rows_styled": 0, "head1": 0, "head2": 0, "head3": 0, "head4": 0, "level_rows": 0, "unit_item_rows": 0, "hierarchy_item_rows": 0, "item_rows": 0, "general_cleanup": True}
        active_head4 = False
        active_heading_context = ""
        has_explicit_markers = False
        protected_formula_info = detect_formula_columns(ws)
        protected_formula_columns = set(protected_formula_info.keys())
        column_layout = detect_sheet_column_layout(ws, protected_formula_info, profile)

        # v3.16.4: if an approved formatted sample workbook exists, map the output copy
        # to the sample's column layout. Example: current Description in Column N,
        # sample Description in Column B -> output Description in Column B.
        sample_target_layout = _sample_target_layout_for_sheet(profile, ws.title)
        sample_role_targets = infer_sample_role_targets_from_file(profile, ws.title)
        sample_role_style_payload = infer_sample_role_styles_from_file(profile, ws.title) if sample_role_targets else {}
        if sample_role_style_payload:
            summary.setdefault("sample_style_learning", {})[ws.title] = sample_role_style_payload
            sheet_counts["sample_style_learning"] = sample_role_style_payload
        if sample_role_targets:
            remap_info = remap_sheet_columns_by_sample_roles(ws, column_layout, sample_role_targets)
            if remap_info.get("applied"):
                summary.setdefault("sample_output_layout_mapping", {})[ws.title] = remap_info
                sheet_counts["sample_output_layout_mapping"] = remap_info
                # Re-detect formulas after the role remap, but keep the approved
                # sample role layout explicit. Otherwise auto-detection can pick
                # the child content column as the heading description column.
                protected_formula_info = detect_formula_columns(ws)
                protected_formula_columns = set(protected_formula_info.keys())
                detected_after_remap = detect_sheet_column_layout(ws, protected_formula_info, profile)
                explicit_layout = _layout_from_sample_role_targets(sample_role_targets, protected_formula_info)
                column_layout = explicit_layout or detected_after_remap
            else:
                summary.setdefault("sample_output_layout_mapping", {})[ws.title] = remap_info
                sheet_counts["sample_output_layout_mapping"] = remap_info
        elif sample_target_layout:
            remap_info = remap_sheet_columns_to_sample_layout(ws, column_layout, sample_target_layout)
            if remap_info.get("applied"):
                summary.setdefault("sample_output_layout_mapping", {})[ws.title] = remap_info
                sheet_counts["sample_output_layout_mapping"] = remap_info
                # Re-detect after the remap so formula protection and description styling follow the new output layout.
                protected_formula_info = detect_formula_columns(ws)
                protected_formula_columns = set(protected_formula_info.keys())
                column_layout = detect_sheet_column_layout(ws, protected_formula_info, profile)
            else:
                summary.setdefault("sample_output_layout_mapping", {})[ws.title] = remap_info
                sheet_counts["sample_output_layout_mapping"] = remap_info

        desc_col_idx = int(column_layout.get("description_column_index") or 2)
        row_type_cols = [int(column_layout.get("row_type_column_index"))] if column_layout.get("row_type_column_index") else []
        unit_cols = [int(column_layout.get("unit_column_index"))] if column_layout.get("unit_column_index") else []
        summary["detected_column_layouts"][ws.title] = {
            "description_column": column_layout.get("description_column"),
            "row_type_column": column_layout.get("row_type_column"),
            "unit_column": column_layout.get("unit_column"),
            "formula_columns": column_layout.get("formula_columns", []),
            "confidence": column_layout.get("confidence", 0),
            "reasons": column_layout.get("reasons", []),
        }
        sheet_counts["column_layout"] = summary["detected_column_layouts"][ws.title]
        if protected_formula_info:
            from openpyxl.utils import get_column_letter as _gcl
            summary["protected_formula_columns"][ws.title] = {
                _gcl(col): info for col, info in sorted(protected_formula_info.items())
            }
            summary["formula_cells_detected"] += sum(int(info.get("count", 0)) for info in protected_formula_info.values())
            sheet_counts["protected_formula_columns"] = [_gcl(col) for col in sorted(protected_formula_columns)]

        # Visible general cleanup on every sheet.
        # v2.5: clear frozen panes and worksheet AutoFilter.
        # This avoids old Formatter behavior such as freezing near Row 76
        # and avoids unwanted filters appearing on Row 1.
        clear_freeze_and_filter(ws)
        ws.sheet_view.showGridLines = True
        ws.sheet_view.zoomScale = 90

        for row in ws.iter_rows():
            row_index = row[0].row
            for cell in row:
                # v3.14: do not touch formula/CostX columns, even for style resets.
                # Formula columns can move by client; they are detected dynamically.
                if is_protected_formula_cell(cell, protected_formula_columns):
                    continue
                cell.font = copy(base_font)
                cell.alignment = Alignment(vertical="center", wrap_text=True)

            row_overrides = (profile or {}).get("row_overrides", {}) if isinstance(profile, dict) else {}
            override_key = f"{ws.title}!{row_index}"
            raw_override = row_overrides.get(override_key, row_overrides.get(str(row_index), "")) if isinstance(row_overrides, dict) else ""
            # Include unit/status columns for row-type detection after sample
            # role mapping. Note/Item markers may be moved to the sample unit
            # column while the content text sits in the sample content column.
            row_type_detection_cols = list(dict.fromkeys([*(row_type_cols or []), *(unit_cols or [])]))
            row_type = str(raw_override or detect_row_type(row, row_type_detection_cols) or "").strip().lower()
            unit_marker = detect_boq_unit_marker(row, unit_cols)
            if row_type:
                has_explicit_markers = True
            desc_cell = ws.cell(row=row_index, column=desc_col_idx)
            # v3.16.8: role-based sample outputs can put level/item text in a
            # separate target column (e.g. Column C) while heading descriptions
            # remain in Column B. Use that visible row-text cell for non-heading
            # styling when the main description column is blank.
            row_text_cell = desc_cell
            try:
                role_level_col = int(sample_role_targets.get("level_col")) if sample_role_targets and sample_role_targets.get("level_col") else None
            except Exception:
                role_level_col = None
            if role_level_col and role_level_col != desc_col_idx:
                maybe_level_cell = ws.cell(row=row_index, column=role_level_col)
                if desc_cell.value in (None, "") and maybe_level_cell.value not in (None, ""):
                    row_text_cell = maybe_level_cell
            desc_cell_protected = is_protected_formula_cell(desc_cell, protected_formula_columns)
            row_text_cell_protected = is_protected_formula_cell(row_text_cell, protected_formula_columns)

            # If no explicit row marker yet, make the first row visibly readable as a header only.
            if not row_type and row_index == 1:
                for cell in row:
                    if cell.value not in (None, ""):
                        cell.font = copy(bold_font)
                        cell.fill = copy(light_fill)
                        cell.border = copy(bottom_border)
                sheet_counts["rows_styled"] += 1
                summary["rows_styled"] += 1
                continue

            if row_type == "head1":
                if isinstance(desc_cell.value, str) and not desc_cell_protected:
                    desc_cell.value = desc_cell.value.upper()
                
                if not desc_cell_protected:
                    desc_cell.font = copy(bold_underline_font)
                desc_cell.fill = copy(head_fill)
                desc_cell.border = copy(bottom_border)
                active_head4 = False
                active_heading_context = "head1"
            elif row_type == "head2":
                if isinstance(desc_cell.value, str) and not desc_cell_protected:
                    desc_cell.value = smart_title(desc_cell.value)
                
                if not desc_cell_protected:
                    desc_cell.font = copy(bold_underline_font)
                desc_cell.border = copy(bottom_border)
                active_head4 = False
                active_heading_context = "head2"
            elif row_type == "head3":
                if isinstance(desc_cell.value, str) and not desc_cell_protected:
                    desc_cell.value = smart_title(desc_cell.value)
                
                if not desc_cell_protected:
                    desc_cell.font = copy(bold_font)
                active_head4 = False
                active_heading_context = "head3"
            elif row_type == "head4":
                # V6-learned Smart QS sentence case for Head4.
                # Keeps BOQ acronyms/codes but uses sentence case for description text.
                if isinstance(desc_cell.value, str) and not desc_cell_protected:
                    desc_cell.value = smart_boq_item_sentence_case(desc_cell.value)
                
                if not desc_cell_protected:
                    desc_cell.font = copy(underline_font)
                desc_cell.border = copy(bottom_border)
                active_head4 = True
                active_heading_context = "head4"
            elif row_type == "level" or (active_head4 and looks_like_level_row(row, desc_col_idx)):
                # Level/floor rows stay as written so drawing references such as MH-L0-001 remain uppercase.
                
                if not row_text_cell_protected:
                    row_text_cell.font = copy(italic_font)
                row_type = "level"
            elif row_type in {"item", "note"}:
                if isinstance(row_text_cell.value, str) and row_type == "item" and not row_text_cell_protected:
                    row_text_cell.value = smart_boq_item_sentence_case(row_text_cell.value)
                
                if not row_text_cell_protected:
                    row_text_cell.font = copy(italic_font)
                row_type = "hierarchy_item"
            elif active_heading_context in {"head1", "head2", "head3", "head4"} and row_text_cell.value not in (None, ""):
                # v3.16.9 hierarchy rule from Dhanrick:
                # after Head1/Head2/Head3/Head4, every non-heading row below it
                # is content/item, even when the text is in the sample content
                # column rather than the heading description column.
                effective_desc_col = int(row_text_cell.column)
                if isinstance(row_text_cell.value, str) and should_sentence_case_item_row(row, unit_marker, effective_desc_col, row_type_cols) and not row_text_cell_protected:
                    row_text_cell.value = smart_boq_item_sentence_case(row_text_cell.value)
                
                if not row_text_cell_protected:
                    row_text_cell.font = copy(italic_font)
                row_type = "unit_item" if unit_marker else "hierarchy_item"
            elif unit_marker:
                # Fallback for sheets where a unit row exists before any heading context.
                # It intentionally does not change formulas, quantities, or stable tool files.
                effective_desc_col = int(row_text_cell.column)
                if isinstance(row_text_cell.value, str) and should_sentence_case_item_row(row, unit_marker, effective_desc_col, row_type_cols) and not row_text_cell_protected:
                    row_text_cell.value = smart_boq_item_sentence_case(row_text_cell.value)
                
                if not row_text_cell_protected:
                    row_text_cell.font = copy(italic_font)
                row_type = "unit_item"
            else:
                # General readable note/blank rows only; no formula/value changes.
                pass

            # v3.17: after safe value/role mapping and base formatting, apply the
            # visual style learned from the formatted sample workbook. This copies
            # font, bold/italic, font size, fill, border, alignment and wrap per
            # row role/cell role without changing formulas or values.
            try:
                style_bucket = row_type or "text_note"
                if style_bucket == "hierarchy_item" and str(unit_marker).strip().lower() == "note":
                    style_bucket = "note"
                elif style_bucket == "hierarchy_item" and str(unit_marker).strip().lower() in {"item", "items"}:
                    style_bucket = "item"
                style_applied = apply_sample_role_styles_to_output_row(ws, row_index, style_bucket, sample_role_targets, sample_role_style_payload)
                if style_applied.get("applied"):
                    sheet_counts.setdefault("sample_styles_applied", 0)
                    sheet_counts["sample_styles_applied"] += 1
                    summary.setdefault("sample_styles_applied", 0)
                    summary["sample_styles_applied"] += 1
            except Exception:
                pass

            if row_type:
                summary["rows_styled"] += 1
                sheet_counts["rows_styled"] += 1
                key = "level_rows" if row_type == "level" else ("unit_item_rows" if row_type == "unit_item" else ("hierarchy_item_rows" if row_type == "hierarchy_item" else row_type))
                if row_type in {"unit_item", "hierarchy_item"}:
                    summary["item_rows"] += 1
                    sheet_counts["item_rows"] += 1
                if key in summary:
                    summary[key] += 1
                    sheet_counts[key] += 1

        sheet_costx_entries = extract_costx_entries(ws)
        # v3.16.8: Only create CostX Extract sheets for raw XGET lists.
        # Normal BOQs can contain XGET formulas in quantity columns; those are
        # protected and should not automatically generate a raw CostX extract.
        if sheet_costx_entries and not has_explicit_markers:
            costx_entries.extend(sheet_costx_entries)
            sheet_counts["costx_entries"] = len(sheet_costx_entries)

        if not has_explicit_markers:
            if sheet_costx_entries:
                sheet_counts["note"] = "Raw CostX XGET list detected; added parsed CostX extract sheet."
            else:
                sheet_counts["note"] = "No explicit Head markers detected on this sheet; applied general cleanup only."
        elif sheet_costx_entries:
            sheet_counts["costx_entries_detected_but_not_extracted"] = len(sheet_costx_entries)
            sheet_counts["note"] = "Formatted BOQ with Head markers contains CostX formulas; formulas were protected but no raw CostX extract sheet was added."

        # Readability widths. Preserve existing larger widths.
        # v3.16.4: width/wrap applies to detected description/marker columns, not only A:L.
        preferred_widths = {1: 10, 2: 50, 3: 18, 4: 16, 5: 16, 6: 16, 7: 16, 8: 16}
        for col_idx in range(1, min(ws.max_column, 12) + 1):
            letter = get_column_letter(col_idx)
            existing = ws.column_dimensions[letter].width or 0
            target_width = preferred_widths.get(col_idx, 14)
            ws.column_dimensions[letter].width = max(existing, target_width)
        for col_idx, target_width in [(desc_col_idx, 68), (row_type_cols[0] if row_type_cols else None, 16), (unit_cols[0] if unit_cols else None, 12)]:
            if col_idx and 1 <= int(col_idx) <= (ws.max_column or 0):
                letter = get_column_letter(int(col_idx))
                existing = ws.column_dimensions[letter].width or 0
                ws.column_dimensions[letter].width = max(existing, target_width)

        # Slightly improve row height where wrap text is useful.
        for row_idx in range(1, min(ws.max_row, 400) + 1):
            if ws.row_dimensions[row_idx].height is None:
                ws.row_dimensions[row_idx].height = 18

        summary["general_cleanup_sheets"] += 1
        summary["sheets"].append(sheet_counts)

    if costx_entries:
        summary["costx_entries"] = len(costx_entries)
        summary["costx_groups"] = len(sorted({entry["relationship"] for entry in costx_entries if entry.get("relationship")}))
        summary["costx_extract_sheet_added"] = True
        add_costx_extract_sheet(wb, costx_entries)

    add_format_report_sheet(wb, source.name, output_path.name, summary)
    wb.save(output_path)
    return summary




def run_formatter_regression_self_test() -> Dict[str, Any]:
    """Run a small local regression suite for the current Formatter engine.

    v3.16.9 goal: catch the exact bugs we found during the Jarvis build:
    - Note/content rows below Head# must preserve real text, not only the word "Note".
    - Formula/manual quantity values must be preserved.
    - Sample role mapping must follow the sample layout without hard-coded B/C/D assumptions.
    - No freeze panes or filters should remain.

    This creates tiny local test workbooks inside Jarvis Input/Output folders.
    It never touches stable external tools.
    """
    from openpyxl import Workbook, load_workbook

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    raw_name = f"{stamp}_SelfTest_Raw_Different_Client.xlsx"
    sample_name = f"{stamp}_SelfTest_Format_Sample.xlsx"
    raw_path = INPUT_DIR / raw_name
    sample_path = INPUT_DIR / sample_name
    output_dir = OUTPUT_DIR / "Formatter"
    output_dir.mkdir(parents=True, exist_ok=True)
    ai_dir = OUTPUT_DIR / "AI_Exports"
    ai_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{stamp}_SelfTest_Formatted.xlsx"
    report_path = ai_dir / f"{stamp}_Jarvis_v3_18_Regression_Safety_Report.json"

    # Raw workbook deliberately uses a different client layout:
    # Row marker/unit in C, description in N, formula/value in O.
    wb = Workbook()
    ws = wb.active
    ws.title = "Different Client Layout"
    raw_rows = [
        (1, "Head1", "GENERALLY", None),
        (2, "Note", "Tenderers are referred to the Specification for the full particulars of workmanship and materials", None),
        (3, "Head1", "GENERAL ITEMS", None),
        (4, "Item", "Allow for shop drawings if required", 1),
        (5, "Head3", "Fire Rated Wall", None),
        (6, "Head4", "Ext/Dry - Sp1_F2 - 2x13mm thick fire rated plasterboard lining", None),
        (7, "m2", "Ground Floor (MH-L0-001-03 to MH-L0-010-03)", "=SUM(1,2)"),
        (8, "m2", "Level 1 (MH-L1-001-02 to MH-L1-009-02)", 25.5),
    ]
    for row_no, marker, desc, value in raw_rows:
        ws.cell(row=row_no, column=3).value = marker
        ws.cell(row=row_no, column=14).value = desc
        if value is not None:
            ws.cell(row=row_no, column=15).value = value
    wb.save(raw_path)

    # Sample workbook defines the desired role layout:
    # heading descriptions in B, markers / item labels in C, values in E, units in F.
    swb = Workbook()
    sws = swb.active
    sws.title = "Different Client Layout"
    sws.cell(1, 2).value = "Fire Rated Wall"
    sws.cell(1, 3).value = "Head3"
    sws.cell(2, 2).value = "Ext/Dry - SP1_F2 - 2x13mm thick fire rated plasterboard lining"
    sws.cell(2, 3).value = "Head4"
    sws.cell(3, 3).value = "Ground Floor (MH-L0-001-03 to MH-L0-010-03)"
    sws.cell(3, 5).value = "#NAME?"
    sws.cell(3, 6).value = "m2"
    swb.save(sample_path)

    profile = resolve_formatter_profile()
    profile = json.loads(json.dumps(profile, ensure_ascii=False))
    profile.setdefault("format_rules", {})["sample_based_learning"] = True
    profile.setdefault("format_rules", {})["sample_output_layout_mode"] = "copy_sample_columns"
    profile["sample_based_learning"] = {
        "sample_file": sample_name,
        "raw_file": raw_name,
        "learned_at": datetime.now().isoformat(timespec="seconds"),
        "self_test": True,
    }

    result: Dict[str, Any] = {
        "version": "v3.18",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "status": "running",
        "tests": [],
        "raw_file": raw_name,
        "sample_file": sample_name,
        "output_file": output_path.name,
        "stable_tools_modified": False,
    }

    def check(name: str, passed: bool, detail: str = "") -> None:
        result["tests"].append({"name": name, "passed": bool(passed), "detail": detail})

    try:
        token = FORMATTER_PROFILE_CONTEXT.set(profile)
        case_token = BOQ_CASE_CONTEXT.set(get_boq_case_dictionary(profile))
        try:
            summary = format_workbook_copy(raw_path, output_path, profile)
        finally:
            BOQ_CASE_CONTEXT.reset(case_token)
            FORMATTER_PROFILE_CONTEXT.reset(token)
        out_wb = load_workbook(output_path, data_only=False)
        out_ws = out_wb["Different Client Layout"]

        # The previous bug created rows with C = Note and no description text.
        row2_values = [out_ws.cell(2, c).value for c in range(1, 8)]
        row2_text = " | ".join(str(v or "") for v in row2_values)
        check("Note row preserves actual note description", "Tenderers are referred" in row2_text and row2_text.strip().lower() != "note", row2_text)

        row4_text = " | ".join(str(out_ws.cell(4, c).value or "") for c in range(1, 8))
        check("Item row preserves description", "Allow for shop drawings" in row4_text, row4_text)

        row6_text = " | ".join(str(out_ws.cell(6, c).value or "") for c in range(1, 8))
        check("Dimension code normaliser works", "SP1_F2" in row6_text and "Sp1_F2" not in row6_text, row6_text)

        check("Formula row value preserved", str(out_ws.cell(7, 5).value or "").startswith("=SUM"), str(out_ws.cell(7, 5).value))
        check("Manual quantity value preserved", out_ws.cell(8, 5).value == 25.5, str(out_ws.cell(8, 5).value))
        check("Unit column follows sample", str(out_ws.cell(7, 6).value or "").lower() == "m2", str(out_ws.cell(7, 6).value))
        check("No freeze panes", not bool(out_ws.freeze_panes), str(out_ws.freeze_panes))
        check("No filters", not bool(getattr(out_ws.auto_filter, "ref", None)), str(getattr(out_ws.auto_filter, "ref", None)))
        # v3.18 regression safety: correction loop memory must be available and not break formatting.
        preview = build_correction_preview("Note rows should keep their actual description and follow the sample content column.", "default_qs_boq")
        check("Correction preview categorises row-role issue", "row_role_mapping" in preview.get("categories", []), str(preview.get("categories", [])))
        check("Mistake memory file path is valid", bool(MISTAKE_MEMORY_FILE.name == "mistake_memory.json"), str(MISTAKE_MEMORY_FILE))

        result["formatter_summary"] = summary
        result["status"] = "passed" if all(t["passed"] for t in result["tests"]) else "failed"
    except Exception as exc:
        result["status"] = "error"
        result["error"] = str(exc)
        result["traceback"] = traceback.format_exc()

    report_path.write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    result["report_relative_path"] = str(report_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
    result["report_download_url"] = clean_download_url(result["report_relative_path"])
    if output_path.exists():
        result["output_relative_path"] = str(output_path.relative_to(OUTPUT_DIR)).replace("\\", "/")
        result["output_download_url"] = clean_download_url(result["output_relative_path"])
    return result

def extract_costx_entries(ws: Any) -> List[Dict[str, Any]]:
    entries: List[Dict[str, Any]] = []
    pattern = re.compile(r'^\s*=?\s*(XGET[A-Z0-9_]+)\(\s*"([^"]+)"(?:\s*,\s*0)?\s*\)\s*$', re.IGNORECASE)

    for row in ws.iter_rows():
        for cell in row:
            value = cell.value
            if value in (None, ""):
                continue
            # v3.16.4: moved CostX cells may be openpyxl ArrayFormula objects.
            # Calling str(ArrayFormula) can be slow/problematic, so read the formula
            # text directly and keep extraction safe.
            try:
                from openpyxl.worksheet.formula import ArrayFormula
                if isinstance(value, ArrayFormula):
                    text = str(getattr(value, "text", "") or "").strip()
                else:
                    text = str(value).strip()
            except Exception:
                text = str(value).strip()
            match = pattern.match(text)
            if not match:
                continue
            function_name = match.group(1).upper()
            dimension = match.group(2).strip()
            if " - " in dimension:
                relationship, tag = dimension.split(" - ", 1)
            else:
                relationship, tag = "", dimension
            relationship = relationship.strip()
            tag = tag.strip()
            entries.append({
                "source_sheet": ws.title,
                "source_row": cell.row,
                "source_cell": cell.coordinate,
                "function": function_name,
                "relationship": relationship,
                "tag": tag,
                "clean_dimension": dimension,
                "suggested_description": f"{relationship} - {tag}" if relationship else tag,
                "unit": infer_costx_unit(function_name),
                "original_xget": text,
                "notes": "Builder-ready raw CostX tag. Next connector can add zone/level tokens and base sheet structure.",
            })
    return entries


def infer_costx_unit(function_name: str) -> str:
    fn = function_name.upper()
    if "AREA" in fn:
        return "m2"
    if "VOLUME" in fn:
        return "m3"
    if "LENGTH" in fn or "PERIMETER" in fn:
        return "m"
    if "COUNT" in fn or "NUMBER" in fn:
        return "no"
    return ""


def add_costx_extract_sheet(wb: Any, entries: List[Dict[str, Any]]) -> None:
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    title = "Jarvis_CostX_Extract"
    if title in wb.sheetnames:
        del wb[title]
    ws = wb.create_sheet(title, 0)
    ws.sheet_properties.tabColor = "0B0B0B"

    headers = [
        "Source Sheet",
        "Source Row",
        "Source Cell",
        "Function",
        "Relationship",
        "Tag",
        "Clean Dimension",
        "Suggested Description",
        "Unit",
        "Original XGET",
        "Notes",
    ]
    ws.append(headers)
    for entry in entries:
        ws.append([
            entry.get("source_sheet", ""),
            entry.get("source_row", ""),
            entry.get("source_cell", ""),
            entry.get("function", ""),
            entry.get("relationship", ""),
            entry.get("tag", ""),
            entry.get("clean_dimension", ""),
            entry.get("suggested_description", ""),
            entry.get("unit", ""),
            entry.get("original_xget", ""),
            entry.get("notes", ""),
        ])

    header_fill = PatternFill("solid", fgColor="0B0B0B")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    thin = Side(style="thin", color="DDDDDD")
    border = Border(bottom=thin)
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.border = border
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(name="Calibri", size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    widths = {
        "A": 18, "B": 11, "C": 11, "D": 17, "E": 15, "F": 22,
        "G": 34, "H": 34, "I": 8, "J": 48, "K": 58,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width
    # No freeze panes or AutoFilter in v2.5 unless the user enables it later.
    clear_freeze_and_filter(ws)

    summary_title = "Jarvis_CostX_Summary"
    if summary_title in wb.sheetnames:
        del wb[summary_title]
    s = wb.create_sheet(summary_title, 1)
    s.sheet_properties.tabColor = "777777"
    s["A1"] = "Jarvis CostX Raw List Summary"
    s["A1"].font = Font(name="Calibri", size=14, bold=True)
    s["A3"] = "Total XGET entries"
    s["B3"] = len(entries)
    s["A4"] = "Relationship groups"
    relationships = sorted({entry.get("relationship", "") for entry in entries if entry.get("relationship")})
    s["B4"] = len(relationships)
    s["A6"] = "Relationship"
    s["B6"] = "Count"
    for cell in s[6]:
        cell.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        cell.fill = header_fill
    counts: Dict[str, int] = {}
    for entry in entries:
        rel = entry.get("relationship") or "Unsorted"
        counts[rel] = counts.get(rel, 0) + 1
    for idx, (rel, count) in enumerate(sorted(counts.items()), start=7):
        s.cell(row=idx, column=1).value = rel
        s.cell(row=idx, column=2).value = count
    s.column_dimensions["A"].width = 24
    s.column_dimensions["B"].width = 12
    clear_freeze_and_filter(s)


def add_format_report_sheet(wb: Any, input_name: str, output_name: str, summary: Dict[str, Any]) -> None:
    from openpyxl.styles import Font, PatternFill, Alignment

    title = "Jarvis_Format_Report"
    if title in wb.sheetnames:
        del wb[title]
    ws = wb.create_sheet(title)
    ws.sheet_properties.tabColor = "0B0B0B"
    ws["A1"] = "Jarvis Formatter v3.18 Report"
    ws["A1"].font = Font(name="Calibri", size=14, bold=True)
    ws["A3"] = "Input file"
    ws["B3"] = input_name
    ws["A4"] = "Output file"
    ws["B4"] = output_name
    ws["A5"] = "Stable tools modified"
    ws["B5"] = "No"
    ws["A6"] = "Rows styled"
    ws["B6"] = summary.get("rows_styled", 0)
    ws["A7"] = "Head1"
    ws["B7"] = summary.get("head1", 0)
    ws["A8"] = "Head2"
    ws["B8"] = summary.get("head2", 0)
    ws["A9"] = "Head3"
    ws["B9"] = summary.get("head3", 0)
    ws["A10"] = "Head4"
    ws["B10"] = summary.get("head4", 0)
    ws["A11"] = "Level rows"
    ws["B11"] = summary.get("level_rows", 0)
    ws["A12"] = "Total item rows italicised"
    ws["B12"] = summary.get("item_rows", 0)
    ws["A13"] = "Unit-detected item rows"
    ws["B13"] = summary.get("unit_item_rows", 0)
    ws["A14"] = "Hierarchy item rows"
    ws["B14"] = summary.get("hierarchy_item_rows", 0)
    ws["A15"] = "Smart item sentence case"
    ws["B15"] = "Yes" if summary.get("smart_item_sentence_case") else "No"
    ws["A16"] = "CostX XGET entries"
    ws["B16"] = summary.get("costx_entries", 0)
    ws["A17"] = "CostX groups"
    ws["B17"] = summary.get("costx_groups", 0)
    ws["A18"] = "CostX extract sheet added"
    ws["B18"] = "Yes" if summary.get("costx_extract_sheet_added") else "No"
    ws["A19"] = "Formula columns protected"
    ws["B19"] = "Yes" if summary.get("formula_columns_protected") else "No"
    ws["A20"] = "Formula cells detected"
    ws["B20"] = summary.get("formula_cells_detected", 0)
    ws["A21"] = "Dimension code normaliser"
    ws["B21"] = summary.get("dimension_code_normaliser", "")
    ws["A22"] = "Smart column detection"
    ws["B22"] = "Yes" if summary.get("smart_column_detection") else "No"
    ws["A23"] = "Client format learning"
    ws["B23"] = summary.get("client_format_learning", "")
    ws["A24"] = "Detected column layouts"
    try:
        ws["B24"] = json.dumps(summary.get("detected_column_layouts", {}), ensure_ascii=False)[:3000]
    except Exception:
        ws["B24"] = str(summary.get("detected_column_layouts", ""))[:3000]
    ws["A25"] = "Formatter profile"
    ws["B25"] = f"{summary.get('profile_name', 'Default QS BOQ Format')} ({summary.get('profile_key', 'default_qs_boq')})"
    ws["A26"] = "Sample-based learning"
    sample_info = summary.get("sample_based_learning") or {}
    ws["B26"] = "Yes" if sample_info else "No"
    ws["A27"] = "Sample profile source"
    ws["B27"] = str(sample_info.get("sample_file", ""))[:300] if isinstance(sample_info, dict) else ""
    ws["A28"] = "Sample output column mapping"
    try:
        ws["B28"] = json.dumps(summary.get("sample_output_layout_mapping", {}), ensure_ascii=False)[:3000]
    except Exception:
        ws["B28"] = str(summary.get("sample_output_layout_mapping", ""))[:3000]
    ws["A29"] = "Sample style learning"
    try:
        ws["B29"] = json.dumps(summary.get("sample_style_learning", {}), ensure_ascii=False)[:3000]
    except Exception:
        ws["B29"] = str(summary.get("sample_style_learning", ""))[:3000]
    ws["A30"] = "Sample styles applied"
    ws["B30"] = summary.get("sample_styles_applied", 0)
    ws["A31"] = "Note"
    explicit = summary.get("head1", 0) + summary.get("head2", 0) + summary.get("head3", 0) + summary.get("head4", 0) + summary.get("level_rows", 0)
    if summary.get("costx_entries", 0):
        ws["B31"] = "Raw CostX XGET list was detected. Jarvis created Jarvis_CostX_Extract and Jarvis_CostX_Summary sheets. This is still a safe copy, not the full Builder v6 engine."
    else:
        item_count = summary.get("item_rows", 0)
        ws["B31"] = ("Head markers were detected and styled. Every non-heading item/content row below the active Head1/Head2/Head3/Head4 hierarchy was mapped by row role and sample style signatures where available." if explicit or item_count else "No Head1/Head2/Head3/Head4 markers were detected. General cleanup was applied only.")
    ws["B28"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["B29"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["B31"].alignment = Alignment(wrap_text=True, vertical="top")

    fill = PatternFill("solid", fgColor="F3F3F3")
    for row in range(3, 32):
        ws.cell(row=row, column=1).font = Font(name="Calibri", size=11, bold=True)
        ws.cell(row=row, column=1).fill = fill
        ws.cell(row=row, column=2).font = Font(name="Calibri", size=11)
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 82
    clear_freeze_and_filter(ws)


def clear_freeze_and_filter(ws: Any) -> None:
    """Remove freeze panes and worksheet-level AutoFilter from a copied sheet.

    Jarvis v2.6 keeps the output simple for BOQ review: no frozen pane at Row 76
    and no default Row 1 filter. This does not delete any data or formulas.
    """
    try:
        ws.freeze_panes = None
    except Exception:
        pass
    try:
        ws.sheet_view.pane = None
    except Exception:
        pass
    try:
        ws.auto_filter.ref = None
    except Exception:
        pass


BOQ_UNIT_MARKERS = {
    "m2", "m²", "sqm", "sq.m", "sq m", "square metre", "square metres",
    "m3", "m³", "cum", "cu.m", "cu m", "cubic metre", "cubic metres",
    "m", "lm", "lin.m", "l/m", "linear metre", "linear metres",
    "mm", "no", "no.", "nr", "nos", "number", "numbers",
    "item", "items", "it", "ea", "each", "set", "sets", "pair", "pairs",
    "t", "tonne", "tonnes", "ton", "tons", "kg", "g",
    "l", "litre", "litres", "ltr", "ltrs",
    "hr", "hrs", "hour", "hours", "day", "days", "week", "weeks",
    "%", "percent", "allow", "lot", "sum", "ps", "pc sum",
}


def normalize_boq_unit_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    # Normalise common superscript/unit formatting but do not alter the workbook cell value.
    cleaned = text.lower().replace("²", "2").replace("³", "3")
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = cleaned.strip(" .")
    replacements = {
        "m 2": "m2", "m^2": "m2", "m²": "m2", "sq m": "sq m",
        "m 3": "m3", "m^3": "m3", "m³": "m3", "cu m": "cu m",
        "no": "no", "no.": "no", "nos": "nos",
    }
    return replacements.get(cleaned, cleaned)


def is_boq_unit_marker(value: Any) -> bool:
    cleaned = normalize_boq_unit_text(value)
    if not cleaned:
        return False
    if cleaned in {normalize_boq_unit_text(x) for x in BOQ_UNIT_MARKERS}:
        return True
    # Allow common compound units or variants without accidentally matching descriptions.
    if re.fullmatch(r"(m2|m3|m|lm|mm|kg|t|hr|hrs|day|days|no|nos|item|items|ea|set|sets|pair|pairs)(/| per )[a-z0-9]+", cleaned):
        return True
    return False


def detect_boq_unit_marker(row: Any, preferred_cols: Optional[List[int]] = None) -> str:
    """Detect BOQ item/unit rows.

    v3.15: preferred_cols comes from smart column detection, so Unit/Row Type
    can move by client. It still falls back to old D/C behavior and short
    isolated cells for older workbooks.
    """
    priority_cells = []
    if preferred_cols:
        for col in preferred_cols:
            try:
                if col and 1 <= int(col) <= len(row):
                    priority_cells.append(row[int(col) - 1])
            except Exception:
                pass
    # Backward-compatible fallback: Column D then C in Dhanrick's current files.
    if len(row) >= 4:
        priority_cells.append(row[3])
    if len(row) >= 3:
        priority_cells.append(row[2])

    seen = set()
    for cell in priority_cells:
        if id(cell) in seen:
            continue
        seen.add(id(cell))
        if is_boq_unit_marker(getattr(cell, "value", None)):
            return str(cell.value).strip()

    # Last-resort fallback: only very short cells to avoid matching words inside descriptions.
    for cell in row:
        value = getattr(cell, "value", None)
        if isinstance(value, str) and len(value.strip()) <= 18 and is_boq_unit_marker(value):
            return value.strip()
    return ""


def detect_row_type(row: Any, preferred_cols: Optional[List[int]] = None) -> str:
    def _classify(value: Any) -> str:
        if value is None:
            return ""
        text = str(value).strip().lower().replace(" ", "")
        if text in {"head1", "heading1", "h1"}:
            return "head1"
        if text in {"head2", "heading2", "h2"}:
            return "head2"
        if text in {"head3", "heading3", "h3"}:
            return "head3"
        if text in {"head4", "heading4", "h4"}:
            return "head4"
        if text in {"level", "lvl", "floor", "storey"}:
            return "level"
        if text in {"item", "items"}:
            return "item"
        if text in {"note", "notes"}:
            return "note"
        return ""

    if preferred_cols:
        for col in preferred_cols:
            try:
                if col and 1 <= int(col) <= len(row):
                    found = _classify(row[int(col) - 1].value)
                    if found:
                        return found
            except Exception:
                pass
    for cell in row:
        found = _classify(cell.value)
        if found:
            return found
    return ""


def is_boq_item_below_heading(row: Any, active_heading_context: str, desc_col_idx: int = 2) -> bool:
    """Return True for BOQ child/item rows under the current heading hierarchy.

    v3.16.4: use the detected description column, not hard-coded Column B.
    Once a Head1/Head2/Head3/Head4 row is found, any following row with a
    description in the detected description column is treated as an item row
    and italicised unless that row is another Head row.
    """
    if active_heading_context not in {"head1", "head2", "head3", "head4"}:
        return False
    if not desc_col_idx or len(row) < int(desc_col_idx):
        return False
    desc = getattr(row[int(desc_col_idx) - 1], "value", None)
    if desc is None:
        return False
    if isinstance(desc, str):
        text = desc.strip()
        if not text:
            return False
        if text.lower().replace(" ", "") in {"head1", "head2", "head3", "head4", "heading1", "heading2", "heading3", "heading4"}:
            return False
    return True


def looks_like_level_row(row: Any, desc_col_idx: int = 2) -> bool:
    desc = row[int(desc_col_idx) - 1].value if desc_col_idx and len(row) >= int(desc_col_idx) else None
    if not isinstance(desc, str) or not desc.strip():
        return False
    desc_l = desc.strip().lower()

    # Strong level/drawing-register patterns. These should stay as written so
    # drawing references such as MH-L0-001-03 are not converted to lowercase.
    if re.match(r"^(lower ground floor|upper ground floor|ground floor|basement|roof|mezzanine|level\s+\d+|lvl\s+\d+|gf\b|lg\b|ug\b)", desc_l):
        return True
    if re.search(r"\b[A-Za-z]{1,4}-[A-Za-z0-9]+-\d{3}", desc):
        return True

    level_words = ["level", "lvl", "ground", "basement", "mezzanine", "roof", "gf", "lg", "ug"]
    if not any(word in desc_l for word in level_words):
        return False
    non_empty_after_b = [cell.value for cell in row[2:] if cell.value not in (None, "")]
    return len(non_empty_after_b) <= 4



def is_note_row_marker(row: Any, row_type_cols: Optional[List[int]] = None, desc_col_idx: int = 2) -> bool:
    """Detect note rows so they stay italic but their project names/drawing refs are not recased."""
    check_cols = []
    if row_type_cols:
        check_cols.extend([int(c) for c in row_type_cols if c])
    check_cols.extend([4, 3])  # backward-compatible fallback only
    seen = set()
    for col in check_cols:
        if col in seen:
            continue
        seen.add(col)
        if len(row) >= col:
            value = getattr(row[col - 1], "value", None)
            if isinstance(value, str) and value.strip().lower() in {"note", "notes", "n/a", "na"}:
                return True
    desc = getattr(row[int(desc_col_idx) - 1], "value", None) if desc_col_idx and len(row) >= int(desc_col_idx) else None
    if isinstance(desc, str) and desc.strip().lower().startswith(("note:", "notes:")):
        return True
    return False


def should_sentence_case_item_row(row: Any, unit_marker: str = "", desc_col_idx: int = 2, row_type_cols: Optional[List[int]] = None) -> bool:
    """Apply item sentence case only to real BOQ item descriptions.

    - Item rows should be sentence case.
    - Level/drawing-reference rows should remain as originally written.
    - Note rows should remain as originally written because they often contain
      proper project names, drawing references and consultant names.
    """
    if looks_like_level_row(row, desc_col_idx):
        return False
    if is_note_row_marker(row, row_type_cols, desc_col_idx):
        return False
    return True


def smart_boq_head4_title(text: str) -> str:
    """Title-case BOQ Head4 descriptions without damaging QS/CostX terms.

    Examples preserved or repaired:
    - FRL, ESD, NCC, BCA, AS, NZS, NATSPEC, MDF, FC, CPD, NB
    - Rw35 / Rw 35, DnT,w, Ext/Dry, Dry/Wet, Wet/Wet, Ext/Void
    - CostX/wall tags: P4_F2, S6c_A1*, TH8f, P1S_A2
    - Units and numeric tokens: 13mm, 14kg/m3, 90mm, -/120/120
    """
    if not text:
        return text

    protected_upper = {
        "FRL", "ESD", "NCC", "BCA", "AS", "NZS", "NATSPEC", "MDF", "FC",
        "CPD", "PIR", "EPS", "SFS", "PFC", "RHS", "SHS", "CHS", "UB", "UC",
        "EA", "UA", "MS", "HDG", "PVDF", "PPE", "PCA", "DDA", "BAL", "NRC",
        "STC", "WIP", "BOQ", "RFI", "NB", "DB", "DBA", "COS", "UNO", "FFL",
    }
    protected_exact = {
        "rw": "Rw",
        "r'w": "R'w",
        "r’w": "R’w",
        "dnt,w": "DnT,w",
        "dntw": "DnT,w",
    }

    small_connectors = {"and", "or", "the", "a", "an", "of", "to", "in", "with", "for", "by", "at", "from"}

    def split_edge(token: str):
        prefix = ""
        suffix = ""
        while token and token[0] in "([{\"\'":
            prefix += token[0]
            token = token[1:]
        while token and token[-1] in ",.;:)]}\"\'":
            suffix = token[-1] + suffix
            token = token[:-1]
        return prefix, token, suffix

    def cap_word(word: str, index: int) -> str:
        if not word:
            return word
        low = word.lower()
        if low in protected_exact:
            return protected_exact[low]
        if low in small_connectors:
            # User prefers BOQ terms started capital. Keep connectors capitalized inside Head4 too.
            return word[:1].upper() + word[1:].lower()
        return word[:1].upper() + word[1:].lower()

    def repair_slash_token(core: str) -> str:
        parts = core.split("/")
        fixed = []
        for part in parts:
            lower = part.lower()
            if lower in {"m2", "m3", "m²", "m³", "mm", "kg", "kgm3", "m2k"}:
                fixed.append(lower)
            elif lower in {"ext", "dry", "wet", "void", "int", "ex", "in"}:
                fixed.append(part[:1].upper() + part[1:].lower())
            elif part.upper() in protected_upper:
                fixed.append(part.upper())
            elif re.search(r"\d", part):
                fixed.append(repair_rating_or_numeric_token(part))
            else:
                fixed.append(part[:1].upper() + part[1:].lower() if part else part)
        return "/".join(fixed)

    def repair_code_part(part: str) -> str:
        if not part:
            return part
        suffix = "*" if part.endswith("*") else ""
        base = part[:-1] if suffix else part
        lower = base.lower()
        # Common wall type codes from CostX / BOQ tags.
        if re.match(r"^th\d+[a-z]?$", lower):
            return "TH" + lower[2:] + suffix
        if re.match(r"^sp\d+[a-z]?$", lower):
            return "SP" + lower[2:] + suffix
        if re.match(r"^s\d+[a-z]?$", lower):
            return "S" + lower[1:] + suffix
        if re.match(r"^p\d+s$", lower):
            return "P" + lower[1:-1] + "S" + suffix
        if re.match(r"^p\d+[a-z]?$", lower):
            return "P" + lower[1:] + suffix
        if re.match(r"^[a-z]+\d+[a-z]*$", base):
            return base[:1].upper() + base[1:] + suffix
        if re.match(r"^[a-z]+\d+$", base):
            return base.upper() + suffix
        if re.match(r"^[a-z]\d+$", lower):
            return lower.upper() + suffix
        return base[:1].upper() + base[1:] + suffix

    def repair_code_token(core: str) -> str:
        return "_".join(repair_code_part(part) for part in core.split("_"))

    def repair_rating_or_numeric_token(core: str) -> str:
        # Acoustic ratings: rw35 / rw 35 => Rw35 / Rw 35; thermal: r2.0 => R2.0.
        lower_core = core.lower()
        if lower_core in {"m2", "m3", "m²", "m³", "mm", "kg", "m2k"}:
            return lower_core
        if re.match(r"^rw\d", core, flags=re.IGNORECASE):
            return "Rw" + core[2:]
        if re.match(r"^r\d", core, flags=re.IGNORECASE):
            return "R" + core[1:]
        # Standalone wall/finish tags such as TH8f, S6c, P12.
        if re.match(r"^[A-Za-z]{1,3}\d+[A-Za-z]*\*?$", core):
            return repair_code_part(core)
        return core

    fixed_tokens = []
    for idx, raw in enumerate(text.split(" ")):
        if raw == "":
            fixed_tokens.append(raw)
            continue
        prefix, core, suffix = split_edge(raw)
        if not core:
            fixed_tokens.append(raw)
            continue

        upper_core = core.upper()
        lower_core = core.lower()

        if lower_core in protected_exact:
            fixed_core = protected_exact[lower_core]
        elif upper_core in protected_upper:
            fixed_core = upper_core
        elif "/" in core:
            fixed_core = repair_slash_token(core)
        elif "_" in core or "*" in core:
            # Wall tags and CostX codes. Repair common lowercase/sentence-case damage.
            fixed_core = repair_code_token(core)
        elif re.search(r"\d", core):
            # Preserve units, dimensions, fire resistance numbers, etc., but repair common ratings.
            fixed_core = repair_rating_or_numeric_token(core)
        elif core.isupper() and len(core) <= 5:
            fixed_core = core
        else:
            fixed_core = cap_word(core, idx)

        fixed_tokens.append(prefix + fixed_core + suffix)

    # Repair common rating labels even if source was inconsistent.
    result = " ".join(fixed_tokens)
    replacements = {
        "Frl": "FRL",
        "Ncc": "NCC",
        "Bca": "BCA",
        "Esd": "ESD",
        "Nb:": "NB:",
        "Rw ": "Rw ",
        "Rw:": "Rw:",
    }
    for bad, good in replacements.items():
        result = result.replace(bad, good)
    result = apply_contextual_lower_mid_phrases(result)
    return result


def get_boq_case_dictionary(profile: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Return editable BOQ casing dictionary.

    Jarvis v3.0 learned the base rules from QS Workbook Formatter v6 and keeps
    the casing words in Settings so future project/client terms can be added
    without rewriting the formatter engine.

    v3.16.8 optimisation: during a formatter run this dictionary is precomputed
    once and stored in a ContextVar. Sentence casing can then reuse it for
    thousands of rows instead of repeatedly reading/merging JSON files.
    """
    if profile is None:
        cached = BOQ_CASE_CONTEXT.get()
        if isinstance(cached, dict):
            return cached
    defaults: Dict[str, Any] = {
        "protected_upper": [
            "FRL", "ESD", "NCC", "BCA", "AS", "NZS", "NATSPEC", "MDF", "FC", "CPD",
            "PIR", "EPS", "SFS", "PFC", "RHS", "SHS", "CHS", "UB", "UC", "EA", "UA",
            "MS", "HDG", "PVDF", "PPE", "PCA", "DDA", "BAL", "NRC", "STC", "WIP",
            "BOQ", "RFI", "MRI", "NB", "DB", "DBA", "COS", "UNO", "FFL", "GIB", "CSR", "USG",
        ],
        "protected_exact": {
            "rw": "Rw",
            "r'w": "R'w",
            "r’w": "R’w",
            "dnt,w": "DnT,w",
            "dntw": "DnT,w",
            "fyrchek": "Fyrchek",
            "gyprock": "Gyprock",
            "villaboard": "Villaboard",
            "aquachek": "AquaChek",
            "acoustigard": "Acoustigard",
            "earthwool": "Earthwool",
            "rondo": "Rondo",
            "autex": "Autex",
            "e-stud": "E-stud",
            "e-studs": "E-studs",
            "c-h stud": "C-H Stud",
            "c-h studs": "C-H Studs",
            "c stud": "C Stud",
            "c studs": "C Studs",
            "ch stud": "C-H Stud",
            "ch studs": "C-H Studs",
        },
        "proper_phrases": {
            "acoustic rating": "Acoustic Rating",
            "thermal rating": "Thermal Rating",
            "fire rating": "Fire Rating",
            "fire resistance level": "Fire Resistance Level",
            "impact rating": "Impact Rating",
            "sound insulation rating": "Sound Insulation Rating",
            "moisture resistant": "Moisture Resistant",
            "water resistant": "Water Resistant",
            "fire rated": "Fire Rated",
            "acoustically rated": "Acoustically Rated",
            "thermal rated": "Thermal Rated",
            # External/Internal are contextual. Headings are title-cased separately;
            # item descriptions keep them lower mid-sentence.
            "c-h studs": "C-H Studs",
            "c-h stud": "C-H Stud",
            "e-stud": "E-stud",
            "e-studs": "E-studs",
        },
        "lower_mid_phrases": [
            "non combustible",
            "non-combustible",
            "fire rated",
            "fire-rated",
            "external",
            "internal"
        ],
        "letter_based_terms": {
            "stud": "stud", "studs": "studs", "track": "track", "tracks": "tracks",
            "channel": "channel", "channels": "channels", "section": "section", "sections": "sections",
            "purlin": "purlin", "purlins": "purlins", "batten": "batten", "battens": "battens",
            "angle": "angle", "angles": "angles", "rail": "rail", "rails": "rails", "plate": "plate", "plates": "plates"
        },
        "slash_words": {
            "ext": "Ext", "int": "Int", "dry": "Dry", "wet": "Wet", "void": "Void",
            "external": "External", "internal": "Internal", "ex": "Ex", "in": "In",
        },
    }
    # v3.13: merge local QS term library before profile-level overrides.
    try:
        term_library = load_qs_term_library()
        defaults["protected_upper"] = _unique_list(list(defaults.get("protected_upper", [])) + list(term_library.get("all_caps_terms", [])))
        defaults["protected_exact"].update({str(k).lower(): str(v) for k, v in (term_library.get("exact_terms", {}) or {}).items()})
        defaults["proper_phrases"].update({str(k).lower(): str(v) for k, v in (term_library.get("proper_phrases", {}) or {}).items()})
        defaults["lower_mid_phrases"] = _unique_list(list(defaults.get("lower_mid_phrases", [])) + [str(x).lower() for x in term_library.get("contextual_lowercase_phrases", [])])
        defaults["slash_words"].update({str(k).lower(): str(v) for k, v in (term_library.get("slash_words", {}) or {}).items()})
        defaults["letter_based_terms"].update({str(k).lower(): str(v) for k, v in (term_library.get("letter_based_nouns", {}) or {}).items()})
    except Exception as exc:
        write_log("qs_term_library_merge_failed", {"error": str(exc)})
    profile = profile or FORMATTER_PROFILE_CONTEXT.get()
    cfg: Dict[str, Any] = {}
    if isinstance(profile, dict) and isinstance(profile.get("casing"), dict):
        cfg = profile.get("casing", {})
    else:
        cfg = read_json("boq_case_dictionary.json", {})
    if not isinstance(cfg, dict) or cfg.get("error"):
        return defaults

    merged = dict(defaults)
    if isinstance(cfg.get("protected_upper"), list):
        merged["protected_upper"] = sorted(set(defaults["protected_upper"] + [str(x).strip() for x in cfg["protected_upper"] if str(x).strip()]))
    if isinstance(cfg.get("protected_exact"), dict):
        merged_exact = dict(defaults["protected_exact"])
        merged_exact.update({str(k).lower(): str(v) for k, v in cfg["protected_exact"].items() if str(k).strip()})
        merged["protected_exact"] = merged_exact
    if isinstance(cfg.get("proper_phrases"), dict):
        merged_phrases = dict(defaults["proper_phrases"])
        merged_phrases.update({str(k).lower(): str(v) for k, v in cfg["proper_phrases"].items() if str(k).strip()})
        merged["proper_phrases"] = merged_phrases
    if isinstance(cfg.get("slash_words"), dict):
        merged_slash = dict(defaults["slash_words"])
        merged_slash.update({str(k).lower(): str(v) for k, v in cfg["slash_words"].items() if str(k).strip()})
        merged["slash_words"] = merged_slash
    if isinstance(cfg.get("lower_mid_phrases"), list):
        merged["lower_mid_phrases"] = sorted(set(defaults.get("lower_mid_phrases", []) + [str(x).strip().lower() for x in cfg["lower_mid_phrases"] if str(x).strip()]))
    if isinstance(cfg.get("letter_based_terms"), dict):
        merged_letter = dict(defaults.get("letter_based_terms", {}))
        merged_letter.update({str(k).lower(): str(v) for k, v in cfg["letter_based_terms"].items() if str(k).strip()})
        merged["letter_based_terms"] = merged_letter

    # v3.10: contextual lowercase rules must win over the default/proper phrase dictionary.
    # Without this, defaults like fire rated => Fire Rated or external wall => External Wall
    # still override the user feedback during actual Excel formatting.
    contextual = {str(x).strip().lower() for x in merged.get("lower_mid_phrases", []) if str(x).strip()}
    conflict_keys = set()
    for phrase in contextual:
        conflict_keys.add(phrase)
        conflict_keys.add(phrase.replace("-", " "))
        conflict_keys.add(phrase.replace(" ", "-"))
    for bucket in ["protected_exact", "proper_phrases"]:
        mapping = merged.get(bucket, {})
        if isinstance(mapping, dict):
            for key in list(mapping.keys()):
                key_l = str(key).strip().lower()
                if key_l in conflict_keys:
                    mapping.pop(key, None)
                    continue
                # single-word contextual rules apply to longer phrases too.
                if ("external" in contextual and key_l.startswith("external ")) or ("internal" in contextual and key_l.startswith("internal ")):
                    mapping.pop(key, None)
    return merged


def repair_boq_code_part(part: str) -> str:
    if not part:
        return part
    suffix = "*" if part.endswith("*") else ""
    base = part[:-1] if suffix else part
    lower = base.lower()
    if re.match(r"^th\d+[a-z]?$", lower):
        return "TH" + lower[2:] + suffix
    if re.match(r"^sp\d+[a-z]?$", lower):
        return "SP" + lower[2:] + suffix
    if re.match(r"^sh\d+[a-z]?$", lower):
        return "SH" + lower[2:] + suffix
    if re.match(r"^s\d+[a-z]?$", lower):
        return "S" + lower[1:] + suffix
    if re.match(r"^p\d+s$", lower):
        return "P" + lower[1:-1] + "S" + suffix
    if re.match(r"^p\d+[a-z]?$", lower):
        return "P" + lower[1:] + suffix
    if re.match(r"^[a-z]\d+[a-z]?$", lower):
        return lower[:1].upper() + lower[1:] + suffix
    if re.match(r"^[a-z]{2,4}\d+[a-z]?$", lower):
        return lower[:1].upper() + lower[1:] + suffix
    if re.match(r"^[a-z]+\d+$", base):
        return base.upper() + suffix
    return base[:1].upper() + base[1:] + suffix


def repair_boq_code_token(token: str) -> str:
    return "_".join(repair_boq_code_part(part) for part in token.split("_"))


def apply_contextual_lower_mid_phrases(text: str, cfg: Optional[Dict[str, Any]] = None) -> str:
    """Apply QS contextual lowercase phrases after normal casing repair."""
    if not isinstance(text, str) or not text:
        return text
    if cfg is None:
        cfg = get_boq_case_dictionary()
    phrases = [str(x).lower() for x in (cfg.get("lower_mid_phrases", []) if isinstance(cfg, dict) else []) if str(x).strip()]
    if not phrases:
        return text
    s = text
    for phrase in sorted(set(phrases), key=len, reverse=True):
        canonical_lower = phrase.lower()
        if " " in canonical_lower:
            pattern = r"\b" + r"\s+".join(re.escape(p) for p in canonical_lower.split()) + r"\b"
        else:
            pattern = rf"\b{re.escape(canonical_lower)}\b"
        def _repl(match: re.Match[str]) -> str:
            before = s[:match.start()]
            is_clause_start = before.strip() == "" or bool(re.search(r"(?:^|[.!?]\s*)$", before))
            if canonical_lower.startswith("non-"):
                return "Non-combustible" if is_clause_start else "non-combustible"
            if is_clause_start:
                return canonical_lower[:1].upper() + canonical_lower[1:]
            return canonical_lower
        s = re.sub(pattern, _repl, s, flags=re.IGNORECASE)
    return s


def apply_boq_protected_terms(text: str) -> str:
    cfg = get_boq_case_dictionary()
    protected_upper = {str(x).upper() for x in cfg.get("protected_upper", [])}
    protected_exact = {str(k).lower(): str(v) for k, v in cfg.get("protected_exact", {}).items()}
    proper_phrases = {str(k).lower(): str(v) for k, v in cfg.get("proper_phrases", {}).items()}
    slash_words = {str(k).lower(): str(v) for k, v in cfg.get("slash_words", {}).items()}
    lower_mid_phrases = [str(x).lower() for x in cfg.get("lower_mid_phrases", []) if str(x).strip()]
    letter_based_terms = {str(k).lower(): str(v) for k, v in cfg.get("letter_based_terms", {}).items()}

    runtime = cfg.get("_compiled_runtime")
    if not isinstance(runtime, dict):
        runtime = {
            "protected_exact": [(re.compile(rf"\b{re.escape(str(k))}\b", re.IGNORECASE), str(v)) for k, v in sorted(protected_exact.items(), key=lambda x: len(x[0]), reverse=True)],
            "proper_phrases": [(re.compile(rf"\b{re.escape(str(k))}\b", re.IGNORECASE), str(v)) for k, v in sorted(proper_phrases.items(), key=lambda x: len(x[0]), reverse=True)],
            "lower_mid": [(re.compile(rf"\b{re.escape(str(x))}\b", re.IGNORECASE), str(x).lower()) for x in sorted(lower_mid_phrases, key=len, reverse=True) if str(x).strip()],
            "protected_upper": [(re.compile(rf"\b{re.escape(str(x))}\b", re.IGNORECASE), str(x).upper()) for x in sorted(protected_upper, key=len, reverse=True) if str(x).strip()],
        }
        try:
            cfg["_compiled_runtime"] = runtime
        except Exception:
            pass

    s = text

    # Slash relationship terms: ext/dry -> Ext/Dry, dry/wet -> Dry/Wet.
    def slash_repl(match: re.Match[str]) -> str:
        left = match.group(1).lower()
        right = match.group(2).lower()
        return f"{slash_words.get(left, left.title())}/{slash_words.get(right, right.title())}"

    slash_keys = "|".join(sorted(map(re.escape, slash_words.keys()), key=len, reverse=True))
    if slash_keys:
        s = re.sub(rf"\b({slash_keys})\s*/\s*({slash_keys})\b", slash_repl, s, flags=re.IGNORECASE)

    # CostX/wall tags with underscores: s6c_f2_a2* -> S6c_F2_A2*
    s = re.sub(r"\b[a-z]+\d+[a-z]*(?:_[a-z]+\d+[a-z]*\*?)+\b", lambda m: repair_boq_code_token(m.group(0)), s, flags=re.IGNORECASE)

    # Standalone tag-like tokens: th8f, s6c, p1s, p4, sh2, x1, t4.
    s = re.sub(r"\b(th\d+[a-z]?|sh\d+[a-z]?|s\d+[a-z]?|p\d+s|p\d+[a-z]?|x\d+[a-z]?|t\d+[a-z]?|a\d+\*?|f\d+[a-z]?|r\d+(?:\.\d+)?)\b", lambda m: repair_boq_code_part(m.group(0)), s, flags=re.IGNORECASE)

    # Letter-based construction/profile terms from feedback, e.g. e-stud -> E-stud,
    # c-h studs -> C-H Studs, z-purlins -> Z-purlins. This is contextual: it only
    # repairs letter/code + known construction noun patterns, not every hyphenated word.
    if letter_based_terms:
        nouns = "|".join(sorted(map(re.escape, letter_based_terms.keys()), key=len, reverse=True))
        def _letter_space_repl(m: re.Match[str]) -> str:
            code = "-".join(part.upper() for part in re.split(r"\s*-\s*", m.group(1)))
            noun_key = m.group(2).lower()
            noun = str(letter_based_terms.get(noun_key, noun_key))
            return f"{code} {noun.title()}"
        def _letter_hyphen_repl(m: re.Match[str]) -> str:
            code = "-".join(part.upper() for part in re.split(r"\s*-\s*", m.group(1)))
            noun_key = m.group(2).lower()
            noun = str(letter_based_terms.get(noun_key, noun_key))
            return f"{code}-{noun.lower()}"
        s = re.sub(rf"\b([a-z](?:\s*-\s*[a-z]){{0,2}})\s+({nouns})\b", _letter_space_repl, s, flags=re.IGNORECASE)
        s = re.sub(rf"\b([a-z](?:\s*-\s*[a-z]){{0,2}})\s*-\s*({nouns})\b", _letter_hyphen_repl, s, flags=re.IGNORECASE)

    # Acoustic/thermal ratings: rw35 -> Rw35, rw 35 -> Rw 35, r:1.0 -> R:1.0.
    s = re.sub(r"\brw\s*(\d+)", lambda m: "Rw" + m.group(1), s, flags=re.IGNORECASE)
    s = re.sub(r"\br\s*:?\s*(\d+(?:\.\d+)?)", lambda m: "R" + m.group(1), s, flags=re.IGNORECASE)

    # Exact words/brands and mixed-case abbreviations.
    for pattern, val in runtime.get("protected_exact", []):
        s = pattern.sub(val, s)

    # Phrases that the BOQ normally keeps started capital.
    for pattern, val in runtime.get("proper_phrases", []):
        s = pattern.sub(val, s)

    # Contextual lowercase phrases: keep lower/mid-sentence but sentence-case if the clause starts with it.
    # Examples:
    #   "2x13mm thick fire rated plasterboard" stays lower in the middle.
    #   "Fire rated plasterboard" keeps only the first word capitalised at sentence start.
    #   "non combustible lining" stays lower mid-sentence, but "Non combustible..." at sentence start.
    for pattern, canonical_lower in runtime.get("lower_mid", []):
        def _lower_mid_repl(match: re.Match[str]) -> str:
            start = match.start()
            before = s[:start]
            is_clause_start = before.strip() == "" or bool(re.search(r"(?:^|[.!?]\s*)$", before))
            if canonical_lower.startswith("non-"):
                return "Non-combustible" if is_clause_start else "non-combustible"
            if is_clause_start:
                return canonical_lower[:1].upper() + canonical_lower[1:]
            return canonical_lower
        s = pattern.sub(_lower_mid_repl, s)

    # Ensure contextual lowercase rules win even if older exact/proper terms were saved.
    s = apply_contextual_lower_mid_phrases(s, cfg)

    # Upper-case acronyms.
    for pattern, term in runtime.get("protected_upper", []):
        s = pattern.sub(term, s)

    # Common punctuation/label cleanup.
    s = re.sub(r"\bFRL\s*:\s*", "FRL: ", s, flags=re.IGNORECASE)
    s = re.sub(r"\bAcoustic Rating\s*:\s*", "Acoustic Rating: ", s, flags=re.IGNORECASE)
    s = re.sub(r"\bThermal Rating\s*:\s*", "Thermal Rating: ", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNB\s*:\s*", "NB: ", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNo\s+details\b", "No details", s, flags=re.IGNORECASE)

    # Preserve dimension/unit notation after sentence casing.
    # Avoid turning 1x13mm / 2x16mm into tag-style 1X13mm.
    s = re.sub(r"(?<=\d)X(?=\d)", "x", s)
    s = re.sub(r"m2\.k/w", "m2.K/W", s, flags=re.IGNORECASE)
    s = re.sub(r"m3\.k/w", "m3.K/W", s, flags=re.IGNORECASE)
    s = re.sub(r"m²\.k/w", "m2.K/W", s, flags=re.IGNORECASE)
    s = re.sub(r"\bkg/m3\b", "kg/m3", s, flags=re.IGNORECASE)
    return s


def sentence_case_fragment(fragment: str, force_capital: bool = True) -> str:
    if not fragment:
        return fragment
    # Lowercase prose, then restore BOQ codes/acronyms/brand terms.
    s = fragment.lower()
    if force_capital:
        # If the clause starts with a numeric dimension/unit (e.g. 2x13mm or 25mm),
        # keep the unit lowercase. Otherwise, capitalise the first word.
        starts_with_dimension = bool(re.match(r"^\d+(?:\.\d+)?(?:x\d+(?:\.\d+)?)?[a-z/0-9.²³]*\b", s, flags=re.IGNORECASE))
        if not starts_with_dimension:
            m = re.search(r"[A-Za-z]", s)
            if m:
                idx = m.start()
                s = s[:idx] + s[idx].upper() + s[idx + 1:]
    s = apply_boq_protected_terms(s)
    return s


def smart_boq_item_sentence_case(text: str) -> str:
    """Smart sentence case for BOQ item / level rows.

    This is the v2.10 improvement learned from Formatter v6 plus Dhanrick's rule:
    non-heading item descriptions should not only be italic; their Description
    text should also be sentence case while preserving QS terms, wall tags and
    common BOQ separators such as "S6c_F2 - ..." and semicolons.
    """
    if not isinstance(text, str):
        return text
    original = text.strip()
    if not original:
        return original

    # Normalise BOQ separators without touching fire ratings like -/120/120.
    s = re.sub(r"\s+", " ", original)
    s = re.sub(r"\s*;\s*", "; ", s).strip()
    s = re.sub(r"\s+[–—-]\s+", " - ", s)

    # Semicolon-separated BOQ clauses are sentence-cased as separate clauses:
    # "...; acoustic rating rw35; thermal rating r1.4".
    pieces = re.split(r"(;\s*)", s)
    rebuilt = []
    for piece in pieces:
        if piece.startswith(";"):
            rebuilt.append(piece)
            continue
        if not piece:
            continue

        # Preserve/rebuild common leading code + dash structure:
        # "S6c_F2 - 1x13mm ..." and "Ext/Dry - S6c_F2 - ...".
        dash_parts = piece.split(" - ")
        if len(dash_parts) > 1:
            fixed_dash_parts = []
            for idx, part in enumerate(dash_parts):
                stripped = part.strip()
                # First one or two dash prefixes are often relationship/tag codes.
                if idx < len(dash_parts) - 1 and re.fullmatch(r"[A-Za-z0-9_/*.+ ]{1,45}", stripped or ""):
                    fixed_dash_parts.append(apply_boq_protected_terms(stripped.lower()))
                else:
                    fixed_dash_parts.append(sentence_case_fragment(stripped, force_capital=True))
            rebuilt.append(" - ".join(fixed_dash_parts))
        else:
            rebuilt.append(sentence_case_fragment(piece.strip(), force_capital=True))

    result = "".join(rebuilt)
    result = re.sub(r"\s+([,.;:])", r"\1", result)
    result = re.sub(r";\s*", "; ", result).strip()
    return result


def smart_heading_title_case(text: str) -> str:
    """QS heading title case for Head2/Head3 and similar heading rows.

    This fixes the old Excel-style Title Case problem:
        "Installation Of Metal Door Frame To Internal Solid Core Door"
    becomes:
        "Installation of Metal Door Frame to Internal Solid Core Door"

    Minor connecting words stay lower-case unless they begin the heading, while
    QS acronyms, exact terms, codes, relationship tags, and learned all-caps
    terms are preserved.
    """
    if not isinstance(text, str):
        return text
    s = re.sub(r"\s+", " ", text.strip())
    if not s:
        return s

    minor_words = {
        "a", "an", "and", "as", "at", "but", "by", "for", "from", "if", "in",
        "into", "nor", "of", "on", "or", "per", "the", "to", "via", "vs", "with",
        "without", "within", "onto", "over", "under", "up", "off"
    }

    cfg = get_boq_case_dictionary()
    try:
        lib = load_qs_term_library()
        minor_words.update({str(x).lower() for x in lib.get("heading_connector_words", []) if str(x).strip()})
    except Exception:
        pass
    protected_upper = set(cfg.get("protected_upper", []))
    protected_exact = dict(cfg.get("protected_exact", {}))
    slash_words = dict(cfg.get("slash_words", {}))

    tokens = s.split(" ")
    out = []
    for idx, token in enumerate(tokens):
        if token == "":
            out.append(token)
            continue
        m = re.match(r"^([^A-Za-z0-9]*)(.*?)([^A-Za-z0-9]*)$", token)
        if not m:
            out.append(token)
            continue
        lead, core, trail = m.groups()
        if not core:
            out.append(token)
            continue

        core_lower = core.lower()

        # Keep BOQ/COSTX-style codes and relationship tags stable.
        if any(ch.isdigit() for ch in core) or any(ch in core for ch in ["/", "_"]):
            fixed = core
        elif idx > 0 and core_lower in minor_words:
            fixed = core_lower
        else:
            # Title case normal words. For hyphenated words, title each component
            # unless the exact term dictionary later restores a custom case.
            if "-" in core:
                fixed = "-".join(part[:1].upper() + part[1:].lower() if part else part for part in core.split("-"))
            else:
                fixed = core[:1].upper() + core[1:].lower()
        out.append(f"{lead}{fixed}{trail}")

    s = " ".join(out)

    # Restore learned exact terms such as Ext/Dry, E-stud, C-H Studs.
    for key, val in sorted(protected_exact.items(), key=lambda x: len(x[0]), reverse=True):
        s = re.sub(rf"\b{re.escape(key)}\b", val, s, flags=re.IGNORECASE)

    # Restore slash relationship words when written as ext/dry, dry/wet, etc.
    def _slash_repl(m: re.Match[str]) -> str:
        left = m.group(1).lower()
        right = m.group(2).lower()
        return f"{slash_words.get(left, left.title())}/{slash_words.get(right, right.title())}"
    s = re.sub(r"\b([a-z]{2,12})/([a-z]{2,12})\b", _slash_repl, s, flags=re.IGNORECASE)

    # Restore all-caps learned acronyms such as MRI, FRL, ESD, HVAC.
    for term in sorted(protected_upper, key=len, reverse=True):
        s = re.sub(rf"\b{re.escape(term)}\b", term, s, flags=re.IGNORECASE)

    # Common QS labels that should remain title-style in headings.
    s = re.sub(r"\bFire Rated\b", "Fire Rated", s, flags=re.IGNORECASE)
    s = re.sub(r"\bAcoustic Rating\b", "Acoustic Rating", s, flags=re.IGNORECASE)
    s = re.sub(r"\bThermal Rating\b", "Thermal Rating", s, flags=re.IGNORECASE)
    return s


def smart_title(text: str) -> str:
    # Backward-compatible name used by the formatter engine.
    return smart_heading_title_case(text)


if __name__ == "__main__":
    settings = read_json("settings.json", {})
    uvicorn.run("app:app", host=settings.get("host", "127.0.0.1"), port=int(settings.get("port", 8505)), reload=True)

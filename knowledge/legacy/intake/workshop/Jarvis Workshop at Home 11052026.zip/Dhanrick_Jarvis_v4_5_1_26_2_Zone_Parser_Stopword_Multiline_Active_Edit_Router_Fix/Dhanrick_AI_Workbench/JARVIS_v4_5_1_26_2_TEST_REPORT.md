# Jarvis v4.5.1.26.2 Test Report

## Version
Jarvis v4.5.1.26.2 — Zone Parser Stopword + Multiline Active Edit Router Fix

## Static validation
- `python3 -m py_compile app.py` — PASS
- `node --check static/assets/app.js` — PASS
- App import / `APP_VERSION` read — PASS

## Targeted backend tests

### 1. Zone parser stopword test
Input:

```text
Zone 1: Old and New
Zone 2: External and Internal
Use Head 2 for Zone 1 and Head 3 for Zone 2
```

Result:

```text
Zone 1: Old, New
Zone 2: External, Internal
```

Status: PASS

Confirmed no `Internal Use` value was produced.

### 2. Full Wall Types parser scenario
Input:

```text
Wall Types
Zone 1: Old and New
Zone 2: External and Internal
Use Head 2 for Zone 1 and Head 3 for Zone 2
Levels are from GF to Level 11 with Level 11 Mezzanine
Preview
Export
```

Result:

```text
Zone 1 / Head2: Old, New
Zone 2 / Head3: External, Internal
Levels: GF, L1-L11, L11 Mezzanine
No Internal Use
```

Status: PASS

### 3. Replace clarification test
Input:

```text
Change Zone 1: Old to Toad
Confirm replace Zone 1: Old with Toad
Review
```

Result:

```text
Zone 1: Toad, New
Old removed
Toad present
Message: Replaced Zone 1: Old with Toad.
```

Status: PASS

### 4. Multiline active Builder edit test
Input:

```text
Use Count
Unit no
```

Result:

```text
is_active_builder_plan_amendment = True
Route = builder_command_router
Function = XGETCOUNT
Unit = no
No Local AI fallback
```

Status: PASS

### 5. Narrow same-line active edit fallback
Inputs tested:

```text
use count unit no
use xgetcount unit no
use steel surface area unit m2
```

Result:

```text
use count unit no -> XGETCOUNT / no
use xgetcount unit no -> XGETCOUNT / no
use steel surface area unit m2 -> XGETCUSTOM / Steel Surface Area / m2
```

Status: PASS

## Synthetic workbook smoke tests
Because the user's real Windows Test.xlsx / Test A files were not included in the uploaded ZIPs, temporary synthetic workbooks were generated and removed after testing.

### 6. Synthetic Wall Types preview/export smoke
Workbook:

```text
Synthetic_Walls.xlsx with 2 XGETWALLAREA entries
```

Result:

```text
Preview status: ok
Formula Integrity Guard: PASS
Generated formula rows: 104
Project hierarchy guard: PASS
Zone token decision: PASS
No Internal Use
```

Status: PASS

### 7. Synthetic Doors/Windows source-preserve count preview/export smoke
Workbook:

```text
Synthetic_Windows_Test.xlsx with 4 XGETCOUNT source-zone formulas on GF and L1
```

Result:

```text
Function: XGETCOUNT
Unit: no
Source-preserve count mode: True
Editable levels: 2
Generated formula rows: 4
Formula guard: PASS
No invented L2/L3/L4 rows in synthetic source-preserve flow
```

Status: PASS

## Regression checklist
- Zone parser stopword / `Internal Use` bug — PASS
- Replace clarification applies and says what changed — PASS
- Multiline `Use Count` + `Unit no` stays in Builder — PASS
- Same-line count/unit aliases stay narrow — PASS
- Structural Steel / Steel Surface Area / m2 active edit support — PASS at router/plan level
- Formula Integrity Guard — PASS on synthetic Wall Types and Doors/Windows export smoke
- State shadow export hook still present — PASS by source/static review
- `state_shadow_snapshot.json` support-log inclusion path still present — PASS by source/static review
- User action rows remain bound to active conversation — PASS by v26.1 carried-forward source/static review
- Support-log leak route not modified by v26.2 — PASS by source/static review

## Not fully tested in this container
These require the user's real workbooks and local running Jarvis:

```text
Windows Test.xlsx real export
Old Test A real export
Real Doors/Windows GF/L1 only verification
Real Mezz forward/reverse regression
Real debug ZIP conversation_id_split_detected = false
Real support-log leak regression after browser actions
```

## Safety confirmation
Builder formula/export engine was not touched. CostX formula generation, Formula Integrity Guard core logic, Doors/Windows source-preserve row generation, Wall/Steel output logic, Mezz alias guard, Output Center, Formatter, and QA Checker were not changed.

## Local test instruction
Before testing v26.2, close all old Jarvis CMD/windows and browser tabs that may still be connected to old v25/v26/v26.1 processes. Then start with `START_JARVIS_v4_5_1_26_2.bat`.

@echo off
cd /d %~dp0
echo Starting Jarvis v4.5.1.26.2...
echo Close all old Jarvis CMD/windows before running this version.
python app.py
pause

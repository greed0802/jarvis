# Known Issues

Resolved in v25: Doors/Windows source-preserve count preview/export should no
longer cross-join source formulas with stale workspace levels.

Deferred: transcript entries for button actions such as Approve & Preview.


## v4.5.1.26 status
- Button actions are now recorded as visible transcript rows for major workflow actions.
- State Kernel shadow snapshots are diagnostic only and are not the source of truth yet.
- Future migration should compare shadow state against current app.py runtime before replacing any active state logic.

## v4.5.1.26.1 cleanup
Resolved in this candidate:
- Action transcript rows are now bound to the active Builder conversation when available.
- replace_target_unclear confirmation replies now apply or cancel instead of looping.
- Multiline active short edits such as `Use Count` + `Unit no` are supported.
- Source-preserve Level_Zone_Setup Working Combo label is cleaned.

## v4.5.1.26.2 cleanup
Resolved in this candidate:
- Zone parser now stops before instruction-line boundaries such as newline + `Use Head`, `Start at Head`, `Levels`, `Preview`, and `Review`.
- Zone values such as `Mixed Use` remain valid because the patch does not globally strip the word `Use` from values.
- Multiline active Builder edits now pass the raw prompt into the count/unit confirmation guard, so `Use Count` + `Unit no` stays in Builder context.
- Narrow same-line active Builder aliases are supported only inside active Builder context: `use count unit no`, `use xgetcount unit no`, and `use steel surface area unit m2`.
- Replace clarification replies now surface the explicit success message, e.g. `Replaced Zone 1: Old with Toad.`

Still deferred:
- Full persistent State Kernel source-of-truth migration.
- Broader UI redesign.
- Full real-workbook regression on the user's Windows Test.xlsx/Test A files must be run on the user's laptop because those workbooks were not included in this ZIP set.

# Jarvis v4.5.1.26.1 Change Report

## Version
v4.5.1.26.1 — Action Transcript Binding + Clarification Resolution + Multiline Active Edits

## Base
v4.5.1.25 accepted base, with v4.5.1.26 shadow/action logging carried forward and patched.

## Files changed
- app.py
- static/assets/app.js
- static/index.html
- START_JARVIS_v4_5_1_26_1.bat
- START_JARVIS_v4_5_1_26_1_SIMPLE_NO_VENV.bat
- JARVIS_v4_5_1_26_1_CHANGE_REPORT.md
- JARVIS_v4_5_1_26_1_TEST_REPORT.md

## Fixes
1. Bound action transcript events to the active Builder conversation when available.
2. Added split-detection metadata for action transcript events.
3. Added explicit replace_target_unclear clarification resolution for Confirm replace / Add / Cancel.
4. Added multiline active Builder short edits such as Use Count + Unit no in one message.
5. Cleaned Level_Zone_Setup Working Combo label for source-preserve count mode.

## Protected logic
- Builder formula/export engine core
- CostX formula generation
- Formula Integrity Guard core logic
- Doors/Windows source-preserve row generation
- Wall/Steel rebuild output logic
- Mezz alias guard
- Multiline zone parser
- Formatter / QA Checker / Output Center engine

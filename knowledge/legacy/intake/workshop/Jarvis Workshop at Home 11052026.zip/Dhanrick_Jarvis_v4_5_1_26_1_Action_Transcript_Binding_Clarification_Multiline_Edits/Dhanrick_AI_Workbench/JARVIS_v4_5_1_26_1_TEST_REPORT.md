# Jarvis v4.5.1.26.1 Test Report

## Static checks
- python3 -m py_compile app.py: PASS
- node --check static/assets/app.js: PASS
- Import app.py / APP_VERSION read: PASS

## Targeted backend checks
- Multiline short active edit `Use Count\nUnit no`: PASS
- Apply count/unit multiline update to active plan: PASS
- `Confirm replace Zone 1: Old with Toad` resolves replace_target_unclear: PASS
- Cancel replacement clarification: PASS

## Expected regression tests for user
1. Variety test with action buttons: transcript should stay in one conversation and include User action rows.
2. Replace clarification test: Zone 1 Old -> Toad should apply after confirmation.
3. Windows source-preserve test: 12 formulas, GF/L1 only, no L2/L3/L4 invention.
4. Wall/Steel regression: 1,976 formulas, Mezz forward/reverse still passes.

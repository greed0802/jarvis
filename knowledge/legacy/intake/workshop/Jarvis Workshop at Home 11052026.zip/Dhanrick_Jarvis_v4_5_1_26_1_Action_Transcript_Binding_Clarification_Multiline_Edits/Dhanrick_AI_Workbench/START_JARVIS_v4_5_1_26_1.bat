@echo off
cd /d %~dp0
echo Starting Jarvis v4.5.1.26.1...
python app.py
pause

# Jarvis v4.5.1.26 — State Kernel Shadow Mode + Action Transcript Logging

## Base
v4.5.1.25 — Framework Scaffold + Doors/Windows Source-Preserve Guard

## Scope
Traceability/state-safety build only. The working app.py runtime remains the source of truth.

## Files changed
- app.py
- static/assets/app.js
- static/index.html
- jarvis/core/state_kernel.py
- jarvis/schemas/active_task_schema.py
- jarvis/schemas/builder_snapshot_schema.py
- jarvis/debug/router_trace.py
- docs/KNOWN_ISSUES.md
- START_JARVIS_v4_5_1_26.bat
- START_JARVIS_v4_5_1_26_SIMPLE_NO_VENV.bat

## Changes
1. Added diagnostic State Kernel shadow snapshots under `data/state_shadow/`.
2. Added debug export artifact `state_shadow_snapshot.json`.
3. Added major button-action transcript logging:
   - User action: Review setup
   - User action: Approve & Preview
   - User action: Export
   - User action: Use setup only
   - User action: Open Preview
4. Added client action metadata for Builder preview/export requests.
5. Cleaned source-preserve Doors/Windows report metadata:
   - Active level/zone preset: Source-preserve count rows
   - Active zone combo id: source_preserve_count_rows

## Protected / not touched
- Builder formula/export engine core
- CostX formula string builder core
- Formula Integrity Guard core logic
- Mezz alias guard
- Multiline Zone parser
- Doors/Windows row generation logic
- Wall Types rebuild flow
- Structural Steel rebuild flow
- Formatter
- QA Checker
- Output Center engine

## Notes
State shadow mode is diagnostic only. It mirrors current runtime state and must not be used as the runtime source of truth yet.

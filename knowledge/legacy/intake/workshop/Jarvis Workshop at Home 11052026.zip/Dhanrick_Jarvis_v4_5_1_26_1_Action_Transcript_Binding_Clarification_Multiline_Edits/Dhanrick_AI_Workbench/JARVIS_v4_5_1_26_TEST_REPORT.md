# Jarvis v4.5.1.26 Test Report

## Static checks
- python3 -m py_compile app.py — PASS
- node --check static/assets/app.js — PASS
- import app and read APP_VERSION — PASS

## Targeted smoke checks
- State shadow snapshot writer — PASS
- Debug shadow payload reader — PASS
- Doors/Windows source-preserve preview with Windows Test.xlsx — PASS
  - safe_to_export: true
  - source_preserve_count_mode: true
  - active_combo_id: source_preserve_count_rows
  - active_level_zone_preset: Source-preserve count rows
  - preview rows: 12
  - groups: GF, L1
- Doors/Windows source-preserve export metadata — PASS
  - formulas: 12
  - GF formulas: 11
  - L1 formulas: 1
  - L2 formulas: 0
  - report active preset: Source-preserve count rows
  - report active combo id: source_preserve_count_rows

## Expected manual regression tests
1. Doors/Windows source-preserve flow with Windows Test.xlsx.
2. Wall Types → Structural Steel / Steel Surface Area / m2 flow.
3. Mezz alias forward and reverse.
4. Refresh/recovery flow.
5. Debug export should contain `state_shadow_snapshot.json`.
6. Conversation export should show User action rows for major button actions.

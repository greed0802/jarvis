# Known Issues

Resolved in v25: Doors/Windows source-preserve count preview/export should no
longer cross-join source formulas with stale workspace levels.

Deferred: transcript entries for button actions such as Approve & Preview.


## v4.5.1.26 status
- Button actions are now recorded as visible transcript rows for major workflow actions.
- State Kernel shadow snapshots are diagnostic only and are not the source of truth yet.
- Future migration should compare shadow state against current app.py runtime before replacing any active state logic.

## v4.5.1.26.1 cleanup
Resolved in this candidate:
- Action transcript rows are now bound to the active Builder conversation when available.
- replace_target_unclear confirmation replies now apply or cancel instead of looping.
- Multiline active short edits such as `Use Count` + `Unit no` are supported.
- Source-preserve Level_Zone_Setup Working Combo label is cleaned.

# Jarvis v4.5.1.24.2E Change Report

## Version
v4.5.1.24.2E — Export Chat Confirmation + Support Log Message Isolation

## Base
v4.5.1.24.2D — Mezz Alias Guard + Safe Export Gate + Multiline Zone Parser Fix

## Scope
UI/status cleanup only.

## Files changed
- `static/assets/app.js`
- `static/index.html`
- `app.py` version text only
- `START_JARVIS_v4_5_1_24_2E.bat`
- `START_JARVIS_v4_5_1_24_2E_SIMPLE_NO_VENV.bat`
- this report
- `JARVIS_v4_5_1_24_2E_TEST_REPORT.md`

## Fixes
1. Successful Builder export now appends a clear visible chat confirmation:
   - `Output ready.`
   - `Your BOQ base sheet has been exported.`
   - actions: Download output, Open Output Center, View details.
2. Support/debug log export no longer injects `Support log ready.` into the visible chat transcript. It remains a toast-only utility action.
3. Typed Review/Reviw no longer adds the extra generic `Builder setup ready.` message before `Review opened...`.

## Not touched
- Builder formula/export engine
- CostX formula generation
- Workbook export structure
- Formula Integrity Guard logic
- Zone parser logic
- Formatter
- QA Checker
- Output Center engine

## Rollback
Use v4.5.1.24.2D package if this UI cleanup causes unexpected chat behavior. The Builder output logic is unchanged from 2D.
